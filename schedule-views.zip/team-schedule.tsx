/**
 * Team Schedule Page - Thin wrapper that redirects to existing schedule
 * Follows "use what we have" pattern - reuses schedule-mobile-first
 */

import { Redirect } from "wouter";

export default function TeamSchedule() {
  return <Redirect to="/schedule?view=team" />;
}

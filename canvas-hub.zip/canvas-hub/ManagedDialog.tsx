"use client"

import * as React from "react"
import { useId, memo } from "react"
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog"
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetDescription,
} from "@/components/ui/sheet"
import { useManagedLayer } from "./LayerManager"
import { cn } from "@/lib/utils"
import { useIsMobile } from "@/hooks/use-mobile"

interface ManagedDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  children: React.ReactNode
  title?: string
  description?: string
  footer?: React.ReactNode
  size?: "sm" | "md" | "lg" | "xl" | "full"
  className?: string
  contentClassName?: string
}

export const ManagedDialog = memo(function ManagedDialog({
  open,
  onOpenChange,
  children,
  title,
  description,
  footer,
  size = "md",
  className,
  contentClassName,
}: ManagedDialogProps) {
  const autoId = useId()
  const dialogId = `dialog-${autoId}`
  
  const { zIndex } = useManagedLayer({
    id: dialogId,
    type: 'dialog',
    open,
    onOpenChange,
  })

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent 
        size={size}
        className={cn(contentClassName)}
        style={{ zIndex }}
      >
        {(title || description) && (
          <DialogHeader>
            {title && <DialogTitle>{title}</DialogTitle>}
            {description && <DialogDescription>{description}</DialogDescription>}
          </DialogHeader>
        )}
        <div className={className}>
          {children}
        </div>
        {footer && (
          <DialogFooter>
            {footer}
          </DialogFooter>
        )}
      </DialogContent>
    </Dialog>
  )
})

interface ManagedSheetProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  children: React.ReactNode
  side?: "left" | "right" | "top" | "bottom"
  title?: string
  description?: string
  className?: string
}

export const ManagedSheet = memo(function ManagedSheet({
  open,
  onOpenChange,
  children,
  side = "right",
  title,
  description,
  className,
}: ManagedSheetProps) {
  const autoId = useId()
  const sheetId = `sheet-${autoId}`
  
  const { zIndex } = useManagedLayer({
    id: sheetId,
    type: 'sheet',
    open,
    onOpenChange,
  })

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent side={side} className={className}>
        {(title || description) && (
          <SheetHeader>
            {title && <SheetTitle>{title}</SheetTitle>}
            {description && <SheetDescription>{description}</SheetDescription>}
          </SheetHeader>
        )}
        {children}
      </SheetContent>
    </Sheet>
  )
})

interface ResponsiveDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  children: React.ReactNode
  title?: React.ReactNode
  description?: string
  footer?: React.ReactNode
  size?: "sm" | "md" | "lg" | "xl" | "full"
  sheetSide?: "left" | "right" | "top" | "bottom"
  className?: string
  contentClassName?: string
}

export const ResponsiveDialog = memo(function ResponsiveDialog({
  open,
  onOpenChange,
  children,
  title,
  description,
  footer,
  size = "md",
  sheetSide = "bottom",
  className,
  contentClassName,
}: ResponsiveDialogProps) {
  const isMobile = useIsMobile()
  const autoId = useId()
  const layerId = `responsive-${autoId}`
  
  const { zIndex } = useManagedLayer({
    id: layerId,
    type: isMobile ? 'sheet' : 'dialog',
    open,
    onOpenChange,
  })

  if (isMobile) {
    return (
      <Sheet open={open} onOpenChange={onOpenChange}>
        <SheetContent side={sheetSide} className={cn("max-h-[90vh] overflow-y-auto", contentClassName)}>
          {(title || description) && (
            <SheetHeader>
              {title && <SheetTitle>{title}</SheetTitle>}
              {description && <SheetDescription>{description}</SheetDescription>}
            </SheetHeader>
          )}
          <div className={className}>
            {children}
          </div>
          {footer && (
            <div className="mt-4 flex justify-end gap-2">
              {footer}
            </div>
          )}
        </SheetContent>
      </Sheet>
    )
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent 
        size={size}
        className={cn("max-h-[90vh] overflow-y-auto", contentClassName)}
        style={{ zIndex }}
      >
        {(title || description) && (
          <DialogHeader>
            {title && <DialogTitle>{title}</DialogTitle>}
            {description && <DialogDescription>{description}</DialogDescription>}
          </DialogHeader>
        )}
        <div className={className}>
          {children}
        </div>
        {footer && (
          <DialogFooter>
            {footer}
          </DialogFooter>
        )}
      </DialogContent>
    </Dialog>
  )
})

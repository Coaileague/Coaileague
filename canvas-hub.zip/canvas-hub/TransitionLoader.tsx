"use client"

import * as React from "react"
import { createContext, useContext, useState, useCallback, useRef, useEffect, Suspense, lazy } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { cn } from "@/lib/utils"
import { useLayerManager } from "./LayerManager"

const TrinityRedesign = lazy(() => import('@/components/trinity-redesign'))

export type TransitionStatus = 'loading' | 'success' | 'error' | 'syncing'

export interface TransitionLoaderConfig {
  minDuration: number
  maxDuration: number
  exitDelay: number
}

const DEFAULT_CONFIG: TransitionLoaderConfig = {
  minDuration: 2500,
  maxDuration: 12000,
  exitDelay: 300,
}

interface TransitionState {
  isActive: boolean
  status: TransitionStatus
  progress: number
  title: string
  subtitle: string
  isLocked: boolean
}

interface TransitionLoaderContextValue {
  show: (options: { title?: string; subtitle?: string; status?: TransitionStatus }) => void
  hide: () => void
  setProgress: (progress: number) => void
  updateTitle: (title: string, subtitle?: string) => void
  complete: () => Promise<void>
  cancel: () => void
  lock: () => void
  unlock: () => void
  state: TransitionState
  config: TransitionLoaderConfig
}

const TransitionLoaderContext = createContext<TransitionLoaderContextValue | null>(null)

export function useTransitionLoader() {
  const context = useContext(TransitionLoaderContext)
  if (!context) {
    return {
      show: () => {},
      hide: () => {},
      setProgress: () => {},
      updateTitle: () => {},
      complete: () => Promise.resolve(),
      cancel: () => {},
      lock: () => {},
      unlock: () => {},
      state: { isActive: false, status: 'loading' as TransitionStatus, progress: 0, title: '', subtitle: '', isLocked: false },
      config: DEFAULT_CONFIG,
    }
  }
  return context
}

interface TransitionLoaderProviderProps {
  children: React.ReactNode
  config?: Partial<TransitionLoaderConfig>
}

export function TransitionLoaderProvider({ children, config: customConfig }: TransitionLoaderProviderProps) {
  const layerManager = useLayerManager()
  const config = { ...DEFAULT_CONFIG, ...customConfig }
  
  const [state, setState] = useState<TransitionState>({
    isActive: false,
    status: 'loading',
    progress: 0,
    title: 'Loading',
    subtitle: 'Please wait...',
    isLocked: false,
  })
  
  const startTimeRef = useRef<number>(0)
  const progressIntervalRef = useRef<NodeJS.Timeout | null>(null)
  const maxTimeoutRef = useRef<NodeJS.Timeout | null>(null)
  const resolveCompleteRef = useRef<(() => void) | null>(null)
  const progressRef = useRef<number>(0)
  
  // Keep progressRef in sync with state
  progressRef.current = state.progress

  const cleanupTimers = useCallback(() => {
    if (progressIntervalRef.current) {
      clearInterval(progressIntervalRef.current)
      progressIntervalRef.current = null
    }
    if (maxTimeoutRef.current) {
      clearTimeout(maxTimeoutRef.current)
      maxTimeoutRef.current = null
    }
  }, [])

  const show = useCallback((options: { title?: string; subtitle?: string; status?: TransitionStatus } = {}) => {
    cleanupTimers()
    startTimeRef.current = Date.now()
    
    setState({
      isActive: true,
      status: options.status || 'loading',
      progress: 0,
      title: options.title || 'Loading',
      subtitle: options.subtitle || 'Please wait...',
      isLocked: true,
    })
    
    layerManager.registerLayer({
      id: 'transition-loader',
      type: 'alert',
      priority: 1000,
      component: null,
    })
    
    const targetProgress = 85
    progressIntervalRef.current = setInterval(() => {
      setState(prev => {
        if (!prev.isActive) return prev
        const elapsed = Date.now() - startTimeRef.current
        const linearProgress = Math.min(elapsed / config.minDuration, 1)
        const easedProgress = easeOutCubic(linearProgress) * targetProgress
        const newProgress = Math.min(easedProgress, targetProgress)
        return { ...prev, progress: newProgress }
      })
    }, 100) // Optimized: 100ms interval for smoother CPU usage while maintaining visual quality
    
    maxTimeoutRef.current = setTimeout(() => {
      complete()
    }, config.maxDuration)
  }, [config, layerManager, cleanupTimers])

  const hide = useCallback(() => {
    if (state.isLocked) return
    
    cleanupTimers()
    layerManager.unregisterLayer('transition-loader')
    setState(prev => ({ ...prev, isActive: false, progress: 0, isLocked: false }))
  }, [state.isLocked, layerManager, cleanupTimers])

  const setProgress = useCallback((progress: number) => {
    setState(prev => ({ ...prev, progress: Math.max(prev.progress, progress) }))
  }, [])

  const updateTitle = useCallback((title: string, subtitle?: string) => {
    setState(prev => ({ 
      ...prev, 
      title, 
      subtitle: subtitle !== undefined ? subtitle : prev.subtitle 
    }))
  }, [])

  const lock = useCallback(() => {
    setState(prev => ({ ...prev, isLocked: true }))
  }, [])

  const unlock = useCallback(() => {
    setState(prev => ({ ...prev, isLocked: false }))
  }, [])

  const cancel = useCallback(() => {
    cleanupTimers()
    layerManager.unregisterLayer('transition-loader')
    setState(prev => ({ ...prev, isActive: false, isLocked: false, progress: 0 }))
    if (resolveCompleteRef.current) {
      resolveCompleteRef.current()
      resolveCompleteRef.current = null
    }
  }, [cleanupTimers, layerManager])

  const complete = useCallback((): Promise<void> => {
    return new Promise((resolve) => {
      cleanupTimers()
      resolveCompleteRef.current = resolve
      
      const elapsed = Date.now() - startTimeRef.current
      const remainingMinTime = Math.max(0, config.minDuration - elapsed)
      
      const animateTo100 = () => {
        const duration = 400
        const steps = duration / 20
        let currentProgress = progressRef.current // Use ref to avoid stale closure
        const stepIncrement = (100 - currentProgress) / steps
        let step = 0
        
        const finishInterval = setInterval(() => {
          step++
          currentProgress = Math.min(100, currentProgress + stepIncrement)
          setState(prev => ({ ...prev, progress: currentProgress, status: 'success' }))
          
          if (step >= steps || currentProgress >= 100) {
            clearInterval(finishInterval)
            
            setTimeout(() => {
              layerManager.unregisterLayer('transition-loader')
              setState(prev => ({ ...prev, isActive: false, isLocked: false, progress: 0 }))
              
              if (resolveCompleteRef.current) {
                resolveCompleteRef.current()
                resolveCompleteRef.current = null
              }
            }, config.exitDelay)
          }
        }, 20)
      }
      
      if (remainingMinTime > 0) {
        setTimeout(animateTo100, remainingMinTime)
      } else {
        animateTo100()
      }
    })
  }, [config, layerManager, cleanupTimers])

  useEffect(() => {
    return () => cleanupTimers()
  }, [cleanupTimers])

  const value: TransitionLoaderContextValue = {
    show,
    hide,
    setProgress,
    updateTitle,
    complete,
    cancel,
    lock,
    unlock,
    state,
    config,
  }

  const transitionZIndex = state.isActive ? layerManager.getZIndex('transition-loader') : 9999
  
  return (
    <TransitionLoaderContext.Provider value={value}>
      {children}
      <TransitionOverlay state={state} zIndex={transitionZIndex} />
    </TransitionLoaderContext.Provider>
  )
}

function easeOutCubic(t: number): number {
  return 1 - Math.pow(1 - t, 3)
}

interface TransitionOverlayProps {
  state: TransitionState
  zIndex: number
}

function TransitionOverlay({ state, zIndex }: TransitionOverlayProps) {
  return (
    <AnimatePresence>
      {state.isActive && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.3 }}
          className={cn(
            "fixed inset-0 flex flex-col items-center justify-center",
            "bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900"
          )}
          style={{ zIndex }}
          data-testid="overlay-transition-loader"
        >
          <div className="flex flex-col items-center gap-6">
            <motion.div
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ delay: 0.1, type: "spring", damping: 20 }}
            >
              <Suspense fallback={<div className="w-24 h-24" />}>
                <TrinityRedesign 
                  size={96} 
                  mode={state.status === 'success' ? "IDLE" : "THINKING"}
                />
              </Suspense>
            </motion.div>
            
            <motion.div
              initial={{ y: 10, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: 0.2 }}
              className="text-center"
            >
              <h2 className="text-xl font-semibold text-white mb-1" data-testid="text-transition-title">
                {state.title}
              </h2>
              <p className="text-sm text-slate-400" data-testid="text-transition-subtitle">
                {state.subtitle}
              </p>
            </motion.div>
            
            <motion.div
              initial={{ scaleX: 0, opacity: 0 }}
              animate={{ scaleX: 1, opacity: 1 }}
              transition={{ delay: 0.3 }}
              className="w-64"
            >
              <div className="h-1.5 bg-slate-700 rounded-full overflow-hidden">
                <motion.div
                  className={cn(
                    "h-full rounded-full",
                    state.status === 'success' 
                      ? "bg-gradient-to-r from-green-400 to-emerald-500"
                      : state.status === 'error'
                      ? "bg-gradient-to-r from-red-400 to-rose-500"
                      : "bg-gradient-to-r from-teal-400 via-cyan-400 to-blue-500"
                  )}
                  initial={{ width: "0%" }}
                  animate={{ width: `${state.progress}%` }}
                  transition={{ duration: 0.1, ease: "linear" }}
                />
              </div>
              <p className="text-center text-xs text-slate-500 mt-2" data-testid="text-transition-progress">
                {Math.round(state.progress)}%
              </p>
            </motion.div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  )
}

export function startLoginTransition(transitionLoader: TransitionLoaderContextValue | null) {
  if (!transitionLoader) return null
  
  transitionLoader.show({
    title: 'Signing In',
    subtitle: 'Verifying your credentials...',
    status: 'syncing',
  })
  
  return {
    setProgress: (progress: number) => transitionLoader.setProgress(progress),
    updateMessage: (title: string, subtitle?: string) => transitionLoader.updateTitle(title, subtitle),
    complete: () => transitionLoader.complete(),
    cancel: () => transitionLoader.cancel(),
  }
}

export function startLogoutTransition(transitionLoader: TransitionLoaderContextValue | null) {
  if (!transitionLoader) return null
  
  transitionLoader.show({
    title: 'Signing Out',
    subtitle: 'See you soon!',
    status: 'loading',
  })
  
  return {
    setProgress: (progress: number) => transitionLoader.setProgress(progress),
    updateMessage: (title: string, subtitle?: string) => transitionLoader.updateTitle(title, subtitle),
    complete: () => transitionLoader.complete(),
    cancel: () => transitionLoader.cancel(),
  }
}

/**
 * UNIVERSAL ORCHESTRATION STEP LOGGER
 * ====================================
 * Fortune 500-grade step-by-step logging for ALL platform automations.
 * 
 * Enforces the 7-step pattern:
 * 1. TRIGGER   → Cron job, button click, API call, event
 * 2. FETCH     → Query database for required data
 * 3. VALIDATE  → Check data exists, guards available, permissions OK
 * 4. PROCESS   → AI analysis, business logic, transformations
 * 5. MUTATE    → Write changes to database (STAGED until approved)
 * 6. CONFIRM   → Return success/update UI (after approval)
 * 7. NOTIFY    → Send alerts to stakeholders
 * 
 * Features:
 * - Step-level database logging with timing
 * - Subscription/credits validation at each step
 * - Staged payload holding until user approval
 * - Automatic upsell triggers when features unavailable
 * - Conflict detection between competing services
 * - Never fails silently - every step is tracked
 */

import { db } from '../../db';
import { systemAuditLogs, workspaces } from '@shared/schema';
import { eq, and, sql, desc, gt } from 'drizzle-orm';
import { platformEventBus } from '../platformEventBus';
import { idempotencyService } from '../ai-brain/idempotencyService';

// Import execution tracker dynamically to avoid circular deps
let executionTracker: any = null;
const getExecutionTracker = async () => {
  if (!executionTracker) {
    const mod = await import('./automationExecutionTracker');
    executionTracker = mod.automationExecutionTracker;
  }
  return executionTracker;
};

// ============================================================================
// TYPES
// ============================================================================

export type OrchestrationStep = 
  | 'TRIGGER'
  | 'FETCH'
  | 'VALIDATE'
  | 'PROCESS'
  | 'MUTATE'
  | 'CONFIRM'
  | 'NOTIFY';

export type StepStatus = 'started' | 'completed' | 'failed' | 'skipped' | 'blocked';

export type OrchestrationDomain = 
  | 'scheduling'
  | 'payroll'
  | 'invoicing'
  | 'quickbooks'
  | 'onboarding'
  | 'compliance'
  | 'time_tracking'
  | 'employee_management'
  | 'client_management'
  | 'analytics'
  | 'hris_sync'
  | 'automation'
  | 'trinity_ai'
  | 'claude_ai'
  | 'general';

export type FeatureTier = 'free' | 'starter' | 'professional' | 'enterprise';

export interface StepLogEntry {
  step: OrchestrationStep;
  status: StepStatus;
  startedAt: Date;
  completedAt?: Date;
  durationMs?: number;
  inputPayload?: Record<string, any>;
  outputPayload?: Record<string, any>;
  error?: string;
  errorCode?: string;
  metadata?: Record<string, any>;
}

export interface OrchestrationContext {
  orchestrationId: string;
  domain: OrchestrationDomain;
  actionName: string;
  actionId?: string;
  workspaceId: string;
  userId?: string;
  triggeredBy: 'user' | 'cron' | 'event' | 'api' | 'ai_brain' | 'webhook';
  triggerDetails?: Record<string, any>;
  requiredFeature?: string;
  requiredTier?: FeatureTier;
  requiresApproval?: boolean;
  externalSystem?: string;
  parentOrchestrationId?: string;
  steps: StepLogEntry[];
  status: 'in_progress' | 'completed' | 'failed' | 'pending_approval' | 'rejected';
  stagedPayload?: Record<string, any>;
  createdAt: Date;
  updatedAt: Date;
}

export interface StartOrchestrationParams {
  domain: OrchestrationDomain;
  actionName: string;
  actionId?: string;
  workspaceId: string;
  userId?: string;
  triggeredBy: OrchestrationContext['triggeredBy'];
  triggerDetails?: Record<string, any>;
  requiredFeature?: string;
  requiredTier?: FeatureTier;
  requiresApproval?: boolean;
  externalSystem?: string;
  parentOrchestrationId?: string;
}

export interface StepResult {
  success: boolean;
  data?: any;
  error?: string;
  errorCode?: string;
  blockedReason?: string;
  upsellRequired?: boolean;
  upsellFeature?: string;
}

export interface SubscriptionCheckResult {
  allowed: boolean;
  currentTier: FeatureTier;
  requiredTier: FeatureTier;
  creditsRemaining?: number;
  creditsRequired?: number;
  upsellRequired: boolean;
  upsellMessage?: string;
}

// ============================================================================
// ORCHESTRATION STEP ORDER
// ============================================================================

const STEP_ORDER: OrchestrationStep[] = ['TRIGGER', 'FETCH', 'VALIDATE', 'PROCESS', 'MUTATE', 'CONFIRM', 'NOTIFY'];

const STEP_DESCRIPTIONS: Record<OrchestrationStep, string> = {
  TRIGGER: 'Automation triggered',
  FETCH: 'Fetching required data',
  VALIDATE: 'Validating data and permissions',
  PROCESS: 'Processing with AI/business logic',
  MUTATE: 'Writing changes to database',
  CONFIRM: 'Confirming changes to UI',
  NOTIFY: 'Sending notifications to stakeholders',
};

// ============================================================================
// UNIVERSAL STEP LOGGER SERVICE
// ============================================================================

class UniversalStepLogger {
  private orchestrations: Map<string, OrchestrationContext> = new Map();
  private activeLocks: Map<string, string> = new Map(); // resource -> orchestrationId
  private executionTrackerIds: Map<string, string> = new Map();
  private heldLockKeys: Map<string, Set<string>> = new Map(); // orchestrationId -> Set<lockKey>

  /**
   * Acquire a resource lock using in-memory tracking with IdempotencyService validation
   * Note: For true distributed locking across multiple instances, a Redis-backed lock would be needed.
   * This implementation provides single-instance safety with idempotency validation.
   */
  private acquireLock(
    resource: string,
    orchestrationId: string,
    workspaceId: string
  ): boolean {
    const lockKey = `orchestration_lock:${workspaceId}:${resource}`;
    const existingLock = this.activeLocks.get(lockKey);
    
    // Check if already held by this orchestration
    if (existingLock === orchestrationId) {
      return true;
    }
    
    // Check if held by another orchestration
    if (existingLock) {
      return false;
    }
    
    // Use idempotency service to check if any process is working on this resource
    const idempotencyCheck = idempotencyService.checkAndMark(lockKey, {
      category: 'execution',
      workspaceId,
      ttlMs: 300000, // 5 min lock TTL
    });
    
    // If key exists and wasn't created by us, someone else holds it
    if (!idempotencyCheck.isNew) {
      return false;
    }
    
    // We got the lock - store it locally
    this.activeLocks.set(lockKey, orchestrationId);
    
    // Track which locks this orchestration holds for cleanup
    if (!this.heldLockKeys.has(orchestrationId)) {
      this.heldLockKeys.set(orchestrationId, new Set());
    }
    this.heldLockKeys.get(orchestrationId)!.add(lockKey);
    
    return true;
  }

  /**
   * Release all locks held by an orchestration
   */
  private releaseAllLocks(orchestrationId: string): void {
    const heldKeys = this.heldLockKeys.get(orchestrationId);
    if (heldKeys) {
      for (const lockKey of heldKeys) {
        if (this.activeLocks.get(lockKey) === orchestrationId) {
          this.activeLocks.delete(lockKey);
          // Mark completed in idempotency service to free the key
          idempotencyService.markCompleted(lockKey, 'released');
        }
      }
      this.heldLockKeys.delete(orchestrationId);
    }
  }

  /**
   * Persist orchestration state to audit logs for durability
   * Uses a single "orchestration_state" log entry per orchestration that gets updated
   */
  private async persistOrchestrationState(context: OrchestrationContext): Promise<void> {
    try {
      const trackerId = this.executionTrackerIds.get(context.orchestrationId);
      
      // Store current state as structured metadata
      const stateMetadata = {
        orchestrationId: context.orchestrationId,
        executionTrackerId: trackerId,
        domain: context.domain,
        actionName: context.actionName,
        actionId: context.actionId,
        status: context.status,
        currentStep: context.steps[context.steps.length - 1]?.step || 'TRIGGER',
        stepCount: context.steps.length,
        completedSteps: context.steps.filter(s => s.status === 'completed').length,
        triggeredBy: context.triggeredBy,
        requiredTier: context.requiredTier,
        externalSystem: context.externalSystem,
        hasStagedPayload: !!context.stagedPayload,
        createdAt: context.createdAt.toISOString(),
        updatedAt: new Date().toISOString(),
        ttlHours: 24, // Auto-expire state after 24 hours
      };

      // Upsert state to audit logs (delete old, insert new)
      await db.execute(sql`
        DELETE FROM system_audit_logs 
        WHERE log_type = 'orchestration_state' 
          AND (metadata->>'orchestrationId')::text = ${context.orchestrationId}
      `);
      
      await db.insert(systemAuditLogs).values({
        workspaceId: context.workspaceId,
        logType: 'orchestration_state',
        severity: 'info',
        category: 'orchestration',
        actor: context.userId || 'system',
        action: `orchestration_${context.status}`,
        targetType: context.domain,
        targetId: context.orchestrationId,
        status: context.status === 'completed' ? 'success' : context.status === 'failed' ? 'failure' : 'pending',
        metadata: stateMetadata,
      });
    } catch (error) {
      console.warn('[UniversalStepLogger] Failed to persist state:', error);
    }
  }

  /**
   * Rehydrate orchestration state from audit logs on startup
   * Rebuilds in-memory maps from persisted state entries
   */
  async rehydrateFromLogs(): Promise<{ restored: number; expired: number }> {
    try {
      const cutoffTime = new Date(Date.now() - 24 * 60 * 60 * 1000); // 24 hours ago
      
      // Query recent in-progress orchestrations
      const stateEntries = await db
        .select()
        .from(systemAuditLogs)
        .where(
          and(
            eq(systemAuditLogs.action, 'orchestration_state'),
            gt(systemAuditLogs.createdAt, cutoffTime)
          )
        );

      let restored = 0;
      let expired = 0;

      for (const entry of stateEntries) {
        const meta = entry.metadata as Record<string, any>;
        if (!meta?.orchestrationId) continue;

        // Check if already in memory
        if (this.orchestrations.has(meta.orchestrationId)) continue;

        // Skip completed/failed - they're historical records
        if (meta.status === 'completed' || meta.status === 'failed') continue;

        // Check if expired (older than TTL)
        const createdAt = new Date(meta.createdAt);
        const ttlMs = (meta.ttlHours || 24) * 60 * 60 * 1000;
        if (Date.now() - createdAt.getTime() > ttlMs) {
          expired++;
          // Mark as expired/failed in logs
          await this.markOrchestrationExpired(meta.orchestrationId, entry.workspaceId || 'unknown');
          continue;
        }

        // Restore execution tracker ID mapping
        if (meta.executionTrackerId) {
          this.executionTrackerIds.set(meta.orchestrationId, meta.executionTrackerId);
        }

        // Note: We don't fully restore the context since steps are not stored in state
        // This provides recovery awareness without full continuity
        console.log(`[UniversalStepLogger] Found in-progress orchestration: ${meta.orchestrationId} (${meta.domain}/${meta.actionName})`);
        restored++;
      }

      if (restored > 0 || expired > 0) {
        console.log(`[UniversalStepLogger] Rehydration complete: ${restored} tracked, ${expired} expired`);
      }

      return { restored, expired };
    } catch (error) {
      console.warn('[UniversalStepLogger] Failed to rehydrate:', error);
      return { restored: 0, expired: 0 };
    }
  }

  /**
   * Mark an orchestration as expired (timed out)
   */
  private async markOrchestrationExpired(orchestrationId: string, workspaceId: string): Promise<void> {
    try {
      // Update execution tracker if we have the ID
      const trackerId = this.executionTrackerIds.get(orchestrationId);
      if (trackerId) {
        const tracker = await getExecutionTracker();
        if (tracker) {
          await tracker.failExecution(trackerId, 'Orchestration expired (timeout)', 'TIMEOUT');
        }
        this.executionTrackerIds.delete(orchestrationId);
      }

      // Log expiration
      await db.insert(systemAuditLogs).values({
        workspaceId,
        logType: 'orchestration_expired',
        severity: 'warning',
        category: 'orchestration',
        actor: 'system',
        action: 'orchestration_timeout',
        targetType: 'orchestration',
        targetId: orchestrationId,
        status: 'failure',
        metadata: { reason: 'TTL exceeded after restart' },
      });
    } catch (error) {
      console.warn('[UniversalStepLogger] Failed to mark expired:', error);
    }
  }

  /**
   * Start a new orchestration with the 7-step pattern
   */
  async startOrchestration(params: StartOrchestrationParams): Promise<OrchestrationContext> {
    const orchestrationId = `orch-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
    
    // Check for idempotency - prevent duplicate orchestrations
    const idempotencyKey = idempotencyService.generateKey({
      category: 'execution',
      actionId: params.actionName,
      workspaceId: params.workspaceId,
      userId: params.userId,
    });
    
    const idempotencyCheck = idempotencyService.checkAndMark(idempotencyKey, {
      category: 'execution',
      workspaceId: params.workspaceId,
      userId: params.userId,
    });
    
    if (!idempotencyCheck.isNew) {
      console.log(`[UniversalStepLogger] Duplicate orchestration blocked: ${params.actionName}`);
      throw new Error('DUPLICATE_ORCHESTRATION: This action is already in progress');
    }

    // Also register with AutomationExecutionTracker for unified tracking
    let executionTrackerId: string | undefined;
    try {
      const tracker = await getExecutionTracker();
      if (tracker) {
        executionTrackerId = await tracker.createExecution({
          workspaceId: params.workspaceId,
          actionType: params.domain,
          actionName: params.actionName,
          actionId: params.actionId,
          triggeredBy: params.userId || 'system',
          triggerSource: params.triggeredBy,
          externalSystem: params.externalSystem,
          requiresVerification: params.requiresApproval,
        });
      }
    } catch (error) {
      console.warn('[UniversalStepLogger] Failed to register with execution tracker:', error);
    }

    const context: OrchestrationContext = {
      orchestrationId,
      domain: params.domain,
      actionName: params.actionName,
      actionId: params.actionId,
      workspaceId: params.workspaceId,
      userId: params.userId,
      triggeredBy: params.triggeredBy,
      triggerDetails: params.triggerDetails,
      requiredFeature: params.requiredFeature,
      requiredTier: params.requiredTier,
      requiresApproval: params.requiresApproval,
      externalSystem: params.externalSystem,
      parentOrchestrationId: params.parentOrchestrationId,
      steps: [],
      status: 'in_progress',
      createdAt: new Date(),
      updatedAt: new Date(),
    };

    this.orchestrations.set(orchestrationId, context);
    
    // Track execution tracker ID for later correlation
    if (executionTrackerId) {
      this.executionTrackerIds.set(orchestrationId, executionTrackerId);
    }
    
    // Log to audit system (uses existing systemAuditLogs infrastructure)
    await this.logToDatabase(context, 'orchestration_started', {
      domain: params.domain,
      actionName: params.actionName,
      triggeredBy: params.triggeredBy,
      executionTrackerId,
    });
    
    // Persist state for durability
    await this.persistOrchestrationState(context);
    
    console.log(`[UniversalStepLogger] Started orchestration ${orchestrationId}: ${params.domain}/${params.actionName}`);
    
    // Emit event for monitoring
    platformEventBus.emit({
      type: 'orchestration_started',
      workspaceId: params.workspaceId,
      metadata: { orchestrationId, domain: params.domain, actionName: params.actionName },
    });
    
    return context;
  }

  /**
   * Execute a step with full logging and validation
   */
  async executeStep<T>(
    orchestrationId: string,
    step: OrchestrationStep,
    executor: () => Promise<StepResult>,
    options?: {
      inputPayload?: Record<string, any>;
      validateSubscription?: boolean;
      acquireLock?: string;
      skipOnPreviousFailure?: boolean;
    }
  ): Promise<StepResult> {
    const context = this.orchestrations.get(orchestrationId);
    if (!context) {
      return { success: false, error: 'Orchestration not found', errorCode: 'ORCHESTRATION_NOT_FOUND' };
    }

    // Check step order
    const lastCompletedStep = this.getLastCompletedStep(context);
    if (lastCompletedStep && !this.isValidNextStep(lastCompletedStep, step)) {
      return { 
        success: false, 
        error: `Invalid step order: ${step} cannot follow ${lastCompletedStep}`,
        errorCode: 'INVALID_STEP_ORDER'
      };
    }

    // Check if previous step failed and we should skip
    if (options?.skipOnPreviousFailure && this.hasFailedStep(context)) {
      const stepEntry: StepLogEntry = {
        step,
        status: 'skipped',
        startedAt: new Date(),
        completedAt: new Date(),
        durationMs: 0,
        metadata: { reason: 'Previous step failed' },
      };
      context.steps.push(stepEntry);
      return { success: false, error: 'Skipped due to previous failure', errorCode: 'PREVIOUS_STEP_FAILED' };
    }

    // Subscription validation for VALIDATE step
    if (options?.validateSubscription && step === 'VALIDATE' && context.requiredTier) {
      const subscriptionCheck = await this.checkSubscription(context.workspaceId, context.requiredTier, context.requiredFeature);
      if (!subscriptionCheck.allowed) {
        const stepEntry: StepLogEntry = {
          step,
          status: 'blocked',
          startedAt: new Date(),
          completedAt: new Date(),
          durationMs: 0,
          error: subscriptionCheck.upsellMessage || 'Feature not available on current plan',
          metadata: { 
            subscriptionCheck,
            upsellRequired: true,
            upsellFeature: context.requiredFeature,
          },
        };
        context.steps.push(stepEntry);
        
        // Trigger upsell
        await this.triggerUpsell(context, subscriptionCheck);
        
        return { 
          success: false, 
          error: subscriptionCheck.upsellMessage,
          errorCode: 'SUBSCRIPTION_REQUIRED',
          upsellRequired: true,
          upsellFeature: context.requiredFeature,
        };
      }
    }

    // Acquire lock for MUTATE step if specified (uses IdempotencyService)
    if (options?.acquireLock && step === 'MUTATE') {
      const lockAcquired = this.acquireLock(options.acquireLock, orchestrationId, context.workspaceId);
      if (!lockAcquired) {
        const stepEntry: StepLogEntry = {
          step,
          status: 'blocked',
          startedAt: new Date(),
          completedAt: new Date(),
          durationMs: 0,
          error: `Resource locked by another orchestration`,
          metadata: { resource: options.acquireLock },
        };
        context.steps.push(stepEntry);
        return { 
          success: false, 
          error: 'Resource locked by another operation',
          errorCode: 'RESOURCE_LOCKED',
          blockedReason: `Resource ${options.acquireLock} is currently being modified`,
        };
      }
    }

    // Start step
    const stepEntry: StepLogEntry = {
      step,
      status: 'started',
      startedAt: new Date(),
      inputPayload: options?.inputPayload,
    };
    context.steps.push(stepEntry);
    context.updatedAt = new Date();
    
    console.log(`[UniversalStepLogger] [${orchestrationId}] Step ${step}: ${STEP_DESCRIPTIONS[step]}`);
    
    try {
      const result = await executor();
      
      stepEntry.completedAt = new Date();
      stepEntry.durationMs = stepEntry.completedAt.getTime() - stepEntry.startedAt.getTime();
      stepEntry.status = result.success ? 'completed' : 'failed';
      stepEntry.outputPayload = result.data;
      
      if (!result.success) {
        stepEntry.error = result.error;
        stepEntry.errorCode = result.errorCode;
      }
      
      // Log to database
      await this.logToDatabase(context, `step_${step.toLowerCase()}_${stepEntry.status}`, {
        step,
        status: stepEntry.status,
        durationMs: stepEntry.durationMs,
        error: stepEntry.error,
      });
      
      // Persist state for durability after each step
      await this.persistOrchestrationState(context);
      
      console.log(`[UniversalStepLogger] [${orchestrationId}] Step ${step}: ${stepEntry.status} (${stepEntry.durationMs}ms)`);
      
      // Release lock on completion/failure (use correct lockKey format)
      if (options?.acquireLock) {
        const lockKey = `orchestration_lock:${context.workspaceId}:${options.acquireLock}`;
        this.activeLocks.delete(lockKey);
        const heldKeys = this.heldLockKeys.get(orchestrationId);
        if (heldKeys) heldKeys.delete(lockKey);
        idempotencyService.markCompleted(lockKey, 'released');
      }
      
      return result;
    } catch (error: any) {
      stepEntry.completedAt = new Date();
      stepEntry.durationMs = stepEntry.completedAt.getTime() - stepEntry.startedAt.getTime();
      stepEntry.status = 'failed';
      stepEntry.error = error.message || 'Unknown error';
      stepEntry.errorCode = 'UNHANDLED_EXCEPTION';
      
      // Log to database
      await this.logToDatabase(context, `step_${step.toLowerCase()}_error`, {
        step,
        error: stepEntry.error,
        stack: error.stack,
      });
      
      // Persist state for durability
      await this.persistOrchestrationState(context);
      
      console.error(`[UniversalStepLogger] [${orchestrationId}] Step ${step} ERROR:`, error.message);
      
      // Release lock on error (use correct lockKey format)
      if (options?.acquireLock) {
        const lockKey = `orchestration_lock:${context.workspaceId}:${options.acquireLock}`;
        this.activeLocks.delete(lockKey);
        const heldKeys = this.heldLockKeys.get(orchestrationId);
        if (heldKeys) heldKeys.delete(lockKey);
        idempotencyService.markCompleted(lockKey, 'released');
      }
      
      return { success: false, error: stepEntry.error, errorCode: 'UNHANDLED_EXCEPTION' };
    }
  }

  /**
   * Stage payload for approval (holds MUTATE until approved)
   */
  async stagePayload(orchestrationId: string, payload: Record<string, any>): Promise<void> {
    const context = this.orchestrations.get(orchestrationId);
    if (!context) {
      throw new Error('Orchestration not found');
    }
    
    context.stagedPayload = payload;
    context.status = 'pending_approval';
    context.updatedAt = new Date();
    
    await this.logToDatabase(context, 'payload_staged', {
      payloadSize: JSON.stringify(payload).length,
      requiresApproval: true,
    });
    
    console.log(`[UniversalStepLogger] [${orchestrationId}] Payload staged for approval`);
    
    // Emit event for UI to show approval dialog
    platformEventBus.emit({
      type: 'orchestration_pending_approval',
      workspaceId: context.workspaceId,
      metadata: {
        orchestrationId,
        domain: context.domain,
        actionName: context.actionName,
        stagedPayload: payload,
      },
    });
  }

  /**
   * Approve staged payload and proceed with CONFIRM step
   */
  async approvePayload(orchestrationId: string, approvedBy: string): Promise<StepResult> {
    const context = this.orchestrations.get(orchestrationId);
    if (!context) {
      return { success: false, error: 'Orchestration not found' };
    }
    
    if (context.status !== 'pending_approval') {
      return { success: false, error: 'Orchestration not pending approval' };
    }
    
    context.status = 'in_progress';
    context.updatedAt = new Date();
    
    await this.logToDatabase(context, 'payload_approved', {
      approvedBy,
      approvedAt: new Date().toISOString(),
    });
    
    console.log(`[UniversalStepLogger] [${orchestrationId}] Payload approved by ${approvedBy}`);
    
    return { success: true, data: context.stagedPayload };
  }

  /**
   * Reject staged payload
   */
  async rejectPayload(orchestrationId: string, rejectedBy: string, reason: string): Promise<void> {
    const context = this.orchestrations.get(orchestrationId);
    if (!context) {
      throw new Error('Orchestration not found');
    }
    
    context.status = 'rejected';
    context.updatedAt = new Date();
    
    await this.logToDatabase(context, 'payload_rejected', {
      rejectedBy,
      rejectedAt: new Date().toISOString(),
      reason,
    });
    
    console.log(`[UniversalStepLogger] [${orchestrationId}] Payload rejected by ${rejectedBy}: ${reason}`);
    
    platformEventBus.emit({
      type: 'orchestration_rejected',
      workspaceId: context.workspaceId,
      metadata: { orchestrationId, rejectedBy, reason },
    });
  }

  /**
   * Complete orchestration successfully
   */
  async completeOrchestration(orchestrationId: string, summary?: Record<string, any>): Promise<void> {
    const context = this.orchestrations.get(orchestrationId);
    if (!context) {
      throw new Error('Orchestration not found');
    }
    
    context.status = 'completed';
    context.updatedAt = new Date();
    
    // Release all held locks
    this.releaseAllLocks(orchestrationId);
    
    // Update execution tracker
    const trackerId = this.executionTrackerIds.get(orchestrationId);
    if (trackerId) {
      try {
        const tracker = await getExecutionTracker();
        if (tracker) {
          await tracker.completeExecution(trackerId, summary);
        }
      } catch (e) {
        console.warn('[UniversalStepLogger] Failed to update execution tracker:', e);
      }
      this.executionTrackerIds.delete(orchestrationId);
    }
    
    const totalDuration = context.steps.reduce((sum, s) => sum + (s.durationMs || 0), 0);
    const completedSteps = context.steps.filter(s => s.status === 'completed').length;
    
    await this.logToDatabase(context, 'orchestration_completed', {
      totalDurationMs: totalDuration,
      completedSteps,
      totalSteps: context.steps.length,
      summary,
      executionTrackerId: trackerId,
    });
    
    console.log(`[UniversalStepLogger] [${orchestrationId}] Orchestration completed in ${totalDuration}ms (${completedSteps}/${context.steps.length} steps)`);
    
    platformEventBus.emit({
      type: 'orchestration_completed',
      workspaceId: context.workspaceId,
      metadata: {
        orchestrationId,
        domain: context.domain,
        actionName: context.actionName,
        totalDurationMs: totalDuration,
        summary,
      },
    });
    
    // Persist final state
    await this.persistOrchestrationState(context);
    
    // Cleanup after delay
    setTimeout(() => this.orchestrations.delete(orchestrationId), 300000); // 5 min retention
  }

  /**
   * Fail orchestration with error details
   */
  async failOrchestration(orchestrationId: string, error: string, errorCode?: string): Promise<void> {
    const context = this.orchestrations.get(orchestrationId);
    if (!context) {
      throw new Error('Orchestration not found');
    }
    
    context.status = 'failed';
    context.updatedAt = new Date();
    
    // Release all held locks
    this.releaseAllLocks(orchestrationId);
    
    // Update execution tracker
    const trackerId = this.executionTrackerIds.get(orchestrationId);
    if (trackerId) {
      try {
        const tracker = await getExecutionTracker();
        if (tracker) {
          await tracker.failExecution(trackerId, error, errorCode);
        }
      } catch (e) {
        console.warn('[UniversalStepLogger] Failed to update execution tracker:', e);
      }
      this.executionTrackerIds.delete(orchestrationId);
    }
    
    const failedStep = context.steps.find(s => s.status === 'failed');
    
    await this.logToDatabase(context, 'orchestration_failed', {
      error,
      errorCode,
      failedAtStep: failedStep?.step,
      completedSteps: context.steps.filter(s => s.status === 'completed').length,
      executionTrackerId: trackerId,
    });
    
    console.error(`[UniversalStepLogger] [${orchestrationId}] Orchestration FAILED at ${failedStep?.step || 'unknown'}: ${error}`);
    
    platformEventBus.emit({
      type: 'orchestration_failed',
      workspaceId: context.workspaceId,
      metadata: {
        orchestrationId,
        domain: context.domain,
        actionName: context.actionName,
        error,
        errorCode,
        failedAtStep: failedStep?.step,
      },
    });
    
    // Persist final state
    await this.persistOrchestrationState(context);
    
    // Cleanup after delay
    setTimeout(() => this.orchestrations.delete(orchestrationId), 300000);
  }

  /**
   * Log a step directly without using executeStep (for manual step tracking)
   * Used by services that manage their own step execution but want consistent logging
   */
  async logStep(
    context: OrchestrationContext,
    step: OrchestrationStep,
    status: StepStatus,
    inputPayload?: Record<string, any>,
    outputPayload?: Record<string, any>,
    error?: string
  ): Promise<void> {
    const now = new Date();
    const stepEntry: StepLogEntry = {
      step,
      status,
      startedAt: now,
      completedAt: status !== 'started' ? now : undefined,
      durationMs: 0,
      inputPayload,
      outputPayload,
      error,
    };
    
    // Track in context if registered
    const registeredContext = this.orchestrations.get(context.orchestrationId);
    if (registeredContext) {
      registeredContext.steps.push(stepEntry);
      registeredContext.updatedAt = now;
      await this.persistOrchestrationState(registeredContext);
    }
    
    // Log to database
    await this.logToDatabase(context, `step_${step.toLowerCase()}_${status}`, {
      step,
      status,
      inputPayload,
      outputPayload,
      error,
    });
    
    console.log(`[UniversalStepLogger] [${context.orchestrationId}] Step ${step}: ${status}`);
  }

  /**
   * Get orchestration status
   */
  getOrchestration(orchestrationId: string): OrchestrationContext | undefined {
    return this.orchestrations.get(orchestrationId);
  }

  /**
   * Get all active orchestrations for a workspace
   */
  getActiveOrchestrations(workspaceId: string): OrchestrationContext[] {
    return Array.from(this.orchestrations.values())
      .filter(o => o.workspaceId === workspaceId && o.status === 'in_progress');
  }

  // ============================================================================
  // PRIVATE HELPERS
  // ============================================================================

  private getLastCompletedStep(context: OrchestrationContext): OrchestrationStep | null {
    const completedSteps = context.steps.filter(s => s.status === 'completed' || s.status === 'skipped');
    if (completedSteps.length === 0) return null;
    return completedSteps[completedSteps.length - 1].step;
  }

  private isValidNextStep(lastStep: OrchestrationStep, nextStep: OrchestrationStep): boolean {
    const lastIndex = STEP_ORDER.indexOf(lastStep);
    const nextIndex = STEP_ORDER.indexOf(nextStep);
    // Allow same step (retry) or next step
    return nextIndex >= lastIndex && nextIndex <= lastIndex + 1;
  }

  private hasFailedStep(context: OrchestrationContext): boolean {
    return context.steps.some(s => s.status === 'failed');
  }

  private async checkSubscription(
    workspaceId: string,
    requiredTier: FeatureTier,
    requiredFeature?: string
  ): Promise<SubscriptionCheckResult> {
    try {
      const [workspace] = await db.select()
        .from(workspaces)
        .where(eq(workspaces.id, workspaceId))
        .limit(1);
      
      if (!workspace) {
        return {
          allowed: false,
          currentTier: 'free',
          requiredTier,
          upsellRequired: true,
          upsellMessage: 'Workspace not found',
        };
      }
      
      const tierOrder: FeatureTier[] = ['free', 'starter', 'professional', 'enterprise'];
      const currentTier = (workspace.subscriptionTier as FeatureTier) || 'free';
      const currentIndex = tierOrder.indexOf(currentTier);
      const requiredIndex = tierOrder.indexOf(requiredTier);
      
      if (currentIndex >= requiredIndex) {
        return {
          allowed: true,
          currentTier,
          requiredTier,
          upsellRequired: false,
        };
      }
      
      return {
        allowed: false,
        currentTier,
        requiredTier,
        upsellRequired: true,
        upsellMessage: `This feature requires ${requiredTier} tier or higher. Current: ${currentTier}. ${requiredFeature ? `Upgrade to unlock ${requiredFeature}.` : ''}`,
      };
    } catch (error) {
      console.error('[UniversalStepLogger] Subscription check error:', error);
      return {
        allowed: true, // Fail open to avoid blocking legitimate operations
        currentTier: 'professional',
        requiredTier,
        upsellRequired: false,
      };
    }
  }

  private async triggerUpsell(context: OrchestrationContext, check: SubscriptionCheckResult): Promise<void> {
    platformEventBus.emit({
      type: 'upsell_triggered',
      workspaceId: context.workspaceId,
      metadata: {
        orchestrationId: context.orchestrationId,
        feature: context.requiredFeature,
        currentTier: check.currentTier,
        requiredTier: check.requiredTier,
        message: check.upsellMessage,
        domain: context.domain,
        actionName: context.actionName,
      },
    });
    
    console.log(`[UniversalStepLogger] Upsell triggered for ${context.requiredFeature}: ${check.currentTier} → ${check.requiredTier}`);
  }

  private async logToDatabase(
    context: OrchestrationContext,
    action: string,
    details: Record<string, any>
  ): Promise<void> {
    try {
      await db.insert(systemAuditLogs).values({
        workspaceId: context.workspaceId,
        userId: context.userId || null,
        action: `orchestration.${action}`,
        entityType: context.domain || 'orchestration',
        entityId: context.orchestrationId,
        metadata: {
          orchestrationId: context.orchestrationId,
          domain: context.domain,
          actionName: context.actionName,
          triggeredBy: 'system',
          ...details,
        },
        ipAddress: 'system',
        userAgent: 'UniversalStepLogger/1.0',
      });
    } catch (error) {
      console.error('[UniversalStepLogger] Failed to log to database:', error);
    }
  }
}

// ============================================================================
// SINGLETON EXPORT
// ============================================================================

export const universalStepLogger = new UniversalStepLogger();

// Initialize on module load - rehydrate from persisted state
(async () => {
  try {
    const result = await universalStepLogger.rehydrateFromLogs();
    if (result.restored > 0 || result.expired > 0) {
      console.log(`[UniversalStepLogger] Startup rehydration: ${result.restored} in-progress, ${result.expired} expired`);
    }
  } catch (error) {
    console.warn('[UniversalStepLogger] Startup rehydration failed:', error);
  }
})();

// ============================================================================
// CONVENIENCE WRAPPER FOR FULL 7-STEP ORCHESTRATION
// ============================================================================

export interface FullOrchestrationConfig<T> {
  domain: OrchestrationDomain;
  actionName: string;
  workspaceId: string;
  userId?: string;
  triggeredBy: OrchestrationContext['triggeredBy'];
  requiredTier?: FeatureTier;
  requiredFeature?: string;
  requiresApproval?: boolean;
  externalSystem?: string;
  lockResource?: string;
  
  // Step executors
  onTrigger: () => Promise<StepResult>;
  onFetch: () => Promise<StepResult>;
  onValidate: () => Promise<StepResult>;
  onProcess: () => Promise<StepResult>;
  onMutate: () => Promise<StepResult>;
  onConfirm: (stagedData?: any) => Promise<StepResult>;
  onNotify: () => Promise<StepResult>;
}

export async function executeFullOrchestration<T>(
  config: FullOrchestrationConfig<T>
): Promise<{ success: boolean; orchestrationId: string; result?: T; error?: string }> {
  const context = await universalStepLogger.startOrchestration({
    domain: config.domain,
    actionName: config.actionName,
    workspaceId: config.workspaceId,
    userId: config.userId,
    triggeredBy: config.triggeredBy,
    requiredTier: config.requiredTier,
    requiredFeature: config.requiredFeature,
    requiresApproval: config.requiresApproval,
    externalSystem: config.externalSystem,
  });

  try {
    // Step 1: TRIGGER
    const triggerResult = await universalStepLogger.executeStep(context.orchestrationId, 'TRIGGER', config.onTrigger);
    if (!triggerResult.success) {
      await universalStepLogger.failOrchestration(context.orchestrationId, triggerResult.error || 'Trigger failed', triggerResult.errorCode);
      return { success: false, orchestrationId: context.orchestrationId, error: triggerResult.error };
    }

    // Step 2: FETCH
    const fetchResult = await universalStepLogger.executeStep(context.orchestrationId, 'FETCH', config.onFetch);
    if (!fetchResult.success) {
      await universalStepLogger.failOrchestration(context.orchestrationId, fetchResult.error || 'Fetch failed', fetchResult.errorCode);
      return { success: false, orchestrationId: context.orchestrationId, error: fetchResult.error };
    }

    // Step 3: VALIDATE (with subscription check)
    const validateResult = await universalStepLogger.executeStep(
      context.orchestrationId, 
      'VALIDATE', 
      config.onValidate,
      { validateSubscription: !!config.requiredTier }
    );
    if (!validateResult.success) {
      await universalStepLogger.failOrchestration(context.orchestrationId, validateResult.error || 'Validation failed', validateResult.errorCode);
      return { success: false, orchestrationId: context.orchestrationId, error: validateResult.error };
    }

    // Step 4: PROCESS
    const processResult = await universalStepLogger.executeStep(context.orchestrationId, 'PROCESS', config.onProcess);
    if (!processResult.success) {
      await universalStepLogger.failOrchestration(context.orchestrationId, processResult.error || 'Processing failed', processResult.errorCode);
      return { success: false, orchestrationId: context.orchestrationId, error: processResult.error };
    }

    // Step 5: MUTATE (with lock if specified)
    const mutateResult = await universalStepLogger.executeStep(
      context.orchestrationId, 
      'MUTATE', 
      config.onMutate,
      { acquireLock: config.lockResource }
    );
    if (!mutateResult.success) {
      await universalStepLogger.failOrchestration(context.orchestrationId, mutateResult.error || 'Mutation failed', mutateResult.errorCode);
      return { success: false, orchestrationId: context.orchestrationId, error: mutateResult.error };
    }

    // If requires approval, stage and wait
    if (config.requiresApproval) {
      await universalStepLogger.stagePayload(context.orchestrationId, mutateResult.data || {});
      return { 
        success: true, 
        orchestrationId: context.orchestrationId,
        result: { pendingApproval: true, stagedData: mutateResult.data } as any,
      };
    }

    // Step 6: CONFIRM
    const confirmResult = await universalStepLogger.executeStep(
      context.orchestrationId, 
      'CONFIRM', 
      () => config.onConfirm(mutateResult.data)
    );
    if (!confirmResult.success) {
      await universalStepLogger.failOrchestration(context.orchestrationId, confirmResult.error || 'Confirmation failed', confirmResult.errorCode);
      return { success: false, orchestrationId: context.orchestrationId, error: confirmResult.error };
    }

    // Step 7: NOTIFY
    const notifyResult = await universalStepLogger.executeStep(context.orchestrationId, 'NOTIFY', config.onNotify);
    if (!notifyResult.success) {
      // Notification failures are not critical - log but continue
      console.warn(`[Orchestration] Notification step failed: ${notifyResult.error}`);
    }

    await universalStepLogger.completeOrchestration(context.orchestrationId, { result: confirmResult.data });
    
    return { 
      success: true, 
      orchestrationId: context.orchestrationId, 
      result: confirmResult.data as T 
    };
  } catch (error: any) {
    await universalStepLogger.failOrchestration(context.orchestrationId, error.message, 'UNHANDLED_EXCEPTION');
    return { success: false, orchestrationId: context.orchestrationId, error: error.message };
  }
}

// Register with AI Brain for diagnostic access
export function registerStepLoggerActions(): void {
  console.log('[UniversalStepLogger] Registered 7-step orchestration pattern');
}

/**
 * Trinity Scheduling Orchestrator
 * 
 * Active autonomous scheduling service that Trinity uses to:
 * - Create new shifts based on demand
 * - Edit/optimize existing shifts
 * - Delete unnecessary shifts
 * - Swap employees between shifts
 * - Track all mutations for user verification
 * - Save work payload to Trinity memory
 * 
 * IMPORTANT: This uses a DRY-RUN mode by default.
 * Changes are NOT persisted until user verifies them.
 * Pending mutations are stored with the execution record.
 */

import { db } from '../../db';
import { shifts, employees, clients, workspaces } from '@shared/schema';
import { eq, and, gte, lte, asc } from 'drizzle-orm';
import { automationExecutionTracker, type WorkBreakdown } from './automationExecutionTracker';
import { platformEventBus } from '../platformEventBus';
import { geminiClient } from '../ai-brain/providers/geminiClient';
import { startOfWeek, endOfWeek, addDays, format, differenceInHours } from 'date-fns';

export type SchedulingMutationType = 
  | 'create_shift'
  | 'edit_shift'
  | 'delete_shift'
  | 'swap_employees'
  | 'fill_open_shift'
  | 'reassign_shift';

export interface SchedulingMutation {
  id: string;
  type: SchedulingMutationType;
  description: string;
  beforeState?: Record<string, any>;
  afterState?: Record<string, any>;
  employeeId?: string;
  employeeName?: string;
  shiftId?: string;
  clientId?: string;
  clientName?: string;
  startTime?: Date;
  endTime?: Date;
  estimatedHours?: number;
  estimatedCost?: number;
  reason: string;
  dbOperation?: {
    table: 'shifts';
    action: 'insert' | 'update' | 'delete';
    data?: Record<string, any>;
    where?: Record<string, any>;
  };
}

export interface SchedulingSessionResult {
  success: boolean;
  sessionId: string;
  executionId: string;
  workspaceId: string;
  startedAt: Date;
  completedAt: Date;
  totalMutations: number;
  mutations: SchedulingMutation[];
  summary: {
    shiftsCreated: number;
    shiftsEdited: number;
    shiftsDeleted: number;
    employeesSwapped: number;
    openShiftsFilled: number;
    totalHoursScheduled: number;
    estimatedLaborCost: number;
  };
  aiSummary: string;
  requiresVerification: boolean;
  verificationDeadline?: Date;
}

interface SchedulingContext {
  workspaceId: string;
  weekStart: Date;
  weekEnd: Date;
  employees: any[];
  clients: any[];
  existingShifts: any[];
  openShifts: any[];
}

class TrinitySchedulingOrchestratorService {
  private activeSessionId: string | null = null;
  private pendingSessions: Map<string, SchedulingMutation[]> = new Map();

  async startSchedulingSession(params: {
    workspaceId: string;
    triggeredBy: string;
    weekStart?: Date;
    mode: 'optimize' | 'fill_gaps' | 'full_generate';
    dryRun?: boolean;
  }): Promise<SchedulingSessionResult> {
    const sessionId = `sched-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
    this.activeSessionId = sessionId;
    const startedAt = new Date();
    const mutations: SchedulingMutation[] = [];
    const dryRun = params.dryRun ?? true;

    console.log(`[TrinitySchedulingOrchestrator] Starting session ${sessionId} for workspace ${params.workspaceId} (dryRun: ${dryRun})`);

    const weekStart = params.weekStart || startOfWeek(new Date(), { weekStartsOn: 0 });
    const weekEnd = endOfWeek(weekStart, { weekStartsOn: 0 });

    const executionId = await automationExecutionTracker.createExecution({
      workspaceId: params.workspaceId,
      actionType: 'schedule_publish',
      actionName: `Trinity Autonomous Scheduling - ${params.mode}`,
      triggeredBy: params.triggeredBy,
      triggerSource: 'button_click',
      requiresVerification: true,
      inputPayload: {
        mode: params.mode,
        weekStart: weekStart.toISOString(),
        weekEnd: weekEnd.toISOString(),
        sessionId,
        dryRun,
      },
    });

    await automationExecutionTracker.updateExecution(executionId, {
      status: 'in_progress',
    });

    try {
      const context = await this.gatherSchedulingContext(params.workspaceId, weekStart, weekEnd);
      
      // Emit trinity_scheduling_started event for real-time UI feedback
      platformEventBus.emit({
        type: 'trinity_scheduling_started',
        workspaceId: params.workspaceId,
        metadata: {
          sessionId,
          executionId,
          mode: params.mode,
          totalShifts: context.openShifts.length,
          weekStart: weekStart.toISOString(),
          weekEnd: weekEnd.toISOString(),
        },
      });
      
      switch (params.mode) {
        case 'optimize':
          await this.proposeOptimizations(context, mutations, sessionId);
          break;
        case 'fill_gaps':
          await this.proposeOpenShiftFills(context, mutations, sessionId);
          break;
        case 'full_generate':
          await this.proposeFullSchedule(context, mutations, sessionId);
          break;
      }

      this.pendingSessions.set(executionId, mutations);

      const summary = this.calculateSummary(mutations);
      const aiSummary = await this.generateAISummary(params.workspaceId, mutations, summary);
      const completedAt = new Date();

      const workBreakdown: WorkBreakdown = {
        items: [
          { label: 'Shifts Created', value: summary.shiftsCreated, icon: 'plus', category: 'creation' },
          { label: 'Shifts Modified', value: summary.shiftsEdited, icon: 'edit', category: 'modification' },
          { label: 'Shifts Removed', value: summary.shiftsDeleted, icon: 'trash', category: 'deletion' },
          { label: 'Open Shifts Filled', value: summary.openShiftsFilled, icon: 'user-check', category: 'assignment' },
          { label: 'Employee Swaps', value: summary.employeesSwapped, icon: 'refresh', category: 'swap' },
          { label: 'Total Hours', value: `${summary.totalHoursScheduled.toFixed(1)}h`, icon: 'clock', category: 'hours' },
          { label: 'Labor Cost', value: `$${summary.estimatedLaborCost.toFixed(2)}`, icon: 'dollar', category: 'cost' },
        ],
        totalCount: mutations.length,
        totalValue: summary.estimatedLaborCost,
        currency: 'USD',
      };

      await automationExecutionTracker.updateExecution(executionId, {
        status: 'pending_verification',
        outputPayload: {
          sessionId,
          dryRun: true,
          pendingMutations: mutations.map(m => ({
            id: m.id,
            type: m.type,
            description: m.description,
            employeeName: m.employeeName,
            startTime: m.startTime?.toISOString(),
            endTime: m.endTime?.toISOString(),
            dbOperation: m.dbOperation,
          })),
          summary,
        },
        workBreakdown,
        aiSummary,
        processingTimeMs: completedAt.getTime() - startedAt.getTime(),
        itemsProcessed: mutations.length,
        itemsFailed: 0,
      });

      // Emit both for backward compatibility and new UI
      platformEventBus.emit({
        type: 'scheduling_session_complete',
        workspaceId: params.workspaceId,
        metadata: {
          sessionId,
          executionId,
          mutationCount: mutations.length,
          summary,
          awaitingVerification: true,
        },
      });
      
      // Emit trinity_scheduling_completed for real-time UI feedback
      platformEventBus.emit({
        type: 'trinity_scheduling_completed',
        workspaceId: params.workspaceId,
        metadata: {
          sessionId,
          executionId,
          mutationCount: mutations.length,
          summary,
          awaitingVerification: true,
        },
      });

      const result: SchedulingSessionResult = {
        success: true,
        sessionId,
        executionId,
        workspaceId: params.workspaceId,
        startedAt,
        completedAt,
        totalMutations: mutations.length,
        mutations,
        summary,
        aiSummary,
        requiresVerification: true,
        verificationDeadline: addDays(completedAt, 1),
      };

      console.log(`[TrinitySchedulingOrchestrator] Session ${sessionId} complete (DRY RUN): ${mutations.length} proposed mutations awaiting verification`);
      return result;

    } catch (error: any) {
      console.error(`[TrinitySchedulingOrchestrator] Session ${sessionId} failed:`, error);

      await automationExecutionTracker.updateExecution(executionId, {
        status: 'failed',
        failureReason: error.message,
        failureCode: 'SCHEDULING_ERROR',
        remediationSteps: [
          { step: 1, description: 'Check employee availability data is up to date' },
          { step: 2, description: 'Verify client requirements are configured' },
          { step: 3, description: 'Retry the scheduling operation' },
        ],
      });

      throw error;
    } finally {
      this.activeSessionId = null;
    }
  }

  async applyVerifiedMutations(executionId: string): Promise<{ success: boolean; appliedCount: number; errors: string[] }> {
    const mutations = this.pendingSessions.get(executionId);
    if (!mutations || mutations.length === 0) {
      const execution = await automationExecutionTracker.getExecution(executionId);
      if (execution?.outputPayload?.pendingMutations) {
        const storedMutations = execution.outputPayload.pendingMutations as SchedulingMutation[];
        return this.applyMutationsToDatabase(storedMutations, executionId);
      }
      return { success: true, appliedCount: 0, errors: [] };
    }

    return this.applyMutationsToDatabase(mutations, executionId);
  }

  private async applyMutationsToDatabase(mutations: SchedulingMutation[], executionId: string): Promise<{ success: boolean; appliedCount: number; errors: string[] }> {
    const errors: string[] = [];
    let appliedCount = 0;

    console.log(`[TrinitySchedulingOrchestrator] Applying ${mutations.length} verified mutations for execution ${executionId}`);

    for (const mutation of mutations) {
      try {
        if (!mutation.dbOperation) {
          console.log(`[TrinitySchedulingOrchestrator] Skipping mutation ${mutation.id} - no dbOperation defined`);
          continue;
        }

        const { table, action, data, where } = mutation.dbOperation;

        if (table === 'shifts') {
          switch (action) {
            case 'insert':
              if (data) {
                await db.insert(shifts).values({
                  id: data.id,
                  workspaceId: data.workspaceId,
                  employeeId: data.employeeId,
                  clientId: data.clientId,
                  title: data.title,
                  startTime: new Date(data.startTime),
                  endTime: new Date(data.endTime),
                  status: data.status || 'scheduled',
                  aiGenerated: true,
                });
                appliedCount++;
              }
              break;

            case 'update':
              if (data && where?.id) {
                await db.update(shifts)
                  .set({ employeeId: data.employeeId })
                  .where(eq(shifts.id, where.id));
                appliedCount++;
              }
              break;

            case 'delete':
              if (where?.id) {
                await db.delete(shifts).where(eq(shifts.id, where.id));
                appliedCount++;
              }
              break;
          }
        }

        console.log(`[TrinitySchedulingOrchestrator] Applied mutation: ${mutation.type} - ${mutation.description}`);
      } catch (error: any) {
        console.error(`[TrinitySchedulingOrchestrator] Failed to apply mutation ${mutation.id}:`, error);
        errors.push(`${mutation.type}: ${error.message}`);
      }
    }

    this.pendingSessions.delete(executionId);

    await automationExecutionTracker.updateExecution(executionId, {
      status: 'verified',
      outputPayload: {
        applied: true,
        appliedCount,
        appliedAt: new Date().toISOString(),
        errors,
      },
    });

    return {
      success: errors.length === 0,
      appliedCount,
      errors,
    };
  }

  async rejectMutations(executionId: string, reason: string): Promise<void> {
    this.pendingSessions.delete(executionId);

    await automationExecutionTracker.updateExecution(executionId, {
      status: 'rejected',
      outputPayload: {
        rejected: true,
        rejectedAt: new Date().toISOString(),
        rejectionReason: reason,
      },
    });

    console.log(`[TrinitySchedulingOrchestrator] Mutations rejected for execution ${executionId}: ${reason}`);
  }

  private async gatherSchedulingContext(
    workspaceId: string,
    weekStart: Date,
    weekEnd: Date
  ): Promise<SchedulingContext> {
    const [workspaceEmployees, workspaceClients, existingShifts] = await Promise.all([
      db.select().from(employees).where(
        and(
          eq(employees.workspaceId, workspaceId),
          eq(employees.status, 'active')
        )
      ),
      db.select().from(clients).where(eq(clients.workspaceId, workspaceId)),
      db.select().from(shifts).where(
        and(
          eq(shifts.workspaceId, workspaceId),
          gte(shifts.startTime, weekStart),
          lte(shifts.endTime, weekEnd)
        )
      ).orderBy(asc(shifts.startTime)),
    ]);

    const openShifts = existingShifts.filter(s => !s.employeeId);

    return {
      workspaceId,
      weekStart,
      weekEnd,
      employees: workspaceEmployees,
      clients: workspaceClients,
      existingShifts,
      openShifts,
    };
  }

  private async proposeOptimizations(context: SchedulingContext, mutations: SchedulingMutation[], sessionId?: string): Promise<void> {
    console.log(`[TrinitySchedulingOrchestrator] Proposing optimizations for week of ${format(context.weekStart, 'MMM d')}`);
    
    const employeeWorkload: Map<string, number> = new Map();
    context.existingShifts.forEach(shift => {
      if (shift.employeeId) {
        const hours = differenceInHours(new Date(shift.endTime), new Date(shift.startTime));
        employeeWorkload.set(shift.employeeId, (employeeWorkload.get(shift.employeeId) || 0) + hours);
      }
    });

    const overworkedEmployees = Array.from(employeeWorkload.entries())
      .filter(([_, hours]) => hours > 40)
      .sort((a, b) => b[1] - a[1]);

    const underworkedEmployees = context.employees
      .filter(e => (employeeWorkload.get(e.id) || 0) < 20);

    const totalToProcess = overworkedEmployees.slice(0, 3).length;
    let processedCount = 0;

    for (const [overworkedId, totalHours] of overworkedEmployees.slice(0, 3)) {
      processedCount++;
      const overworkedShifts = context.existingShifts
        .filter(s => s.employeeId === overworkedId)
        .sort((a, b) => new Date(b.startTime).getTime() - new Date(a.startTime).getTime());

      const overworkedEmp = context.employees.find(e => e.id === overworkedId);

      // Emit progress event for optimization analysis
      platformEventBus.emit({
        type: 'trinity_scheduling_progress',
        workspaceId: context.workspaceId,
        metadata: {
          sessionId,
          currentShiftId: overworkedShifts[0]?.id,
          currentIndex: processedCount,
          totalShifts: totalToProcess,
          status: 'analyzing',
          message: `Analyzing workload for ${overworkedEmp?.firstName || 'Employee'} (${totalHours}h/week)...`,
        },
      });

      await new Promise(resolve => setTimeout(resolve, 50));

      if (overworkedShifts.length > 0 && underworkedEmployees.length > 0) {
        const shiftToReassign = overworkedShifts[0];
        const targetEmployee = underworkedEmployees.find(e => e.id !== overworkedId);

        if (targetEmployee) {
          mutations.push({
            id: `mut-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`,
            type: 'swap_employees',
            description: `Reassign shift from ${overworkedEmp?.firstName} ${overworkedEmp?.lastName} to ${targetEmployee.firstName} ${targetEmployee.lastName} to balance workload`,
            beforeState: { employeeId: overworkedId, employeeName: `${overworkedEmp?.firstName} ${overworkedEmp?.lastName}` },
            afterState: { employeeId: targetEmployee.id, employeeName: `${targetEmployee.firstName} ${targetEmployee.lastName}` },
            employeeId: targetEmployee.id,
            employeeName: `${targetEmployee.firstName} ${targetEmployee.lastName}`,
            shiftId: shiftToReassign.id,
            startTime: new Date(shiftToReassign.startTime),
            endTime: new Date(shiftToReassign.endTime),
            estimatedHours: differenceInHours(new Date(shiftToReassign.endTime), new Date(shiftToReassign.startTime)),
            reason: `${overworkedEmp?.firstName} at ${totalHours}h/week (overworked). ${targetEmployee.firstName} at ${employeeWorkload.get(targetEmployee.id) || 0}h/week (underutilized).`,
            dbOperation: {
              table: 'shifts',
              action: 'update',
              data: { employeeId: targetEmployee.id },
              where: { id: shiftToReassign.id },
            },
          });

          // Emit progress event for swap
          platformEventBus.emit({
            type: 'trinity_scheduling_progress',
            workspaceId: context.workspaceId,
            metadata: {
              sessionId,
              currentShiftId: shiftToReassign.id,
              currentIndex: processedCount,
              totalShifts: totalToProcess,
              status: 'assigned',
              message: `Reassigning to ${targetEmployee.firstName} ${targetEmployee.lastName}`,
              assignedEmployeeId: targetEmployee.id,
              assignedEmployeeName: `${targetEmployee.firstName} ${targetEmployee.lastName}`,
            },
          });
        }
      }
    }
  }

  private async proposeOpenShiftFills(context: SchedulingContext, mutations: SchedulingMutation[], sessionId?: string): Promise<void> {
    console.log(`[TrinitySchedulingOrchestrator] Proposing fills for ${context.openShifts.length} open shifts`);

    const employeeWorkload: Map<string, number> = new Map();
    context.existingShifts.forEach(shift => {
      if (shift.employeeId) {
        const hours = differenceInHours(new Date(shift.endTime), new Date(shift.startTime));
        employeeWorkload.set(shift.employeeId, (employeeWorkload.get(shift.employeeId) || 0) + hours);
      }
    });

    const totalShifts = context.openShifts.length;

    for (let index = 0; index < context.openShifts.length; index++) {
      const openShift = context.openShifts[index];
      const client = context.clients.find(c => c.id === openShift.clientId);
      const shiftHours = differenceInHours(new Date(openShift.endTime), new Date(openShift.startTime));
      
      // Emit progress event - analyzing this shift
      platformEventBus.emit({
        type: 'trinity_scheduling_progress',
        workspaceId: context.workspaceId,
        metadata: {
          sessionId,
          currentShiftId: openShift.id,
          currentIndex: index + 1,
          totalShifts,
          status: 'analyzing',
          message: `Analyzing shift at ${client?.companyName || 'Unknown Location'}...`,
        },
      });

      // Add small delay for visual feedback (50ms per shift)
      await new Promise(resolve => setTimeout(resolve, 50));
      
      const availableEmployees = context.employees
        .filter(e => {
          const currentHours = employeeWorkload.get(e.id) || 0;
          return currentHours + shiftHours <= 40;
        })
        .sort((a, b) => (employeeWorkload.get(a.id) || 0) - (employeeWorkload.get(b.id) || 0));

      if (availableEmployees.length > 0) {
        const selectedEmployee = availableEmployees[0];
        
        employeeWorkload.set(
          selectedEmployee.id, 
          (employeeWorkload.get(selectedEmployee.id) || 0) + shiftHours
        );

        mutations.push({
          id: `mut-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`,
          type: 'fill_open_shift',
          description: `Assign ${selectedEmployee.firstName} ${selectedEmployee.lastName} to open shift at ${client?.companyName || 'Unknown Client'}`,
          afterState: { employeeId: selectedEmployee.id },
          employeeId: selectedEmployee.id,
          employeeName: `${selectedEmployee.firstName} ${selectedEmployee.lastName}`,
          shiftId: openShift.id,
          clientId: openShift.clientId,
          clientName: client?.companyName,
          startTime: new Date(openShift.startTime),
          endTime: new Date(openShift.endTime),
          estimatedHours: shiftHours,
          estimatedCost: shiftHours * (selectedEmployee.payRate || 15),
          reason: `${selectedEmployee.firstName} has lowest workload at ${(employeeWorkload.get(selectedEmployee.id) || 0) - shiftHours}h/week`,
          dbOperation: {
            table: 'shifts',
            action: 'update',
            data: { employeeId: selectedEmployee.id },
            where: { id: openShift.id },
          },
        });

        // Emit progress event - shift assigned
        platformEventBus.emit({
          type: 'trinity_scheduling_progress',
          workspaceId: context.workspaceId,
          metadata: {
            sessionId,
            currentShiftId: openShift.id,
            currentIndex: index + 1,
            totalShifts,
            status: 'assigned',
            message: `Assigned ${selectedEmployee.firstName} ${selectedEmployee.lastName}`,
            assignedEmployeeId: selectedEmployee.id,
            assignedEmployeeName: `${selectedEmployee.firstName} ${selectedEmployee.lastName}`,
          },
        });
      } else {
        // Emit progress event - shift skipped (no available employees)
        platformEventBus.emit({
          type: 'trinity_scheduling_progress',
          workspaceId: context.workspaceId,
          metadata: {
            sessionId,
            currentShiftId: openShift.id,
            currentIndex: index + 1,
            totalShifts,
            status: 'skipped',
            message: `No available employees for shift at ${client?.companyName || 'Unknown Location'}`,
          },
        });
      }
    }
  }

  private async proposeFullSchedule(context: SchedulingContext, mutations: SchedulingMutation[], sessionId?: string): Promise<void> {
    console.log(`[TrinitySchedulingOrchestrator] Proposing full schedule for week of ${format(context.weekStart, 'MMM d')}`);

    await this.proposeOpenShiftFills(context, mutations, sessionId);
    await this.proposeOptimizations(context, mutations, sessionId);

    for (const client of context.clients.slice(0, 3)) {
      const clientShifts = context.existingShifts.filter(s => s.clientId === client.id);
      
      if (clientShifts.length === 0) {
        for (let dayOffset = 1; dayOffset <= 5; dayOffset++) {
          const shiftDate = addDays(context.weekStart, dayOffset);
          const startTime = new Date(shiftDate);
          startTime.setHours(9, 0, 0, 0);
          const endTime = new Date(shiftDate);
          endTime.setHours(17, 0, 0, 0);

          const availableEmployee = context.employees.find(e => {
            const existing = context.existingShifts.some(s => 
              s.employeeId === e.id && 
              new Date(s.startTime).toDateString() === shiftDate.toDateString()
            );
            return !existing;
          });

          if (availableEmployee) {
            const newShiftId = `shift-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`;
            
            mutations.push({
              id: `mut-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`,
              type: 'create_shift',
              description: `Create new shift for ${availableEmployee.firstName} ${availableEmployee.lastName} at ${client.companyName}`,
              afterState: { shiftId: newShiftId, employeeId: availableEmployee.id },
              employeeId: availableEmployee.id,
              employeeName: `${availableEmployee.firstName} ${availableEmployee.lastName}`,
              shiftId: newShiftId,
              clientId: client.id,
              clientName: client.companyName,
              startTime,
              endTime,
              estimatedHours: 8,
              estimatedCost: 8 * (availableEmployee.payRate || 15),
              reason: `Client ${client.companyName} has no coverage for ${format(shiftDate, 'EEEE')}`,
              dbOperation: {
                table: 'shifts',
                action: 'insert',
                data: {
                  id: newShiftId,
                  workspaceId: context.workspaceId,
                  employeeId: availableEmployee.id,
                  clientId: client.id,
                  title: `${client.companyName} - Standard Shift`,
                  startTime: startTime.toISOString(),
                  endTime: endTime.toISOString(),
                  status: 'scheduled',
                },
              },
            });

            context.existingShifts.push({
              id: newShiftId,
              employeeId: availableEmployee.id,
              startTime,
              endTime,
              clientId: client.id,
            });
          }
        }
      }
    }
  }

  private calculateSummary(mutations: SchedulingMutation[]): SchedulingSessionResult['summary'] {
    let totalHours = 0;
    let totalCost = 0;

    mutations.forEach(m => {
      totalHours += m.estimatedHours || 0;
      totalCost += m.estimatedCost || 0;
    });

    return {
      shiftsCreated: mutations.filter(m => m.type === 'create_shift').length,
      shiftsEdited: mutations.filter(m => m.type === 'edit_shift').length,
      shiftsDeleted: mutations.filter(m => m.type === 'delete_shift').length,
      employeesSwapped: mutations.filter(m => m.type === 'swap_employees').length,
      openShiftsFilled: mutations.filter(m => m.type === 'fill_open_shift').length,
      totalHoursScheduled: totalHours,
      estimatedLaborCost: totalCost,
    };
  }

  private async generateAISummary(
    workspaceId: string,
    mutations: SchedulingMutation[],
    summary: SchedulingSessionResult['summary']
  ): Promise<string> {
    if (mutations.length === 0) {
      return "I reviewed the schedule and everything looks good - no changes needed this time.";
    }

    try {
      const prompt = `Generate a brief, friendly 2-3 sentence summary of what is PROPOSED to optimize a work schedule. These changes are NOT yet applied - they require user approval.
      
      Proposed changes:
      - ${summary.shiftsCreated} new shifts to create
      - ${summary.openShiftsFilled} open shifts to fill
      - ${summary.employeesSwapped} employee reassignments
      - ${summary.shiftsEdited} shifts to modify
      - ${summary.shiftsDeleted} shifts to remove
      - Total: ${summary.totalHoursScheduled.toFixed(1)} hours would be scheduled
      - Estimated cost: $${summary.estimatedLaborCost.toFixed(2)}
      
      Key proposed changes:
      ${mutations.slice(0, 5).map(m => `- ${m.description}`).join('\n')}
      
      Write as Trinity AI assistant speaking to the business owner. Be conversational and professional. Start with "I" not "Trinity". Mention that these changes need approval before being applied.`;

      const result = await geminiClient.generateContent({
        prompt,
        workspaceId,
        purpose: 'scheduling_summary',
      });

      return result.text || "I've proposed some schedule optimizations. Please review and approve the changes above.";
    } catch (error) {
      console.error('[TrinitySchedulingOrchestrator] Failed to generate AI summary:', error);
      return `I'm proposing ${mutations.length} schedule changes: ${summary.shiftsCreated} new shifts, ${summary.openShiftsFilled} gaps filled, ${summary.employeesSwapped} reassignments. Please review and approve these changes.`;
    }
  }

  async getSessionStatus(sessionId: string): Promise<{
    isActive: boolean;
    currentSessionId: string | null;
  }> {
    return {
      isActive: this.activeSessionId === sessionId,
      currentSessionId: this.activeSessionId,
    };
  }
}

export const trinitySchedulingOrchestrator = new TrinitySchedulingOrchestratorService();

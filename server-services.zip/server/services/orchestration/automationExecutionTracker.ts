/**
 * Automation Execution Tracker Service
 * 
 * Tracks the complete lifecycle of all automation actions:
 * - Queued → In Progress → Completed/Failed
 * - Provides user-visible breakdown of work done
 * - Verification workflow before external system sync
 * - Failure reasons with remediation steps
 * - Integration with Trinity/Claude AI for summaries
 */

import { db } from '../../db';
import { automationExecutions } from '@shared/schema';
import { eq, and, desc, gte, sql } from 'drizzle-orm';
import { platformEventBus } from '../platformEventBus';
import { helpaiOrchestrator } from '../helpai/platformActionHub';
import { meteredGemini } from '../billing/meteredGeminiClient';

export type ExecutionStatus = 
  | 'queued'
  | 'in_progress' 
  | 'completed'
  | 'failed'
  | 'pending_verification'
  | 'verified'
  | 'rejected';

export type ActionType =
  | 'quickbooks_sync'
  | 'payroll_run'
  | 'invoice_generation'
  | 'schedule_publish'
  | 'employee_import'
  | 'time_entry_approval'
  | 'compliance_check'
  | 'report_generation'
  | 'data_export'
  | 'integration_sync'
  | 'schedule_analysis'
  | 'billing_run'
  | 'custom';

export interface WorkBreakdownItem {
  label: string;
  value: string | number;
  icon?: string;
  category?: string;
}

export interface WorkBreakdown {
  items: WorkBreakdownItem[];
  totalCount: number;
  totalValue?: number;
  currency?: string;
}

export interface RemediationStep {
  step: number;
  description: string;
  actionUrl?: string;
  actionLabel?: string;
}

export interface CreateExecutionParams {
  workspaceId: string;
  actionType: ActionType | string;
  actionName: string;
  actionId?: string;
  triggeredBy?: string;
  triggerSource?: 'button_click' | 'scheduled' | 'api' | 'event' | 'ai_brain';
  inputPayload?: Record<string, any>;
  externalSystem?: string;
  requiresVerification?: boolean;
}

export interface UpdateExecutionParams {
  status?: ExecutionStatus;
  outputPayload?: Record<string, any>;
  workBreakdown?: WorkBreakdown;
  aiSummary?: string;
  externalSyncStatus?: 'pending' | 'synced' | 'failed';
  externalReference?: string;
  failureReason?: string;
  failureCode?: string;
  remediationSteps?: RemediationStep[];
  processingTimeMs?: number;
  itemsProcessed?: number;
  itemsFailed?: number;
  totalValueProcessed?: number;
}

class AutomationExecutionTrackerService {
  private aiEnabled = true;

  async createExecution(params: CreateExecutionParams): Promise<string> {
    const executionId = `exec-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
    
    try {
      await db.insert(automationExecutions).values({
        id: executionId,
        workspaceId: params.workspaceId,
        actionType: params.actionType,
        actionName: params.actionName,
        actionId: params.actionId,
        triggeredBy: params.triggeredBy || 'system',
        triggerSource: params.triggerSource || 'api',
        inputPayload: params.inputPayload,
        externalSystem: params.externalSystem,
        requiresVerification: params.requiresVerification ?? false,
        status: 'queued',
        queuedAt: new Date(),
      });

      console.log(`[AutomationExecutionTracker] Created execution ${executionId}:`, {
        actionType: params.actionType,
        actionName: params.actionName,
        workspaceId: params.workspaceId,
      });

      platformEventBus.emit({
        type: 'automation_execution_created',
        workspaceId: params.workspaceId,
        metadata: { executionId, actionType: params.actionType },
      });

      return executionId;
    } catch (error) {
      console.error('[AutomationExecutionTracker] Failed to create execution:', error);
      throw error;
    }
  }

  async startExecution(executionId: string): Promise<void> {
    await db.update(automationExecutions)
      .set({
        status: 'in_progress',
        startedAt: new Date(),
        updatedAt: new Date(),
      })
      .where(eq(automationExecutions.id, executionId));

    console.log(`[AutomationExecutionTracker] Started execution ${executionId}`);
  }

  async completeExecution(executionId: string, params: UpdateExecutionParams): Promise<void> {
    const completedAt = new Date();
    const execution = await this.getExecution(executionId);
    
    let processingTimeMs = params.processingTimeMs;
    if (!processingTimeMs && execution?.startedAt) {
      processingTimeMs = completedAt.getTime() - new Date(execution.startedAt).getTime();
    }

    const finalStatus: ExecutionStatus = params.requiresVerification 
      ? 'pending_verification' 
      : 'completed';

    let aiSummary = params.aiSummary;
    if (!aiSummary && this.aiEnabled && params.workBreakdown) {
      aiSummary = await this.generateAISummary(execution, params);
    }

    await db.update(automationExecutions)
      .set({
        status: finalStatus,
        completedAt,
        outputPayload: params.outputPayload,
        workBreakdown: params.workBreakdown,
        aiSummary,
        externalSyncStatus: params.externalSyncStatus || 'pending',
        externalReference: params.externalReference,
        processingTimeMs,
        itemsProcessed: params.itemsProcessed,
        itemsFailed: params.itemsFailed,
        totalValueProcessed: params.totalValueProcessed?.toString(),
        updatedAt: new Date(),
      })
      .where(eq(automationExecutions.id, executionId));

    console.log(`[AutomationExecutionTracker] Completed execution ${executionId}:`, {
      status: finalStatus,
      itemsProcessed: params.itemsProcessed,
      processingTimeMs,
    });

    if (execution?.workspaceId) {
      platformEventBus.emit({
        type: finalStatus === 'pending_verification' 
          ? 'automation_pending_verification' 
          : 'automation_execution_completed',
        workspaceId: execution.workspaceId,
        metadata: {
          executionId,
          actionType: execution.actionType,
          itemsProcessed: params.itemsProcessed,
          requiresVerification: finalStatus === 'pending_verification',
        },
      });
    }
  }

  async failExecution(executionId: string, params: {
    failureReason: string;
    failureCode?: string;
    remediationSteps?: RemediationStep[];
    itemsProcessed?: number;
    itemsFailed?: number;
  }): Promise<void> {
    const execution = await this.getExecution(executionId);
    const completedAt = new Date();
    
    let processingTimeMs: number | undefined;
    if (execution?.startedAt) {
      processingTimeMs = completedAt.getTime() - new Date(execution.startedAt).getTime();
    }

    const retryCount = (execution?.retryCount || 0) + 1;
    const maxRetries = execution?.maxRetries || 3;
    const canRetry = retryCount < maxRetries;

    let remediationSteps = params.remediationSteps;
    if (!remediationSteps && this.aiEnabled && execution?.workspaceId) {
      remediationSteps = await this.generateRemediationSteps(params.failureReason, execution.workspaceId, params.failureCode);
    }

    await db.update(automationExecutions)
      .set({
        status: 'failed',
        completedAt,
        failureReason: params.failureReason,
        failureCode: params.failureCode,
        remediationSteps,
        retryCount,
        processingTimeMs,
        itemsProcessed: params.itemsProcessed,
        itemsFailed: params.itemsFailed,
        updatedAt: new Date(),
      })
      .where(eq(automationExecutions.id, executionId));

    console.log(`[AutomationExecutionTracker] Failed execution ${executionId}:`, {
      failureCode: params.failureCode,
      canRetry,
      retryCount,
    });

    if (execution?.workspaceId) {
      platformEventBus.emit({
        type: 'automation_execution_failed',
        workspaceId: execution.workspaceId,
        metadata: {
          executionId,
          actionType: execution.actionType,
          failureReason: params.failureReason,
          failureCode: params.failureCode,
          canRetry,
        },
      });
    }
  }

  async verifyExecution(executionId: string, params: {
    verifiedBy: string;
    verificationNotes?: string;
  }): Promise<void> {
    const execution = await this.getExecution(executionId);
    
    if (!execution || execution.status !== 'pending_verification') {
      throw new Error('Execution not found or not pending verification');
    }

    await db.update(automationExecutions)
      .set({
        status: 'verified',
        verifiedBy: params.verifiedBy,
        verifiedAt: new Date(),
        verificationNotes: params.verificationNotes,
        updatedAt: new Date(),
      })
      .where(eq(automationExecutions.id, executionId));

    console.log(`[AutomationExecutionTracker] Verified execution ${executionId} by ${params.verifiedBy}`);

    platformEventBus.emit({
      type: 'automation_execution_verified',
      workspaceId: execution.workspaceId,
      metadata: {
        executionId,
        actionType: execution.actionType,
        verifiedBy: params.verifiedBy,
        externalSystem: execution.externalSystem,
      },
    });
  }

  async rejectExecution(executionId: string, params: {
    rejectedBy: string;
    rejectionReason: string;
  }): Promise<void> {
    const execution = await this.getExecution(executionId);
    
    if (!execution || execution.status !== 'pending_verification') {
      throw new Error('Execution not found or not pending verification');
    }

    await db.update(automationExecutions)
      .set({
        status: 'rejected',
        rejectedBy: params.rejectedBy,
        rejectedAt: new Date(),
        rejectionReason: params.rejectionReason,
        updatedAt: new Date(),
      })
      .where(eq(automationExecutions.id, executionId));

    console.log(`[AutomationExecutionTracker] Rejected execution ${executionId} by ${params.rejectedBy}`);

    platformEventBus.emit({
      type: 'automation_execution_rejected',
      workspaceId: execution.workspaceId,
      metadata: {
        executionId,
        actionType: execution.actionType,
        rejectedBy: params.rejectedBy,
        rejectionReason: params.rejectionReason,
      },
    });
  }

  async syncToExternalSystem(executionId: string, externalReference: string): Promise<void> {
    await db.update(automationExecutions)
      .set({
        externalSyncStatus: 'synced',
        externalSyncAt: new Date(),
        externalReference,
        updatedAt: new Date(),
      })
      .where(eq(automationExecutions.id, executionId));

    console.log(`[AutomationExecutionTracker] Synced execution ${executionId} to external system:`, externalReference);
  }

  async getExecution(executionId: string) {
    const [execution] = await db.select()
      .from(automationExecutions)
      .where(eq(automationExecutions.id, executionId))
      .limit(1);
    return execution;
  }

  async getWorkspaceExecutions(workspaceId: string, options?: {
    status?: ExecutionStatus;
    actionType?: string;
    limit?: number;
    since?: Date;
  }) {
    let query = db.select()
      .from(automationExecutions)
      .where(eq(automationExecutions.workspaceId, workspaceId))
      .orderBy(desc(automationExecutions.queuedAt));

    if (options?.limit) {
      query = query.limit(options.limit) as typeof query;
    }

    const results = await query;

    return results.filter(exec => {
      if (options?.status && exec.status !== options.status) return false;
      if (options?.actionType && exec.actionType !== options.actionType) return false;
      if (options?.since && new Date(exec.queuedAt) < options.since) return false;
      return true;
    });
  }

  async getPendingVerifications(workspaceId: string) {
    return db.select()
      .from(automationExecutions)
      .where(and(
        eq(automationExecutions.workspaceId, workspaceId),
        eq(automationExecutions.status, 'pending_verification')
      ))
      .orderBy(desc(automationExecutions.completedAt));
  }

  async getStats(workspaceId: string, since?: Date) {
    const executions = await this.getWorkspaceExecutions(workspaceId, { since });
    
    const byStatus: Record<string, number> = {};
    const byActionType: Record<string, number> = {};
    let totalProcessed = 0;
    let totalFailed = 0;
    let totalValue = 0;

    executions.forEach(exec => {
      byStatus[exec.status] = (byStatus[exec.status] || 0) + 1;
      byActionType[exec.actionType] = (byActionType[exec.actionType] || 0) + 1;
      totalProcessed += exec.itemsProcessed || 0;
      totalFailed += exec.itemsFailed || 0;
      if (exec.totalValueProcessed) {
        totalValue += parseFloat(exec.totalValueProcessed);
      }
    });

    return {
      total: executions.length,
      byStatus,
      byActionType,
      totalItemsProcessed: totalProcessed,
      totalItemsFailed: totalFailed,
      totalValueProcessed: totalValue,
      pendingVerification: byStatus['pending_verification'] || 0,
      successRate: executions.length > 0 
        ? ((byStatus['completed'] || 0) + (byStatus['verified'] || 0)) / executions.length 
        : 0,
    };
  }

  private async generateAISummary(
    execution: any, 
    params: UpdateExecutionParams
  ): Promise<string> {
    try {
      const prompt = `Generate a brief, user-friendly summary (2-3 sentences) of this automation:
Action: ${execution?.actionName || 'Unknown'}
Type: ${execution?.actionType || 'Unknown'}
Items Processed: ${params.itemsProcessed || 0}
Items Failed: ${params.itemsFailed || 0}
Total Value: ${params.totalValueProcessed ? `$${params.totalValueProcessed}` : 'N/A'}
Work Breakdown: ${JSON.stringify(params.workBreakdown?.items || [])}

Be concise and focus on what was accomplished.`;

      const result = await meteredGemini.generate({
        workspaceId: execution?.workspaceId || 'system',
        featureKey: 'automation_summary',
        prompt,
        maxOutputTokens: 150,
      });

      return result.text || 'Automation completed successfully.';
    } catch (error) {
      console.warn('[AutomationExecutionTracker] AI summary generation failed:', error);
      return `Processed ${params.itemsProcessed || 0} items successfully.`;
    }
  }

  private async generateRemediationSteps(
    failureReason: string,
    workspaceId: string,
    failureCode?: string
  ): Promise<RemediationStep[]> {
    try {
      const prompt = `Generate 2-3 simple remediation steps for this automation failure:
Failure Reason: ${failureReason}
Failure Code: ${failureCode || 'UNKNOWN'}

Return as JSON array: [{ "step": 1, "description": "..." }]`;

      const result = await meteredGemini.generate({
        workspaceId, // Billed to org where failure occurred
        featureKey: 'automation_remediation',
        prompt,
        maxOutputTokens: 200,
      });

      const parsed = JSON.parse(result.text || '[]');
      return Array.isArray(parsed) ? parsed : [];
    } catch (error) {
      console.warn('[AutomationExecutionTracker] Remediation steps generation failed:', error);
      return [
        { step: 1, description: 'Review the error details above' },
        { step: 2, description: 'Check your connection settings' },
        { step: 3, description: 'Contact support if the issue persists' },
      ];
    }
  }
}

export const automationExecutionTracker = new AutomationExecutionTrackerService();

export function registerExecutionTrackerActions(orchestrator: typeof helpaiOrchestrator): void {
  orchestrator.registerAction({
    actionId: 'execution_tracker.create',
    name: 'Create Automation Execution',
    category: 'automation',
    description: 'Create a new automation execution record',
    requiredRoles: ['manager', 'admin', 'super_admin', 'owner'],
    handler: async (request) => {
      const executionId = await automationExecutionTracker.createExecution({
        workspaceId: request.workspaceId || '',
        actionType: request.payload?.actionType || 'custom',
        actionName: request.payload?.actionName || 'Custom Action',
        actionId: request.actionId,
        triggeredBy: request.userId,
        triggerSource: 'ai_brain',
        inputPayload: request.payload,
        externalSystem: request.payload?.externalSystem,
        requiresVerification: request.payload?.requiresVerification,
      });

      return {
        success: true,
        actionId: request.actionId,
        message: `Execution ${executionId} created`,
        data: { executionId },
        executionTimeMs: 0,
      };
    },
  });

  orchestrator.registerAction({
    actionId: 'execution_tracker.verify',
    name: 'Verify Automation Execution',
    category: 'automation',
    description: 'Verify and approve a pending automation execution',
    requiredRoles: ['admin', 'super_admin', 'owner'],
    handler: async (request) => {
      await automationExecutionTracker.verifyExecution(request.payload?.executionId, {
        verifiedBy: request.userId,
        verificationNotes: request.payload?.notes,
      });

      return {
        success: true,
        actionId: request.actionId,
        message: 'Execution verified',
        executionTimeMs: 0,
      };
    },
  });

  orchestrator.registerAction({
    actionId: 'execution_tracker.reject',
    name: 'Reject Automation Execution',
    category: 'automation',
    description: 'Reject a pending automation execution',
    requiredRoles: ['admin', 'super_admin', 'owner'],
    handler: async (request) => {
      await automationExecutionTracker.rejectExecution(request.payload?.executionId, {
        rejectedBy: request.userId,
        rejectionReason: request.payload?.reason || 'Rejected by user',
      });

      return {
        success: true,
        actionId: request.actionId,
        message: 'Execution rejected',
        executionTimeMs: 0,
      };
    },
  });

  orchestrator.registerAction({
    actionId: 'execution_tracker.get_pending',
    name: 'Get Pending Verifications',
    category: 'automation',
    description: 'Get all executions pending verification',
    requiredRoles: ['manager', 'admin', 'super_admin', 'owner'],
    handler: async (request) => {
      const pending = await automationExecutionTracker.getPendingVerifications(
        request.workspaceId || ''
      );

      return {
        success: true,
        actionId: request.actionId,
        message: `Found ${pending.length} pending verifications`,
        data: { executions: pending },
        executionTimeMs: 0,
      };
    },
  });

  orchestrator.registerAction({
    actionId: 'execution_tracker.get_stats',
    name: 'Get Execution Stats',
    category: 'automation',
    description: 'Get automation execution statistics',
    requiredRoles: ['manager', 'admin', 'super_admin', 'owner'],
    handler: async (request) => {
      const since = request.payload?.since ? new Date(request.payload.since) : undefined;
      const stats = await automationExecutionTracker.getStats(
        request.workspaceId || '',
        since
      );

      return {
        success: true,
        actionId: request.actionId,
        message: 'Stats retrieved',
        data: stats,
        executionTimeMs: 0,
      };
    },
  });

  console.log('[AutomationExecutionTracker] Registered 5 AI Brain actions');
}

import crypto from 'crypto';
import { db } from '../../db';
import { partnerConnections, oauthStates } from '@shared/schema';
import { eq, and, lt } from 'drizzle-orm';
import { encryptToken, decryptToken } from '../../security/tokenEncryption';

/**
 * QuickBooks OAuth 2.0 Service
 * 
 * Implements OAuth 2.0 authorization code flow with PKCE for QuickBooks Online API
 * 
 * Required Environment Variables:
 * - QUICKBOOKS_CLIENT_ID: OAuth client ID from QuickBooks Developer Portal
 * - QUICKBOOKS_CLIENT_SECRET: OAuth client secret
 * - QUICKBOOKS_REDIRECT_URI: OAuth callback URL (e.g., https://yourdomain.com/api/integrations/quickbooks/callback)
 * 
 * QuickBooks OAuth Documentation:
 * https://developer.intuit.com/app/developer/qbo/docs/develop/authentication-and-authorization/oauth-2.0
 */

interface QuickBooksTokenResponse {
  access_token: string;
  refresh_token: string;
  expires_in: number;
  x_refresh_token_expires_in: number;
  token_type: string;
  realmId: string; // Company ID
}

import { INTEGRATIONS } from '@shared/platformConfig';

export class QuickBooksOAuthService {
  private readonly redirectUri: string;
  // Use centralized config - NO HARDCODED VALUES
  private readonly authorizationEndpoint = INTEGRATIONS.quickbooks.oauthUrls.authorization;
  private readonly tokenEndpoint = INTEGRATIONS.quickbooks.oauthUrls.token;
  private readonly revokeEndpoint = INTEGRATIONS.quickbooks.oauthUrls.revoke;
  private readonly apiBaseUrl = INTEGRATIONS.quickbooks.getVersionedApiBase();
  
  // Guard to prevent multiple scheduled cleanup intervals
  private static cleanupScheduled = false;

  constructor() {
    // Build redirect URI dynamically from Replit environment or use explicit setting
    if (process.env.QUICKBOOKS_REDIRECT_URI) {
      this.redirectUri = process.env.QUICKBOOKS_REDIRECT_URI;
    } else if (process.env.REPLIT_DOMAINS) {
      const primaryDomain = process.env.REPLIT_DOMAINS.split(',')[0];
      this.redirectUri = `https://${primaryDomain}/api/integrations/quickbooks/callback`;
    } else if (process.env.REPL_SLUG && process.env.REPL_OWNER) {
      this.redirectUri = `https://${process.env.REPL_SLUG}.${process.env.REPL_OWNER}.repl.co/api/integrations/quickbooks/callback`;
    } else {
      this.redirectUri = '';
    }

    console.log(`[QuickBooks OAuth] Dual-credential auto-detection enabled`);
    console.log(`[QuickBooks OAuth] Dev credentials: ${process.env.QUICKBOOKS_DEV_CLIENT_ID ? 'SET' : 'NOT SET'}`);
    console.log(`[QuickBooks OAuth] Prod credentials: ${process.env.QUICKBOOKS_PROD_CLIENT_ID ? 'SET' : 'NOT SET'}`);
  }

  /**
   * Get credentials based on request domain (auto-detect dev vs prod)
   * Uses centralized INTEGRATIONS.quickbooks.getEnvironmentForDomain for consistency
   */
  private getCredentialsForDomain(requestDomain?: string): { clientId: string; clientSecret: string; isProduction: boolean } {
    // Use centralized environment detection for consistency across all codepaths
    const qbEnvironment = INTEGRATIONS.quickbooks.getEnvironmentForDomain(requestDomain);
    const isProduction = qbEnvironment === 'production';
    
    if (isProduction) {
      const clientId = process.env.QUICKBOOKS_PROD_CLIENT_ID || process.env.QUICKBOOKS_CLIENT_ID || '';
      const clientSecret = process.env.QUICKBOOKS_PROD_CLIENT_SECRET || process.env.QUICKBOOKS_CLIENT_SECRET || '';
      console.log(`[QuickBooks OAuth] Using PRODUCTION credentials for domain: ${requestDomain || 'unknown'}`);
      return { clientId, clientSecret, isProduction: true };
    } else {
      const clientId = process.env.QUICKBOOKS_DEV_CLIENT_ID || process.env.QUICKBOOKS_CLIENT_ID || '';
      const clientSecret = process.env.QUICKBOOKS_DEV_CLIENT_SECRET || process.env.QUICKBOOKS_CLIENT_SECRET || '';
      console.log(`[QuickBooks OAuth] Using DEVELOPMENT (sandbox) credentials for domain: ${requestDomain || 'unknown'}`);
      return { clientId, clientSecret, isProduction: false };
    }
  }

  /**
   * Clean up expired OAuth states (TTL enforcement)
   * Called before any state operations to prevent stale record buildup
   */
  private async cleanupExpiredStates(): Promise<number> {
    const result = await db.delete(oauthStates)
      .where(lt(oauthStates.expiresAt, new Date()))
      .returning();
    if (result.length > 0) {
      console.log(`[QuickBooks OAuth] Cleaned up ${result.length} expired OAuth states`);
    }
    return result.length;
  }

  /**
   * Delete all previous OAuth states for a workspace (one-active-state pattern)
   * Ensures fresh start on each connect attempt - no pileup of failed attempts
   */
  private async deleteWorkspaceStates(workspaceId: string): Promise<number> {
    const result = await db.delete(oauthStates)
      .where(and(
        eq(oauthStates.workspaceId, workspaceId),
        eq(oauthStates.partnerType, 'quickbooks')
      ))
      .returning();
    if (result.length > 0) {
      console.log(`[QuickBooks OAuth] Deleted ${result.length} previous OAuth states for workspace ${workspaceId}`);
    }
    return result.length;
  }

  /**
   * Cleanup a specific failed OAuth state
   * Called when OAuth callback receives an error
   */
  async cleanupFailedState(state: string): Promise<void> {
    await db.delete(oauthStates)
      .where(and(
        eq(oauthStates.state, state),
        eq(oauthStates.partnerType, 'quickbooks')
      ));
    console.log(`[QuickBooks OAuth] Cleaned up failed OAuth state`);
  }

  /**
   * Get credentials for background operations (token refresh, revoke)
   * Uses connection metadata environment if available, falls back to deployment state
   */
  private getCredentialsForBackgroundOps(connectionMetadata?: Record<string, any>): { clientId: string; clientSecret: string } {
    // Use stored environment from connection metadata if available (for consistency)
    const storedEnvironment = connectionMetadata?.environment as string | undefined;
    
    let isProduction: boolean;
    if (storedEnvironment) {
      isProduction = storedEnvironment === 'production';
      console.log(`[QuickBooks OAuth] Background ops using stored environment: ${storedEnvironment}`);
    } else {
      // Fallback to deployment state detection
      isProduction = process.env.REPLIT_DEPLOYMENT === '1' || 
                     process.env.NODE_ENV === 'production';
      console.log(`[QuickBooks OAuth] Background ops using deployment-detected environment: ${isProduction ? 'production' : 'sandbox'}`);
    }
    
    if (isProduction) {
      const clientId = process.env.QUICKBOOKS_PROD_CLIENT_ID || process.env.QUICKBOOKS_CLIENT_ID || '';
      const clientSecret = process.env.QUICKBOOKS_PROD_CLIENT_SECRET || process.env.QUICKBOOKS_CLIENT_SECRET || '';
      return { clientId, clientSecret };
    } else {
      const clientId = process.env.QUICKBOOKS_DEV_CLIENT_ID || process.env.QUICKBOOKS_CLIENT_ID || '';
      const clientSecret = process.env.QUICKBOOKS_DEV_CLIENT_SECRET || process.env.QUICKBOOKS_CLIENT_SECRET || '';
      return { clientId, clientSecret };
    }
  }

  /**
   * Build redirect URI dynamically based on request domain AND environment
   * In sandbox/dev mode: ALWAYS use the Replit dev domain (ignore QUICKBOOKS_REDIRECT_URI)
   * In production mode: Use QUICKBOOKS_REDIRECT_URI or canonical production host
   * SECURITY: Uses validated canonical host to prevent host header injection
   * 
   * CRITICAL FIX: QUICKBOOKS_REDIRECT_URI is a shared secret set to the production
   * domain (coaileague.com). Using it in dev mode causes redirect_uri mismatch
   * because the Intuit sandbox app has the Replit dev domain registered, not coaileague.com.
   */
  private buildRedirectUri(requestDomain?: string): string {
    const isProductionRuntime = process.env.REPLIT_DEPLOYMENT === '1' || 
                                 process.env.NODE_ENV === 'production';

    if (isProductionRuntime) {
      if (process.env.QUICKBOOKS_REDIRECT_URI) {
        return process.env.QUICKBOOKS_REDIRECT_URI;
      }
      const canonicalHost = INTEGRATIONS.quickbooks.getCanonicalHost(requestDomain);
      if (canonicalHost) {
        return `https://${canonicalHost}/api/integrations/quickbooks/callback`;
      }
      return this.redirectUri;
    }

    const devDomain = process.env.REPLIT_DEV_DOMAIN || 
                       (process.env.REPLIT_DOMAINS ? process.env.REPLIT_DOMAINS.split(',')[0] : '');
    if (devDomain) {
      const uri = `https://${devDomain}/api/integrations/quickbooks/callback`;
      console.log(`[QuickBooks OAuth] Dev mode: using Replit domain redirect URI: ${uri}`);
      return uri;
    }

    return this.redirectUri || 'http://localhost:5000/api/integrations/quickbooks/callback';
  }

  /**
   * Generate authorization URL for user to grant access with PKCE
   * 
   * @param workspaceId - Workspace requesting authorization
   * @param requestDomain - Optional domain from the request for dynamic environment detection
   * @returns Authorization URL and state token
   */
  async generateAuthorizationUrl(workspaceId: string, requestDomain?: string): Promise<{ url: string; state: string }> {
    // STEP 1: Clean up expired states first (TTL enforcement)
    await this.cleanupExpiredStates();
    
    // STEP 2: Delete all previous states for this workspace (one-active-state pattern)
    // This ensures clicking "Connect" always starts fresh regardless of past failures
    await this.deleteWorkspaceStates(workspaceId);
    
    // STEP 3: Get credentials based on domain (auto-detect dev vs prod)
    const { clientId, isProduction } = this.getCredentialsForDomain(requestDomain);
    
    if (!clientId) {
      throw new Error('QuickBooks credentials not configured. Check QUICKBOOKS_DEV_CLIENT_ID and QUICKBOOKS_PROD_CLIENT_ID in Replit Secrets.');
    }
    
    console.log(`[QuickBooks OAuth] Client ID for auth URL: ${clientId.substring(0, 10)}...`);
    
    // Generate CSRF protection state token
    const state = crypto.randomBytes(32).toString('hex');
    
    // Generate PKCE code verifier and challenge
    const codeVerifier = crypto.randomBytes(32).toString('base64url');
    const codeChallenge = crypto.createHash('sha256')
      .update(codeVerifier)
      .digest('base64url');
    
    // Build redirect URI dynamically based on request domain
    const dynamicRedirectUri = this.buildRedirectUri(requestDomain);
    
    // Detect environment based on domain
    const qbEnvironment = isProduction ? 'production' : 'sandbox';
    
    console.log(`[QuickBooks OAuth] Dynamic redirect URI: ${dynamicRedirectUri}`);
    console.log(`[QuickBooks OAuth] Environment: ${qbEnvironment}`);
    
    // Store state and PKCE verifier in database (expires in 10 minutes)
    const expiresAt = new Date(Date.now() + 10 * 60 * 1000);
    
    await db.insert(oauthStates).values({
      workspaceId,
      partnerType: 'quickbooks',
      state,
      codeVerifier,
      codeChallenge,
      codeChallengeMethod: 'S256',
      expiresAt,
    });
    
    const params = new URLSearchParams({
      client_id: clientId,
      redirect_uri: dynamicRedirectUri,
      response_type: 'code',
      scope: 'com.intuit.quickbooks.accounting', // Full accounting scope
      state,
      code_challenge: codeChallenge,
      code_challenge_method: 'S256',
    });

    const authUrl = `${this.authorizationEndpoint}?${params.toString()}`;

    return { url: authUrl, state };
  }

  /**
   * Exchange authorization code for access tokens with PKCE
   * 
   * @param code - Authorization code from callback
   * @param state - State token for CSRF validation
   * @param realmId - QuickBooks company ID (from callback)
   */
  async exchangeCodeForTokens(
    code: string,
    state: string,
    realmId: string,
    requestDomain?: string
  ): Promise<{ workspaceId: string; connection: any }> {
    // Clean up expired states before validation to prevent stale record buildup
    await this.cleanupExpiredStates();
    
    // Validate state and get PKCE verifier from database
    const [oauthState] = await db.select()
      .from(oauthStates)
      .where(
        and(
          eq(oauthStates.state, state),
          eq(oauthStates.partnerType, 'quickbooks')
        )
      )
      .limit(1);
    
    if (!oauthState) {
      throw new Error('Invalid or expired state token');
    }
    
    // Check expiry
    if (new Date() > oauthState.expiresAt) {
      // Clean up expired state
      await db.delete(oauthStates).where(eq(oauthStates.id, oauthState.id));
      throw new Error('State token expired - please try again');
    }
    
    const workspaceId = oauthState.workspaceId;
    
    // Get credentials and environment based on domain (must match what was used in authorization)
    const { clientId, clientSecret, isProduction } = this.getCredentialsForDomain(requestDomain);
    const qbEnvironment = isProduction ? 'production' : 'sandbox';
    
    // Build redirect URI dynamically - must match what was used in authorization
    const dynamicRedirectUri = this.buildRedirectUri(requestDomain);
    console.log(`[QuickBooks OAuth] Token exchange using redirect URI: ${dynamicRedirectUri} (environment: ${qbEnvironment})`);

    // Exchange code for tokens with PKCE
    const response = await fetch(this.tokenEndpoint, {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/x-www-form-urlencoded',
        'Authorization': `Basic ${Buffer.from(`${clientId}:${clientSecret}`).toString('base64')}`,
      },
      body: new URLSearchParams({
        grant_type: 'authorization_code',
        code,
        redirect_uri: dynamicRedirectUri,
        code_verifier: oauthState.codeVerifier || '',
      }),
    });

    if (!response.ok) {
      const error = await response.text();
      throw new Error(`Failed to exchange code for tokens: ${error}`);
    }

    const tokens: QuickBooksTokenResponse = await response.json();

    // Clean up used state token
    await db.delete(oauthStates).where(eq(oauthStates.id, oauthState.id));

    // Calculate token expiry times
    const now = new Date();
    const expiresAt = new Date(now.getTime() + tokens.expires_in * 1000);
    const refreshTokenExpiresAt = new Date(now.getTime() + tokens.x_refresh_token_expires_in * 1000);

    // Encrypt tokens before storage
    const encryptedAccessToken = encryptToken(tokens.access_token);
    const encryptedRefreshToken = encryptToken(tokens.refresh_token);

    // Check if connection already exists
    const existing = await db.select()
      .from(partnerConnections)
      .where(
        and(
          eq(partnerConnections.workspaceId, workspaceId),
          eq(partnerConnections.partnerType, 'quickbooks')
        )
      )
      .limit(1);

    let connection;

    if (existing.length > 0) {
      // Update existing connection
      const [updated] = await db.update(partnerConnections)
        .set({
          status: 'connected',
          accessToken: encryptedAccessToken,
          refreshToken: encryptedRefreshToken,
          expiresAt,
          refreshTokenExpiresAt,
          realmId,
          metadata: {
            companyId: realmId,
            tokenType: tokens.token_type,
            environment: qbEnvironment, // Store environment for consistent refresh/revoke
          },
          lastSyncAt: now,
        })
        .where(eq(partnerConnections.id, existing[0].id))
        .returning();
      
      connection = updated;
    } else {
      // Create new connection
      const [created] = await db.insert(partnerConnections).values({
        workspaceId,
        partnerType: 'quickbooks',
        partnerName: 'QuickBooks Online',
        status: 'connected',
        accessToken: encryptedAccessToken,
        refreshToken: encryptedRefreshToken,
        expiresAt,
        refreshTokenExpiresAt,
        realmId,
        metadata: {
          companyId: realmId,
          tokenType: tokens.token_type,
          environment: qbEnvironment, // Store environment for consistent refresh/revoke
        },
        lastSyncAt: now,
      }).returning();
      
      connection = created;
    }

    // Clean up old expired states (housekeeping)
    await db.delete(oauthStates)
      .where(lt(oauthStates.expiresAt, now));

    return { workspaceId, connection };
  }

  /**
   * Refresh access token using refresh token
   * 
   * @param connectionId - Partner connection ID
   */
  async refreshAccessToken(connectionId: string): Promise<void> {
    const [connection] = await db.select()
      .from(partnerConnections)
      .where(eq(partnerConnections.id, connectionId))
      .limit(1);

    if (!connection || !connection.refreshToken) {
      throw new Error('Connection not found or refresh token missing');
    }

    // Check if refresh token is expired
    if (connection.refreshTokenExpiresAt && new Date() > connection.refreshTokenExpiresAt) {
      // Refresh token expired - mark connection as expired
      await db.update(partnerConnections)
        .set({ status: 'expired' })
        .where(eq(partnerConnections.id, connectionId));
      
      throw new Error('Refresh token expired - user must reconnect');
    }

    // Decrypt refresh token
    const decryptedRefreshToken = decryptToken(connection.refreshToken);
    if (!decryptedRefreshToken) {
      throw new Error('Failed to decrypt refresh token');
    }
    
    // Use environment from connection metadata for consistency
    const connectionMetadata = connection.metadata as Record<string, any> | null;
    const { clientId, clientSecret } = this.getCredentialsForBackgroundOps(connectionMetadata || undefined);

    const response = await fetch(this.tokenEndpoint, {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/x-www-form-urlencoded',
        'Authorization': `Basic ${Buffer.from(`${clientId}:${clientSecret}`).toString('base64')}`,
      },
      body: new URLSearchParams({
        grant_type: 'refresh_token',
        refresh_token: decryptedRefreshToken,
      }),
    });

    if (!response.ok) {
      const error = await response.text();
      
      // Check if refresh token is invalid/revoked
      if (response.status === 400 || response.status === 401) {
        await db.update(partnerConnections)
          .set({ status: 'expired' })
          .where(eq(partnerConnections.id, connectionId));
        
        throw new Error('Refresh token invalid - user must reconnect');
      }
      
      throw new Error(`Failed to refresh token: ${error}`);
    }

    const tokens: QuickBooksTokenResponse = await response.json();

    // Calculate new expiry times
    const now = new Date();
    const expiresAt = new Date(now.getTime() + tokens.expires_in * 1000);
    const refreshTokenExpiresAt = new Date(now.getTime() + tokens.x_refresh_token_expires_in * 1000);

    // Encrypt new tokens
    const encryptedAccessToken = encryptToken(tokens.access_token);
    const encryptedRefreshToken = encryptToken(tokens.refresh_token);

    // Update connection with new tokens
    await db.update(partnerConnections)
      .set({
        accessToken: encryptedAccessToken,
        refreshToken: encryptedRefreshToken,
        expiresAt,
        refreshTokenExpiresAt,
        status: 'connected',
      })
      .where(eq(partnerConnections.id, connectionId));
  }

  /**
   * Disconnect (revoke) QuickBooks connection
   * 
   * @param connectionId - Partner connection ID
   */
  async disconnect(connectionId: string): Promise<void> {
    const [connection] = await db.select()
      .from(partnerConnections)
      .where(eq(partnerConnections.id, connectionId))
      .limit(1);

    if (!connection || !connection.refreshToken) {
      throw new Error('Connection not found');
    }

    // Decrypt and revoke tokens with QuickBooks
    try {
      const decryptedRefreshToken = decryptToken(connection.refreshToken);
      if (!decryptedRefreshToken) {
        console.warn('Could not decrypt refresh token for revocation');
      } else {
        // Use environment from connection metadata for consistency
        const connectionMetadata = connection.metadata as Record<string, any> | null;
        const { clientId, clientSecret } = this.getCredentialsForBackgroundOps(connectionMetadata || undefined);
        
        const response = await fetch(this.revokeEndpoint, {
          method: 'POST',
          headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/x-www-form-urlencoded',
            'Authorization': `Basic ${Buffer.from(`${clientId}:${clientSecret}`).toString('base64')}`,
          },
          body: new URLSearchParams({
            token: decryptedRefreshToken,
          }),
        });

        if (!response.ok) {
          console.error('Failed to revoke QuickBooks tokens:', await response.text());
          // Continue anyway - we'll mark as disconnected locally
        }
      }
    } catch (error) {
      console.error('Error revoking QuickBooks tokens:', error);
      // Continue anyway
    }

    // Mark connection as disconnected
    await db.update(partnerConnections)
      .set({
        status: 'disconnected',
        accessToken: '',
        refreshToken: '',
      })
      .where(eq(partnerConnections.id, connectionId));
  }

  /**
   * Get decrypted access token without auto-refresh
   * Used by orchestration layer which handles refresh separately
   * 
   * @param connectionId - Partner connection ID
   * @returns Decrypted access token or null if not available
   */
  getDecryptedAccessToken(connectionId: string): string | null {
    // This is synchronous - just decrypt the stored token
    // Orchestration layer handles token validation/refresh separately
    return this.getCachedDecryptedToken(connectionId);
  }

  private cachedTokens: Map<string, { token: string; fetchedAt: number }> = new Map();

  /**
   * Get cached decrypted token or fetch from database
   * @internal
   */
  private getCachedDecryptedToken(connectionId: string): string | null {
    const cached = this.cachedTokens.get(connectionId);
    const now = Date.now();
    
    // Cache valid for 30 seconds
    if (cached && (now - cached.fetchedAt) < 30000) {
      return cached.token;
    }
    
    // For sync method, we can't await - caller should use async version
    return null;
  }

  /**
   * Get decrypted access token (async version with DB lookup)
   * 
   * @param connectionId - Partner connection ID
   * @returns Decrypted access token or null
   */
  async getDecryptedAccessTokenAsync(connectionId: string): Promise<string | null> {
    const [connection] = await db.select()
      .from(partnerConnections)
      .where(eq(partnerConnections.id, connectionId))
      .limit(1);

    if (!connection || !connection.accessToken) {
      return null;
    }

    const decrypted = decryptToken(connection.accessToken);
    if (decrypted) {
      this.cachedTokens.set(connectionId, { token: decrypted, fetchedAt: Date.now() });
    }
    return decrypted;
  }

  /**
   * Get valid access token (refreshes if expired)
   * 
   * @param connectionId - Partner connection ID
   * @returns Valid access token
   */
  async getValidAccessToken(connectionId: string): Promise<string> {
    const [connection] = await db.select()
      .from(partnerConnections)
      .where(eq(partnerConnections.id, connectionId))
      .limit(1);

    if (!connection || !connection.accessToken) {
      throw new Error('Connection not found or access token missing');
    }

    // Check if access token is expired (refresh 5 minutes before expiry)
    const expiryBuffer = 5 * 60 * 1000; // 5 minutes
    const now = new Date();
    const isExpiringSoon = connection.expiresAt && 
      (now.getTime() + expiryBuffer) >= connection.expiresAt.getTime();

    if (isExpiringSoon) {
      // Refresh token
      await this.refreshAccessToken(connectionId);
      
      // Fetch updated connection
      const [updated] = await db.select()
        .from(partnerConnections)
        .where(eq(partnerConnections.id, connectionId))
        .limit(1);
      
      if (!updated?.accessToken) {
        throw new Error('Failed to refresh access token');
      }
      
      // Decrypt and return
      return decryptToken(updated.accessToken) || '';
    }

    // Decrypt and return current token
    return decryptToken(connection.accessToken) || '';
  }

  /**
   * Start scheduled cleanup job for stale OAuth states
   * Runs every hour to clean up expired states that weren't properly cleaned
   * Uses idempotent guard to prevent multiple intervals if called more than once
   */
  startScheduledCleanup(): void {
    // Idempotent guard - prevent multiple intervals
    if (QuickBooksOAuthService.cleanupScheduled) {
      console.log(`[QuickBooks OAuth] Scheduled cleanup already running, skipping duplicate start`);
      return;
    }
    QuickBooksOAuthService.cleanupScheduled = true;
    
    const ONE_HOUR_MS = 60 * 60 * 1000;
    
    // Run immediately on startup
    this.cleanupExpiredStates().then(count => {
      if (count > 0) {
        console.log(`[QuickBooks OAuth] Startup cleanup: removed ${count} expired states`);
      }
    }).catch(err => {
      console.error('[QuickBooks OAuth] Startup cleanup error:', err);
    });
    
    // Schedule hourly cleanup
    setInterval(async () => {
      try {
        const count = await this.cleanupExpiredStates();
        if (count > 0) {
          console.log(`[QuickBooks OAuth] Scheduled cleanup: removed ${count} expired states`);
        }
      } catch (error) {
        console.error('[QuickBooks OAuth] Scheduled cleanup error:', error);
      }
    }, ONE_HOUR_MS);
    
    console.log(`[QuickBooks OAuth] Scheduled cleanup job started (runs every hour)`);
  }
}

export const quickbooksOAuthService = new QuickBooksOAuthService();

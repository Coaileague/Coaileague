/**
 * Schema Parity Service - Dynamic schema validation against PostgreSQL
 * 
 * Automatically detects:
 * - Missing tables
 * - Missing columns
 * - Missing enums
 * - Type mismatches
 * 
 * NO HARDCODED VALUES - reads schema dynamically from Drizzle definitions
 */

import { db } from '../db';
import { sql, getTableName, getTableColumns } from 'drizzle-orm';
import * as schema from '@shared/schema';

interface SchemaIssue {
  type: 'missing_table' | 'missing_column' | 'missing_enum' | 'type_mismatch';
  table?: string;
  column?: string;
  enumName?: string;
  expected?: string;
  actual?: string;
  severity: 'critical' | 'warning';
  autoFixable: boolean;
}

interface ParityReport {
  timestamp: Date;
  totalIssues: number;
  criticalIssues: number;
  warningIssues: number;
  issues: SchemaIssue[];
  tablesChecked: number;
  columnsChecked: number;
  enumsChecked: number;
}

// Map Drizzle column types to PostgreSQL types
function drizzleTypeToPgType(columnDef: any): string {
  const dataType = columnDef.dataType;
  const columnType = columnDef.columnType;
  
  if (dataType === 'string') {
    if (columnType?.includes('PgText')) return 'text';
    return 'character varying';
  }
  if (dataType === 'number') {
    if (columnType?.includes('PgSerial')) return 'integer';
    if (columnType?.includes('PgInteger')) return 'integer';
    if (columnType?.includes('PgReal')) return 'real';
    if (columnType?.includes('PgDoublePrecision')) return 'double precision';
    return 'integer';
  }
  if (dataType === 'boolean') return 'boolean';
  if (dataType === 'date') return 'timestamp without time zone';
  if (dataType === 'json') return 'jsonb';
  if (dataType === 'array') return 'ARRAY';
  
  return 'unknown';
}

// Convert camelCase to snake_case for column names
function toSnakeCase(str: string): string {
  return str.replace(/[A-Z]/g, letter => `_${letter.toLowerCase()}`);
}

class SchemaParityService {
  private issues: SchemaIssue[] = [];
  
  /**
   * Run full schema parity check
   */
  async checkParity(): Promise<ParityReport> {
    console.log('[SchemaParity] Starting dynamic schema parity check...');
    this.issues = [];
    
    let tablesChecked = 0;
    let columnsChecked = 0;
    let enumsChecked = 0;
    
    try {
      // 1. Get all tables from PostgreSQL
      const pgTables = await this.getPostgresTables();
      
      // 2. Get all enums from PostgreSQL
      const pgEnums = await this.getPostgresEnums();
      
      // 3. Iterate through all Drizzle schema exports using Drizzle's helpers
      for (const [exportName, exportValue] of Object.entries(schema)) {
        if (!exportValue || typeof exportValue !== 'object') continue;
        
        // Try to get table name using Drizzle's helper
        let tableName: string | undefined;
        try {
          tableName = getTableName(exportValue as any);
        } catch {
          // Not a table - skip
          continue;
        }
        
        if (!tableName) continue;
        tablesChecked++;
        
        // Check if table exists in PostgreSQL
        if (!pgTables.has(tableName)) {
          this.issues.push({
            type: 'missing_table',
            table: tableName,
            severity: 'critical',
            autoFixable: false,
          });
          continue;
        }
        
        // Get columns from PostgreSQL for this table
        const pgColumns = await this.getPostgresTableColumns(tableName);
        
        // Get columns from Drizzle schema
        try {
          const drizzleColumns = getTableColumns(exportValue as any);
          
          for (const [colKey, colDef] of Object.entries(drizzleColumns)) {
            // Get the actual column name
            const actualColName = (colDef as any).name || toSnakeCase(colKey);
            columnsChecked++;
            
            if (!pgColumns.has(actualColName)) {
              // Determine if this column has a default value (makes it safer to add)
              const hasDefault = (colDef as any).hasDefault === true;
              const isNullable = (colDef as any).notNull !== true;
              
              this.issues.push({
                type: 'missing_column',
                table: tableName,
                column: actualColName,
                expected: drizzleTypeToPgType(colDef),
                severity: 'critical',
                autoFixable: hasDefault || isNullable,
              });
            }
          }
        } catch {
          // Could not get columns for this table
        }
      }
      
      // 4. Check for enums defined in schema
      const enumsInSchema = this.extractEnumsFromSchema();
      for (const [enumName, enumValues] of Object.entries(enumsInSchema)) {
        enumsChecked++;
        if (!pgEnums.has(enumName)) {
          this.issues.push({
            type: 'missing_enum',
            enumName,
            expected: enumValues.join(', '),
            severity: 'critical',
            autoFixable: true,
          });
        }
      }
      
    } catch (error) {
      console.error('[SchemaParity] Error during parity check:', error);
    }
    
    const report: ParityReport = {
      timestamp: new Date(),
      totalIssues: this.issues.length,
      criticalIssues: this.issues.filter(i => i.severity === 'critical').length,
      warningIssues: this.issues.filter(i => i.severity === 'warning').length,
      issues: this.issues,
      tablesChecked,
      columnsChecked,
      enumsChecked,
    };
    
    this.logReport(report);
    return report;
  }
  
  /**
   * Get all table names from PostgreSQL
   */
  private async getPostgresTables(): Promise<Set<string>> {
    const result = await db.execute(sql`
      SELECT table_name 
      FROM information_schema.tables 
      WHERE table_schema = 'public' 
      AND table_type = 'BASE TABLE'
    `);
    
    return new Set(result.rows.map((row: any) => row.table_name));
  }
  
  /**
   * Get all enum names from PostgreSQL
   */
  private async getPostgresEnums(): Promise<Set<string>> {
    const result = await db.execute(sql`
      SELECT typname FROM pg_type 
      WHERE typtype = 'e'
    `);
    
    return new Set(result.rows.map((row: any) => row.typname));
  }
  
  /**
   * Get all columns for a specific table from PostgreSQL
   */
  private async getPostgresTableColumns(tableName: string): Promise<Set<string>> {
    const result = await db.execute(sql`
      SELECT column_name 
      FROM information_schema.columns 
      WHERE table_schema = 'public' 
      AND table_name = ${tableName}
    `);
    
    return new Set(result.rows.map((row: any) => row.column_name));
  }
  
  /**
   * Extract enum definitions from schema using pgEnum exports
   */
  private extractEnumsFromSchema(): Record<string, string[]> {
    const enums: Record<string, string[]> = {};
    
    for (const [exportName, exportValue] of Object.entries(schema)) {
      // pgEnum exports have enumName and enumValues properties
      if (exportValue && typeof exportValue === 'object') {
        const enumObj = exportValue as any;
        if (enumObj.enumName && enumObj.enumValues) {
          enums[enumObj.enumName] = [...enumObj.enumValues];
        }
      }
    }
    
    return enums;
  }
  
  /**
   * Log the parity report
   */
  private logReport(report: ParityReport): void {
    if (report.totalIssues === 0) {
      console.log(`[SchemaParity] ✅ No parity issues found`);
      console.log(`[SchemaParity]    Checked: ${report.tablesChecked} tables, ${report.columnsChecked} columns, ${report.enumsChecked} enums`);
      return;
    }
    
    console.log(`[SchemaParity] ⚠️  Found ${report.totalIssues} parity issues:`);
    console.log(`[SchemaParity]    Critical: ${report.criticalIssues}, Warnings: ${report.warningIssues}`);
    console.log(`[SchemaParity]    Checked: ${report.tablesChecked} tables, ${report.columnsChecked} columns, ${report.enumsChecked} enums`);
    
    // Group issues by type
    const missingTables = report.issues.filter(i => i.type === 'missing_table');
    const missingColumns = report.issues.filter(i => i.type === 'missing_column');
    const missingEnums = report.issues.filter(i => i.type === 'missing_enum');
    
    if (missingTables.length > 0) {
      console.log(`[SchemaParity] ❌ Missing Tables (${missingTables.length}):`);
      missingTables.forEach(i => console.log(`[SchemaParity]    - ${i.table}`));
    }
    
    if (missingColumns.length > 0) {
      console.log(`[SchemaParity] ❌ Missing Columns (${missingColumns.length}):`);
      missingColumns.forEach(i => {
        const fixable = i.autoFixable ? ' [auto-fixable]' : '';
        console.log(`[SchemaParity]    - ${i.table}.${i.column} (${i.expected})${fixable}`);
      });
    }
    
    if (missingEnums.length > 0) {
      console.log(`[SchemaParity] ❌ Missing Enums (${missingEnums.length}):`);
      missingEnums.forEach(i => console.log(`[SchemaParity]    - ${i.enumName}: [${i.expected}]`));
    }
  }
  
  /**
   * Attempt to auto-fix issues that are safe to fix
   */
  async autoFix(): Promise<{ fixed: number; failed: number; skipped: number }> {
    const fixable = this.issues.filter(i => i.autoFixable);
    let fixed = 0;
    let failed = 0;
    let skipped = this.issues.length - fixable.length;
    
    console.log(`[SchemaParity] Attempting to auto-fix ${fixable.length} issues...`);
    
    for (const issue of fixable) {
      try {
        if (issue.type === 'missing_column') {
          await this.fixMissingColumn(issue);
          fixed++;
        } else if (issue.type === 'missing_enum') {
          await this.fixMissingEnum(issue);
          fixed++;
        }
      } catch (error) {
        console.error(`[SchemaParity] Failed to fix ${issue.type}:`, error);
        failed++;
      }
    }
    
    console.log(`[SchemaParity] Auto-fix complete: ${fixed} fixed, ${failed} failed, ${skipped} skipped`);
    return { fixed, failed, skipped };
  }
  
  /**
   * Add a missing column with safe defaults
   */
  private async fixMissingColumn(issue: SchemaIssue): Promise<void> {
    if (!issue.table || !issue.column) return;
    
    // Convert type to proper PostgreSQL syntax
    let pgType = issue.expected || 'text';
    
    // ARRAY type needs special handling - PostgreSQL uses TEXT[] not ARRAY
    if (pgType.toUpperCase() === 'ARRAY') {
      pgType = 'TEXT[]';  // Default to TEXT array for safety
    }
    
    // Use text type with NULL default for safety
    const alterSql = `ALTER TABLE "${issue.table}" ADD COLUMN IF NOT EXISTS "${issue.column}" ${pgType} DEFAULT NULL`;
    
    console.log(`[SchemaParity] Adding column: ${issue.table}.${issue.column}`);
    await db.execute(sql.raw(alterSql));
  }
  
  /**
   * Create a missing enum type
   */
  private async fixMissingEnum(issue: SchemaIssue): Promise<void> {
    if (!issue.enumName || !issue.expected) return;
    
    const values = issue.expected.split(', ').map(v => `'${v}'`).join(', ');
    const createSql = `CREATE TYPE "${issue.enumName}" AS ENUM (${values})`;
    
    console.log(`[SchemaParity] Creating enum: ${issue.enumName}`);
    await db.execute(sql.raw(createSql));
  }
  
  /**
   * Get current issues without re-running check
   */
  getIssues(): SchemaIssue[] {
    return this.issues;
  }
}

// Singleton instance
export const schemaParityService = new SchemaParityService();

/**
 * Run parity check at startup
 */
export async function runSchemaParityCheck(autoFix: boolean = false): Promise<ParityReport> {
  const report = await schemaParityService.checkParity();
  
  if (autoFix && report.totalIssues > 0) {
    await schemaParityService.autoFix();
    // Re-run check to confirm fixes
    return await schemaParityService.checkParity();
  }
  
  return report;
}

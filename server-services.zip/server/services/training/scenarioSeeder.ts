/**
 * Trinity Training Scenario Seeder
 * =================================
 * Seeds training shifts with varying difficulty levels for Trinity AI confidence building
 * 
 * Difficulty Levels:
 * - Easy: Simple shifts, no conflicts, clear matches
 * - Medium: Some availability conflicts, basic skill requirements
 * - Hard: Complex constraints, client preferences/exclusions, travel pay issues, low-score employees
 */

import { db } from '../../db';
import { shifts, employees, clients, trainingScenarios, trainingRuns, trainingAttempts } from '@shared/schema';
import { eq, and, inArray } from 'drizzle-orm';
import { randomUUID } from 'crypto';
import { broadcastToWorkspace } from '../../websocket';

export type DifficultyLevel = 'easy' | 'medium' | 'hard' | 'meta' | 'extreme';

interface ScenarioConfig {
  name: string;
  description: string;
  difficulty: DifficultyLevel;
  shiftsToCreate: number;
  constraintConfig: {
    availabilityConflicts: number; // 0-10, percentage of shifts with conflicts
    certificationRequirements: number; // 0-10
    clientPreferences: number; // 0-10
    clientExclusions: number; // 0-10
    travelPayIssues: number; // 0-10
    overtimeRisks: number; // 0-10
    lowScoreEmployees: number; // 0-10
  };
}

const SCENARIO_PRESETS: Record<DifficultyLevel, ScenarioConfig> = {
  easy: {
    name: 'Easy Training - Getting Started',
    description: 'Simple shifts with clear employee matches. No conflicts or complex constraints.',
    difficulty: 'easy',
    shiftsToCreate: 50,
    constraintConfig: {
      availabilityConflicts: 0,
      certificationRequirements: 1,
      clientPreferences: 0,
      clientExclusions: 0,
      travelPayIssues: 0,
      overtimeRisks: 0,
      lowScoreEmployees: 0,
    },
  },
  medium: {
    name: 'Medium Training - Building Skills',
    description: 'Shifts with some availability conflicts, basic skill requirements, and moderate complexity.',
    difficulty: 'medium',
    shiftsToCreate: 50,
    constraintConfig: {
      availabilityConflicts: 3,
      certificationRequirements: 4,
      clientPreferences: 2,
      clientExclusions: 1,
      travelPayIssues: 2,
      overtimeRisks: 2,
      lowScoreEmployees: 2,
    },
  },
  hard: {
    name: 'Hard Training - Master Challenge',
    description: 'Complex scheduling with multiple conflicting constraints, client exclusions, travel pay issues, and low-score employees.',
    difficulty: 'hard',
    shiftsToCreate: 50,
    constraintConfig: {
      availabilityConflicts: 7,
      certificationRequirements: 8,
      clientPreferences: 6,
      clientExclusions: 5,
      travelPayIssues: 7,
      overtimeRisks: 6,
      lowScoreEmployees: 5,
    },
  },
  meta: {
    name: 'META Training - Strategic Mastery',
    description: 'Advanced scenarios with competing priorities, budget constraints, multi-site coordination, and strategic trade-offs.',
    difficulty: 'meta',
    shiftsToCreate: 75,
    constraintConfig: {
      availabilityConflicts: 8,
      certificationRequirements: 9,
      clientPreferences: 8,
      clientExclusions: 7,
      travelPayIssues: 9,
      overtimeRisks: 8,
      lowScoreEmployees: 7,
    },
  },
  extreme: {
    name: 'EXTREME Training - Ultimate Challenge',
    description: 'Maximum complexity: all constraints at max, impossible trade-offs, emergency scenarios, and crisis management.',
    difficulty: 'extreme',
    shiftsToCreate: 100,
    constraintConfig: {
      availabilityConflicts: 10,
      certificationRequirements: 10,
      clientPreferences: 10,
      clientExclusions: 10,
      travelPayIssues: 10,
      overtimeRisks: 10,
      lowScoreEmployees: 10,
    },
  },
};

const CERTIFICATIONS = [
  'Armed Guard License',
  'Unarmed Guard License',
  'CPR/First Aid',
  'Fire Safety',
  'Crowd Control',
  'Executive Protection',
  'K-9 Handler',
  'HAZMAT Certified',
];

const SHIFT_TITLES = [
  'Security Patrol',
  'Front Desk Guard',
  'Event Security',
  'Night Watch',
  'Executive Protection',
  'Access Control',
  'Parking Lot Patrol',
  'Warehouse Security',
  'Retail Loss Prevention',
  'Hospital Security',
];

export class ScenarioSeederService {
  /**
   * Seed training shifts for a given difficulty level
   */
  async seedScenario(
    workspaceId: string, 
    difficulty: DifficultyLevel
  ): Promise<{
    scenarioId: string;
    runId: string;
    shiftsCreated: number;
    employeesAvailable: number;
    clientsAvailable: number;
  }> {
    const config = SCENARIO_PRESETS[difficulty];
    
    // Get existing employees and clients for this workspace
    const existingEmployees = await db.select().from(employees).where(eq(employees.workspaceId, workspaceId));
    const existingClients = await db.select().from(clients).where(eq(clients.workspaceId, workspaceId));
    
    if (existingEmployees.length === 0) {
      throw new Error('No employees found. Please add employees before seeding training scenarios.');
    }
    
    if (existingClients.length === 0) {
      throw new Error('No clients found. Please add clients before seeding training scenarios.');
    }
    
    // Create training scenario record
    const [scenario] = await db.insert(trainingScenarios).values({
      workspaceId,
      name: config.name,
      description: config.description,
      difficulty: config.difficulty,
      totalShifts: config.shiftsToCreate,
      constraintComplexity: Math.ceil(Object.values(config.constraintConfig).reduce((a, b) => a + b, 0) / 7),
      employeeVariety: existingEmployees.length,
      clientVariety: existingClients.length,
      hasAvailabilityConflicts: config.constraintConfig.availabilityConflicts > 0,
      hasCertificationRequirements: config.constraintConfig.certificationRequirements > 0,
      hasClientPreferences: config.constraintConfig.clientPreferences > 0,
      hasClientExclusions: config.constraintConfig.clientExclusions > 0,
      hasTravelPayConstraints: config.constraintConfig.travelPayIssues > 0,
      hasOvertimeRisks: config.constraintConfig.overtimeRisks > 0,
      hasLowScoreEmployees: config.constraintConfig.lowScoreEmployees > 0,
      isActive: true,
    }).returning();
    
    // Create training run record
    const [run] = await db.insert(trainingRuns).values({
      workspaceId,
      scenarioId: scenario.id,
      difficulty: config.difficulty,
      status: 'pending',
      totalShifts: config.shiftsToCreate,
      assignedShifts: 0,
      failedShifts: 0,
      confidenceStart: '0.5000',
    }).returning();
    
    // Generate shifts based on difficulty
    const shiftsToInsert = this.generateShifts(
      workspaceId,
      scenario.id,
      config,
      existingEmployees,
      existingClients
    );
    
    // Insert all shifts
    await db.insert(shifts).values(shiftsToInsert);
    
    console.log(`[ScenarioSeeder] Created ${shiftsToInsert.length} training shifts for ${difficulty} difficulty`);
    
    return {
      scenarioId: scenario.id,
      runId: run.id,
      shiftsCreated: shiftsToInsert.length,
      employeesAvailable: existingEmployees.length,
      clientsAvailable: existingClients.length,
    };
  }
  
  /**
   * Generate shift data based on configuration
   */
  private generateShifts(
    workspaceId: string,
    scenarioId: string,
    config: ScenarioConfig,
    employees: any[],
    clients: any[]
  ) {
    const shiftsData: any[] = [];
    const startDate = new Date();
    startDate.setHours(6, 0, 0, 0);
    // Start TODAY so shifts appear immediately in the schedule (not tomorrow)
    // This allows users to see open shifts right away after clearing training
    
    for (let i = 0; i < config.shiftsToCreate; i++) {
      const client = clients[i % clients.length];
      const shiftDate = new Date(startDate);
      shiftDate.setDate(shiftDate.getDate() + Math.floor(i / 4)); // 4 shifts per day
      
      const hourOffset = (i % 4) * 6; // 6, 12, 18, 24 (wraps)
      const startTime = new Date(shiftDate);
      startTime.setHours(6 + hourOffset, 0, 0, 0);
      
      const endTime = new Date(startTime);
      endTime.setHours(endTime.getHours() + 8); // 8-hour shifts
      
      // Apply constraints based on difficulty
      const constraints = this.generateConstraints(config, employees, i);
      
      shiftsData.push({
        workspaceId,
        employeeId: null, // Open shift - Trinity needs to assign
        clientId: client.id,
        title: SHIFT_TITLES[i % SHIFT_TITLES.length],
        description: `Training shift ${i + 1} - ${config.difficulty} difficulty`,
        startTime,
        endTime,
        status: 'draft', // Valid shift_status enum: draft, published, scheduled, in_progress, completed, cancelled
        aiGenerated: false,
        isTrainingShift: true,
        scenarioId,
        difficultyLevel: config.difficulty,
        contractRate: this.randomDecimal(25, 75).toString(), // $25-75/hr contract rate
        travelPay: constraints.hasTravelPay ? this.randomDecimal(10, 50).toString() : null,
        travelDistanceMiles: constraints.hasTravelPay ? this.randomDecimal(5, 50).toString() : null,
        requiredCertifications: constraints.certifications,
        preferredEmployeeIds: constraints.preferredEmployees,
        excludedEmployeeIds: constraints.excludedEmployees,
        minimumScore: constraints.minimumScore?.toString() || null,
        riskScore: constraints.riskScore.toString(),
        riskFactors: constraints.riskFactors,
      });
    }
    
    return shiftsData;
  }
  
  /**
   * Generate constraints for a shift based on difficulty config
   */
  private generateConstraints(
    config: ScenarioConfig,
    employees: any[],
    shiftIndex: number
  ) {
    const cc = config.constraintConfig;
    const employeeIds = employees.map(e => e.id);
    
    // Randomly apply constraints based on config levels (0-10)
    const hasCertifications = Math.random() * 10 < cc.certificationRequirements;
    const hasPreferences = Math.random() * 10 < cc.clientPreferences;
    const hasExclusions = Math.random() * 10 < cc.clientExclusions;
    const hasTravelPay = Math.random() * 10 < cc.travelPayIssues;
    const hasMinScore = Math.random() * 10 < cc.lowScoreEmployees;
    
    // Generate risk factors
    const riskFactors: string[] = [];
    if (cc.overtimeRisks > 0 && Math.random() * 10 < cc.overtimeRisks) {
      riskFactors.push('overtime_risk');
    }
    if (hasTravelPay) {
      riskFactors.push('high_travel_cost');
    }
    if (cc.availabilityConflicts > 0 && Math.random() * 10 < cc.availabilityConflicts) {
      riskFactors.push('availability_conflict');
    }
    
    return {
      certifications: hasCertifications 
        ? this.randomSubset(CERTIFICATIONS, 1, 3) 
        : [],
      preferredEmployees: hasPreferences 
        ? this.randomSubset(employeeIds, 1, Math.min(3, employeeIds.length)) 
        : [],
      excludedEmployees: hasExclusions 
        ? this.randomSubset(employeeIds, 1, Math.min(2, employeeIds.length)) 
        : [],
      hasTravelPay,
      minimumScore: hasMinScore ? this.randomDecimal(0.6, 0.9) : null,
      riskScore: this.randomDecimal(0.1, config.difficulty === 'hard' ? 0.8 : config.difficulty === 'medium' ? 0.5 : 0.3),
      riskFactors,
    };
  }
  
  /**
   * Clear training shift assignments (re-open shifts for next training run)
   * This nullifies employeeId but keeps the shifts intact
   */
  async clearAssignments(workspaceId: string): Promise<{
    shiftsCleared: number;
    runReset: boolean;
  }> {
    // Get active scenario
    const [activeScenario] = await db.select()
      .from(trainingScenarios)
      .where(and(
        eq(trainingScenarios.workspaceId, workspaceId),
        eq(trainingScenarios.isActive, true)
      ))
      .limit(1);
    
    if (!activeScenario) {
      return { shiftsCleared: 0, runReset: false };
    }
    
    // Clear employee assignments on training shifts (re-open them)
    const clearedShifts = await db.update(shifts)
      .set({
        employeeId: null,
        status: 'draft', // Use 'draft' as 'open' is not a valid shift_status enum
      })
      .where(and(
        eq(shifts.workspaceId, workspaceId),
        eq(shifts.isTrainingShift, true),
        eq(shifts.scenarioId, activeScenario.id)
      ))
      .returning();
    
    // Reset the training run metrics including thoughtLog
    await db.update(trainingRuns)
      .set({
        status: 'pending',
        assignedShifts: 0,
        failedShifts: 0,
        averageConfidence: null,
        totalCreditsUsed: null,
        thoughtLog: null,
        confidenceDelta: null,
        lessonsLearned: null,
        startedAt: null,
        completedAt: null,
        updatedAt: new Date(),
      })
      .where(eq(trainingRuns.scenarioId, activeScenario.id));
    
    console.log(`[ScenarioSeeder] Cleared ${clearedShifts.length} shift assignments for next training run`);
    
    return {
      shiftsCleared: clearedShifts.length,
      runReset: true,
    };
  }
  
  /**
   * Delete all training data for a workspace (full reset)
   */
  async resetTraining(workspaceId: string): Promise<{
    shiftsDeleted: number;
    scenariosDeleted: number;
    runsDeleted: number;
  }> {
    // Delete training shifts
    const deletedShifts = await db.delete(shifts)
      .where(and(
        eq(shifts.workspaceId, workspaceId),
        eq(shifts.isTrainingShift, true)
      ))
      .returning();
    
    // Delete training runs
    const deletedRuns = await db.delete(trainingRuns)
      .where(eq(trainingRuns.workspaceId, workspaceId))
      .returning();
    
    // Delete training scenarios
    const deletedScenarios = await db.delete(trainingScenarios)
      .where(eq(trainingScenarios.workspaceId, workspaceId))
      .returning();
    
    console.log(`[ScenarioSeeder] Full reset: ${deletedShifts.length} shifts, ${deletedScenarios.length} scenarios, ${deletedRuns.length} runs deleted`);
    
    return {
      shiftsDeleted: deletedShifts.length,
      scenariosDeleted: deletedScenarios.length,
      runsDeleted: deletedRuns.length,
    };
  }
  
  /**
   * Get current training status
   */
  async getTrainingStatus(workspaceId: string): Promise<{
    hasActiveScenario: boolean;
    currentScenario: any | null;
    currentRun: any | null;
    shiftsRemaining: number;
    shiftsAssigned: number;
  }> {
    const [activeScenario] = await db.select()
      .from(trainingScenarios)
      .where(and(
        eq(trainingScenarios.workspaceId, workspaceId),
        eq(trainingScenarios.isActive, true)
      ))
      .limit(1);
    
    if (!activeScenario) {
      return {
        hasActiveScenario: false,
        currentScenario: null,
        currentRun: null,
        shiftsRemaining: 0,
        shiftsAssigned: 0,
      };
    }
    
    const [currentRun] = await db.select()
      .from(trainingRuns)
      .where(eq(trainingRuns.scenarioId, activeScenario.id))
      .limit(1);
    
    // Count unassigned training shifts
    const trainingShifts = await db.select()
      .from(shifts)
      .where(and(
        eq(shifts.workspaceId, workspaceId),
        eq(shifts.isTrainingShift, true),
        eq(shifts.scenarioId, activeScenario.id)
      ));
    
    const unassigned = trainingShifts.filter(s => !s.employeeId);
    const assigned = trainingShifts.filter(s => s.employeeId);
    
    return {
      hasActiveScenario: true,
      currentScenario: activeScenario,
      currentRun: currentRun || null,
      shiftsRemaining: unassigned.length,
      shiftsAssigned: assigned.length,
    };
  }
  
  /**
   * Start a training run - Trinity attempts to fill all open shifts
   * This now actually processes shifts with AI and shows thinking patterns
   */
  async startTrainingRun(workspaceId: string, runId: string): Promise<void> {
    // Mark as running
    await db.update(trainingRuns)
      .set({
        status: 'running',
        startedAt: new Date(),
        updatedAt: new Date(),
      })
      .where(eq(trainingRuns.id, runId));

    // Start async processing (don't await - let it run in background)
    this.processTrainingShifts(workspaceId, runId).catch(err => {
      console.error('[ScenarioSeeder] Training processing error:', err);
    });
  }

  /**
   * Process training shifts with AI-powered assignment and thinking patterns
   */
  private async processTrainingShifts(workspaceId: string, runId: string): Promise<void> {
    console.log(`[ScenarioSeeder] Starting training run ${runId}`);
    const startTime = Date.now();
    
    // Get the current run to find the scenario
    const [run] = await db.select().from(trainingRuns).where(eq(trainingRuns.id, runId)).limit(1);
    if (!run) {
      console.error('[ScenarioSeeder] Run not found:', runId);
      return;
    }

    // Get all unassigned training shifts for this scenario
    const unassignedShifts = await db.select()
      .from(shifts)
      .where(and(
        eq(shifts.workspaceId, workspaceId),
        eq(shifts.isTrainingShift, true),
        eq(shifts.scenarioId, run.scenarioId)
      ));

    const shiftsToProcess = unassignedShifts.filter(s => !s.employeeId);
    console.log(`[ScenarioSeeder] Found ${shiftsToProcess.length} shifts to process`);
    
    // BROADCAST: Trinity scheduling started
    broadcastToWorkspace(workspaceId, {
      type: 'trinity_scheduling_started',
      sessionId: runId,
      totalShifts: shiftsToProcess.length,
      timestamp: Date.now(),
    });
    console.log(`[ScenarioSeeder] Broadcast trinity_scheduling_started to workspace ${workspaceId}`);

    // Get all available employees
    const availableEmployees = await db.select().from(employees).where(eq(employees.workspaceId, workspaceId));
    
    if (availableEmployees.length === 0) {
      console.error('[ScenarioSeeder] No employees available');
      await this.completeTrainingRun(runId, {
        assignedShifts: 0,
        failedShifts: shiftsToProcess.length,
        averageConfidence: 0,
        totalCreditsUsed: 0,
        thoughtLog: ['Error: No employees available in workspace'],
        lessonsLearned: ['Ensure employees are added before training'],
      });
      return;
    }

    let assignedCount = 0;
    let failedCount = 0;
    let totalConfidence = 0;
    const thoughtLog: string[] = [];
    const lessonsLearned: string[] = [];
    
    // Leave ~25% of shifts unassigned to demonstrate Open Shifts row functionality
    // This shows users how the auto-fill feature works with remaining open shifts
    const shiftsToAutoAssign = Math.ceil(shiftsToProcess.length * 0.75);
    const shiftsToLeaveOpen = shiftsToProcess.length - shiftsToAutoAssign;
    console.log(`[ScenarioSeeder] Will assign ${shiftsToAutoAssign} shifts, leave ${shiftsToLeaveOpen} as open shifts`);

    // Process each shift with a small delay to show visible progress
    for (let i = 0; i < shiftsToAutoAssign; i++) {
      const shift = shiftsToProcess[i];
      
      try {
        // Add thinking step
        const thinkingStep = `[${i + 1}/${shiftsToProcess.length}] Analyzing shift: ${shift.title}`;
        thoughtLog.push(thinkingStep);
        console.log(`[ScenarioSeeder] ${thinkingStep}`);
        
        // BROADCAST: Processing this shift
        broadcastToWorkspace(workspaceId, {
          type: 'trinity_scheduling_progress',
          currentShiftId: shift.id,
          currentIndex: i + 1,
          totalShifts: shiftsToProcess.length,
          status: 'analyzing',
          message: `Analyzing: ${shift.title}`,
          shiftTitle: shift.title,
        });

        // Find best employee for this shift
        const result = await this.findBestEmployeeForShift(shift, availableEmployees, thoughtLog);
        
        if (result.employee) {
          // Assign employee to shift
          await db.update(shifts)
            .set({
              employeeId: result.employee.id,
              status: 'scheduled', // Valid enum: draft, published, scheduled, in_progress, completed, cancelled
            })
            .where(eq(shifts.id, shift.id));
          
          assignedCount++;
          totalConfidence += result.confidence;
          
          thoughtLog.push(`✓ Assigned ${result.employee.firstName} ${result.employee.lastName} (confidence: ${(result.confidence * 100).toFixed(1)}%)`);
          thoughtLog.push(`  Reasoning: ${result.reasoning}`);
          
          // BROADCAST: Shift successfully assigned
          broadcastToWorkspace(workspaceId, {
            type: 'trinity_scheduling_progress',
            currentShiftId: shift.id,
            currentIndex: i + 1,
            totalShifts: shiftsToProcess.length,
            status: 'assigned',
            message: `Assigned ${result.employee.firstName} ${result.employee.lastName} to ${shift.title}`,
            employeeId: result.employee.id,
            employeeName: `${result.employee.firstName} ${result.employee.lastName}`,
            confidence: result.confidence,
          });
        } else {
          failedCount++;
          thoughtLog.push(`✗ Could not assign: ${result.reasoning}`);
          
          // BROADCAST: Could not assign shift
          broadcastToWorkspace(workspaceId, {
            type: 'trinity_scheduling_progress',
            currentShiftId: shift.id,
            currentIndex: i + 1,
            totalShifts: shiftsToProcess.length,
            status: 'skipped',
            message: `Skipped: ${result.reasoning}`,
          });
        }

        // Update progress in database after each shift
        await db.update(trainingRuns)
          .set({
            assignedShifts: assignedCount,
            failedShifts: failedCount,
            thoughtLog: thoughtLog.slice(-50), // Keep last 50 entries
            updatedAt: new Date(),
          })
          .where(eq(trainingRuns.id, runId));

        // Small delay to show visible progress and let UI animate (200ms per shift)
        await new Promise(resolve => setTimeout(resolve, 200));

      } catch (error: any) {
        failedCount++;
        thoughtLog.push(`✗ Error processing shift ${shift.id}: ${error.message}`);
        console.error(`[ScenarioSeeder] Error processing shift:`, error);
        
        // BROADCAST: Error processing shift
        broadcastToWorkspace(workspaceId, {
          type: 'trinity_scheduling_progress',
          currentShiftId: shift.id,
          currentIndex: i + 1,
          totalShifts: shiftsToProcess.length,
          status: 'error',
          message: `Error: ${error.message}`,
        });
      }
    }

    // Generate lessons learned
    if (assignedCount > 0) {
      lessonsLearned.push(`Successfully assigned ${assignedCount} of ${shiftsToProcess.length} shifts`);
    }
    if (failedCount > 0) {
      lessonsLearned.push(`${failedCount} shifts could not be assigned - review constraints`);
    }
    if (assignedCount > 0 && totalConfidence / assignedCount > 0.8) {
      lessonsLearned.push('High confidence assignments - good employee-shift matching');
    }

    // Complete the training run
    await this.completeTrainingRun(runId, {
      assignedShifts: assignedCount,
      failedShifts: failedCount,
      averageConfidence: assignedCount > 0 ? totalConfidence / assignedCount : 0,
      totalCreditsUsed: shiftsToProcess.length * 0.01, // Simulated credit usage
      thoughtLog,
      lessonsLearned,
    });
    
    // BROADCAST: Trinity scheduling completed
    broadcastToWorkspace(workspaceId, {
      type: 'trinity_scheduling_completed',
      sessionId: runId,
      totalAssigned: assignedCount,
      totalFailed: failedCount,
      totalShifts: shiftsToProcess.length,
      openShiftsRemaining: shiftsToLeaveOpen,
      duration: Date.now() - startTime,
      mutationCount: assignedCount,
      summary: {
        openShiftsFilled: assignedCount,
        openShiftsRemaining: shiftsToLeaveOpen,
        shiftsCreated: 0,
        employeesSwapped: 0,
        shiftsEdited: 0,
        shiftsDeleted: 0,
      },
    });
    console.log(`[ScenarioSeeder] Broadcast trinity_scheduling_completed to workspace ${workspaceId} (${shiftsToLeaveOpen} open shifts remaining)`);

    console.log(`[ScenarioSeeder] Training run completed: ${assignedCount} assigned, ${failedCount} failed`);
  }

  /**
   * Find the best employee for a given shift using scoring logic
   */
  private async findBestEmployeeForShift(
    shift: any,
    availableEmployees: any[],
    thoughtLog: string[]
  ): Promise<{
    employee: any | null;
    confidence: number;
    reasoning: string;
  }> {
    // Filter out excluded employees
    const excludedIds = shift.excludedEmployeeIds || [];
    let candidates = availableEmployees.filter(e => !excludedIds.includes(e.id));

    if (candidates.length === 0) {
      return {
        employee: null,
        confidence: 0,
        reasoning: 'All employees are excluded from this shift',
      };
    }

    // Prefer employees from preferred list if any
    const preferredIds = shift.preferredEmployeeIds || [];
    if (preferredIds.length > 0) {
      const preferred = candidates.filter(e => preferredIds.includes(e.id));
      if (preferred.length > 0) {
        candidates = preferred;
        thoughtLog.push(`  Found ${preferred.length} preferred employees for this shift`);
      }
    }

    // Score each candidate
    const scored = candidates.map(emp => {
      let score = 0.5; // Base score
      let reasons: string[] = [];

      // Bonus for reliability rating
      if (emp.reliabilityRating) {
        const reliability = parseFloat(emp.reliabilityRating);
        score += reliability * 0.2;
        if (reliability > 0.8) reasons.push('high reliability');
      }

      // Bonus for performance rating
      if (emp.performanceRating) {
        const performance = parseFloat(emp.performanceRating);
        score += performance * 0.15;
        if (performance > 0.8) reasons.push('strong performance');
      }

      // Bonus for certifications match
      const requiredCerts = shift.requiredCertifications || [];
      if (requiredCerts.length > 0 && emp.certifications) {
        const empCerts = emp.certifications || [];
        const matched = requiredCerts.filter((c: string) => empCerts.includes(c));
        if (matched.length === requiredCerts.length) {
          score += 0.15;
          reasons.push('all certifications matched');
        } else if (matched.length > 0) {
          score += 0.05;
          reasons.push(`${matched.length}/${requiredCerts.length} certifications`);
        }
      }

      // Random small bonus for variety
      score += Math.random() * 0.1;

      return {
        employee: emp,
        score: Math.min(score, 1),
        reasons,
      };
    });

    // Sort by score and pick the best
    scored.sort((a, b) => b.score - a.score);
    const best = scored[0];

    if (best) {
      return {
        employee: best.employee,
        confidence: best.score,
        reasoning: best.reasons.length > 0 
          ? best.reasons.join(', ') 
          : 'Best available match based on overall scoring',
      };
    }

    return {
      employee: null,
      confidence: 0,
      reasoning: 'No suitable candidates found',
    };
  }
  
  /**
   * Complete a training run with metrics
   */
  async completeTrainingRun(
    runId: string,
    metrics: {
      assignedShifts: number;
      failedShifts: number;
      averageConfidence: number;
      totalCreditsUsed: number;
      thoughtLog: string[];
      lessonsLearned: string[];
    }
  ): Promise<void> {
    const [run] = await db.select().from(trainingRuns).where(eq(trainingRuns.id, runId)).limit(1);
    
    const confidenceStart = Number(run?.confidenceStart || 0.5);
    const confidenceDelta = metrics.averageConfidence - confidenceStart;
    
    await db.update(trainingRuns)
      .set({
        status: 'completed',
        assignedShifts: metrics.assignedShifts,
        failedShifts: metrics.failedShifts,
        averageConfidence: metrics.averageConfidence.toFixed(4),
        totalCreditsUsed: metrics.totalCreditsUsed.toFixed(2),
        confidenceEnd: metrics.averageConfidence.toFixed(4),
        confidenceDelta: confidenceDelta.toFixed(4),
        thoughtLog: metrics.thoughtLog,
        lessonsLearned: metrics.lessonsLearned,
        completedAt: new Date(),
        updatedAt: new Date(),
      })
      .where(eq(trainingRuns.id, runId));
  }
  
  // Utility methods
  private randomDecimal(min: number, max: number): number {
    return Math.round((Math.random() * (max - min) + min) * 100) / 100;
  }
  
  private randomSubset<T>(array: T[], min: number, max: number): T[] {
    const count = Math.floor(Math.random() * (max - min + 1)) + min;
    const shuffled = [...array].sort(() => 0.5 - Math.random());
    return shuffled.slice(0, count);
  }
}

export const scenarioSeederService = new ScenarioSeederService();

/**
 * Universal Notification Engine
 * RBAC-aware, dynamic notification system for all workspace events
 * Sends notifications through multiple channels with role-based filtering
 * Now uses database persistence instead of in-memory storage
 * LIVE UPDATES: Broadcasts via WebSocket for real-time delivery
 * 
 * TRINITY AI ENRICHMENT: All notifications are enriched by Trinity AI to provide
 * contextual, meaningful content instead of generic templates. Every notification
 * gets a structured breakdown: Problem → Issue → Solution → Outcome
 */

import { db } from '../db';
import { notifications, users, employees, platformUpdates, platformRoles } from '@shared/schema';
import { eq, and, desc, inArray, isNull, or, gte, sql } from 'drizzle-orm';
import aiBrainConfig from "@shared/config/aiBrainGuardrails";
import { broadcastToWorkspace, broadcastNotificationToUser, broadcastPlatformUpdateGlobal } from '../websocket';
import { enrichNotificationWithAI } from './aiNotificationService';
import { eventBus } from './trinity/eventBus';
import { featureRegistryService } from './featureRegistryService';

export interface NotificationPayload {
  workspaceId: string;
  type: "document_extraction" | "issue_detected" | "migration_complete" | "guardrail_violation" | "quota_warning" | "platform_update" | "system";
  title: string;
  message: string;
  metadata?: Record<string, any>;
  severity?: "info" | "warning" | "error" | "critical";
  userId?: string;
  targetRoles?: string[]; // RBAC: Only send to these roles
  actionUrl?: string;
}

export class UniversalNotificationEngine {
  /**
   * Send notification with RBAC filtering
   * Persists to database for all notifications
   * Now enriched by Trinity AI for contextual, meaningful content
   */
  async sendNotification(payload: NotificationPayload): Promise<{
    success: boolean;
    recipientCount: number;
    channels: string[];
    notificationIds: string[];
  }> {
    try {
      const notificationRule = aiBrainConfig.notificationRules.find(
        (r) => r.triggerType === payload.type
      );

      if (!notificationRule || !notificationRule.enabled) {
        console.log(`[UniversalNotificationEngine] Notification type ${payload.type} is disabled`);
        return { success: false, recipientCount: 0, channels: [], notificationIds: [] };
      }

      // TRINITY FEATURE VALIDATION: Pre-validate content before enrichment
      // This catches stale data, vague language, and missing feature references
      const skipFeatureCheck = payload.metadata?.skipFeatureCheck === true;
      const blockCheck = featureRegistryService.shouldBlockNotification(payload.title, payload.message);
      if (blockCheck.block && !skipFeatureCheck) {
        console.log(`[UniversalNotificationEngine] BLOCKED - Validation failed: ${blockCheck.reason}`);
        console.log(`[UniversalNotificationEngine] Title: "${payload.title}"`);
        return { success: false, recipientCount: 0, channels: [], notificationIds: [] };
      }

      // Pre-enrich with feature context for Trinity AI
      const preValidation = featureRegistryService.validateNotificationContent(
        payload.title,
        payload.message,
        payload.metadata
      );
      
      // Log any validation warnings
      if (preValidation.issues.length > 0) {
        const warnings = preValidation.issues.filter(i => i.severity === 'warning');
        if (warnings.length > 0) {
          console.log(`[UniversalNotificationEngine] Validation warnings:`, 
            warnings.map(w => `${w.type}: ${w.message}`).join('; '));
        }
      }

      // TRINITY AI ENRICHMENT: Generate contextual, meaningful content
      // This replaces generic templates with AI-generated structured breakdowns
      const enriched = await enrichNotificationWithAI({
        title: payload.title,
        message: payload.message,
        type: payload.type,
        workspaceId: payload.workspaceId,
        metadata: payload.metadata,
      });
      
      // Use enriched values for storage and broadcast
      // Merge feature context from validation with AI enrichment
      const enrichedTitle = enriched.title;
      const enrichedMessage = enriched.message;
      const enrichedMetadata = {
        ...enriched.metadata,
        severity: payload.severity || 'info',
        // Include feature registry validation context
        featureReferences: preValidation.enrichedContent?.featureReferences || [],
        featureContext: preValidation.enrichedContent?.metadata?.featureContext || {},
        validatedAt: preValidation.enrichedContent?.metadata?.validatedAt,
      };

      const notificationIds: string[] = [];
      let recipientCount = 0;

      // If specific userId provided, send to that user only
      if (payload.userId) {
        const [notification] = await db
          .insert(notifications)
          .values({
            workspaceId: payload.workspaceId,
            userId: payload.userId,
            type: payload.type as any,
            title: enrichedTitle,
            message: enrichedMessage,
            actionUrl: payload.actionUrl,
            metadata: enrichedMetadata,
            isRead: false,
          })
          .returning();
        
        notificationIds.push(notification.id);
        recipientCount = 1;
        
        // Emit event for cross-device sync
        eventBus.emit('notification_created', {
          id: notification.id,
          workspaceId: payload.workspaceId,
          userId: payload.userId,
          type: payload.type,
          title: enrichedTitle,
          timestamp: new Date().toISOString(),
        });
        
        // LIVE UPDATE: Broadcast via WebSocket with enriched content AND metadata
        broadcastNotificationToUser(payload.workspaceId, payload.userId, {
          id: notification.id,
          type: payload.type,
          title: enrichedTitle,
          message: enrichedMessage,
          severity: payload.severity || 'info',
          actionUrl: payload.actionUrl,
          createdAt: notification.createdAt,
          metadata: enrichedMetadata,
        });
      } else if (payload.targetRoles && payload.targetRoles.length > 0) {
        // RBAC: Send to all users with specified roles in workspace
        const workspaceEmployees = await db.query.employees.findMany({
          where: and(
            eq(employees.workspaceId, payload.workspaceId),
            eq(employees.isActive, true)
          ),
          columns: { userId: true, workspaceRole: true },
        });
        
        // Filter by target roles (since inArray requires proper typing)
        const filteredEmployees = workspaceEmployees.filter(
          emp => payload.targetRoles!.includes(emp.workspaceRole as string)
        );

        for (const emp of filteredEmployees) {
          if (emp.userId) {
            const [notification] = await db
              .insert(notifications)
              .values({
                workspaceId: payload.workspaceId,
                userId: emp.userId,
                type: payload.type as any,
                title: enrichedTitle,
                message: enrichedMessage,
                actionUrl: payload.actionUrl,
                metadata: enrichedMetadata,
                isRead: false,
              })
              .returning();
            
            notificationIds.push(notification.id);
            recipientCount++;
            
            // Emit event for cross-device sync
            eventBus.emit('notification_created', {
              id: notification.id,
              workspaceId: payload.workspaceId,
              userId: emp.userId,
              type: payload.type,
              title: enrichedTitle,
              timestamp: new Date().toISOString(),
            });
            
            // LIVE UPDATE: Broadcast via WebSocket with enriched content AND metadata
            broadcastNotificationToUser(payload.workspaceId, emp.userId, {
              id: notification.id,
              type: payload.type,
              title: enrichedTitle,
              message: enrichedMessage,
              severity: payload.severity || 'info',
              actionUrl: payload.actionUrl,
              createdAt: notification.createdAt,
              metadata: enrichedMetadata,
            });
          }
        }
      } else {
        // Send to all active employees in workspace
        const workspaceEmployees = await db.query.employees.findMany({
          where: and(
            eq(employees.workspaceId, payload.workspaceId),
            eq(employees.isActive, true)
          ),
          columns: { userId: true },
        });

        for (const emp of workspaceEmployees) {
          if (emp.userId) {
            const [notification] = await db
              .insert(notifications)
              .values({
                workspaceId: payload.workspaceId,
                userId: emp.userId,
                type: payload.type as any,
                title: enrichedTitle,
                message: enrichedMessage,
                actionUrl: payload.actionUrl,
                metadata: enrichedMetadata,
                isRead: false,
              })
              .returning();
            
            notificationIds.push(notification.id);
            recipientCount++;
            
            // Emit event for cross-device sync
            eventBus.emit('notification_created', {
              id: notification.id,
              workspaceId: payload.workspaceId,
              userId: emp.userId,
              type: payload.type,
              title: enrichedTitle,
              timestamp: new Date().toISOString(),
            });
            
            // LIVE UPDATE: Broadcast via WebSocket with enriched content AND metadata
            broadcastNotificationToUser(payload.workspaceId, emp.userId, {
              id: notification.id,
              type: payload.type,
              title: enrichedTitle,
              message: enrichedMessage,
              severity: payload.severity || 'info',
              actionUrl: payload.actionUrl,
              createdAt: notification.createdAt,
              metadata: enrichedMetadata,
            });
          }
        }
      }

      // Also broadcast workspace-wide notification event for UI refresh
      broadcastToWorkspace(payload.workspaceId, {
        type: 'notification_count_updated',
        action: 'new_notifications',
        count: recipientCount,
        title: enrichedTitle,
        timestamp: new Date().toISOString(),
      });

      console.log(`[UniversalNotificationEngine] Notification sent: ${payload.title} to ${recipientCount} recipients (${notificationRule.channels.join(", ")}) + WebSocket broadcast`);

      return {
        success: true,
        recipientCount,
        channels: notificationRule.channels,
        notificationIds,
      };
    } catch (error: any) {
      console.error("[UniversalNotificationEngine] Error:", error);
      return { success: false, recipientCount: 0, channels: [], notificationIds: [] };
    }
  }

  /**
   * Send platform-wide notification to all admins across all workspaces
   * Now enriched by Trinity AI for contextual, meaningful content
   */
  async sendPlatformNotification(payload: {
    type: string;
    title: string;
    message: string;
    metadata?: Record<string, any>;
    severity?: "info" | "warning" | "error" | "critical";
    actionUrl?: string;
    targetRoles?: string[];
  }): Promise<{
    success: boolean;
    recipientCount: number;
  }> {
    try {
      const targetRoles = payload.targetRoles || ['org_owner', 'org_admin'];
      
      // TRINITY AI ENRICHMENT: Generate contextual content for platform notifications
      const enriched = await enrichNotificationWithAI({
        title: payload.title,
        message: payload.message,
        type: payload.type,
        workspaceId: 'platform',
        metadata: payload.metadata,
      });
      
      const enrichedTitle = enriched.title;
      const enrichedMessage = enriched.message;
      const enrichedMetadata = {
        ...enriched.metadata,
        severity: payload.severity || 'info',
        platformNotification: true,
      };
      
      // Get all active admins across all workspaces
      const allEmployees = await db.query.employees.findMany({
        where: eq(employees.isActive, true),
        columns: { userId: true, workspaceId: true, workspaceRole: true },
      });
      
      // Filter by target roles
      const admins = allEmployees.filter(
        emp => targetRoles.includes(emp.workspaceRole as string)
      );

      let recipientCount = 0;
      const workspacesNotified = new Set<string>();
      
      for (const admin of admins) {
        if (admin.userId && admin.workspaceId) {
          const [notification] = await db.insert(notifications).values({
            workspaceId: admin.workspaceId,
            userId: admin.userId,
            type: 'system' as any,
            title: enrichedTitle,
            message: enrichedMessage,
            actionUrl: payload.actionUrl || '/whats-new',
            metadata: enrichedMetadata,
            isRead: false,
          }).returning();
          
          recipientCount++;
          
          // LIVE UPDATE: Broadcast with enriched content AND metadata
          broadcastNotificationToUser(admin.workspaceId, admin.userId, {
            id: notification.id,
            type: 'platform_update',
            title: enrichedTitle,
            message: enrichedMessage,
            severity: payload.severity || 'info',
            actionUrl: payload.actionUrl || '/whats-new',
            createdAt: notification.createdAt,
            metadata: enrichedMetadata,
          });
          
          workspacesNotified.add(admin.workspaceId);
        }
      }
      
      // Broadcast count update to all affected workspaces
      for (const wsId of workspacesNotified) {
        broadcastToWorkspace(wsId, {
          type: 'notification_count_updated',
          action: 'platform_notification',
          title: enrichedTitle,
          timestamp: new Date().toISOString(),
        });
      }

      console.log(`[UniversalNotificationEngine] Platform notification sent to ${recipientCount} admins across ${workspacesNotified.size} workspaces + WebSocket broadcast`);

      return {
        success: true,
        recipientCount,
      };
    } catch (error: any) {
      console.error("[UniversalNotificationEngine] Platform notification error:", error);
      return { success: false, recipientCount: 0 };
    }
  }

  /**
   * Get workspace notifications from database
   */
  async getWorkspaceNotifications(
    workspaceId: string,
    options?: { unreadOnly?: boolean; limit?: number; offset?: number }
  ) {
    try {
      const limit = options?.limit || 50;
      const offset = options?.offset || 0;

      const conditions = [eq(notifications.workspaceId, workspaceId)];
      if (options?.unreadOnly) {
        conditions.push(eq(notifications.isRead, false));
      }

      const results = await db.query.notifications.findMany({
        where: and(...conditions),
        orderBy: [desc(notifications.createdAt)],
        limit,
        offset,
      });

      return results;
    } catch (error: any) {
      console.error("[UniversalNotificationEngine] Error fetching notifications:", error);
      return [];
    }
  }

  /**
   * Get user notifications with filtering
   */
  async getUserNotifications(
    workspaceId: string,
    userId: string,
    options?: { unreadOnly?: boolean; limit?: number; offset?: number }
  ) {
    try {
      const limit = options?.limit || 50;
      const offset = options?.offset || 0;

      const conditions = [
        eq(notifications.workspaceId, workspaceId),
        eq(notifications.userId, userId),
      ];
      
      if (options?.unreadOnly) {
        conditions.push(eq(notifications.isRead, false));
      }

      const results = await db.query.notifications.findMany({
        where: and(...conditions),
        orderBy: [desc(notifications.createdAt)],
        limit,
        offset,
      });

      return results;
    } catch (error: any) {
      console.error("[UniversalNotificationEngine] Error fetching user notifications:", error);
      return [];
    }
  }

  /**
   * Mark notification as read
   */
  async markAsRead(notificationId: string): Promise<boolean> {
    try {
      await db
        .update(notifications)
        .set({ isRead: true, readAt: new Date() })
        .where(eq(notifications.id, notificationId));
      return true;
    } catch (error: any) {
      console.error("[UniversalNotificationEngine] Error marking as read:", error);
      return false;
    }
  }

  /**
   * Mark all notifications as read for a user
   */
  async markAllAsRead(workspaceId: string, userId: string): Promise<number> {
    try {
      const result = await db
        .update(notifications)
        .set({ isRead: true, readAt: new Date() })
        .where(
          and(
            eq(notifications.workspaceId, workspaceId),
            eq(notifications.userId, userId),
            eq(notifications.isRead, false)
          )
        );
      return 1; // Return count affected
    } catch (error: any) {
      console.error("[UniversalNotificationEngine] Error marking all as read:", error);
      return 0;
    }
  }

  /**
   * Get unread notification count
   */
  async getUnreadCount(workspaceId: string, userId: string): Promise<number> {
    try {
      const unread = await db.query.notifications.findMany({
        where: and(
          eq(notifications.workspaceId, workspaceId),
          eq(notifications.userId, userId),
          eq(notifications.isRead, false)
        ),
        columns: { id: true },
      });
      return unread.length;
    } catch (error: any) {
      console.error("[UniversalNotificationEngine] Error getting unread count:", error);
      return 0;
    }
  }

  /**
   * Send platform-wide update (What's New feed)
   * THE SINGLE SOURCE OF TRUTH for all platform updates
   * Uses Trinity AI enrichment for contextual, meaningful content
   */
  async sendPlatformUpdate(payload: {
    title: string;
    description: string;
    category?: 'feature' | 'improvement' | 'bugfix' | 'security' | 'announcement';
    workspaceId?: string;
    priority?: number;
    learnMoreUrl?: string;
    metadata?: Record<string, any>;
  }): Promise<{ success: boolean; id?: string; isDuplicate?: boolean }> {
    try {
      // Check for duplicates (same title within 24 hours)
      const oneDayAgo = new Date(Date.now() - 24 * 60 * 60 * 1000);
      const existingByTitle = await db.select({ id: platformUpdates.id })
        .from(platformUpdates)
        .where(
          and(
            or(
              eq(platformUpdates.title, payload.title),
              sql`${platformUpdates.metadata}->>'originalTitle' = ${payload.title}`
            ),
            payload.workspaceId 
              ? eq(platformUpdates.workspaceId, payload.workspaceId)
              : isNull(platformUpdates.workspaceId),
            gte(platformUpdates.date, oneDayAgo)
          )
        )
        .limit(1);
      
      if (existingByTitle.length > 0) {
        console.log(`[UniversalNotificationEngine] Duplicate platform update (24h), skipping: ${payload.title}`);
        return { success: true, id: existingByTitle[0].id, isDuplicate: true };
      }

      // TRINITY AI ENRICHMENT: Generate structured breakdown
      const enriched = await enrichNotificationWithAI({
        title: payload.title,
        message: payload.description,
        type: 'platform_update',
        category: payload.category,
        workspaceId: payload.workspaceId,
        metadata: payload.metadata,
      });

      const enrichedMetadata = {
        ...payload.metadata,
        originalTitle: payload.title,
        generatedAt: new Date().toISOString(),
        aiEnriched: true,
        // Include Trinity-generated structured breakdown fields
        ...enriched.metadata,
      };

      // Insert into platform updates table
      const updateId = `trinity-${Date.now()}-${crypto.randomUUID().slice(0, 8)}`;
      const [update] = await db.insert(platformUpdates).values({
        id: updateId,
        title: enriched.title,
        description: enriched.message,
        category: payload.category || 'announcement',
        workspaceId: payload.workspaceId || null,
        priority: payload.priority || 1,
        isNew: true,
        visibility: 'all',
        learnMoreUrl: payload.learnMoreUrl,
        metadata: enrichedMetadata,
        date: new Date(),
      }).returning({ id: platformUpdates.id });

      console.log(`[UniversalNotificationEngine] Platform update created: ${enriched.title}`);

      // Emit event for cross-device sync (mobile/desktop consistency)
      eventBus.emit('platform_update_created', {
        id: update.id,
        title: enriched.title,
        description: enriched.message,
        category: payload.category || 'announcement',
        workspaceId: payload.workspaceId,
        timestamp: new Date().toISOString(),
      });

      // Broadcast via WebSocket for real-time UNS updates
      broadcastPlatformUpdateGlobal({
        id: update.id,
        title: enriched.title,
        description: enriched.message,
        category: payload.category || 'announcement',
        priority: payload.priority || 1,
        learnMoreUrl: payload.learnMoreUrl,
        metadata: enrichedMetadata,
        workspaceId: payload.workspaceId,
        visibility: 'all',
      });

      return { success: true, id: update.id };
    } catch (error: any) {
      console.error("[UniversalNotificationEngine] Error creating platform update:", error);
      return { success: false };
    }
  }
}

// Singleton instance
export const universalNotificationEngine = new UniversalNotificationEngine();

// Backward compatibility alias
export const notificationEngine = universalNotificationEngine;

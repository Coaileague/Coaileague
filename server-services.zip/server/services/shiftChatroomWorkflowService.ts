/**
 * ShiftChatroomWorkflowService - GetSling-style Shift Chatroom Workflow
 * 
 * Features:
 * - Auto-create chatroom when employee starts shift
 * - Add shift employees to chatroom
 * - Handle photos, reports, and activity logging
 * - Auto-close chatroom after shift ends
 * - Generate DAR (Daily Activity Report)
 * - Send DAR to client after verification
 * - Meeting room recording with Trinity (premium)
 * 
 * Integrates with:
 * - UniversalStepLogger (7-step pattern)
 * - Trinity+Claude orchestration
 * - Audit integrity system
 */

import { db } from "../db";
import { 
  shiftChatrooms, 
  shiftChatroomMembers, 
  shiftChatroomMessages,
  darReports,
  trinityMeetingRecordings,
  shifts,
  employees,
  clients,
  sites,
  siteContacts,
  users,
  workspaces,
  timeEntries
} from "@shared/schema";
import { eq, and, gte, lte, sql, desc } from "drizzle-orm";
import { format } from "date-fns";
import crypto from "crypto";
import { universalStepLogger, type OrchestrationContext, type OrchestrationStep, type StepStatus } from "./orchestration/universalStepLogger";

export interface ShiftChatroomContext {
  workspaceId: string;
  shiftId: string;
  userId: string;
  employeeId?: string;
  clientId?: string;
  siteId?: string;
}

export interface DARGenerationResult {
  darId: string;
  status: 'draft' | 'pending_review' | 'verified' | 'sent';
  summary?: string;
  contentHash: string;
}

export interface ChatroomMessage {
  content: string;
  messageType: 'text' | 'photo' | 'report' | 'system';
  attachmentUrl?: string;
  attachmentType?: string;
  attachmentSize?: number;
  metadata?: Record<string, any>;
}

class ShiftChatroomWorkflowService {
  private static instance: ShiftChatroomWorkflowService;

  private constructor() {}

  public static getInstance(): ShiftChatroomWorkflowService {
    if (!ShiftChatroomWorkflowService.instance) {
      ShiftChatroomWorkflowService.instance = new ShiftChatroomWorkflowService();
    }
    return ShiftChatroomWorkflowService.instance;
  }

  /**
   * Create orchestration context for step logging
   */
  private createOrchestrationContext(
    actionName: string,
    workspaceId: string,
    userId?: string,
    triggeredBy: "user" | "cron" | "event" | "api" | "ai_brain" | "webhook" = "user"
  ): OrchestrationContext {
    return {
      orchestrationId: crypto.randomUUID(),
      domain: "scheduling",
      actionName,
      workspaceId,
      userId,
      triggeredBy,
    } as OrchestrationContext;
  }

  /**
   * Log orchestration step to UniversalStepLogger
   */
  private async logStep(
    context: OrchestrationContext,
    step: OrchestrationStep,
    status: StepStatus,
    inputPayload?: Record<string, any>,
    outputPayload?: Record<string, any>,
    error?: string
  ): Promise<void> {
    try {
      await universalStepLogger.logStep(context, step, status, inputPayload, outputPayload, error);
    } catch (e) {
      console.error("[ShiftChatroom] Failed to log step:", e);
    }
  }

  /**
   * Start Shift Workflow
   * TRIGGER → FETCH → VALIDATE → PROCESS → MUTATE → CONFIRM → NOTIFY
   */
  async startShift(context: ShiftChatroomContext): Promise<{
    success: boolean;
    chatroomId?: string;
    error?: string;
    steps: Array<{ step: string; status: string; duration: number }>;
  }> {
    const steps: Array<{ step: string; status: string; duration: number }> = [];
    const stepStart = Date.now();
    let currentStep = 'TRIGGER';

    // Create orchestration context for audit logging (outside try for catch access)
    const orchContext = this.createOrchestrationContext(
      'shift_start_workflow',
      context.workspaceId,
      context.userId
    );

    try {
      steps.push({ step: 'TRIGGER', status: 'started', duration: 0 });
      await this.logStep(orchContext, 'TRIGGER', 'started', { shiftId: context.shiftId, workspaceId: context.workspaceId });
      console.log(`[ShiftChatroom] Starting shift workflow for shift ${context.shiftId}`);

      currentStep = 'FETCH';
      const fetchStart = Date.now();
      
      const [shift] = await db.select().from(shifts).where(eq(shifts.id, context.shiftId));
      if (!shift) {
        throw new Error('Shift not found');
      }

      const [employee] = context.employeeId 
        ? await db.select().from(employees).where(eq(employees.id, context.employeeId))
        : [];

      steps.push({ step: 'FETCH', status: 'completed', duration: Date.now() - fetchStart });
      await this.logStep(orchContext, 'FETCH', 'completed', { shiftId: context.shiftId }, { shiftFound: !!shift, employeeFound: !!employee });

      currentStep = 'VALIDATE';
      const validateStart = Date.now();

      if (shift.status === 'completed') {
        throw new Error('Cannot start a completed shift');
      }

      const existingChatroom = await db.select()
        .from(shiftChatrooms)
        .where(and(
          eq(shiftChatrooms.shiftId, context.shiftId),
          eq(shiftChatrooms.status, 'active')
        ))
        .limit(1);

      if (existingChatroom.length > 0) {
        steps.push({ step: 'VALIDATE', status: 'completed', duration: Date.now() - validateStart });
        await this.logStep(orchContext, 'VALIDATE', 'completed', { shiftId: context.shiftId }, { existingChatroom: true, chatroomId: existingChatroom[0].id });
        await this.logStep(orchContext, 'PROCESS', 'skipped', { shiftId: context.shiftId }, { reason: 'existing_chatroom_found' });
        await this.logStep(orchContext, 'MUTATE', 'skipped', { shiftId: context.shiftId }, { reason: 'existing_chatroom_found' });
        await this.logStep(orchContext, 'CONFIRM', 'completed', { shiftId: context.shiftId, chatroomId: existingChatroom[0].id }, { reason: 'existing_chatroom_found' });
        await this.logStep(orchContext, 'NOTIFY', 'completed', { shiftId: context.shiftId, chatroomId: existingChatroom[0].id, workspaceId: context.workspaceId }, { workflowComplete: true, earlyReturn: true });
        return {
          success: true,
          chatroomId: existingChatroom[0].id,
          steps,
          error: undefined
        };
      }

      steps.push({ step: 'VALIDATE', status: 'completed', duration: Date.now() - validateStart });
      await this.logStep(orchContext, 'VALIDATE', 'completed', { shiftId: context.shiftId }, { existingChatroom: false, shiftStatus: shift.status });

      currentStep = 'PROCESS';
      const processStart = Date.now();

      const chatroomName = this.generateChatroomName(shift, employee);
      const chatroomId = crypto.randomUUID();

      steps.push({ step: 'PROCESS', status: 'completed', duration: Date.now() - processStart });
      await this.logStep(orchContext, 'PROCESS', 'completed', { shiftId: context.shiftId }, { chatroomId, chatroomName });

      currentStep = 'MUTATE';
      const mutateStart = Date.now();

      await db.insert(shiftChatrooms).values({
        id: chatroomId,
        workspaceId: context.workspaceId,
        shiftId: context.shiftId,
        name: chatroomName,
        description: `Shift chatroom for ${format(new Date(shift.startTime), 'MMM d, yyyy h:mm a')}`,
        status: 'active',
        autoCloseTimeoutMinutes: 60,
        isAuditProtected: true,
        isMeetingRoom: false,
        trinityRecordingEnabled: false,
      });

      await db.insert(shiftChatroomMembers).values({
        id: crypto.randomUUID(),
        chatroomId,
        userId: context.userId,
        employeeId: context.employeeId || null,
        role: 'member',
        joinedAt: new Date(),
      });

      await db.update(shifts)
        .set({ status: 'in_progress', updatedAt: new Date() })
        .where(eq(shifts.id, context.shiftId));

      await this.sendSystemMessage(chatroomId, context.userId, 
        `Shift started. Welcome to the shift chatroom! Share photos, reports, and updates here.`);

      steps.push({ step: 'MUTATE', status: 'completed', duration: Date.now() - mutateStart });
      await this.logStep(orchContext, 'MUTATE', 'completed', { shiftId: context.shiftId, chatroomId }, { chatroomCreated: true, memberAdded: true, shiftUpdated: true });

      currentStep = 'CONFIRM';
      const confirmStart = Date.now();

      const [createdChatroom] = await db.select()
        .from(shiftChatrooms)
        .where(eq(shiftChatrooms.id, chatroomId));

      if (!createdChatroom) {
        throw new Error('Failed to create chatroom');
      }

      steps.push({ step: 'CONFIRM', status: 'completed', duration: Date.now() - confirmStart });
      await this.logStep(orchContext, 'CONFIRM', 'completed', { shiftId: context.shiftId, chatroomId }, { verified: true });

      currentStep = 'NOTIFY';
      const notifyStart = Date.now();

      console.log(`[ShiftChatroom] Shift ${context.shiftId} started, chatroom ${chatroomId} created`);

      steps.push({ step: 'NOTIFY', status: 'completed', duration: Date.now() - notifyStart });
      await this.logStep(orchContext, 'NOTIFY', 'completed', { shiftId: context.shiftId, chatroomId }, { workflowComplete: true });

      const totalDuration = Date.now() - stepStart;
      console.log(`[ShiftChatroom] Workflow completed in ${totalDuration}ms`);

      return {
        success: true,
        chatroomId,
        steps,
      };
    } catch (error: any) {
      console.error(`[ShiftChatroom] Error in step ${currentStep}:`, error);
      steps.push({ step: currentStep, status: 'failed', duration: Date.now() - stepStart });
      // Log error to UniversalStepLogger
      await this.logStep(orchContext, currentStep as OrchestrationStep, 'failed', { shiftId: context.shiftId }, undefined, error.message);
      
      return {
        success: false,
        error: error.message || 'Unknown error',
        steps,
      };
    }
  }

  /**
   * End Shift Workflow
   * Closes chatroom and generates DAR
   */
  async endShift(
    context: ShiftChatroomContext,
    closureReason: 'manual' | 'auto_timeout' | 'shift_completed' = 'shift_completed'
  ): Promise<{
    success: boolean;
    darId?: string;
    error?: string;
    steps: Array<{ step: string; status: string; duration: number }>;
  }> {
    const steps: Array<{ step: string; status: string; duration: number }> = [];
    const stepStart = Date.now();
    let currentStep = 'TRIGGER';

    // Create orchestration context for audit logging (outside try for catch access)
    const orchContext = this.createOrchestrationContext(
      'shift_end_workflow',
      context.workspaceId,
      context.userId
    );

    try {
      steps.push({ step: 'TRIGGER', status: 'started', duration: 0 });
      await this.logStep(orchContext, 'TRIGGER', 'started', { shiftId: context.shiftId, workspaceId: context.workspaceId });

      currentStep = 'FETCH';
      const fetchStart = Date.now();

      const [chatroom] = await db.select()
        .from(shiftChatrooms)
        .where(and(
          eq(shiftChatrooms.shiftId, context.shiftId),
          eq(shiftChatrooms.status, 'active')
        ));

      if (!chatroom) {
        steps.push({ step: 'FETCH', status: 'completed', duration: Date.now() - fetchStart });
        await this.logStep(orchContext, 'FETCH', 'completed', { shiftId: context.shiftId }, { chatroomFound: false });
        await this.logStep(orchContext, 'VALIDATE', 'skipped', { shiftId: context.shiftId }, { reason: 'no_active_chatroom' });
        await this.logStep(orchContext, 'PROCESS', 'skipped', { shiftId: context.shiftId }, { reason: 'no_active_chatroom' });
        await this.logStep(orchContext, 'MUTATE', 'skipped', { shiftId: context.shiftId }, { reason: 'no_active_chatroom' });
        await this.logStep(orchContext, 'CONFIRM', 'completed', { shiftId: context.shiftId, workspaceId: context.workspaceId }, { reason: 'no_active_chatroom' });
        await this.logStep(orchContext, 'NOTIFY', 'completed', { shiftId: context.shiftId, workspaceId: context.workspaceId }, { workflowComplete: true, earlyReturn: true });
        return { success: true, steps, error: 'No active chatroom found' };
      }

      const [shift] = await db.select().from(shifts).where(eq(shifts.id, context.shiftId));
      const messages = await db.select()
        .from(shiftChatroomMessages)
        .where(eq(shiftChatroomMessages.chatroomId, chatroom.id))
        .orderBy(shiftChatroomMessages.createdAt);

      steps.push({ step: 'FETCH', status: 'completed', duration: Date.now() - fetchStart });
      await this.logStep(orchContext, 'FETCH', 'completed', { shiftId: context.shiftId, chatroomId: chatroom.id }, { chatroomFound: true, messageCount: messages.length });

      currentStep = 'VALIDATE';
      const validateStart = Date.now();

      steps.push({ step: 'VALIDATE', status: 'completed', duration: Date.now() - validateStart });
      await this.logStep(orchContext, 'VALIDATE', 'completed', { shiftId: context.shiftId, chatroomId: chatroom.id, closureReason }, { valid: true });

      currentStep = 'PROCESS';
      const processStart = Date.now();

      const darResult = await this.generateDAR(context, chatroom, shift, messages);

      steps.push({ step: 'PROCESS', status: 'completed', duration: Date.now() - processStart });
      await this.logStep(orchContext, 'PROCESS', 'completed', { shiftId: context.shiftId, chatroomId: chatroom.id }, { darId: darResult.darId, darGenerated: true });

      currentStep = 'MUTATE';
      const mutateStart = Date.now();

      await db.update(shiftChatrooms)
        .set({
          status: 'closed',
          closedAt: new Date(),
          closedBy: context.userId,
          closureReason,
          darGenerated: true,
          darGeneratedAt: new Date(),
          updatedAt: new Date(),
        })
        .where(eq(shiftChatrooms.id, chatroom.id));

      await db.update(shifts)
        .set({ status: 'completed', updatedAt: new Date() })
        .where(eq(shifts.id, context.shiftId));

      await this.sendSystemMessage(chatroom.id, context.userId,
        `Shift ended. Chatroom closed. DAR generated for client review.`);

      steps.push({ step: 'MUTATE', status: 'completed', duration: Date.now() - mutateStart });
      await this.logStep(orchContext, 'MUTATE', 'completed', { shiftId: context.shiftId, chatroomId: chatroom.id, darId: darResult.darId }, { chatroomClosed: true, shiftCompleted: true });

      currentStep = 'CONFIRM';
      steps.push({ step: 'CONFIRM', status: 'completed', duration: 0 });
      await this.logStep(orchContext, 'CONFIRM', 'completed', { shiftId: context.shiftId, chatroomId: chatroom.id, darId: darResult.darId }, { verified: true });

      currentStep = 'NOTIFY';
      console.log(`[ShiftChatroom] Shift ${context.shiftId} ended, DAR ${darResult.darId} generated`);
      steps.push({ step: 'NOTIFY', status: 'completed', duration: 0 });
      await this.logStep(orchContext, 'NOTIFY', 'completed', { shiftId: context.shiftId, chatroomId: chatroom.id, darId: darResult.darId, closureReason }, { workflowComplete: true });

      return {
        success: true,
        darId: darResult.darId,
        steps,
      };
    } catch (error: any) {
      console.error(`[ShiftChatroom] Error in step ${currentStep}:`, error);
      steps.push({ step: currentStep, status: 'failed', duration: Date.now() - stepStart });
      // Log error to UniversalStepLogger
      await this.logStep(orchContext, currentStep as OrchestrationStep, 'failed', { shiftId: context.shiftId }, undefined, error.message);
      
      return {
        success: false,
        error: error.message || 'Unknown error',
        steps,
      };
    }
  }

  /**
   * Send message to chatroom
   */
  async sendMessage(
    chatroomId: string,
    userId: string,
    message: ChatroomMessage
  ): Promise<{ success: boolean; messageId?: string; error?: string }> {
    try {
      const [chatroom] = await db.select()
        .from(shiftChatrooms)
        .where(eq(shiftChatrooms.id, chatroomId));

      if (!chatroom || chatroom.status !== 'active') {
        return { success: false, error: 'Chatroom not active' };
      }

      const messageId = crypto.randomUUID();

      await db.insert(shiftChatroomMessages).values({
        id: messageId,
        chatroomId,
        userId,
        content: message.content,
        messageType: message.messageType,
        attachmentUrl: message.attachmentUrl,
        attachmentType: message.attachmentType,
        attachmentSize: message.attachmentSize,
        metadata: message.metadata,
        isAuditProtected: message.messageType === 'photo' || message.messageType === 'report',
      });

      await db.update(shiftChatroomMembers)
        .set({
          lastActiveAt: new Date(),
          messageCount: sql`${shiftChatroomMembers.messageCount} + 1`,
          photoCount: message.messageType === 'photo' 
            ? sql`${shiftChatroomMembers.photoCount} + 1` 
            : shiftChatroomMembers.photoCount,
        })
        .where(and(
          eq(shiftChatroomMembers.chatroomId, chatroomId),
          eq(shiftChatroomMembers.userId, userId)
        ));

      return { success: true, messageId };
    } catch (error: any) {
      console.error('[ShiftChatroom] Error sending message:', error);
      return { success: false, error: error.message };
    }
  }

  /**
   * Generate DAR (Daily Activity Report)
   */
  private async generateDAR(
    context: ShiftChatroomContext,
    chatroom: any,
    shift: any,
    messages: any[]
  ): Promise<DARGenerationResult> {
    const photoCount = messages.filter(m => m.messageType === 'photo').length;
    const messageCount = messages.length;

    const content = this.compileDARContent(shift, messages);
    const contentHash = crypto.createHash('sha256').update(content).digest('hex');

    const darId = crypto.randomUUID();

    let employeeName = 'Unknown';
    if (shift.employeeId) {
      const [employee] = await db.select()
        .from(employees)
        .where(eq(employees.id, shift.employeeId));
      if (employee) {
        employeeName = `${employee.firstName} ${employee.lastName}`;
      }
    }

    const [timeEntry] = await db.select()
      .from(timeEntries)
      .where(eq(timeEntries.shiftId, shift.id))
      .orderBy(desc(timeEntries.createdAt))
      .limit(1);

    await db.insert(darReports).values({
      id: darId,
      workspaceId: context.workspaceId,
      shiftId: context.shiftId,
      chatroomId: chatroom.id,
      clientId: shift.clientId,
      title: `Daily Activity Report - ${format(new Date(shift.startTime), 'MMM d, yyyy')}`,
      summary: this.generateDARSummary(shift, messages),
      content,
      photoCount,
      messageCount,
      employeeId: shift.employeeId,
      employeeName,
      shiftStartTime: new Date(shift.startTime),
      shiftEndTime: new Date(shift.endTime),
      actualClockIn: timeEntry?.clockIn || null,
      actualClockOut: timeEntry?.clockOut || null,
      status: 'draft',
      isAuditProtected: true,
      contentHash,
    });

    return {
      darId,
      status: 'draft',
      summary: this.generateDARSummary(shift, messages),
      contentHash,
    };
  }

  /**
   * Compile DAR content from messages
   */
  private compileDARContent(shift: any, messages: any[]): string {
    const lines: string[] = [
      `# Daily Activity Report`,
      ``,
      `**Date:** ${format(new Date(shift.startTime), 'MMMM d, yyyy')}`,
      `**Shift:** ${format(new Date(shift.startTime), 'h:mm a')} - ${format(new Date(shift.endTime), 'h:mm a')}`,
      ``,
      `## Activity Log`,
      ``,
    ];

    for (const msg of messages) {
      if (msg.messageType === 'system') continue;
      
      const time = format(new Date(msg.createdAt), 'h:mm a');
      
      if (msg.messageType === 'photo') {
        lines.push(`- **${time}** [PHOTO] ${msg.content || 'Photo attachment'}`);
      } else if (msg.messageType === 'report') {
        lines.push(`- **${time}** [REPORT] ${msg.content}`);
      } else {
        lines.push(`- **${time}** ${msg.content}`);
      }
    }

    return lines.join('\n');
  }

  /**
   * Generate DAR summary (AI-enhanced in production)
   */
  private generateDARSummary(shift: any, messages: any[]): string {
    const photoCount = messages.filter(m => m.messageType === 'photo').length;
    const activityCount = messages.filter(m => m.messageType !== 'system').length;
    
    return `Shift completed with ${activityCount} activities logged and ${photoCount} photos captured.`;
  }

  /**
   * Send system message to chatroom
   */
  private async sendSystemMessage(chatroomId: string, userId: string, content: string): Promise<void> {
    await db.insert(shiftChatroomMessages).values({
      id: crypto.randomUUID(),
      chatroomId,
      userId,
      content,
      messageType: 'system',
      isAuditProtected: false,
    });
  }

  /**
   * Generate chatroom name
   */
  private generateChatroomName(shift: any, employee?: any): string {
    const dateStr = format(new Date(shift.startTime), 'MMM d');
    const timeStr = format(new Date(shift.startTime), 'h:mma');
    
    if (employee) {
      return `${employee.firstName}'s Shift - ${dateStr} ${timeStr}`;
    }
    
    return `Shift Chatroom - ${dateStr} ${timeStr}`;
  }

  /**
   * Get site info for shift
   */
  async getSiteInfo(shiftId: string): Promise<{
    site: any | null;
    contacts: any[];
    address: string | null;
  }> {
    const [shift] = await db.select().from(shifts).where(eq(shifts.id, shiftId));
    if (!shift) {
      return { site: null, contacts: [], address: null };
    }

    let site = null;
    let contacts: any[] = [];
    let address: string | null = (shift as any).jobSiteAddress || null;

    if (shift.siteId) {
      const [siteResult] = await db.select().from(sites).where(eq(sites.id, shift.siteId));
      site = siteResult;

      if (site) {
        const parts = [site.addressLine1, site.addressLine2, site.city, site.state, site.zip].filter(Boolean);
        address = parts.length > 0 ? parts.join(', ') : address;

        contacts = await db.select().from(siteContacts).where(eq(siteContacts.siteId, site.id));
      }
    }

    if (!address && shift.clientId) {
      const [client] = await db.select().from(clients).where(eq(clients.id, shift.clientId));
      if (client?.address) {
        address = client.address;
      }
    }

    return { site, contacts, address };
  }

  /**
   * Verify DAR and mark as ready to send
   */
  async verifyDAR(darId: string, userId: string, notes?: string): Promise<{
    success: boolean;
    error?: string;
  }> {
    try {
      await db.update(darReports)
        .set({
          status: 'verified',
          verifiedBy: userId,
          verifiedAt: new Date(),
          verificationNotes: notes,
          updatedAt: new Date(),
        })
        .where(eq(darReports.id, darId));

      return { success: true };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  }

  /**
   * Send DAR to client
   */
  async sendDARToClient(darId: string): Promise<{
    success: boolean;
    error?: string;
  }> {
    try {
      const [dar] = await db.select().from(darReports).where(eq(darReports.id, darId));
      
      if (!dar) {
        return { success: false, error: 'DAR not found' };
      }

      if (dar.status !== 'verified') {
        return { success: false, error: 'DAR must be verified before sending' };
      }

      const clientAccessToken = crypto.randomBytes(32).toString('hex');

      await db.update(darReports)
        .set({
          status: 'sent',
          sentToClient: true,
          sentAt: new Date(),
          clientAccessToken,
          updatedAt: new Date(),
        })
        .where(eq(darReports.id, darId));

      console.log(`[ShiftChatroom] DAR ${darId} sent to client`);

      return { success: true };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  }

  /**
   * Auto-close stale chatrooms
   */
  async autoCloseStaleRooms(): Promise<{ closed: number }> {
    try {
      const now = new Date();
      
      const staleChatrooms = await db.select()
        .from(shiftChatrooms)
        .innerJoin(shifts, eq(shiftChatrooms.shiftId, shifts.id))
        .where(and(
          eq(shiftChatrooms.status, 'active'),
          lte(shifts.endTime, new Date(now.getTime() - 60 * 60 * 1000))
        ));

      let closed = 0;

      for (const { shift_chatrooms: chatroom, shifts: shift } of staleChatrooms) {
        await this.endShift(
          {
            workspaceId: chatroom.workspaceId,
            shiftId: chatroom.shiftId,
            userId: 'system',
          },
          'auto_timeout'
        );
        closed++;
      }

      if (closed > 0) {
        console.log(`[ShiftChatroom] Auto-closed ${closed} stale chatrooms`);
      }

      return { closed };
    } catch (error) {
      console.error('[ShiftChatroom] Error auto-closing rooms:', error);
      return { closed: 0 };
    }
  }

  /**
   * Check if data can be deleted (audit integrity system)
   */
  canDelete(entityType: 'message' | 'photo' | 'dar' | 'chatroom', entity: any): {
    allowed: boolean;
    reason: string;
  } {
    if (entity.isAuditProtected) {
      return {
        allowed: false,
        reason: 'This item is protected by the audit integrity system and cannot be deleted.'
      };
    }

    if (entityType === 'dar') {
      return {
        allowed: false,
        reason: 'Daily Activity Reports cannot be deleted for compliance purposes.'
      };
    }

    if (entityType === 'message' && entity.messageType === 'photo') {
      const ageInDays = (Date.now() - new Date(entity.createdAt).getTime()) / (1000 * 60 * 60 * 24);
      if (ageInDays < 90) {
        return {
          allowed: false,
          reason: 'Photos must be retained for at least 90 days before deletion.'
        };
      }
    }

    return { allowed: true, reason: '' };
  }

  // =========================================================================
  // TRINITY MEETING ROOM RECORDING (PREMIUM FEATURE)
  // =========================================================================

  /**
   * Enable Trinity recording for a chatroom (Premium Feature)
   * Requires professional tier or credits
   */
  async enableTrinityRecording(
    chatroomId: string,
    workspaceId: string,
    userId: string
  ): Promise<{ success: boolean; error?: string; isPremium: boolean; creditCost?: number }> {
    try {
      // Import premium gating dynamically to avoid circular imports
      const { premiumFeatureGating } = await import('./premiumFeatureGating');
      
      // Check premium access
      const access = await premiumFeatureGating.checkAccess(workspaceId, 'trinity_meeting_recording', userId);
      
      if (!access.allowed) {
        return {
          success: false,
          error: access.reason,
          isPremium: true,
          creditCost: access.creditCost,
        };
      }

      // Update chatroom to enable recording
      await db.update(shiftChatrooms)
        .set({
          trinityRecordingEnabled: true,
          isMeetingRoom: true,
          updatedAt: new Date(),
        })
        .where(eq(shiftChatrooms.id, chatroomId));

      // Log system message
      await this.sendSystemMessage(chatroomId, userId,
        '[PREMIUM] Trinity AI recording enabled. All conversations will be transcribed and summarized.');

      console.log(`[ShiftChatroom] Trinity recording enabled for chatroom ${chatroomId}`);

      return {
        success: true,
        isPremium: true,
        creditCost: access.creditCost,
      };
    } catch (error: any) {
      console.error('[ShiftChatroom] Error enabling Trinity recording:', error);
      return {
        success: false,
        error: error.message,
        isPremium: true,
      };
    }
  }

  /**
   * Generate meeting transcript and summary (Premium Feature)
   * Charges credits per minute of recording
   */
  async generateMeetingTranscript(
    chatroomId: string,
    workspaceId: string,
    userId: string
  ): Promise<{
    success: boolean;
    transcriptId?: string;
    summary?: string;
    actionItems?: string[];
    creditsUsed?: number;
    error?: string;
  }> {
    try {
      const { premiumFeatureGating } = await import('./premiumFeatureGating');
      
      // Get chatroom and messages
      const [chatroom] = await db.select()
        .from(shiftChatrooms)
        .where(eq(shiftChatrooms.id, chatroomId));

      if (!chatroom) {
        return { success: false, error: 'Chatroom not found' };
      }

      if (!chatroom.trinityRecordingEnabled) {
        return { success: false, error: 'Trinity recording is not enabled for this chatroom' };
      }

      const messages = await db.select()
        .from(shiftChatroomMessages)
        .where(eq(shiftChatroomMessages.chatroomId, chatroomId))
        .orderBy(shiftChatroomMessages.createdAt);

      // Calculate estimated recording minutes based on message count and timespan
      const firstMessage = messages[0];
      const lastMessage = messages[messages.length - 1];
      const timeSpanMinutes = firstMessage && lastMessage
        ? Math.ceil((new Date(lastMessage.createdAt!).getTime() - new Date(firstMessage.createdAt!).getTime()) / 60000)
        : 1;
      
      const estimatedMinutes = Math.max(1, Math.min(timeSpanMinutes, 120)); // Cap at 120 minutes

      // Check access with units (minutes) for proper per-minute billing validation
      const access = await premiumFeatureGating.checkAccess(
        workspaceId, 
        'trinity_meeting_recording', 
        userId,
        estimatedMinutes  // Pass minutes for credit/limit validation
      );
      
      if (!access.allowed) {
        return {
          success: false,
          error: access.reason,
        };
      }

      // Deduct credits for the minutes used
      const deduction = await premiumFeatureGating.deductCredits(
        workspaceId,
        'trinity_meeting_recording',
        estimatedMinutes,
        userId,
        { chatroomId, messageCount: messages.length }
      );

      if (!deduction.success) {
        return {
          success: false,
          error: deduction.error,
        };
      }

      // Generate transcript using AI
      const transcript = await this.generateAITranscript(chatroom, messages);

      // Get unique participant IDs
      const participantIds = [...new Set(messages.map(m => m.userId))];
      
      // Persist transcript to trinityMeetingRecordings for audit/billing
      const transcriptId = crypto.randomUUID();
      await db.insert(trinityMeetingRecordings).values({
        id: transcriptId,
        workspaceId,
        chatroomId,
        title: `Meeting Transcript - ${chatroom.name || 'Shift Chat'}`,
        startedAt: firstMessage?.createdAt || new Date(),
        endedAt: lastMessage?.createdAt || new Date(),
        durationMinutes: estimatedMinutes,
        transcription: messages
          .filter(m => m.messageType !== 'system')
          .map(m => `[${new Date(m.createdAt!).toLocaleTimeString()}] ${m.userId}: ${m.content}`)
          .join('\n'),
        aiSummary: transcript.summary,
        actionItems: transcript.actionItems,
        participantCount: participantIds.length,
        participantIds,
        isPremiumFeature: true,
        aiCreditsUsed: deduction.creditsDeducted,
        isAuditProtected: true,
        status: 'completed',
      });

      // Update chatroom with transcript metadata
      await db.update(shiftChatrooms)
        .set({
          metadata: sql`COALESCE(${shiftChatrooms.metadata}, '{}')::jsonb || ${JSON.stringify({
            lastTranscriptId: transcriptId,
            lastTranscriptAt: new Date().toISOString(),
            totalRecordingMinutes: estimatedMinutes,
          })}::jsonb`,
          updatedAt: new Date(),
        })
        .where(eq(shiftChatrooms.id, chatroomId));

      // Send system message
      await this.sendSystemMessage(chatroomId, userId,
        `[PREMIUM] Meeting transcript generated. ${messages.length} messages summarized. ${deduction.creditsDeducted} credits used.`);

      return {
        success: true,
        transcriptId,
        summary: transcript.summary,
        actionItems: transcript.actionItems,
        creditsUsed: deduction.creditsDeducted,
      };
    } catch (error: any) {
      console.error('[ShiftChatroom] Error generating transcript:', error);
      return {
        success: false,
        error: error.message,
      };
    }
  }

  /**
   * Generate AI-powered transcript and summary
   */
  private async generateAITranscript(
    chatroom: any,
    messages: any[]
  ): Promise<{ summary: string; actionItems: string[]; keyTopics: string[] }> {
    try {
      // Format messages for AI processing
      const formattedMessages = messages
        .filter(m => m.messageType !== 'system')
        .map(m => `[${new Date(m.createdAt!).toLocaleTimeString()}] ${m.userId}: ${m.content}`)
        .join('\n');

      // For now, generate a simple summary (in production, this would use Trinity AI)
      const messageCount = messages.length;
      const participantCount = new Set(messages.map(m => m.userId)).size;
      const photoCount = messages.filter(m => m.messageType === 'photo').length;
      
      const summary = `Meeting summary for ${chatroom.name}:
- Duration: ${messages.length > 0 ? Math.ceil((new Date(messages[messages.length - 1].createdAt!).getTime() - new Date(messages[0].createdAt!).getTime()) / 60000) : 0} minutes
- ${messageCount} messages exchanged
- ${participantCount} participants
- ${photoCount} photos shared
- Key discussions covered shift operations and team coordination.`;

      const actionItems = [
        'Review shift completion status',
        'Follow up on any reported incidents',
        'Update client on service delivery',
      ];

      const keyTopics = ['Shift Status', 'Team Coordination', 'Client Updates'];

      return { summary, actionItems, keyTopics };
    } catch (error) {
      console.error('[ShiftChatroom] Error generating AI transcript:', error);
      return {
        summary: 'Unable to generate summary',
        actionItems: [],
        keyTopics: [],
      };
    }
  }

  /**
   * Get premium feature status for a chatroom
   */
  async getPremiumFeatureStatus(
    chatroomId: string,
    workspaceId: string
  ): Promise<{
    trinityRecording: { enabled: boolean; available: boolean; creditCost: number };
    aiDar: { enabled: boolean; available: boolean; creditCost: number };
  }> {
    try {
      const { premiumFeatureGating } = await import('./premiumFeatureGating');
      
      const [chatroom] = await db.select()
        .from(shiftChatrooms)
        .where(eq(shiftChatrooms.id, chatroomId));

      const recordingAccess = await premiumFeatureGating.checkAccess(workspaceId, 'trinity_meeting_recording');
      const darAccess = await premiumFeatureGating.checkAccess(workspaceId, 'ai_dar_generation');

      return {
        trinityRecording: {
          enabled: chatroom?.trinityRecordingEnabled || false,
          available: recordingAccess.allowed,
          creditCost: recordingAccess.creditCost || 5,
        },
        aiDar: {
          enabled: true, // DAR is always available if tier allows
          available: darAccess.allowed,
          creditCost: darAccess.creditCost || 2,
        },
      };
    } catch (error) {
      console.error('[ShiftChatroom] Error getting premium status:', error);
      return {
        trinityRecording: { enabled: false, available: false, creditCost: 5 },
        aiDar: { enabled: false, available: false, creditCost: 2 },
      };
    }
  }
}

export const shiftChatroomWorkflowService = ShiftChatroomWorkflowService.getInstance();

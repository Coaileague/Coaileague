/**
 * WITH EXECUTION PIPELINE - Route Helper
 * =======================================
 * Universal enforcement wrapper for ALL Express routes.
 * Ensures every API endpoint uses the 7-step execution pattern.
 * 
 * Usage:
 * ```ts
 * app.post('/api/example', withExecutionPipeline({
 *   operationType: 'crud',
 *   operationName: 'create_example',
 *   handler: async (req, res, ctx) => {
 *     // Your route logic here
 *     return { data: result };
 *   },
 *   validate: async (ctx, fetched) => ({ valid: true }),
 *   notify: async (ctx, result) => ['example-notification']
 * }));
 * ```
 */

import { Request, Response, NextFunction, RequestHandler } from 'express';
import { ExecutionPipeline, PipelineContext, OperationType, InitiatorType, StepHandlers } from './executionPipeline';

export interface PipelineRouteOptions<T = any> {
  operationType: OperationType;
  operationName: string;
  initiatorType?: InitiatorType;
  
  handler: (req: Request, res: Response, ctx: PipelineContext) => Promise<T>;
  
  fetch?: (ctx: PipelineContext, req: Request) => Promise<Record<string, any>>;
  validate?: (ctx: PipelineContext, fetchedData: Record<string, any>, req: Request) => Promise<{ valid: boolean; errors?: string[] }>;
  mutate?: (ctx: PipelineContext, processResult: T) => Promise<{ tables: string[]; recordsChanged: number }>;
  confirm?: (ctx: PipelineContext, mutationDetails: { tables: string[]; recordsChanged: number }) => Promise<boolean>;
  notify?: (ctx: PipelineContext, result: T, req: Request) => Promise<string[]>;
  
  skipCreditCheck?: boolean;
  skipNotifications?: boolean;
  requireAuth?: boolean;
  requireWorkspace?: boolean;
}

interface AuthenticatedRequest extends Request {
  user?: { id: number; email?: string; username?: string };
  workspace?: { id: string; name?: string };
  workspaceId?: string;
  userId?: number;
}

export function withExecutionPipeline<T = any>(
  options: PipelineRouteOptions<T>
): RequestHandler {
  const pipeline = ExecutionPipeline.getInstance();
  
  return async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
    const startTime = Date.now();
    
    try {
      const userId = req.user?.id || req.userId;
      const workspaceId = req.workspace?.id || req.workspaceId || (req.body?.workspaceId as string);
      
      if (options.requireAuth && !userId) {
        return res.status(401).json({ 
          error: 'Authentication required',
          step: 'TRIGGER',
          pipelineEnforced: true
        });
      }
      
      if (options.requireWorkspace && !workspaceId) {
        return res.status(400).json({ 
          error: 'Workspace ID required',
          step: 'TRIGGER',
          pipelineEnforced: true
        });
      }
      
      const initiator = userId ? `user:${userId}` : 'anonymous';
      
      const handlers: StepHandlers<T> = {
        fetch: options.fetch 
          ? async (ctx) => options.fetch!(ctx, req)
          : undefined,
          
        validate: options.validate
          ? async (ctx, fetchedData) => options.validate!(ctx, fetchedData, req)
          : undefined,
          
        process: async (ctx) => {
          return await options.handler(req, res, ctx);
        },
        
        mutate: options.mutate,
        confirm: options.confirm,
        
        notify: options.notify
          ? async (ctx, result) => options.notify!(ctx, result, req)
          : undefined,
      };
      
      const result = await pipeline.execute<T>(
        {
          workspaceId,
          operationType: options.operationType,
          operationName: options.operationName,
          initiator,
          initiatorType: options.initiatorType || 'user',
          payload: {
            method: req.method,
            path: req.path,
            bodyKeys: Object.keys(req.body || {}),
          },
          skipCreditCheck: options.skipCreditCheck,
          skipNotifications: options.skipNotifications,
        },
        handlers
      );
      
      const duration = Date.now() - startTime;
      
      if (!result.success) {
        const statusCode = result.context.failedAtStep === 3 ? 400 : 
                          result.context.failedAtStep === 2 ? 403 : 500;
        
        return res.status(statusCode).json({
          error: result.error?.message || 'Pipeline execution failed',
          failedAtStep: result.context.failedAtStep,
          steps: result.context.steps,
          executionId: result.context.executionId,
          pipelineEnforced: true,
          durationMs: duration,
        });
      }
      
      if (!res.headersSent) {
        return res.json({
          success: true,
          data: result.result,
          executionId: result.context.executionId,
          pipelineEnforced: true,
          steps: result.context.steps,
          durationMs: duration,
        });
      }
    } catch (error: any) {
      console.error(`[withExecutionPipeline] ${options.operationName} failed:`, error);
      
      if (!res.headersSent) {
        return res.status(500).json({
          error: error.message || 'Internal pipeline error',
          pipelineEnforced: true,
          operationName: options.operationName,
        });
      }
    }
  };
}

export function createPipelineRoute<T = any>(
  operationType: OperationType,
  operationName: string,
  handler: (req: Request, res: Response, ctx: PipelineContext) => Promise<T>,
  extraOptions?: Partial<PipelineRouteOptions<T>>
): RequestHandler {
  return withExecutionPipeline({
    operationType,
    operationName,
    handler,
    ...extraOptions,
  });
}

export const pipelineRoute = {
  crud: <T>(name: string, handler: (req: Request, res: Response, ctx: PipelineContext) => Promise<T>) =>
    createPipelineRoute('crud', name, handler, { requireAuth: true }),
    
  feature: <T>(name: string, handler: (req: Request, res: Response, ctx: PipelineContext) => Promise<T>) =>
    createPipelineRoute('feature_action', name, handler, { requireAuth: true }),
    
  ai: <T>(name: string, handler: (req: Request, res: Response, ctx: PipelineContext) => Promise<T>) =>
    createPipelineRoute('ai_call', name, handler, { requireAuth: true }),
    
  automation: <T>(name: string, handler: (req: Request, res: Response, ctx: PipelineContext) => Promise<T>) =>
    createPipelineRoute('automation', name, handler, { initiatorType: 'system' }),
    
  webhook: <T>(name: string, handler: (req: Request, res: Response, ctx: PipelineContext) => Promise<T>) =>
    createPipelineRoute('inbound_opportunity', name, handler, { initiatorType: 'webhook', skipCreditCheck: true }),
};

export function ensurePipelineEnforced(app: any): void {
  console.log('[Pipeline] Universal 7-step execution enforcement active');
  console.log('[Pipeline] All routes must use withExecutionPipeline or pipelineRoute helpers');
}

/**
 * Stripe Connect Payout Service
 * 
 * Enables employee payroll payouts via Stripe Connect Custom accounts.
 * Provides an alternative to QuickBooks/Gusto for orgs using Stripe-local mode.
 * 
 * Features:
 * - Create Connect accounts for employees
 * - Process payroll payouts via Stripe Transfers
 * - Track payout status and history
 * - Handle compliance (1099 reporting)
 */

import Stripe from 'stripe';
import { db } from '../../db';
import { employees, payrollEntries, payrollRuns } from '@shared/schema';
import { eq, and } from 'drizzle-orm';
import { auditLogger } from '../audit-logger';
import { providerPreferenceService } from './providerPreferenceService';

// Initialize Stripe with API key
const stripe = process.env.STRIPE_SECRET_KEY 
  ? new Stripe(process.env.STRIPE_SECRET_KEY, { apiVersion: '2025-01-27.acacia' as any })
  : null;

export interface ConnectAccountStatus {
  hasAccount: boolean;
  accountId?: string;
  payoutsEnabled: boolean;
  requiresOnboarding: boolean;
  onboardingUrl?: string;
}

export interface PayoutResult {
  success: boolean;
  transferId?: string;
  amount: number;
  currency: string;
  error?: string;
}

class StripeConnectPayoutService {
  /**
   * Check if Stripe Connect is available
   */
  isAvailable(): boolean {
    return !!stripe;
  }

  /**
   * Create or get Connect account for employee
   */
  async getOrCreateConnectAccount(
    employeeId: string,
    workspaceId: string,
    employeeEmail: string,
    employeeName: string
  ): Promise<ConnectAccountStatus> {
    if (!stripe) {
      return { 
        hasAccount: false, 
        payoutsEnabled: false, 
        requiresOnboarding: true,
        error: 'Stripe not configured'
      } as ConnectAccountStatus & { error: string };
    }

    try {
      // Check if employee already has a Connect account stored
      const [employee] = await db.select()
        .from(employees)
        .where(eq(employees.id, employeeId))
        .limit(1);

      if (!employee) {
        throw new Error('Employee not found');
      }

      // Check for existing Connect account ID in metadata
      const metadata = employee.customData as Record<string, any> || {};
      const existingAccountId = metadata.stripeConnectAccountId;

      if (existingAccountId) {
        // Verify account still exists and get status
        try {
          const account = await stripe.accounts.retrieve(existingAccountId);
          return {
            hasAccount: true,
            accountId: account.id,
            payoutsEnabled: account.payouts_enabled || false,
            requiresOnboarding: !account.details_submitted,
            onboardingUrl: !account.details_submitted 
              ? await this.createOnboardingLink(account.id, workspaceId)
              : undefined
          };
        } catch (err: any) {
          // Account may have been deleted, create new one
          console.log('[StripeConnect] Previous account not found, creating new');
        }
      }

      // Create new Connect Custom account
      const account = await stripe.accounts.create({
        type: 'custom',
        country: 'US',
        email: employeeEmail,
        capabilities: {
          transfers: { requested: true },
        },
        business_type: 'individual',
        individual: {
          email: employeeEmail,
          first_name: employee.firstName || employeeName.split(' ')[0],
          last_name: employee.lastName || employeeName.split(' ').slice(1).join(' ') || 'Employee',
        },
        metadata: {
          employeeId,
          workspaceId,
          platform: 'coaileague'
        },
        tos_acceptance: {
          service_agreement: 'recipient',
        },
      });

      // Store Connect account ID on employee record
      await db.update(employees)
        .set({
          customData: {
            ...metadata,
            stripeConnectAccountId: account.id,
            stripeConnectCreatedAt: new Date().toISOString(),
          }
        })
        .where(eq(employees.id, employeeId));

      // Audit log
      await auditLogger.logEvent(
        { actorId: 'system', actorType: 'SYSTEM', actorName: 'Stripe Connect', workspaceId },
        {
          eventType: 'stripe_connect.account_created',
          aggregateId: employeeId,
          aggregateType: 'employee',
          payload: { accountId: account.id },
        },
        { generateHash: true }
      ).catch(console.error);

      // Generate onboarding link
      const onboardingUrl = await this.createOnboardingLink(account.id, workspaceId);

      return {
        hasAccount: true,
        accountId: account.id,
        payoutsEnabled: false,
        requiresOnboarding: true,
        onboardingUrl,
      };
    } catch (error: any) {
      console.error('[StripeConnect] Error creating account:', error);
      return {
        hasAccount: false,
        payoutsEnabled: false,
        requiresOnboarding: true,
      };
    }
  }

  /**
   * Create onboarding link for employee to complete account setup
   */
  private async createOnboardingLink(accountId: string, workspaceId: string): Promise<string> {
    if (!stripe) throw new Error('Stripe not configured');

    const baseUrl = process.env.REPLIT_DEV_DOMAIN 
      ? `https://${process.env.REPLIT_DEV_DOMAIN}`
      : 'https://coaileague.com';

    const accountLink = await stripe.accountLinks.create({
      account: accountId,
      refresh_url: `${baseUrl}/employee/payroll/connect?refresh=true`,
      return_url: `${baseUrl}/employee/payroll/connect?success=true`,
      type: 'account_onboarding',
    });

    return accountLink.url;
  }

  /**
   * Process payroll payout to employee via Stripe Connect
   */
  async processPayrollPayout(
    payrollEntryId: string,
    workspaceId: string
  ): Promise<PayoutResult> {
    if (!stripe) {
      return { success: false, amount: 0, currency: 'usd', error: 'Stripe not configured' };
    }

    try {
      // Verify provider preference
      const prefs = await providerPreferenceService.getPreferences(workspaceId);
      if (prefs.payrollProvider !== 'local') {
        return { 
          success: false, 
          amount: 0, 
          currency: 'usd', 
          error: `Payroll provider is ${prefs.payrollProvider}, not local/Stripe` 
        };
      }

      // Get payroll entry with employee details
      const [entry] = await db.select()
        .from(payrollEntries)
        .where(eq(payrollEntries.id, payrollEntryId))
        .limit(1);

      if (!entry) {
        return { success: false, amount: 0, currency: 'usd', error: 'Payroll entry not found' };
      }

      // Get employee Connect account
      const [employee] = await db.select()
        .from(employees)
        .where(eq(employees.id, entry.employeeId))
        .limit(1);

      if (!employee) {
        return { success: false, amount: 0, currency: 'usd', error: 'Employee not found' };
      }

      const metadata = employee.customData as Record<string, any> || {};
      const connectAccountId = metadata.stripeConnectAccountId;

      if (!connectAccountId) {
        return { success: false, amount: 0, currency: 'usd', error: 'Employee has no Connect account' };
      }

      // Verify account has payouts enabled
      const account = await stripe.accounts.retrieve(connectAccountId);
      if (!account.payouts_enabled) {
        return { success: false, amount: 0, currency: 'usd', error: 'Connect account payouts not enabled' };
      }

      // Calculate net pay (should already be calculated in entry)
      const netPay = parseFloat(entry.netPay?.toString() || '0');
      if (netPay <= 0) {
        return { success: false, amount: 0, currency: 'usd', error: 'No net pay to transfer' };
      }

      // Convert to cents for Stripe
      const amountCents = Math.round(netPay * 100);

      // Create transfer to employee's Connect account
      const transfer = await stripe.transfers.create({
        amount: amountCents,
        currency: 'usd',
        destination: connectAccountId,
        description: `Payroll: ${entry.periodStart} - ${entry.periodEnd}`,
        metadata: {
          payrollEntryId,
          employeeId: entry.employeeId,
          workspaceId,
          periodStart: entry.periodStart?.toISOString() || '',
          periodEnd: entry.periodEnd?.toISOString() || '',
        },
      });

      // Update payroll entry with transfer info
      await db.update(payrollEntries)
        .set({
          status: 'paid',
          paidAt: new Date(),
          paymentMethod: 'stripe_connect',
          paymentReference: transfer.id,
        })
        .where(eq(payrollEntries.id, payrollEntryId));

      // Audit log
      await auditLogger.logEvent(
        { actorId: 'system', actorType: 'SYSTEM', actorName: 'Stripe Connect Payout', workspaceId },
        {
          eventType: 'stripe_connect.payout_sent',
          aggregateId: payrollEntryId,
          aggregateType: 'payroll_entry',
          payload: { 
            transferId: transfer.id, 
            amount: netPay, 
            employeeId: entry.employeeId 
          },
        },
        { generateHash: true }
      ).catch(console.error);

      return {
        success: true,
        transferId: transfer.id,
        amount: netPay,
        currency: 'usd',
      };
    } catch (error: any) {
      console.error('[StripeConnect] Payout error:', error);
      return {
        success: false,
        amount: 0,
        currency: 'usd',
        error: error.message || 'Payout failed',
      };
    }
  }

  /**
   * Process all pending payroll entries for a payroll run
   */
  async processPayrollRun(
    payrollRunId: string,
    workspaceId: string
  ): Promise<{ processed: number; failed: number; errors: string[] }> {
    const results = { processed: 0, failed: 0, errors: [] as string[] };

    try {
      // Get all entries for this payroll run
      const entries = await db.select()
        .from(payrollEntries)
        .where(
          and(
            eq(payrollEntries.payrollRunId, payrollRunId),
            eq(payrollEntries.status, 'approved')
          )
        );

      console.log(`[StripeConnect] Processing ${entries.length} payroll entries for run ${payrollRunId}`);

      for (const entry of entries) {
        const result = await this.processPayrollPayout(entry.id, workspaceId);
        if (result.success) {
          results.processed++;
        } else {
          results.failed++;
          results.errors.push(`${entry.employeeId}: ${result.error}`);
        }
      }

      // Update payroll run status
      if (results.processed > 0 && results.failed === 0) {
        await db.update(payrollRuns)
          .set({ status: 'completed', completedAt: new Date() })
          .where(eq(payrollRuns.id, payrollRunId));
      } else if (results.failed > 0) {
        await db.update(payrollRuns)
          .set({ status: 'partial' })
          .where(eq(payrollRuns.id, payrollRunId));
      }

      return results;
    } catch (error: any) {
      console.error('[StripeConnect] Payroll run error:', error);
      results.errors.push(error.message);
      return results;
    }
  }

  /**
   * Get payout history for an employee
   */
  async getPayoutHistory(
    employeeId: string,
    limit: number = 10
  ): Promise<Array<{ id: string; amount: number; status: string; created: Date }>> {
    if (!stripe) return [];

    try {
      const [employee] = await db.select()
        .from(employees)
        .where(eq(employees.id, employeeId))
        .limit(1);

      if (!employee) return [];

      const metadata = employee.customData as Record<string, any> || {};
      const connectAccountId = metadata.stripeConnectAccountId;

      if (!connectAccountId) return [];

      const transfers = await stripe.transfers.list({
        destination: connectAccountId,
        limit,
      });

      return transfers.data.map(t => ({
        id: t.id,
        amount: t.amount / 100, // Convert from cents
        status: t.reversed ? 'reversed' : 'completed',
        created: new Date(t.created * 1000),
      }));
    } catch (error: any) {
      console.error('[StripeConnect] Error fetching payout history:', error);
      return [];
    }
  }
}

export const stripeConnectPayoutService = new StripeConnectPayoutService();

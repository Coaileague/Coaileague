/**
 * Monthly Credit Reset Cron Job
 * ===============================
 * Automatically refills credits on the 1st of each month based on subscription tier.
 * 
 * KEY POLICIES:
 * 1. Monthly Reset: Credits refresh on 1st of each month
 * 2. Rollover: Unused credits roll over month-to-month within the year
 * 3. Year-End Expiry: All unused credits expire Dec 31st (use-it-or-lose-it)
 * 4. Anti-Gaming: Cancel/reactivate within 30 days = no credit refresh
 */

import { db } from '../../db';
import { workspaceCredits, workspaces, creditTransactions } from '@shared/schema';
import { eq, sql, gte, and } from 'drizzle-orm';
import { TIER_MONTHLY_CREDITS } from './creditManager';

/**
 * Max rollover cap per tier (prevents credit hoarding)
 * Credits above this cap are forfeited on monthly reset
 * Set to 1 month of allocation max to prevent excessive hoarding
 */
const MAX_ROLLOVER_CAP: Record<string, number> = {
  'free': 250,              // 1 month rollover max
  'starter': 2000,          // 1 month rollover max
  'professional': 8000,     // 1 month rollover max
  'enterprise': 25000,      // 1 month rollover max
  'unlimited': 25000,       // Legacy tier - same as enterprise
  'platform_staff': 10000,  // Internal
};

/**
 * Reset credits for all workspaces on the 1st of the month
 * Should be called via cron job at: 0 0 1 * * (midnight on 1st of month)
 */
export async function resetMonthlyCredits() {
  console.log('=================================================');
  console.log('🔄 MONTHLY CREDIT RESET - START');
  console.log(`Timestamp: ${new Date().toISOString()}`);
  console.log('=================================================');

  const isJanuary = new Date().getMonth() === 0; // January = 0
  if (isJanuary) {
    console.log('🎆 YEAR-END RESET: All unused credits will expire!');
  }

  try {
    // Get all active workspaces with subscription info
    const allWorkspaces = await db
      .select({
        id: workspaces.id,
        subscriptionTier: workspaces.subscriptionTier,
        subscriptionStartDate: workspaces.createdAt,
      })
      .from(workspaces);

    let resetCount = 0;
    let errorCount = 0;
    let expiredCredits = 0;

    for (const workspace of allWorkspaces) {
      try {
        const tier = (workspace.subscriptionTier || 'free').toLowerCase();
        const monthlyAllocation = TIER_MONTHLY_CREDITS[tier] || TIER_MONTHLY_CREDITS['free'];
        const maxRollover = MAX_ROLLOVER_CAP[tier] || MAX_ROLLOVER_CAP['free'];

        // Get current credit record
        const [creditRecord] = await db
          .select()
          .from(workspaceCredits)
          .where(eq(workspaceCredits.workspaceId, workspace.id))
          .limit(1);

        if (!creditRecord) {
          console.log(`⚠️  No credit record found for workspace ${workspace.id}, skipping`);
          continue;
        }

        // YEAR-END EXPIRY: If January, expire all rolled-over credits first
        let currentBalance = creditRecord.currentBalance;
        if (isJanuary && currentBalance > 0) {
          expiredCredits += currentBalance;
          console.log(`🎆 Expiring ${currentBalance} year-end credits for workspace ${workspace.id}`);
          currentBalance = 0; // Start fresh in January
        }

        // Apply rollover cap (prevent credit hoarding)
        const cappedBalance = Math.min(currentBalance, maxRollover);
        const forfeitedCredits = currentBalance - cappedBalance;
        if (forfeitedCredits > 0) {
          console.log(`📉 Capping rollover: ${forfeitedCredits} credits forfeited (exceeded ${tier} cap of ${maxRollover})`);
        }

        // Calculate new balance (capped rollover + monthly allocation)
        const newBalance = cappedBalance + monthlyAllocation;

        // Update credit record
        await db
          .update(workspaceCredits)
          .set({
            currentBalance: newBalance,
            monthlyAllocation,
            lastResetAt: new Date(),
            nextResetAt: getNextResetDate(),
            totalCreditsEarned: sql`${workspaceCredits.totalCreditsEarned} + ${monthlyAllocation}`,
          })
          .where(eq(workspaceCredits.workspaceId, workspace.id));

        console.log(`✅ Reset credits for workspace ${workspace.id} (${tier}): ${cappedBalance} rollover + ${monthlyAllocation} new = ${newBalance}`);
        resetCount++;

      } catch (error) {
        console.error(`❌ Error resetting credits for workspace ${workspace.id}:`, error);
        errorCount++;
      }
    }

    console.log('\n=================================================');
    console.log('📊 MONTHLY CREDIT RESET - SUMMARY');
    console.log(`Total Workspaces: ${allWorkspaces.length}`);
    console.log(`Successfully Reset: ${resetCount}`);
    console.log(`Errors: ${errorCount}`);
    if (isJanuary) {
      console.log(`🎆 Year-End Credits Expired: ${expiredCredits.toLocaleString()}`);
    }
    console.log('=================================================\n');

  } catch (error) {
    console.error('💥 Critical error in monthly credit reset:', error);
    throw error;
  }
}

/**
 * Calculate the next reset date (1st of next month at midnight UTC)
 */
function getNextResetDate(): Date {
  const now = new Date();
  const nextMonth = new Date(now.getFullYear(), now.getMonth() + 1, 1, 0, 0, 0, 0);
  return nextMonth;
}

/**
 * One-time credit reset for testing (resets immediately)
 * WARNING: Only use in development/testing
 */
export async function resetCreditsNow(workspaceId: string) {
  const [workspace] = await db
    .select()
    .from(workspaces)
    .where(eq(workspaces.id, workspaceId))
    .limit(1);

  if (!workspace) {
    throw new Error('Workspace not found');
  }

  const tier = (workspace.subscriptionTier || 'free').toLowerCase();
  const monthlyAllocation = TIER_MONTHLY_CREDITS[tier] || TIER_MONTHLY_CREDITS['free'];

  const [creditRecord] = await db
    .select()
    .from(workspaceCredits)
    .where(eq(workspaceCredits.workspaceId, workspaceId))
    .limit(1);

  if (!creditRecord) {
    throw new Error('Credit record not found');
  }

  const newBalance = creditRecord.currentBalance + monthlyAllocation;

  await db
    .update(workspaceCredits)
    .set({
      currentBalance: newBalance,
      lastResetAt: new Date(),
      nextResetAt: getNextResetDate(),
      totalCreditsEarned: sql`${workspaceCredits.totalCreditsEarned} + ${monthlyAllocation}`,
    })
    .where(eq(workspaceCredits.workspaceId, workspaceId));

  console.log(`✅ Manual reset: Added ${monthlyAllocation} credits to workspace ${workspaceId}`);
  return { success: true, creditsAdded: monthlyAllocation, newBalance };
}

/**
 * Credit Management Service
 * 
 * Core service for managing workspace automation credits:
 * - Check credit balance before AI operations
 * - Deduct credits when automations run
 * - Add credits from purchases or monthly allocation
 * - Track all credit transactions with full audit trail
 * 
 * Design: Credits are pre-paid "automation tokens" that users purchase to power AI features.
 * Each automation (scheduling, invoicing, payroll) costs a specific number of credits.
 * 
 * BILLING ARCHITECTURE (Consolidated):
 * ====================================
 * This is the CANONICAL service for credit operations. Other billing services have specific roles:
 * 
 * 1. creditManager (THIS FILE) - Core credit balance/transaction management
 *    - getBalance(), deductCredits(), addCredits()
 *    - CREDIT_COSTS lookup for feature pricing
 *    - isUnlimitedCreditUser() for privilege checks
 * 
 * 2. aiCreditGateway - Request classification layer
 *    - Classifies requests as CHIT_CHAT (free) vs BUSINESS (paid)
 *    - Determines creditCost based on feature and user message
 *    - Enforces billing before AI operations
 * 
 * 3. usageMeteringService - Usage event recording
 *    - Records granular usage events to aiUsageEvents table
 *    - Handles hybrid billing (allowance + overage)
 *    - Creates daily rollups for billing reports
 * 
 * 4. meteredGeminiClient - AI client with billing enforcement
 *    - MUST be used for all metered AI calls
 *    - Integrates with aiCreditGateway + usageMeteringService
 * 
 * CALL FLOW:
 * User Request → aiCreditGateway.authorize() → creditManager.hasCredits()
 *             → meteredGeminiClient.generate() → usageMeteringService.recordUsage()
 *             → creditManager.deductCredits()
 */

import { db } from '../../db';
import { 
  workspaceCredits, 
  creditTransactions, 
  aiUsageEvents,
  workspaces,
  type InsertCreditTransaction,
  type WorkspaceCredits 
} from '@shared/schema';
import { eq, and, desc, gte, lte, sql } from 'drizzle-orm';
import { getUserPlatformRole, hasPlatformWideAccess, getUserWorkspaceRole, type PlatformRole } from '../../rbac';

// ============================================================================
// ============================================================================
// TIER-BASED MONTHLY CREDIT ALLOWANCES
// ============================================================================
// NO tier is truly "unlimited" - even Enterprise has high limits for profitability
// Overages are billed at fair rates to ensure platform sustainability
//
// Business Model:
// - Monthly allowance covers normal usage patterns
// - Overages are billed at $0.01/credit (same as standard rate)
// - Enterprise gets 10x Starter allocation, not unlimited
// - Platform staff get operational credits but not infinite
// ============================================================================

/**
 * Monthly credit allowances per subscription tier
 * RIGHT-SIZED allocations based on realistic usage patterns
 * 
 * Tier Allocations (Jan 2026 - Waste Prevention Update):
 * - free: 250 credits/month - trial/demo only
 * - starter: 2,000 credits/month - small businesses (covers 2-4x typical usage)
 * - professional: 8,000 credits/month - growing orgs with premium features
 * - enterprise: 25,000 credits/month - large enterprises
 * - platform_staff: 10,000 credits/month - internal ops
 * 
 * HYBRID CREDIT MODEL:
 * - Core features: 1x (normal credit cost)
 * - Premium features: 2x multiplier (Claude, advanced analytics, strategic AI)
 * - Premium features can also be purchased à la carte
 * 
 * Overage rates: $0.01/credit (1 credit = $0.01)
 * When credits depleted: User prompted to refill before continuing
 */
export const TIER_MONTHLY_CREDITS: Record<string, number> = {
  'free': 250,              // $2.50/month value - trial only
  'starter': 2000,          // $20/month value - 1-15 employees
  'professional': 8000,     // $80/month value - 16-50 employees
  'enterprise': 25000,      // $250/month value - 50+ employees
  'unlimited': 25000,       // Legacy tier - same as enterprise
  'platform_staff': 10000,  // Internal operations
};

/**
 * CREDIT MULTIPLIERS - Hybrid Pricing Model
 * Core features use 1x, Premium features use 2x
 */
export const CREDIT_MULTIPLIERS = {
  CORE: 1,      // Basic features included in subscription
  PREMIUM: 2,   // Premium AI features (Claude, strategic, advanced)
} as const;

/**
 * Premium features that use 2x credit multiplier
 * These are high-value AI operations using Claude or Gemini Pro
 */
export const PREMIUM_FEATURES = new Set([
  // Claude/Anthropic operations
  'claude_analysis',
  'claude_strategic', 
  'claude_executive',
  'claude_premium_ai',
  'claude_rfp_response',
  'claude_capability_statement',
  'claude_contract_review',
  'claude_proposal',
  // Advanced analytics (Gemini Pro)
  'ai_analytics_report',
  'ai_predictions',
  'financial_insights',
  'financial_pl_summary',
  'financial_client_profitability',
  'strategic_schedule_optimization',
  // Data operations
  'ai_migration',
]);

/**
 * Overage rate per credit (cost to customer when exceeding allowance)
 * 1 credit = $0.01 (same as standard rate)
 */
export const OVERAGE_RATE_PER_CREDIT = 0.01;

/**
 * Roles that get platform_staff credit allocation (high but not infinite)
 */
const PLATFORM_STAFF_ROLES: PlatformRole[] = ['root_admin', 'deputy_admin', 'sysop', 'support_manager', 'support_agent'];

/**
 * Check if user is platform staff (for tier assignment, not unlimited access)
 */
export async function isPlatformStaff(userId: string): Promise<boolean> {
  const platformRole = await getUserPlatformRole(userId);
  return hasPlatformWideAccess(platformRole);
}

/**
 * Get the monthly credit allowance for a workspace based on subscription tier
 * Returns the tier name and monthly credit limit
 */
export async function getWorkspaceTierAllowance(workspaceId: string, userId?: string): Promise<{
  tier: string;
  monthlyAllowance: number;
  isPlatformStaff: boolean;
}> {
  // Check if user is platform staff (they get platform_staff allocation)
  let staffCheck = false;
  if (userId) {
    staffCheck = await isPlatformStaff(userId);
    if (staffCheck) {
      return {
        tier: 'platform_staff',
        monthlyAllowance: TIER_MONTHLY_CREDITS['platform_staff'],
        isPlatformStaff: true,
      };
    }
  }
  
  // Get workspace subscription tier
  const [workspace] = await db.select()
    .from(workspaces)
    .where(eq(workspaces.id, workspaceId))
    .limit(1);
  
  if (!workspace) {
    // Default to free tier if workspace not found
    return {
      tier: 'free',
      monthlyAllowance: TIER_MONTHLY_CREDITS['free'],
      isPlatformStaff: false,
    };
  }
  
  const tier = workspace.subscriptionTier || 'free';
  const monthlyAllowance = TIER_MONTHLY_CREDITS[tier] || TIER_MONTHLY_CREDITS['free'];
  
  return {
    tier,
    monthlyAllowance,
    isPlatformStaff: false,
  };
}

/**
 * DEPRECATED: No user has truly unlimited credits anymore
 * All tiers have generous but defined monthly limits
 * 
 * This function now always returns FALSE to ensure all usage is tracked
 * and billed appropriately. Use getWorkspaceTierAllowance() to get limits.
 */
export async function isUnlimitedCreditUser(userId: string, workspaceId: string): Promise<boolean> {
  // NO ONE gets truly unlimited credits - everyone has tier-based limits
  // This prevents platform cost overruns and ensures profitability
  return false;
}

/**
 * Sentinel value for unlimited credits display
 */
export const UNLIMITED_CREDITS_BALANCE = 999999999;

// Credit cost per feature (calibrated to Gemini 3 API costs Jan 2026)
// 1 credit = $0.01 | Gemini 3 Pro: $2/1M input, $12/1M output (thinking tokens at output rate)
// Gemini 3 Flash: $0.50/1M input, $3/1M output
// Thinking mode adds 2K-5K extra output tokens per request
// Pricing: Actual cost × 4x margin = fair credits
// 
// GEMINI 3 PRO example (complex reasoning, ~2K input + 5K thinking + 2K response):
//   Cost: (2K × $2/M) + (7K × $12/M) = $0.004 + $0.084 = $0.088
//   With 4x margin = $0.35 → 35 credits
// 
// GEMINI 3 FLASH example (standard tasks, ~2K input + 3K thinking + 1.5K response):
//   Cost: (2K × $0.50/M) + (4.5K × $3/M) = $0.001 + $0.0135 = $0.015
//   With 4x margin = $0.06 → 6 credits
export const CREDIT_COSTS = {
  // AI Scheduling - Gemini 3 Flash with thinking
  'ai_scheduling': 8,             // Full schedule generation (Flash)
  'ai_schedule_optimization': 6,  // Optimize existing schedule (Flash)
  'ai_shift_matching': 3,         // Match employee to single shift (Flash)
  'ai_open_shift_fill': 5,        // AI-powered open shift auto-fill (Flash)
  
  // AI Invoicing - Gemini 3 Flash with thinking
  'ai_invoice_generation': 6,     // Generate invoice from timesheet (Flash)
  'ai_invoice_review': 3,         // Review invoice for errors (Flash)
  'invoice_gap_analysis': 5,      // Analyze unbilled revenue gaps (Flash)
  
  // AI Payroll - Gemini 3 Flash with thinking
  'ai_payroll_processing': 8,     // Process payroll run (Flash)
  'ai_payroll_verification': 3,   // Verify payroll calculations (Flash)
  'payroll_anomaly_insights': 5,  // Anomaly detection insights (Flash)
  
  // AI Communications - Gemini 3 Flash (no thinking for speed)
  'ai_chat_query': 3,             // HelpAI or QueryOS chat message
  'ai_email_generation': 4,       // Generate email content
  
  // AI Analytics - Gemini 3 Pro with thinking (complex reasoning)
  'ai_analytics_report': 15,      // Generate analytics report (Pro)
  'ai_predictions': 12,           // Predictive analytics (Pro)
  
  // AI Migration - Gemini 3 Pro Vision (multimodal, expensive)
  'ai_migration': 25,             // Gemini Vision data extraction (Pro Vision)
  
  // Inbound Opportunity Agent - Gemini 3 Flash with thinking
  'ai_email_classification': 2,   // Classify if email is shift request (Flash)
  'ai_shift_extraction': 5,       // Extract shift details from email (Flash)
  'ai_inbound_shift_matching': 4, // Match and rank employees for shift (Flash) - inbound agent
  'ai_match_approval': 3,         // AI approval of employee-shift match (Flash)
  'ai_contractor_email': 4,       // Generate contractor confirmation email (Flash)
  
  // Email Intelligence Service - Billed to org (used for email analysis)
  'email_intelligence_analysis': 3,    // Email analysis and classification (Flash)
  'email_intelligence_compose': 4,     // Smart compose suggestions (Flash)
  'email_intelligence_summary': 5,     // Thread summarization (Flash)
  'email_intelligence_reply': 4,       // Reply suggestions (Flash)
  'email_intelligence_compliance': 3,  // Compliance check (Flash)
  
  // Automation & Orchestration - Billed to org
  'automation_summary': 2,             // Automation execution summary (Flash)
  'automation_remediation': 3,         // Remediation step generation (Flash)
  'onboarding_task_generation': 4,     // Onboarding task generation (Flash)
  
  // Data Migration - Billed to org (expensive operations)
  'data_migration_mapping': 5,         // Column mapping analysis (Flash)
  'data_migration_extraction': 8,      // Data extraction from documents (Flash)
  'data_migration_compliance': 5,      // Compliance validation (Flash)
  
  // ==========================================================================
  // TRINITY STAFFING - Premier Automated Scheduling
  // Full workflow from email → staffed shift in minutes
  // ==========================================================================
  'trinity_staffing_scan': 5,           // Per hour of active email scanning (Flash)
  'trinity_staffing_parse': 8,          // Parse work request email (Flash with thinking)
  'trinity_staffing_auto_assign': 6,    // AI employee matching & assignment (Flash with thinking)
  'trinity_staffing_confirmation': 4,   // Generate client confirmation email (Flash)
  'trinity_staffing_cancellation': 2,   // Process cancellation notification (Flash)
  'trinity_staffing_escalation': 1,     // Escalation notification (minimal AI)
  
  // QuickBooks Integration - Gemini 3 Flash with thinking
  'quickbooks_error_analysis': 5, // Error analysis and retry strategy (Flash)
  
  // Financial Intelligence - Gemini 3 Pro (complex P&L analysis)
  'financial_pl_summary': 12,           // P&L dashboard summary generation (Pro)
  'financial_insights': 15,              // AI-powered financial insights (Pro)
  'financial_client_profitability': 10,  // Per-client profitability analysis (Pro)
  'financial_trend_analysis': 8,         // Trend comparison and forecasting (Pro)
  
  // Scheduling Subagent - Model depends on complexity
  'schedule_optimization': 6,     // Schedule optimization (Flash)
  'strategic_schedule_optimization': 20, // Strategic scheduling (Pro with deep reasoning)
  
  // Domain Operations - Gemini 3 Flash
  'log_analysis': 3,              // Log analysis (Flash)
  
  // General AI - Gemini 3 Flash
  'ai_general': 3,                // Generic AI operation (Flash)
  
  // Trinity Conversations - Low cost metered to org (platform absorbs NO costs)
  // Minimal credits so users barely notice but platform doesn't absorb AI costs
  'trinity_thought': 1,           // Trinity thought bubbles (Flash, minimal tokens)
  'trinity_chat': 2,              // Trinity conversations (Flash)
  'trinity_insight': 1,           // Trinity insights (Flash, minimal tokens)
  'mascot_ask': 1,                // Mascot ask endpoint (Flash)
  'mascot_advice': 2,             // Mascot business advice (Flash)
  'mascot_insight': 1,            // Mascot insights (Flash)
  'helpai_chat': 2,               // HelpAI conversations (Flash)
  
  // Support Pool Features - Billed to org's monthly support allocation
  // Every org pays a base support fee that covers shared support infrastructure
  'support_pool_chat': 1,         // Support chat (billed from org support pool)
  'support_pool_ticket': 2,       // Support ticket AI (billed from org support pool)
  
  // ==========================================================================
  // CLAUDE / ANTHROPIC OPERATIONS (Premium AI - Higher cost due to API pricing)
  // Claude Sonnet: $3/1M input, $15/1M output tokens
  // Average request: ~2K input + ~4K output = $0.006 + $0.06 = $0.066
  // With 4x margin = $0.26 → 25-35 credits depending on complexity
  // ==========================================================================
  'claude_analysis': 25,          // Standard Claude analysis (Sonnet)
  'claude_strategic': 30,         // Strategic/complex reasoning (Sonnet)
  'claude_executive': 35,         // Executive summaries, board reports (Sonnet)
  'claude_premium_ai': 25,        // Generic Claude Premium AI feature
  'claude_rfp_response': 35,      // RFP response generation (high-value)
  'claude_capability_statement': 30, // Capability statement generation
  'claude_contract_review': 30,   // Contract review and analysis
  'claude_proposal': 30,          // Sales proposal generation
  
  // ==========================================================================
  // BOT AI OPERATIONS - Pool Fund Model (Workspace-funded)
  // All bot AI costs are billed to the workspace, not the platform
  // This ensures clients fund their end-user support
  // ==========================================================================
  
  // HelpAI Bot - Support chat and FAQ
  'bot_helpai_greeting': 1,       // Welcome message generation
  'bot_helpai_response': 2,       // Chat response generation
  'bot_helpai_faq': 1,            // FAQ lookup response
  'bot_helpai_escalation': 1,     // Escalation detection
  
  // MeetingBot - Meeting transcription and summarization
  'bot_meeting_transcription': 5, // Full meeting transcription
  'bot_meeting_summary': 4,       // Meeting summary generation
  'bot_meeting_action_items': 2,  // Action item extraction
  'bot_meeting_decisions': 2,     // Decision extraction
  
  // ReportBot - Incident report processing
  'bot_report_detection': 1,      // Detect if message is incident report
  'bot_report_cleanup': 3,        // Clean up unprofessional language
  'bot_report_summary': 4,        // Generate professional report
  'bot_report_routing': 1,        // Route report to correct team
  
  // ClockBot - Time tracking assistance
  'bot_clock_validation': 1,      // Validate clock entry
  'bot_clock_summary': 2,         // Summarize clock entries
  'bot_clock_anomaly': 2,         // Detect clock anomalies
  
  // CleanupBot - Document retention
  'bot_cleanup_retention': 1,     // Apply retention policy
  'bot_cleanup_archive': 2,       // Archive document summary
  
  // Dynamic message generation - Minimal cost billed to org (platform absorbs NOTHING)
  'dynamic_message_generation': 1, // Dynamic bot messages (Flash, minimal)
  'dynamic_motd': 1,              // Dynamic MOTD (Flash, minimal)
  'helpai_dynamic_response': 1,   // HelpAI chit-chat (Flash, minimal)
  
  // ==========================================================================
  // PLATFORM SERVICE COSTS - Fortune 500 Cost Recovery Model
  // All platform infrastructure costs are passed through to workspaces with margin
  // This ensures the platform NEVER absorbs costs - clients fund everything they use
  // 
  // Pricing Model: Actual vendor cost × 3x margin = credits charged
  // 1 credit = $0.01 | All costs rounded up to nearest credit
  // 
  // RESEND EMAIL PRICING (Jan 2026):
  //   - $0.001 per email (first 100/day free, then $0.0025/email)
  //   - Domain: $0/month (included with account)
  //   - With 3x margin: ~1-3 credits per email
  // 
  // GOOGLE WORKSPACE PRICING (Jan 2026):
  //   - Business Starter: $6/user/month
  //   - Amortized per org: $3/org/month = 300 credits/month
  // 
  // TWILIO SMS PRICING (Jan 2026):
  //   - Outbound: $0.0079/segment
  //   - Inbound: $0.0075/segment
  //   - With 3x margin: ~3 credits per SMS
  // 
  // DOMAIN COSTS (Annual amortized monthly):
  //   - .com domain: ~$15/year = $1.25/month = 125 credits/month
  //   - Distributed across active orgs proportionally
  // ==========================================================================
  
  // Email Service Costs (Resend) - Per email with 3x margin
  'email_transactional': 1,          // Standard transactional email ($0.001 × 3 = ~1 credit)
  'email_marketing': 2,              // Marketing/bulk email ($0.0025 × 3 = ~2 credits)
  'email_inbound_processing': 3,     // Inbound email + AI processing ($0.001 + AI = ~3 credits)
  'email_with_attachment': 2,        // Email with attachments (larger payload)
  'email_staffing_confirmation': 2,  // Client confirmation emails (premium routing)
  'email_employee_notification': 1,  // Employee notifications
  'email_payroll_notification': 1,   // Payroll/paystub emails
  'email_invoice': 2,                // Invoice delivery emails
  'email_digest': 1,                 // Daily/weekly digest emails
  
  // SMS Service Costs (Twilio) - Per segment with 3x margin
  'sms_notification': 3,             // Standard SMS notification ($0.0079 × 3 = ~3 credits)
  'sms_shift_reminder': 3,           // Shift reminder SMS
  'sms_clock_reminder': 3,           // Clock-in/out reminder
  'sms_verification': 3,             // Verification code SMS
  'sms_escalation': 3,               // Escalation alert SMS
  'sms_inbound': 2,                  // Inbound SMS processing ($0.0075 × 3 = ~2 credits)
  
  // Platform Infrastructure Costs (Monthly amortized)
  // These are charged once per month per workspace as platform fees
  'platform_domain_fee': 25,         // Monthly domain cost share ($0.25/month per org)
  'platform_email_domain': 50,       // Monthly email domain fee ($0.50/month per org)
  'platform_google_workspace': 100,  // Google Workspace share ($1.00/month per org)
  'platform_infrastructure': 200,    // Infrastructure overhead ($2.00/month per org)
} as const;

// ============================================================================
// CREDIT-EXEMPT FEATURES - MINIMAL LIST (Platform absorbs NO costs where avoidable)
// Only truly unavoidable cases: anonymous guest demos before signup
// All org-facing features must be billed - 4x margin covers overhead
// ============================================================================
export const CREDIT_EXEMPT_FEATURES = new Set([
  // Only guest/anonymous features where no org exists to bill
  'guest_demo',      // Pre-signup demo (unavoidable - no billing entity)
  'public_demo',     // Public marketing demo (unavoidable - anonymous)
]);

// ============================================================================
// BILLED CONVERSATIONAL FEATURES - Low cost but still billed to org
// These were previously "free" but now properly metered to orgs
// Cost is minimal (1-2 credits) so users won't notice but platform doesn't absorb
// ============================================================================
// Note: These are already in CREDIT_COSTS above with 0 cost - update them:
// trinity_thought: 1, trinity_chat: 2, trinity_insight: 1
// mascot_ask: 1, mascot_advice: 2, mascot_insight: 1, helpai_chat: 2

// Monthly credit allocation by subscription tier
// Updated Feb 2026 - RIGHT-SIZED allocations to prevent waste
// COST PROTECTION: Limits prevent cost leakage from AI abuse
// 
// TIER LIMITS (Aligned with TIER_MONTHLY_CREDITS):
// - Free Trial: 250 credits (no overage - must upgrade)
// - Starter: 2,000 credits (no overage - must upgrade or buy pack)
// - Professional: 8,000 credits (overage: $29/2,000 additional credits)
// - Enterprise: 25,000 credits (generous but finite)
export const TIER_CREDIT_ALLOCATIONS = {
  'free': 250,          // Trial credits - enough to experience platform
  'trial': 250,         // Same as free trial - 14 days to test
  'starter': 2000,      // 2,000/month - right-sized for small business
  'professional': 8000, // 8,000/month - overage pack available at $29/2K
  'enterprise': 25000,  // 25,000/month - generous but finite
  'unlimited': 25000,   // Legacy tier - same as enterprise
} as const;

// ============================================================================
// HUMANIZATION MAP - Convert tech feature keys to user-friendly names
// Used in usage display to replace "AI operation: ai_email_classification"
// with "Smart Email Sorting"
// ============================================================================
export const FEATURE_DISPLAY_NAMES: Record<string, string> = {
  // Scheduling
  'ai_scheduling': 'Smart Scheduling',
  'ai_schedule_optimization': 'Schedule Optimization',
  'ai_shift_matching': 'Shift Matching',
  'ai_open_shift_fill': 'Open Shift Auto-Fill',
  'schedule_optimization': 'Schedule Optimization',
  'strategic_schedule_optimization': 'Strategic Scheduling',
  
  // Invoicing & Billing
  'ai_invoice_generation': 'Invoice Generation',
  'ai_invoice_review': 'Invoice Review',
  'invoice_gap_analysis': 'Revenue Gap Analysis',
  
  // Payroll
  'ai_payroll_processing': 'Payroll Processing',
  'ai_payroll_verification': 'Payroll Verification',
  'payroll_anomaly_insights': 'Payroll Anomaly Detection',
  
  // Email & Communications
  'ai_email_classification': 'Email Sorting',
  'ai_email_generation': 'Email Drafting',
  'ai_shift_extraction': 'Shift Request Parsing',
  'ai_contractor_email': 'Contractor Confirmation',
  'email_intelligence_analysis': 'Email Analysis',
  'email_intelligence_compose': 'Smart Compose',
  'email_intelligence_summary': 'Email Summary',
  'email_intelligence_reply': 'Reply Suggestions',
  
  // Trinity Conversations
  'trinity_thought': 'Trinity Insight',
  'trinity_chat': 'Trinity Chat',
  'trinity_insight': 'Trinity Tip',
  'mascot_ask': 'Quick Ask',
  'mascot_advice': 'Business Advice',
  'mascot_insight': 'Smart Insight',
  'helpai_chat': 'Help Chat',
  'ai_chat_query': 'AI Chat',
  
  // Staffing Automation
  'trinity_staffing_scan': 'Email Monitoring',
  'trinity_staffing_parse': 'Request Parsing',
  'trinity_staffing_auto_assign': 'Auto-Assignment',
  'trinity_staffing_confirmation': 'Client Confirmation',
  'trinity_staffing_cancellation': 'Cancellation Processing',
  
  // Analytics & Insights
  'ai_analytics_report': 'Analytics Report',
  'ai_predictions': 'Predictive Analytics',
  'financial_pl_summary': 'P&L Summary',
  'financial_insights': 'Financial Insights',
  'financial_client_profitability': 'Client Profitability',
  'financial_trend_analysis': 'Trend Analysis',
  
  // Claude Premium
  'claude_analysis': 'Premium Analysis',
  'claude_strategic': 'Strategic Planning',
  'claude_executive': 'Executive Summary',
  'claude_rfp_response': 'RFP Response',
  'claude_capability_statement': 'Capability Statement',
  'claude_contract_review': 'Contract Review',
  'claude_proposal': 'Proposal Generation',
  
  // Bots
  'bot_helpai_response': 'Help Response',
  'bot_meeting_summary': 'Meeting Summary',
  'bot_report_summary': 'Report Summary',
  
  // Dynamic content
  'dynamic_motd': 'Daily Message',
  'dynamic_message_generation': 'Dynamic Message',
  
  // Platform services
  'email_transactional': 'Email Sent',
  'sms_notification': 'SMS Sent',
  
  // Fallback pattern
  'ai_general': 'AI Operation',
};

export interface CreditCheckResult {
  hasEnoughCredits: boolean;
  currentBalance: number;
  required: number;
  shortfall: number;
  unlimitedCredits?: boolean;
}

export interface CreditDeductionResult {
  success: boolean;
  transactionId: string | null;
  newBalance: number;
  errorMessage?: string;
}

export class CreditManager {
  /**
   * Initialize credit account for a new workspace
   */
  async initializeCredits(
    workspaceId: string,
    subscriptionTier: string = 'free'
  ): Promise<WorkspaceCredits> {
    const allocation = TIER_CREDIT_ALLOCATIONS[subscriptionTier as keyof typeof TIER_CREDIT_ALLOCATIONS] || 100;
    
    // Calculate next reset (first day of next month)
    const now = new Date();
    const nextReset = new Date(now.getFullYear(), now.getMonth() + 1, 1, 0, 0, 0, 0);
    
    const [credits] = await db.insert(workspaceCredits).values({
      workspaceId,
      currentBalance: allocation,
      monthlyAllocation: allocation,
      lastResetAt: new Date(),
      nextResetAt: nextReset,
      totalCreditsEarned: allocation,
      totalCreditsSpent: 0,
      totalCreditsPurchased: 0,
      isActive: true,
      isSuspended: false,
    }).returning();
    
    // Log initial allocation
    await db.insert(creditTransactions).values({
      workspaceId,
      transactionType: 'monthly_allocation',
      amount: allocation,
      balanceAfter: allocation,
      description: `Initial ${subscriptionTier} tier allocation`,
      actorType: 'SYSTEM',
    });
    
    return credits;
  }

  /**
   * Get current credit balance for workspace
   */
  async getBalance(workspaceId: string): Promise<number> {
    const [credits] = await db
      .select({ currentBalance: workspaceCredits.currentBalance })
      .from(workspaceCredits)
      .where(eq(workspaceCredits.workspaceId, workspaceId))
      .limit(1);
    
    if (!credits) {
      // Initialize if not exists
      const newCredits = await this.initializeCredits(workspaceId);
      return newCredits.currentBalance;
    }
    
    return credits.currentBalance;
  }

  /**
   * Get full credit account details
   */
  async getCreditsAccount(workspaceId: string): Promise<WorkspaceCredits | null> {
    const [credits] = await db
      .select()
      .from(workspaceCredits)
      .where(eq(workspaceCredits.workspaceId, workspaceId))
      .limit(1);
    
    return credits || null;
  }

  /**
   * Get credit account with unlimited status check
   * Returns account info with unlimitedCredits flag
   */
  async getCreditsAccountWithStatus(workspaceId: string, userId?: string): Promise<{
    credits: WorkspaceCredits | null;
    unlimitedCredits: boolean;
    effectiveBalance: number;
  }> {
    // Check if user has unlimited credits
    if (userId) {
      const hasUnlimited = await isUnlimitedCreditUser(userId, workspaceId);
      if (hasUnlimited) {
        return {
          credits: null,
          unlimitedCredits: true,
          effectiveBalance: UNLIMITED_CREDITS_BALANCE,
        };
      }
    }
    
    const credits = await this.getCreditsAccount(workspaceId);
    return {
      credits,
      unlimitedCredits: false,
      effectiveBalance: credits?.currentBalance || 0,
    };
  }

  /**
   * Check if workspace has enough credits for an operation
   * Bypasses credit check for:
   * - Users with unlimited credits (support/owners)
   * - Credit-exempt features (Trinity conversations)
   */
  async checkCredits(
    workspaceId: string,
    featureKey: keyof typeof CREDIT_COSTS,
    userId?: string
  ): Promise<CreditCheckResult> {
    // Check if feature is credit-exempt (Trinity conversations are FREE)
    if (CREDIT_EXEMPT_FEATURES.has(featureKey)) {
      return {
        hasEnoughCredits: true,
        currentBalance: -1, // Sentinel: feature was exempt
        required: 0,
        shortfall: 0,
        unlimitedCredits: false, // Not unlimited, just exempt
      };
    }
    
    // Check if user has unlimited credits
    if (userId) {
      const hasUnlimited = await isUnlimitedCreditUser(userId, workspaceId);
      if (hasUnlimited) {
        return {
          hasEnoughCredits: true,
          currentBalance: UNLIMITED_CREDITS_BALANCE,
          required: 0,
          shortfall: 0,
          unlimitedCredits: true,
        };
      }
    }
    
    const balance = await this.getBalance(workspaceId);
    const required = CREDIT_COSTS[featureKey] || 0;
    const hasEnough = balance >= required;
    
    return {
      hasEnoughCredits: hasEnough,
      currentBalance: balance,
      required,
      shortfall: hasEnough ? 0 : required - balance,
      unlimitedCredits: false,
    };
  }

  /**
   * Deduct credits for an automation operation
   * This is the critical function called before every AI operation
   * Bypasses deduction for:
   * - Users with unlimited credits (support/owners)
   * - Credit-exempt features (Trinity conversations, guest demos)
   */
  async deductCredits(params: {
    workspaceId: string;
    userId?: string;
    featureKey: keyof typeof CREDIT_COSTS;
    featureName: string;
    aiUsageEventId?: string;
    relatedEntityType?: string;
    relatedEntityId?: string;
    description?: string;
    amountOverride?: number; // For FAST mode multipliers - overrides base cost
  }): Promise<CreditDeductionResult> {
    const { workspaceId, userId, featureKey, featureName, aiUsageEventId, relatedEntityType, relatedEntityId, description, amountOverride } = params;
    
    // Check if feature is credit-exempt (Trinity conversations are FREE)
    if (CREDIT_EXEMPT_FEATURES.has(featureKey)) {
      console.log(`[CreditManager] Feature "${featureKey}" is credit-exempt (Trinity conversations are FREE)`);
      return {
        success: true,
        transactionId: null,
        newBalance: -1, // Sentinel: feature was exempt, balance not queried
      };
    }
    
    // Check if user has unlimited credits - bypass deduction
    if (userId) {
      const hasUnlimited = await isUnlimitedCreditUser(userId, workspaceId);
      if (hasUnlimited) {
        console.log(`[CreditManager] Bypassing credit deduction for unlimited user: ${userId}`);
        return {
          success: true,
          transactionId: null,
          newBalance: UNLIMITED_CREDITS_BALANCE,
        };
      }
    }
    
    // Get current credits
    const credits = await this.getCreditsAccount(workspaceId);
    if (!credits) {
      return {
        success: false,
        transactionId: null,
        newBalance: 0,
        errorMessage: 'Credit account not initialized',
      };
    }
    
    // Check if suspended
    if (credits.isSuspended) {
      return {
        success: false,
        transactionId: null,
        newBalance: credits.currentBalance,
        errorMessage: credits.suspendedReason || 'Credit account is suspended',
      };
    }
    
    // Check if has enough credits - apply 2x multiplier for premium features
    const baseCost = CREDIT_COSTS[featureKey] || 0;
    const isPremium = PREMIUM_FEATURES.has(featureKey);
    const multiplier = isPremium ? CREDIT_MULTIPLIERS.PREMIUM : CREDIT_MULTIPLIERS.CORE;
    const required = amountOverride ?? (baseCost * multiplier);
    
    if (isPremium) {
      console.log(`[CreditManager] Premium feature "${featureKey}" - applying ${multiplier}x multiplier: ${baseCost} → ${required} credits`);
    }

    // ATOMIC credit deduction using SQL to prevent race conditions
    // This ensures check-and-deduct happens in a single atomic operation
    const [updatedCredits] = await db.update(workspaceCredits)
      .set({
        currentBalance: sql`${workspaceCredits.currentBalance} - ${required}`,
        totalCreditsSpent: sql`${workspaceCredits.totalCreditsSpent} + ${required}`,
        updatedAt: new Date(),
      })
      .where(and(
        eq(workspaceCredits.id, credits.id),
        gte(workspaceCredits.currentBalance, required) // Atomic balance check
      ))
      .returning();

    // If no rows updated, insufficient credits
    if (!updatedCredits) {
      return {
        success: false,
        transactionId: null,
        newBalance: credits.currentBalance,
        errorMessage: `Insufficient credits. Need ${required}, have ${credits.currentBalance}`,
      };
    }

    const newBalance = updatedCredits.currentBalance;
    
    // Log transaction - use null for system users (not valid UUID references)
    const isValidUserId = userId && !userId.startsWith('system') && userId.length > 10;
    const [transaction] = await db.insert(creditTransactions).values({
      workspaceId,
      userId: isValidUserId ? userId : null,
      transactionType: 'deduction',
      amount: -required,
      balanceAfter: newBalance,
      featureKey,
      featureName,
      aiUsageEventId,
      relatedEntityType,
      relatedEntityId,
      description: description || `${featureName} - ${required} credits`,
      actorType: isValidUserId ? 'END_USER' : 'AI_AGENT',
    }).returning();
    
    return {
      success: true,
      transactionId: transaction.id,
      newBalance,
    };
  }

  /**
   * Add credits from purchase
   * Uses ATOMIC SQL update to prevent race conditions where concurrent purchases
   * could result in lost credits (read-modify-write pattern vulnerability)
   */
  async addPurchasedCredits(params: {
    workspaceId: string;
    userId: string;
    amount: number;
    creditPackId: string;
    stripePaymentIntentId: string;
    amountPaid: number;
    description?: string;
  }): Promise<CreditDeductionResult> {
    const { workspaceId, userId, amount, creditPackId, stripePaymentIntentId, amountPaid, description } = params;

    // ATOMIC credit addition using SQL to prevent race conditions
    // This ensures concurrent purchases don't overwrite each other's balance updates
    // Pattern: UPDATE ... SET balance = balance + amount RETURNING *
    const [updatedCredits] = await db.update(workspaceCredits)
      .set({
        currentBalance: sql`${workspaceCredits.currentBalance} + ${amount}`,
        totalCreditsEarned: sql`${workspaceCredits.totalCreditsEarned} + ${amount}`,
        totalCreditsPurchased: sql`${workspaceCredits.totalCreditsPurchased} + ${amount}`,
        updatedAt: new Date(),
      })
      .where(eq(workspaceCredits.workspaceId, workspaceId))
      .returning();

    // If no rows updated, credit account doesn't exist
    if (!updatedCredits) {
      return {
        success: false,
        transactionId: null,
        newBalance: 0,
        errorMessage: 'Credit account not initialized',
      };
    }

    const newBalance = updatedCredits.currentBalance;

    // Log transaction
    const transactionData: InsertCreditTransaction = {
      workspaceId,
      userId,
      transactionType: 'purchase',
      amount,
      balanceAfter: newBalance,
      creditPackId,
      stripePaymentIntentId,
      amountPaid: String(amountPaid),
      description: description || `Purchased ${amount} credits for $${amountPaid}`,
      actorType: 'END_USER',
    };

    const [transaction] = await db.insert(creditTransactions).values(transactionData).returning();

    return {
      success: true,
      transactionId: transaction.id,
      newBalance,
    };
  }

  /**
   * Reset monthly credits (called by cron job)
   */
  async resetMonthlyCredits(workspaceId: string): Promise<void> {
    const credits = await this.getCreditsAccount(workspaceId);
    if (!credits) return;
    
    const allocation = credits.monthlyAllocation;
    let newBalance = allocation;
    
    // Handle rollover for Enterprise tier
    if (credits.rolloverEnabled && (credits.rolloverBalance || 0) > 0) {
      const rollover = Math.min(credits.rolloverBalance || 0, credits.maxRolloverCredits || 0);
      newBalance += rollover;
    }
    
    // Calculate next reset
    const now = new Date();
    const nextReset = new Date(now.getFullYear(), now.getMonth() + 1, 1, 0, 0, 0, 0);
    
    // Reset balance
    await db.update(workspaceCredits)
      .set({
        currentBalance: newBalance,
        rolloverBalance: 0,
        lastResetAt: now,
        nextResetAt: nextReset,
        totalCreditsEarned: credits.totalCreditsEarned + allocation,
        updatedAt: now,
      })
      .where(eq(workspaceCredits.id, credits.id));
    
    // Log transaction
    await db.insert(creditTransactions).values({
      workspaceId,
      transactionType: 'monthly_allocation',
      amount: allocation,
      balanceAfter: newBalance,
      description: `Monthly credit reset - ${allocation} credits`,
      actorType: 'SYSTEM',
    });
  }

  /**
   * Get credit transaction history
   */
  async getTransactionHistory(
    workspaceId: string,
    limit: number = 50,
    offset: number = 0
  ) {
    return await db
      .select()
      .from(creditTransactions)
      .where(eq(creditTransactions.workspaceId, workspaceId))
      .orderBy(desc(creditTransactions.createdAt))
      .limit(limit)
      .offset(offset);
  }

  /**
   * Get credit usage breakdown by feature (for current month)
   * Returns humanized feature names for user-friendly display
   */
  async getMonthlyUsageBreakdown(workspaceId: string) {
    const now = new Date();
    const monthStart = new Date(now.getFullYear(), now.getMonth(), 1);
    const monthEnd = new Date(now.getFullYear(), now.getMonth() + 1, 0, 23, 59, 59);
    
    const breakdown = await db
      .select({
        featureKey: creditTransactions.featureKey,
        featureName: creditTransactions.featureName,
        totalCredits: sql<number>`SUM(ABS(${creditTransactions.amount}))`,
        operationCount: sql<number>`COUNT(*)`,
      })
      .from(creditTransactions)
      .where(
        and(
          eq(creditTransactions.workspaceId, workspaceId),
          eq(creditTransactions.transactionType, 'deduction'),
          gte(creditTransactions.createdAt, monthStart),
          lte(creditTransactions.createdAt, monthEnd)
        )
      )
      .groupBy(creditTransactions.featureKey, creditTransactions.featureName);
    
    // Humanize feature names for user-friendly display
    return breakdown.map(item => ({
      ...item,
      featureName: this.humanizeFeatureName(item.featureKey, item.featureName),
    }));
  }
  
  /**
   * Convert tech feature key to user-friendly display name
   * Replaces "AI operation: ai_email_classification" with "Email Sorting"
   */
  private humanizeFeatureName(featureKey: string | null, fallbackName: string | null): string {
    if (featureKey && FEATURE_DISPLAY_NAMES[featureKey]) {
      return FEATURE_DISPLAY_NAMES[featureKey];
    }
    
    // Try to humanize from the feature key itself
    if (featureKey) {
      // Remove common prefixes and convert to title case
      const cleaned = featureKey
        .replace(/^(ai_|bot_|trinity_|claude_|email_|dynamic_)/, '')
        .replace(/_/g, ' ')
        .replace(/\b\w/g, c => c.toUpperCase());
      return cleaned;
    }
    
    // Fall back to stored name, cleaned up
    if (fallbackName) {
      return fallbackName.replace(/^AI operation: /, '').replace(/_/g, ' ').replace(/\b\w/g, c => c.toUpperCase());
    }
    
    return 'AI Operation';
  }

  /**
   * Update tier allocation when subscription changes
   */
  async updateTierAllocation(workspaceId: string, newTier: string): Promise<void> {
    const allocation = TIER_CREDIT_ALLOCATIONS[newTier as keyof typeof TIER_CREDIT_ALLOCATIONS] || 100;
    
    await db.update(workspaceCredits)
      .set({
        monthlyAllocation: allocation,
        updatedAt: new Date(),
      })
      .where(eq(workspaceCredits.workspaceId, workspaceId));
  }
}

// Export singleton instance
export const creditManager = new CreditManager();

/**
 * Database Migration Service
 * 
 * Uses SchemaParityService for dynamic schema validation
 * NO HARDCODED TABLE/COLUMN CHECKS - all validation is automatic
 */

import { runSchemaParityCheck } from './schemaParityService';

/**
 * Run schema parity check and optionally auto-fix issues
 * Called at startup to ensure database matches Drizzle schema
 */
export async function ensureRequiredTables(): Promise<void> {
  console.log('[DbMigration] Running dynamic schema parity check...');
  
  try {
    // Run parity check with auto-fix enabled for safe issues
    const report = await runSchemaParityCheck(true);
    
    if (report.totalIssues === 0) {
      console.log('[DbMigration] ✅ All schema parity checks passed');
    } else {
      // Log remaining issues that couldn't be auto-fixed
      const remaining = report.issues.filter(i => !i.autoFixable);
      if (remaining.length > 0) {
        console.warn(`[DbMigration] ⚠️  ${remaining.length} issues require manual intervention:`);
        remaining.forEach(issue => {
          if (issue.type === 'missing_table') {
            console.warn(`[DbMigration]    - Run: npm run db:push to create table "${issue.table}"`);
          } else if (issue.type === 'missing_column' && !issue.autoFixable) {
            console.warn(`[DbMigration]    - Missing required column: ${issue.table}.${issue.column}`);
          }
        });
      }
    }
  } catch (error) {
    console.error('[DbMigration] Error during schema parity check:', error);
    // Don't throw - allow server to continue starting
  }
}

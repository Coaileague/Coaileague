/**
 * Production Database Seeding Service
 * 
 * Automatically migrates essential data from development to production
 * on first deployment. Uses idempotent INSERT ... ON CONFLICT DO NOTHING
 * to safely handle re-runs.
 * 
 * Trigger: Runs on server startup when REPLIT_DEPLOYMENT=1 (production)
 * Guard: Checks for sentinel user (root@getdc360.com) to avoid duplicate runs
 */

import { db } from "../db";
import { users, platformRoles, workspaces, employees } from "@shared/schema";
import { eq, sql } from "drizzle-orm";

const SENTINEL_USER_ID = 'root-user-00000000';
const SENTINEL_EMAIL = 'root@getdc360.com';

/**
 * One-time data corrections - runs on PRODUCTION startup only
 * Fixes existing records that were created with incorrect data
 * EXPORTED so it can be called independently in server/index.ts
 */
export async function runDataCorrections(): Promise<void> {
  const isProduction = process.env.REPLIT_DEPLOYMENT === '1';
  if (!isProduction) return;
  
  console.log('🔧 Data Corrections Service: Starting...');
  
  // Fix TXPS org owner role - employee was created without workspace_role
  try {
    await db.execute(sql`
      UPDATE employees 
      SET workspace_role = 'org_owner', employee_number = 'EMP-TXPS-00001'
      WHERE id = '3fd50980-85f8-4f18-8b7a-5906ba8ccfe0'
        AND (workspace_role IS NULL OR workspace_role != 'org_owner')
    `);
    console.log('🔧 Data Correction: Fixed TXPS org owner workspace_role');
  } catch (err) {
    console.log('🔧 Data Correction: TXPS org owner fix skipped (may not exist)');
  }
  
  console.log('🔧 Data Corrections Service: Complete');
}

/**
 * One-time password migrations - runs EVERY startup (dev and prod)
 * Use this for urgent password updates that need to apply to existing users
 * EXPORTED so it can be called independently in server/index.ts
 */
export async function runPasswordMigrations(): Promise<void> {
  console.log('🔑 Password Migration Service: Starting...');
  
  // Password migrations now empty - login working, password preserved
  const migrations: Array<{ email: string; newHash: string; note: string }> = [];
  
  if (migrations.length === 0) {
    console.log('🔑 Password Migration: No pending migrations');
    console.log('🔑 Password Migration Service: Complete');
    return;
  }
  
  for (const migration of migrations) {
    try {
      const result = await db.execute(sql`
        UPDATE users 
        SET password_hash = ${migration.newHash}, login_attempts = 0
        WHERE email = ${migration.email}
      `);
      console.log(`🔑 Password Migration: SUCCESS - Updated ${migration.email}`);
    } catch (err) {
      console.log(`🔑 Password Migration: SKIPPED - ${migration.email} (user may not exist in this database)`);
    }
  }
  
  console.log('🔑 Password Migration Service: Complete');
}

export async function runProductionSeed(): Promise<{ success: boolean; message: string }> {
  const isProduction = process.env.REPLIT_DEPLOYMENT === '1';
  
  console.log(`🌱 Production Seed: Environment check - REPLIT_DEPLOYMENT=${process.env.REPLIT_DEPLOYMENT}`);
  
  if (!isProduction) {
    console.log('🌱 Production Seed: Skipping (not in production deployment)');
    return { success: true, message: 'Skipped - not in production' };
  }
  
  // Always run password migrations first (for existing users)
  console.log('🔑 Running password migrations...');
  await runPasswordMigrations();
  
  try {
    // Check if sentinel user already exists
    const existingUser = await db.select({ id: users.id })
      .from(users)
      .where(eq(users.id, SENTINEL_USER_ID))
      .limit(1);
    
    if (existingUser.length > 0) {
      console.log(`🌱 Production Seed: Sentinel user (${SENTINEL_EMAIL}) already exists. Skipping migration.`);
      return { success: true, message: 'Already seeded' };
    }
    
    console.log('🌱 Production Seed: Starting database migration...');
    
    // Run all inserts in a transaction
    await db.transaction(async (tx) => {
      // =========================================================================
      // 1. USERS TABLE - Core authentication data
      // =========================================================================
      console.log('🌱 Seeding users...');
      
      const usersData = [
        { id: 'ai-bot', email: 'ai-bot@workforceos.com', firstName: 'AI', lastName: 'Assistant', passwordHash: 'no-password-bot-account', role: 'user', emailVerified: false },
        { id: 'helpos-ai-bot', email: 'helpos@workforceos.com', firstName: 'HelpOS', lastName: 'AI Bot', passwordHash: null, role: 'user', emailVerified: true },
        { id: 'root-admin-workfos', email: 'root@workf-os.com', firstName: 'Brigido', lastName: 'Guillen', passwordHash: '$2b$10$XEUX3wL9wI2VEjEoUdCSw.O8xFVIfhUJAGahknql8PdWYj0DITrSe', role: 'user', emailVerified: true, currentWorkspaceId: 'ops-workspace-00000000' },
        { id: '48003611', email: 'txpsinvestigations@gmail.com', firstName: 'Brigido', lastName: 'Guillen', passwordHash: '$2b$10$Ys8kclEUPliSbv0HQVU5veqYeHxmu6Bd43/IIGNLO.dUp3VMvj/HC', role: 'user', emailVerified: false, currentWorkspaceId: '37a04d24-51bd-4856-9faa-d26a2fe82094' },
        { id: 'root-user-00000000', email: 'root@getdc360.com', firstName: 'Brigido', lastName: 'Guillen', passwordHash: '$2b$10$wN0UMmTiGuG0wEi/04xywOqwnLUILRxQmFTjuTfgovPv1kBS.T3ei', role: 'admin', emailVerified: false, currentWorkspaceId: 'ops-workspace-00000000' },
        { id: 'helpai-bot', email: 'helpai@coaileague.ai', firstName: 'HelpAI', lastName: 'Bot', passwordHash: null, role: 'user', emailVerified: false },
      ];
      
      for (const user of usersData) {
        await tx.execute(sql`
          INSERT INTO users (id, email, first_name, last_name, password_hash, role, email_verified, current_workspace_id, created_at, updated_at, login_attempts, mfa_enabled)
          VALUES (${user.id}, ${user.email}, ${user.firstName}, ${user.lastName}, ${user.passwordHash}, ${user.role}, ${user.emailVerified}, ${(user as any).currentWorkspaceId || null}, NOW(), NOW(), 0, FALSE)
          ON CONFLICT (id) DO NOTHING
        `);
      }
      
      // =========================================================================
      // 2. PLATFORM_ROLES TABLE - Admin and system roles
      // =========================================================================
      console.log('🌱 Seeding platform roles...');
      
      const rolesData = [
        { id: 'e2d402f8-fb44-4129-a0f2-703f0dc91aaa', userId: 'root-user-00000000', role: 'root_admin' },
        { id: 'b495135c-14bf-4579-8c04-23fd38994696', userId: 'root-admin-workfos', role: 'root_admin' },
      ];
      
      for (const pr of rolesData) {
        await tx.execute(sql`
          INSERT INTO platform_roles (id, user_id, role, granted_at)
          VALUES (${pr.id}, ${pr.userId}, ${pr.role}, NOW())
          ON CONFLICT (id) DO NOTHING
        `);
      }
      
      // =========================================================================
      // 3. WORKSPACES TABLE - Organization/tenant data
      // =========================================================================
      console.log('🌱 Seeding workspaces...');
      
      const workspacesData = [
        { id: 'ops-workspace-00000000', name: 'CoAIleague Support', ownerId: 'root-user-00000000', subscriptionTier: 'enterprise', subscriptionStatus: 'active' },
        { id: '37a04d24-51bd-4856-9faa-d26a2fe82094', name: 'Statewide Protective Services', ownerId: '48003611', subscriptionTier: 'enterprise', subscriptionStatus: 'active' },
      ];
      
      for (const ws of workspacesData) {
        await tx.execute(sql`
          INSERT INTO workspaces (id, name, owner_id, subscription_tier, subscription_status, created_at, updated_at)
          VALUES (${ws.id}, ${ws.name}, ${ws.ownerId}, ${ws.subscriptionTier}, ${ws.subscriptionStatus}, NOW(), NOW())
          ON CONFLICT (id) DO NOTHING
        `);
      }
      
      // =========================================================================
      // 4. EMPLOYEES TABLE - Employee records
      // =========================================================================
      console.log('🌱 Seeding employees...');
      
      const employeesData = [
        { id: '8d31a497-e9fe-48d9-b819-9c6869948c39', userId: 'root-user-00000000', workspaceId: 'ops-workspace-00000000', firstName: 'Root', lastName: 'Administrator', email: 'root@getdc360.com', hourlyRate: '0.00', workspaceRole: 'org_owner', employeeNumber: 'EMP-ROOT-00001' },
        { id: 'helpai-employee', userId: null, workspaceId: 'ops-workspace-00000000', firstName: 'HelpAI', lastName: 'Bot', email: 'helpai@coaileague.support', hourlyRate: null, role: 'AI Support Assistant', workspaceRole: null, employeeNumber: 'EMP-HELP-00001' },
        { id: 'trinity-employee', userId: null, workspaceId: 'ops-workspace-00000000', firstName: 'Trinity', lastName: 'AI', email: 'trinity@coaileague.support', hourlyRate: null, role: 'AI Platform Guide', workspaceRole: null, employeeNumber: 'EMP-TRIN-00001' },
        { id: '3fd50980-85f8-4f18-8b7a-5906ba8ccfe0', userId: '48003611', workspaceId: '37a04d24-51bd-4856-9faa-d26a2fe82094', firstName: 'Brigido', lastName: 'Guillen', email: 'txpsinvestigations@gmail.com', hourlyRate: '25.00', workspaceRole: 'org_owner', employeeNumber: 'EMP-TXPS-00001' },
      ];
      
      for (const emp of employeesData) {
        await tx.execute(sql`
          INSERT INTO employees (id, user_id, workspace_id, first_name, last_name, email, hourly_rate, role, workspace_role, employee_number, created_at, updated_at)
          VALUES (${emp.id}, ${emp.userId}, ${emp.workspaceId}, ${emp.firstName}, ${emp.lastName}, ${emp.email}, ${emp.hourlyRate}, ${(emp as any).role || null}, ${emp.workspaceRole}, ${emp.employeeNumber}, NOW(), NOW())
          ON CONFLICT (id) DO NOTHING
        `);
      }
    });
    
    console.log('✅ Production Seed: Database migration completed successfully!');
    console.log('   - Users: 6 core accounts (no test/demo data)');
    console.log('   - Platform Roles: 2 admin roles');
    console.log('   - Workspaces: 2 organizations (ops + Statewide)');
    console.log('   - Employees: 4 records');
    
    return { success: true, message: 'Production database seeded successfully' };
    
  } catch (error) {
    console.error('❌ Production Seed: Migration failed:', error);
    return { success: false, message: `Seed failed: ${error}` };
  }
}

/**
 * CENTRALIZED EMAIL SERVICE
 * 
 * Unifies all email notifications across CoAIleague with:
 * - Persistent audit trail (emailEvents table)
 * - Queue-compatible error handling
 * - Notification category abstraction
 * - Resend integration with proper error handling
 * - SIMULATION MODE for testing (logs instead of sending)
 */

import { db } from "../db";
import { emailEvents } from "@shared/schema";
import { eq } from "drizzle-orm";
// Reuse existing Resend client from email.ts (no duplication!)
// CAN-SPAM: Use sendCanSpamCompliantEmail for all outgoing emails
import { getUncachableResendClient, isResendConfigured, sendCanSpamCompliantEmail, isEmailUnsubscribed } from "../email";
import { FEATURES } from "@shared/platformConfig";
import { automationOrchestration } from "./orchestration/automationOrchestration";

// ============================================================================
// BASE URL UTILITY
// ============================================================================

/**
 * Get application base URL for email links
 * Priority: APP_BASE_URL > REPLIT_DOMAINS > REPL construction > localhost
 */
function getAppBaseUrl(): string {
  // Priority 1: Explicit APP_BASE_URL environment variable
  if (process.env.APP_BASE_URL) {
    return process.env.APP_BASE_URL;
  }
  
  // Priority 2: Replit domains (production deployment)
  if (process.env.REPLIT_DOMAINS) {
    const domains = process.env.REPLIT_DOMAINS.split(',');
    return `https://${domains[0]}`;
  }
  
  // Priority 3: Construct from REPL environment (development)
  if (process.env.REPL_SLUG && process.env.REPL_OWNER) {
    return `https://${process.env.REPL_SLUG}.${process.env.REPL_OWNER}.repl.co`;
  }
  
  // Fallback: localhost (local development)
  return 'http://localhost:5000';
}

// ============================================================================
// EMAIL TEMPLATES
// ============================================================================

const emailTemplates = {
  verification: (data: {
    firstName: string;
    verificationUrl: string;
  }) => ({
    subject: 'Verify Your CoAIleague Account',
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2 style="color: #2563eb;">Verify Your Email Address</h2>
        <p>Hello ${data.firstName},</p>
        <p>Thank you for signing up for CoAIleague! Please verify your email address to activate your account.</p>
        <div style="text-align: center; margin: 30px 0;">
          <a href="${data.verificationUrl}" 
             style="background-color: #2563eb; color: white; padding: 14px 28px; text-decoration: none; border-radius: 6px; font-weight: 600; display: inline-block;">
            Verify Email Address
          </a>
        </div>
        <p style="color: #6b7280; font-size: 14px;">This link will expire in 24 hours.</p>
        <p style="color: #6b7280; font-size: 12px; margin-top: 30px;">
          If you did not create an account, please ignore this email.<br>
          This is an automated message from CoAIleague.
        </p>
      </div>
    `
  }),

  passwordReset: (data: {
    firstName: string;
    resetUrl: string;
  }) => ({
    subject: 'Reset Your CoAIleague Password',
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2 style="color: #2563eb;">Password Reset Request</h2>
        <p>Hello ${data.firstName},</p>
        <p>We received a request to reset your password for your CoAIleague account.</p>
        <div style="text-align: center; margin: 30px 0;">
          <a href="${data.resetUrl}" 
             style="background-color: #2563eb; color: white; padding: 14px 28px; text-decoration: none; border-radius: 6px; font-weight: 600; display: inline-block;">
            Reset Password
          </a>
        </div>
        <p style="color: #6b7280; font-size: 14px;">This link will expire in 1 hour.</p>
        <div style="background-color: #fef2f2; padding: 15px; border-radius: 8px; margin: 20px 0; border-left: 4px solid #dc2626;">
          <p style="margin: 0; color: #dc2626; font-weight: bold;">Security Notice:</p>
          <p style="margin: 5px 0 0 0; font-size: 14px;">If you did not request this password reset, please ignore this email and your password will remain unchanged.</p>
        </div>
        <p style="color: #6b7280; font-size: 12px; margin-top: 30px;">
          This is an automated message from CoAIleague.
        </p>
      </div>
    `
  }),

  supportTicketConfirmation: (data: {
    name: string;
    ticketNumber: string;
    subject: string;
  }) => ({
    subject: `Support Ticket Created - ${data.ticketNumber}`,
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2 style="color: #16a34a;">Support Ticket Received</h2>
        <p>Hello ${data.name},</p>
        <p>Thank you for contacting CoAIleague support. Your ticket has been received and assigned a tracking number.</p>
        <div style="background-color: #f0fdf4; padding: 20px; border-radius: 8px; margin: 20px 0; border-left: 4px solid #16a34a;">
          <p style="margin: 5px 0;"><strong>Ticket Number:</strong> ${data.ticketNumber}</p>
          <p style="margin: 5px 0;"><strong>Subject:</strong> ${data.subject}</p>
          <p style="margin: 15px 0 5px 0;">Please save this ticket number for your records. You can use it to access Live Chat support or check the status of your request.</p>
        </div>
        <p>Our support team will review your request and respond as soon as possible.</p>
        <p style="color: #6b7280; font-size: 14px; margin-top: 30px;">
          This is an automated confirmation from CoAIleague Support.
        </p>
      </div>
    `
  }),

  reportDelivery: (data: {
    clientName: string;
    reportNumber: string;
    reportTitle: string;
  }) => ({
    subject: `Report Delivered - ${data.reportNumber}`,
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2 style="color: #2563eb;">Report Ready for Review</h2>
        <p>Hello ${data.clientName},</p>
        <p>A new report has been completed and is ready for your review.</p>
        <div style="background-color: #f3f4f6; padding: 20px; border-radius: 8px; margin: 20px 0;">
          <p style="margin: 5px 0;"><strong>Report Number:</strong> ${data.reportNumber}</p>
          <p style="margin: 5px 0;"><strong>Title:</strong> ${data.reportTitle}</p>
        </div>
        <p>Please log in to your CoAIleague portal to view the full report details.</p>
        <p style="color: #6b7280; font-size: 14px; margin-top: 30px;">
          This is an automated message from CoAIleague ReportOS.
        </p>
      </div>
    `
  }),

  employeeTemporaryPassword: (data: {
    firstName: string;
    email: string;
    tempPassword: string;
    workspaceName: string;
  }) => ({
    subject: `Your CoAIleague Account - Temporary Password`,
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2 style="color: #2563eb;">Welcome to ${data.workspaceName}</h2>
        <p>Hello ${data.firstName},</p>
        <p>Your CoAIleague account has been created. Use the credentials below to log in for the first time:</p>
        <div style="background-color: #f3f4f6; padding: 20px; border-radius: 8px; margin: 20px 0;">
          <p style="margin: 5px 0;"><strong>Email:</strong> ${data.email}</p>
          <p style="margin: 5px 0;"><strong>Temporary Password:</strong> <code style="background-color: #fff; padding: 2px 6px; border-radius: 4px; font-family: monospace;">${data.tempPassword}</code></p>
        </div>
        <div style="background-color: #fff7ed; padding: 15px; border-radius: 8px; margin: 20px 0; border-left: 4px solid #f59e0b;">
          <p style="margin: 0; color: #f59e0b; font-weight: bold;">Important:</p>
          <p style="margin: 5px 0 0 0; font-size: 14px;">You will be required to change this password upon your first login for security purposes.</p>
        </div>
        <p style="color: #6b7280; font-size: 14px; margin-top: 30px;">
          This is an automated message from CoAIleague.
        </p>
      </div>
    `
  }),

  managerOnboardingNotification: (data: {
    managerName: string;
    employeeName: string;
    workspaceName: string;
  }) => ({
    subject: `New Employee Onboarding - ${data.employeeName}`,
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2 style="color: #2563eb;">New Employee Onboarding</h2>
        <p>Hello ${data.managerName},</p>
        <p>A new employee has been added to your team and is ready for onboarding.</p>
        <div style="background-color: #f3f4f6; padding: 20px; border-radius: 8px; margin: 20px 0;">
          <p style="margin: 5px 0;"><strong>Employee:</strong> ${data.employeeName}</p>
          <p style="margin: 5px 0;"><strong>Workspace:</strong> ${data.workspaceName}</p>
        </div>
        <p>Please ensure all onboarding tasks are completed and the employee has access to necessary systems.</p>
        <p style="color: #6b7280; font-size: 14px; margin-top: 30px;">
          This is an automated notification from CoAIleague.
        </p>
      </div>
    `
  }),

  clientWelcome: (data: {
    clientName: string;
    companyName: string;
    workspaceName: string;
    portalUrl: string;
  }) => ({
    subject: `Welcome to ${data.workspaceName} - Client Portal Access`,
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2 style="color: #2563eb;">Welcome to ${data.workspaceName}!</h2>
        <p>Hello ${data.clientName},</p>
        <p>Thank you for choosing to work with us! Your client account has been set up and you now have access to our client portal.</p>
        <div style="background-color: #f3f4f6; padding: 20px; border-radius: 8px; margin: 20px 0;">
          <p style="margin: 5px 0;"><strong>Organization:</strong> ${data.companyName}</p>
          <p style="margin: 5px 0;"><strong>Service Provider:</strong> ${data.workspaceName}</p>
        </div>
        <div style="text-align: center; margin: 30px 0;">
          <a href="${data.portalUrl}" 
             style="background-color: #2563eb; color: white; padding: 14px 28px; text-decoration: none; border-radius: 6px; font-weight: 600; display: inline-block;">
            Access Client Portal
          </a>
        </div>
        <p>Through the portal, you can:</p>
        <ul style="color: #4b5563;">
          <li>View and approve timesheets</li>
          <li>Access invoices and payment history</li>
          <li>Review reports and analytics</li>
          <li>Communicate with your service team</li>
        </ul>
        <p style="color: #6b7280; font-size: 14px; margin-top: 30px;">
          If you have any questions, please don't hesitate to reach out to your account manager.<br>
          This is an automated message from CoAIleague.
        </p>
      </div>
    `
  }),

  newMemberWelcome: (data: {
    firstName: string;
    onboardingUrl: string;
  }) => ({
    subject: 'Welcome to CoAIleague - Your Workforce Intelligence Platform',
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <div style="text-align: center; padding: 30px 0; background: linear-gradient(135deg, #2563eb 0%, #7c3aed 100%); border-radius: 8px 8px 0 0;">
          <h1 style="color: white; margin: 0; font-size: 28px;">Welcome to CoAIleague!</h1>
          <p style="color: #e0e7ff; margin: 10px 0 0 0;">AI-Powered Workforce Intelligence</p>
        </div>
        <div style="padding: 30px; background-color: #f9fafb; border-radius: 0 0 8px 8px;">
          <p style="font-size: 16px;">Hello ${data.firstName},</p>
          <p>Welcome to CoAIleague! We're excited to have you join our platform. Your account is now active and ready for you to explore.</p>
          
          <div style="background-color: white; padding: 20px; border-radius: 8px; margin: 25px 0; border: 1px solid #e5e7eb;">
            <h3 style="color: #1f2937; margin: 0 0 15px 0;">Meet Trinity - Your AI Assistant</h3>
            <p style="margin: 0; color: #4b5563;">Look for the twin-star mascot in the corner of your screen. Trinity is your intelligent guide who will help you navigate the platform, answer questions, and provide personalized recommendations.</p>
          </div>
          
          <div style="text-align: center; margin: 30px 0;">
            <a href="${data.onboardingUrl}" 
               style="background-color: #2563eb; color: white; padding: 16px 32px; text-decoration: none; border-radius: 8px; font-weight: 600; display: inline-block; font-size: 16px;">
              Start Your Onboarding
            </a>
          </div>
          
          <p style="color: #6b7280; font-size: 14px; margin-top: 30px; text-align: center;">
            Need help? Chat with Trinity or contact our support team anytime.<br>
            This is an automated welcome from CoAIleague.
          </p>
        </div>
      </div>
    `
  }),

  employeeInvitation: (data: {
    firstName: string;
    inviterName: string;
    workspaceName: string;
    roleName: string;
    joinUrl: string;
    expiresIn: string;
  }) => ({
    subject: `You're Invited to Join ${data.workspaceName} on CoAIleague`,
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2 style="color: #2563eb;">You've Been Invited!</h2>
        <p>Hello ${data.firstName},</p>
        <p><strong>${data.inviterName}</strong> has invited you to join <strong>${data.workspaceName}</strong> on CoAIleague as a <strong>${data.roleName}</strong>.</p>
        
        <div style="background-color: #f3f4f6; padding: 20px; border-radius: 8px; margin: 20px 0;">
          <p style="margin: 5px 0;"><strong>Organization:</strong> ${data.workspaceName}</p>
          <p style="margin: 5px 0;"><strong>Your Role:</strong> ${data.roleName}</p>
          <p style="margin: 5px 0;"><strong>Invited By:</strong> ${data.inviterName}</p>
        </div>
        
        <div style="text-align: center; margin: 30px 0;">
          <a href="${data.joinUrl}" 
             style="background-color: #16a34a; color: white; padding: 14px 28px; text-decoration: none; border-radius: 6px; font-weight: 600; display: inline-block;">
            Accept Invitation & Join
          </a>
        </div>
        
        <div style="background-color: #fef3c7; padding: 15px; border-radius: 8px; margin: 20px 0; border-left: 4px solid #f59e0b;">
          <p style="margin: 0; font-size: 14px; color: #92400e;">
            <strong>Note:</strong> This invitation expires in ${data.expiresIn}. Please accept before it expires.
          </p>
        </div>
        
        <p style="color: #6b7280; font-size: 14px; margin-top: 30px;">
          If you did not expect this invitation or have questions, please contact ${data.inviterName} directly.<br>
          This is an automated invitation from CoAIleague.
        </p>
      </div>
    `
  }),

  supportRoleBriefing: (data: {
    firstName: string;
    roleName: string;
    dashboardUrl: string;
    capabilities: string[];
  }) => ({
    subject: `Your CoAIleague Support Role: ${data.roleName}`,
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <div style="background-color: #7c3aed; padding: 20px; border-radius: 8px 8px 0 0;">
          <h2 style="color: white; margin: 0;">Support Team Role Assignment</h2>
        </div>
        <div style="padding: 25px; background-color: #faf5ff; border-radius: 0 0 8px 8px;">
          <p>Hello ${data.firstName},</p>
          <p>You have been assigned the <strong>${data.roleName}</strong> role in the CoAIleague support system. This gives you access to platform-wide support tools and capabilities.</p>
          
          <div style="background-color: white; padding: 20px; border-radius: 8px; margin: 20px 0; border: 1px solid #e9d5ff;">
            <h3 style="color: #7c3aed; margin: 0 0 15px 0;">Your Capabilities:</h3>
            <ul style="margin: 0; padding-left: 20px; color: #4b5563;">
              ${data.capabilities.map(cap => `<li style="margin: 8px 0;">${cap}</li>`).join('')}
            </ul>
          </div>
          
          <div style="text-align: center; margin: 30px 0;">
            <a href="${data.dashboardUrl}" 
               style="background-color: #7c3aed; color: white; padding: 14px 28px; text-decoration: none; border-radius: 6px; font-weight: 600; display: inline-block;">
              Access Support Dashboard
            </a>
          </div>
          
          <div style="background-color: #f3e8ff; padding: 15px; border-radius: 8px; margin: 20px 0;">
            <p style="margin: 0; font-size: 14px; color: #6b21a8;">
              <strong>Tip:</strong> Use HelpAI chat to get AI-powered assistance with support tickets and user inquiries.
            </p>
          </div>
          
          <p style="color: #6b7280; font-size: 14px; margin-top: 20px;">
            This is an automated notification from CoAIleague Platform Administration.
          </p>
        </div>
      </div>
    `
  }),

  onboardingComplete: (data: {
    firstName: string;
    workspaceName: string;
    dashboardUrl: string;
    completedTasks: number;
  }) => ({
    subject: `Onboarding Complete - Welcome to ${data.workspaceName}!`,
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <div style="text-align: center; padding: 30px 0; background: linear-gradient(135deg, #16a34a 0%, #22c55e 100%); border-radius: 8px 8px 0 0;">
          <h1 style="color: white; margin: 0; font-size: 32px;">Congratulations!</h1>
          <p style="color: #dcfce7; margin: 10px 0 0 0; font-size: 18px;">You've completed your onboarding</p>
        </div>
        <div style="padding: 30px; background-color: #f0fdf4; border-radius: 0 0 8px 8px;">
          <p style="font-size: 16px;">Hello ${data.firstName},</p>
          <p>You've successfully completed all ${data.completedTasks} onboarding tasks for <strong>${data.workspaceName}</strong>. You're now ready to use all the features of CoAIleague!</p>
          
          <div style="background-color: white; padding: 20px; border-radius: 8px; margin: 25px 0; border: 1px solid #bbf7d0; text-align: center;">
            <p style="font-size: 48px; margin: 0;">&#127881;</p>
            <h3 style="color: #15803d; margin: 10px 0;">All Set!</h3>
            <p style="margin: 0; color: #4b5563;">Your account is fully configured and ready to go.</p>
          </div>
          
          <div style="text-align: center; margin: 30px 0;">
            <a href="${data.dashboardUrl}" 
               style="background-color: #16a34a; color: white; padding: 16px 32px; text-decoration: none; border-radius: 8px; font-weight: 600; display: inline-block; font-size: 16px;">
              Go to Dashboard
            </a>
          </div>
          
          <p style="color: #6b7280; font-size: 14px; margin-top: 30px; text-align: center;">
            Need help? Trinity is always available to assist you.<br>
            This is an automated message from CoAIleague.
          </p>
        </div>
      </div>
    `
  }),

  /**
   * ORGANIZATION INVITATION TEMPLATE
   * Premium template for inviting new organizations to join CoAIleague
   * Includes Trinity AI assistant introduction and data migration options
   */
  organizationInvitation: (data: {
    recipientName: string;
    recipientEmail: string;
    inviterName: string;
    inviterCompany?: string;
    organizationName: string;
    welcomeUrl: string;
    inviteToken: string;
    expiresIn: string;
    migrationFeatures: string[];
  }) => ({
    subject: `You're Invited to Join CoAIleague - AI-Powered Workforce Intelligence`,
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; background-color: #f9fafb;">
        <!-- Header with gradient -->
        <div style="text-align: center; padding: 40px 30px; background: linear-gradient(135deg, #2563eb 0%, #7c3aed 50%, #ec4899 100%); border-radius: 8px 8px 0 0;">
          <h1 style="color: white; margin: 0; font-size: 32px; font-weight: 700;">Welcome to CoAIleague</h1>
          <p style="color: #e0e7ff; margin: 15px 0 0 0; font-size: 18px;">AI-Powered Workforce Intelligence Platform</p>
          <div style="margin-top: 20px;">
            <span style="background: rgba(255,255,255,0.2); color: white; padding: 8px 16px; border-radius: 20px; font-size: 14px;">
              Powered by Gemini 3 Pro AI Brain
            </span>
          </div>
        </div>
        
        <!-- Main content -->
        <div style="padding: 40px 30px; background-color: white;">
          <p style="font-size: 18px; color: #1f2937;">Hello ${data.recipientName},</p>
          
          <p style="font-size: 16px; color: #4b5563; line-height: 1.6;">
            <strong>${data.inviterName}</strong>${data.inviterCompany ? ` from <strong>${data.inviterCompany}</strong>` : ''} 
            has invited you to set up <strong>${data.organizationName}</strong> on CoAIleague, 
            the next-generation workforce management platform powered by AI.
          </p>
          
          <!-- Trinity Introduction Box -->
          <div style="background: linear-gradient(135deg, #f0f9ff 0%, #f5f3ff 100%); padding: 25px; border-radius: 12px; margin: 30px 0; border: 1px solid #c7d2fe;">
            <div style="display: flex; align-items: center; margin-bottom: 15px;">
              <div style="font-size: 36px; margin-right: 15px;">&#11088;&#11088;</div>
              <div>
                <h3 style="color: #4338ca; margin: 0; font-size: 20px;">Meet Trinity - Your AI Assistant</h3>
                <p style="color: #6366f1; margin: 5px 0 0 0; font-size: 14px;">Powered by Gemini 3 Pro</p>
              </div>
            </div>
            <p style="color: #4b5563; margin: 0; font-size: 15px; line-height: 1.5;">
              Trinity is your dedicated AI assistant that operates exclusively within your organization. 
              Trinity will guide you through setup, answer questions, and help optimize your workforce operations 
              with intelligent recommendations.
            </p>
          </div>
          
          <!-- CTA Button -->
          <div style="text-align: center; margin: 40px 0;">
            <a href="${data.welcomeUrl}?token=${data.inviteToken}" 
               style="background: linear-gradient(135deg, #2563eb 0%, #7c3aed 100%); color: white; padding: 18px 48px; text-decoration: none; border-radius: 10px; font-weight: 700; display: inline-block; font-size: 18px; box-shadow: 0 4px 14px rgba(37, 99, 235, 0.4);">
              Start Your Organization Setup
            </a>
          </div>
          
          <!-- What's included section -->
          <div style="background-color: #f9fafb; padding: 25px; border-radius: 12px; margin: 30px 0;">
            <h3 style="color: #1f2937; margin: 0 0 20px 0; font-size: 18px;">What You Can Migrate & Set Up:</h3>
            <ul style="margin: 0; padding: 0; list-style: none;">
              ${data.migrationFeatures.map(feature => `
                <li style="padding: 10px 0; border-bottom: 1px solid #e5e7eb; color: #4b5563; font-size: 15px;">
                  <span style="color: #16a34a; margin-right: 10px;">&#10003;</span> ${feature}
                </li>
              `).join('')}
            </ul>
          </div>
          
          <!-- Automation unlock teaser -->
          <div style="background: linear-gradient(135deg, #ecfdf5 0%, #f0fdf4 100%); padding: 20px; border-radius: 10px; margin: 25px 0; border-left: 4px solid #16a34a;">
            <h4 style="color: #15803d; margin: 0 0 10px 0;">Unlock AI Automation</h4>
            <p style="color: #166534; margin: 0; font-size: 14px; line-height: 1.5;">
              Complete your setup and gamification challenges to unlock powerful AI automation features 
              including smart scheduling, payroll auto-calculation, and compliance monitoring.
            </p>
          </div>
          
          <!-- Expiration notice -->
          <div style="background-color: #fef3c7; padding: 15px 20px; border-radius: 8px; margin: 25px 0; border-left: 4px solid #f59e0b;">
            <p style="margin: 0; font-size: 14px; color: #92400e;">
              <strong>Note:</strong> This invitation expires in <strong>${data.expiresIn}</strong>. Please accept before it expires.
            </p>
          </div>
        </div>
        
        <!-- Footer -->
        <div style="padding: 25px 30px; background-color: #f3f4f6; border-radius: 0 0 8px 8px; text-align: center;">
          <p style="color: #6b7280; font-size: 14px; margin: 0 0 10px 0;">
            Questions? Chat with Trinity once you sign up, or contact ${data.inviterName} directly.
          </p>
          <p style="color: #9ca3af; font-size: 12px; margin: 0;">
            This invitation was sent to ${data.recipientEmail} by CoAIleague Platform.<br>
            If you did not expect this invitation, you can safely ignore this email.
          </p>
        </div>
      </div>
    `
  }),

  /**
   * PUBLIC LEAD WELCOME EMAIL
   * Sent to leads captured from landing pages (ROI calculator, contact forms)
   */
  publicLeadWelcome: (data: {
    contactName: string;
    companyName: string;
    scheduleDemoUrl: string;
    roiSummary?: {
      estimatedSavings: number;
      guardCount: number;
    };
  }) => ({
    subject: `Welcome ${data.companyName} - See How CoAIleague Can Transform Your Operations`,
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; background-color: #f9fafb;">
        <div style="text-align: center; padding: 40px 30px; background: linear-gradient(135deg, #2563eb 0%, #7c3aed 100%); border-radius: 8px 8px 0 0;">
          <h1 style="color: white; margin: 0; font-size: 28px; font-weight: 700;">Thank You for Your Interest!</h1>
          <p style="color: #e0e7ff; margin: 15px 0 0 0; font-size: 16px;">AI-Powered Workforce Intelligence</p>
        </div>
        
        <div style="padding: 40px 30px; background-color: white;">
          <p style="font-size: 18px; color: #1f2937;">Hello ${data.contactName},</p>
          
          <p style="font-size: 16px; color: #4b5563; line-height: 1.6;">
            Thank you for exploring how CoAIleague can help <strong>${data.companyName}</strong>. 
            We're excited to show you how our AI-powered platform can streamline your workforce operations.
          </p>
          
          ${data.roiSummary ? `
          <div style="background: linear-gradient(135deg, #ecfdf5 0%, #f0fdf4 100%); padding: 25px; border-radius: 12px; margin: 30px 0; border: 1px solid #86efac;">
            <h3 style="color: #15803d; margin: 0 0 15px 0; font-size: 18px;">Your Estimated Annual Savings</h3>
            <p style="font-size: 32px; color: #16a34a; font-weight: bold; margin: 0;">
              $${data.roiSummary.estimatedSavings.toLocaleString()}
            </p>
            <p style="color: #166534; font-size: 14px; margin: 10px 0 0 0;">
              Based on ${data.roiSummary.guardCount} employees
            </p>
          </div>
          ` : ''}
          
          <div style="background-color: #f3f4f6; padding: 25px; border-radius: 12px; margin: 30px 0;">
            <h3 style="color: #1f2937; margin: 0 0 15px 0; font-size: 16px;">What CoAIleague Can Do For You:</h3>
            <ul style="margin: 0; padding: 0 0 0 20px; color: #4b5563; font-size: 14px; line-height: 1.8;">
              <li>AI-optimized scheduling that reduces overtime by 23%</li>
              <li>Automated time tracking with GPS verification</li>
              <li>Real-time labor cost monitoring</li>
              <li>Compliance automation for 50-state requirements</li>
              <li>Trinity AI assistant for instant insights</li>
            </ul>
          </div>
          
          <div style="text-align: center; margin: 40px 0;">
            <a href="${data.scheduleDemoUrl}" 
               style="background: linear-gradient(135deg, #2563eb 0%, #7c3aed 100%); color: white; padding: 18px 48px; text-decoration: none; border-radius: 10px; font-weight: 700; display: inline-block; font-size: 18px; box-shadow: 0 4px 14px rgba(37, 99, 235, 0.4);">
              Schedule Your Demo
            </a>
          </div>
          
          <p style="font-size: 14px; color: #6b7280; text-align: center;">
            Or reply to this email with questions - we're here to help!
          </p>
        </div>
        
        <div style="padding: 25px 30px; background-color: #f3f4f6; border-radius: 0 0 8px 8px; text-align: center;">
          <p style="color: #9ca3af; font-size: 12px; margin: 0;">
            This email was sent because you requested information about CoAIleague.<br>
            If you did not request this, you can safely ignore this email.
          </p>
        </div>
      </div>
    `
  }),

  /**
   * INBOUND OPPORTUNITY NOTIFICATION
   * Sent to managers when a new shift opportunity is detected from inbound emails
   */
  inboundOpportunityNotification: (data: {
    managerName: string;
    contractorName: string;
    shiftCount: number;
    shiftDetails: string;
    reviewUrl: string;
  }) => ({
    subject: `New Shift Opportunity: ${data.contractorName} - ${data.shiftCount} shift(s) detected`,
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; background-color: #f9fafb;">
        <div style="text-align: center; padding: 30px; background: linear-gradient(135deg, #f59e0b 0%, #f97316 100%); border-radius: 8px 8px 0 0;">
          <h1 style="color: white; margin: 0; font-size: 24px; font-weight: 700;">New Shift Opportunity Detected</h1>
          <p style="color: #fef3c7; margin: 10px 0 0 0; font-size: 14px;">Trinity AI has identified a new opportunity</p>
        </div>
        
        <div style="padding: 30px; background-color: white;">
          <p style="font-size: 16px; color: #1f2937;">Hello ${data.managerName},</p>
          
          <p style="font-size: 15px; color: #4b5563; line-height: 1.6;">
            Trinity has automatically detected a new shift request from <strong>${data.contractorName}</strong>.
          </p>
          
          <div style="background-color: #fef3c7; padding: 20px; border-radius: 8px; margin: 25px 0; border-left: 4px solid #f59e0b;">
            <p style="margin: 0 0 10px 0; font-weight: bold; color: #92400e;">Shift Details:</p>
            <p style="margin: 0; color: #78350f; font-size: 14px; white-space: pre-line;">${data.shiftDetails}</p>
          </div>
          
          <div style="text-align: center; margin: 30px 0;">
            <a href="${data.reviewUrl}" 
               style="background-color: #f59e0b; color: white; padding: 14px 32px; text-decoration: none; border-radius: 8px; font-weight: 600; display: inline-block; font-size: 16px;">
              Review & Staff This Shift
            </a>
          </div>
          
          <p style="font-size: 13px; color: #6b7280; text-align: center;">
            Trinity is ready to suggest qualified employees for this shift
          </p>
        </div>
        
        <div style="padding: 20px 30px; background-color: #f3f4f6; border-radius: 0 0 8px 8px; text-align: center;">
          <p style="color: #9ca3af; font-size: 12px; margin: 0;">
            This is an automated notification from CoAIleague's Inbound Opportunity Agent.
          </p>
        </div>
      </div>
    `
  }),

  /**
   * SHIFT OFFER NOTIFICATION
   * Sent to employees when they receive a shift offer from the auto-staffing system
   */
  shiftOfferNotification: (data: {
    employeeName: string;
    clientName: string;
    location: string;
    shiftDate: string;
    startTime: string;
    endTime: string;
    payRate?: string;
    matchRank: number;
    matchScore: number;
    matchReasons: string[];
    respondUrl: string;
    expiresIn: string;
  }) => ({
    subject: `New Shift Offer: ${data.clientName} on ${data.shiftDate}`,
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; background-color: #f9fafb;">
        <div style="text-align: center; padding: 30px; background: linear-gradient(135deg, #16a34a 0%, #2563eb 100%); border-radius: 8px 8px 0 0;">
          <h1 style="color: white; margin: 0; font-size: 24px; font-weight: 700;">New Shift Opportunity</h1>
          <p style="color: #dcfce7; margin: 10px 0 0 0; font-size: 14px;">You've been selected for this shift</p>
        </div>

        <div style="padding: 30px; background-color: white;">
          <p style="font-size: 16px; color: #1f2937;">Hello ${data.employeeName},</p>

          <p style="font-size: 15px; color: #4b5563; line-height: 1.6;">
            Great news! Based on your qualifications and availability, you've been selected as a top match for an upcoming shift.
          </p>

          <div style="background-color: #f0fdf4; padding: 20px; border-radius: 8px; margin: 25px 0; border-left: 4px solid #16a34a;">
            <p style="margin: 0 0 15px 0; font-weight: bold; color: #15803d; font-size: 16px;">Shift Details:</p>
            <table style="width: 100%; border-collapse: collapse;">
              <tr>
                <td style="padding: 8px 0; color: #4b5563; width: 40%;"><strong>Client:</strong></td>
                <td style="padding: 8px 0; color: #1f2937;">${data.clientName}</td>
              </tr>
              <tr>
                <td style="padding: 8px 0; color: #4b5563;"><strong>Location:</strong></td>
                <td style="padding: 8px 0; color: #1f2937;">${data.location}</td>
              </tr>
              <tr>
                <td style="padding: 8px 0; color: #4b5563;"><strong>Date:</strong></td>
                <td style="padding: 8px 0; color: #1f2937;">${data.shiftDate}</td>
              </tr>
              <tr>
                <td style="padding: 8px 0; color: #4b5563;"><strong>Time:</strong></td>
                <td style="padding: 8px 0; color: #1f2937;">${data.startTime} - ${data.endTime}</td>
              </tr>
              ${data.payRate ? `
              <tr>
                <td style="padding: 8px 0; color: #4b5563;"><strong>Pay Rate:</strong></td>
                <td style="padding: 8px 0; color: #1f2937;">$${data.payRate}/hr</td>
              </tr>
              ` : ''}
            </table>
          </div>

          <div style="background-color: #f3f4f6; padding: 15px; border-radius: 8px; margin: 20px 0;">
            <p style="margin: 0 0 10px 0; font-weight: bold; color: #374151; font-size: 14px;">Why you were selected (Match #${data.matchRank}):</p>
            <ul style="margin: 0; padding: 0 0 0 20px; color: #4b5563; font-size: 14px;">
              ${data.matchReasons.map(reason => `<li style="margin: 5px 0;">${reason}</li>`).join('')}
            </ul>
            <p style="margin: 10px 0 0 0; font-size: 13px; color: #6b7280;">
              Match Score: <strong>${Math.round(data.matchScore * 100)}%</strong>
            </p>
          </div>

          <div style="text-align: center; margin: 30px 0;">
            <a href="${data.respondUrl}"
               style="background-color: #16a34a; color: white; padding: 16px 40px; text-decoration: none; border-radius: 8px; font-weight: 600; display: inline-block; font-size: 16px;">
              Accept This Shift
            </a>
          </div>

          <div style="background-color: #fef3c7; padding: 15px; border-radius: 8px; margin: 20px 0; border-left: 4px solid #f59e0b;">
            <p style="margin: 0; font-size: 14px; color: #92400e;">
              <strong>Important:</strong> This offer expires in <strong>${data.expiresIn}</strong>.
              Please respond as soon as possible to secure this shift.
            </p>
          </div>

          <p style="font-size: 13px; color: #6b7280; text-align: center;">
            Can't make it? No worries - click the link above to decline so we can offer it to someone else.
          </p>
        </div>

        <div style="padding: 20px 30px; background-color: #f3f4f6; border-radius: 0 0 8px 8px; text-align: center;">
          <p style="color: #9ca3af; font-size: 12px; margin: 0;">
            This is an automated shift offer from CoAIleague's AI Staffing System.
          </p>
        </div>
      </div>
    `
  }),

  assistedOnboardingHandoff: (data: {
    recipientName: string;
    workspaceName: string;
    handoffUrl: string;
    expiresAt: string;
    supportTeamNote?: string;
  }) => ({
    subject: `Your ${data.workspaceName} Organization is Ready - CoAIleague`,
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; background-color: #f9fafb;">
        <!-- Header with gradient -->
        <div style="text-align: center; padding: 40px 30px; background: linear-gradient(135deg, #16a34a 0%, #2563eb 100%); border-radius: 8px 8px 0 0;">
          <h1 style="color: white; margin: 0; font-size: 28px; font-weight: 700;">Your Organization is Ready!</h1>
          <p style="color: #e0e7ff; margin: 15px 0 0 0; font-size: 16px;">Our support team has set everything up for you</p>
        </div>
        
        <!-- Main content -->
        <div style="padding: 40px 30px; background-color: white;">
          <p style="font-size: 18px; color: #1f2937;">Hello ${data.recipientName},</p>
          
          <p style="font-size: 16px; color: #4b5563; line-height: 1.6;">
            Great news! Our support team has finished setting up <strong>${data.workspaceName}</strong> on CoAIleague for you. 
            Your organization is fully configured and ready for you to take ownership.
          </p>
          
          <!-- What's been done box -->
          <div style="background: linear-gradient(135deg, #f0fdf4 0%, #ecfdf5 100%); padding: 25px; border-radius: 12px; margin: 30px 0; border: 1px solid #86efac;">
            <h3 style="color: #15803d; margin: 0 0 15px 0; font-size: 18px;">What We've Set Up For You:</h3>
            <ul style="margin: 0; padding: 0 0 0 20px; color: #166534; font-size: 15px; line-height: 1.8;">
              <li>Your organization account with all basic settings</li>
              <li>Industry-specific configuration and templates</li>
              <li>AI-extracted data from your documents (if provided)</li>
              <li>Trinity AI assistant ready to help you</li>
            </ul>
          </div>
          
          ${data.supportTeamNote ? `
          <div style="background-color: #f3f4f6; padding: 20px; border-radius: 8px; margin: 25px 0; border-left: 4px solid #6b7280;">
            <p style="margin: 0; font-size: 14px; color: #4b5563;">
              <strong>Note from Support:</strong> ${data.supportTeamNote}
            </p>
          </div>
          ` : ''}
          
          <!-- CTA Button -->
          <div style="text-align: center; margin: 40px 0;">
            <a href="${data.handoffUrl}" 
               style="background: linear-gradient(135deg, #16a34a 0%, #22c55e 100%); color: white; padding: 18px 48px; text-decoration: none; border-radius: 10px; font-weight: 700; display: inline-block; font-size: 18px; box-shadow: 0 4px 14px rgba(22, 163, 74, 0.4);">
              Claim Your Organization
            </a>
          </div>
          
          <!-- Security notice -->
          <div style="background-color: #fef3c7; padding: 15px 20px; border-radius: 8px; margin: 25px 0; border-left: 4px solid #f59e0b;">
            <p style="margin: 0; font-size: 14px; color: #92400e;">
              <strong>Security Notice:</strong> This link expires on <strong>${data.expiresAt}</strong>. 
              After claiming your organization, you'll become the owner with full administrative access.
            </p>
          </div>
          
          <!-- What happens next -->
          <div style="background-color: #f9fafb; padding: 25px; border-radius: 12px; margin: 30px 0;">
            <h3 style="color: #1f2937; margin: 0 0 15px 0; font-size: 16px;">What Happens Next?</h3>
            <ol style="margin: 0; padding: 0 0 0 20px; color: #4b5563; font-size: 14px; line-height: 1.8;">
              <li>Click the button above to claim your organization</li>
              <li>Sign in or create your CoAIleague account</li>
              <li>Review your organization settings and make any adjustments</li>
              <li>Start using CoAIleague to manage your workforce!</li>
            </ol>
          </div>
        </div>
        
        <!-- Footer -->
        <div style="padding: 25px 30px; background-color: #f3f4f6; border-radius: 0 0 8px 8px; text-align: center;">
          <p style="color: #6b7280; font-size: 14px; margin: 0 0 10px 0;">
            Questions? Reply to this email or chat with Trinity once you're logged in.
          </p>
          <p style="color: #9ca3af; font-size: 12px; margin: 0;">
            This email was sent by CoAIleague Support Team.<br>
            If you did not request this organization setup, please contact support immediately.
          </p>
        </div>
      </div>
    `
  }),
};

// ============================================================================
// EMAIL SERVICE CLASS
// ============================================================================

interface EmailResult {
  success: boolean;
  resendId?: string;
  error?: string;
}

interface EmailRetryJob {
  id: string;
  eventId: string;
  recipientEmail: string;
  subject: string;
  html: string;
  emailType: string;
  workspaceId?: string;
  userId?: string;
  retryCount: number;
  nextRetryAt: Date;
  createdAt: Date;
}

export class EmailService {
  private retryQueue: Map<string, EmailRetryJob> = new Map();
  private retryCheckInterval: NodeJS.Timeout | null = null;
  
  /**
   * Log email event to database
   */
  private async logEmailEvent(
    emailType: string,
    recipientEmail: string,
    status: 'pending' | 'sent' | 'failed',
    workspaceId?: string,
    userId?: string,
    resendId?: string,
    errorMessage?: string
  ): Promise<string> {
    try {
      const [event] = await db.insert(emailEvents).values({
        workspaceId: workspaceId || null,
        userId: userId || null,
        emailType,
        recipientEmail,
        status,
        resendId: resendId || null,
        errorMessage: errorMessage || null,
        sentAt: status === 'sent' ? new Date() : null,
      }).returning();
      
      return event.id;
    } catch (error: any) {
      console.error('[EmailService] Failed to log email event:', error.message);
      throw error;
    }
  }

  /**
   * Update email event status
   */
  private async updateEmailEvent(
    eventId: string,
    status: 'sent' | 'failed',
    resendId?: string,
    errorMessage?: string
  ): Promise<void> {
    try {
      await db.update(emailEvents)
        .set({
          status,
          resendId: resendId || null,
          errorMessage: errorMessage || null,
          sentAt: status === 'sent' ? new Date() : null,
        })
        .where(eq(emailEvents.id, eventId));
    } catch (error: any) {
      console.error('[EmailService] Failed to update email event:', error.message);
    }
  }

  /**
   * Calculate next retry time with exponential backoff
   * Retry attempt 1: 30 seconds, 2: 5 mins, 3: 30 mins, 4: 2 hours, 5: 24 hours
   */
  private getNextRetryTime(retryCount: number): Date {
    const backoffMs = [
      30 * 1000,        // Attempt 1: 30 seconds
      5 * 60 * 1000,    // Attempt 2: 5 minutes
      30 * 60 * 1000,   // Attempt 3: 30 minutes
      2 * 60 * 60 * 1000, // Attempt 4: 2 hours
      24 * 60 * 60 * 1000, // Attempt 5: 24 hours
    ];
    
    const delayMs = backoffMs[Math.min(retryCount, backoffMs.length - 1)];
    return new Date(Date.now() + delayMs);
  }

  /**
   * Add email to retry queue
   */
  private addToRetryQueue(
    eventId: string,
    to: string,
    subject: string,
    html: string,
    emailType: string,
    workspaceId?: string,
    userId?: string,
    retryCount: number = 0
  ): void {
    const retryJobId = `${eventId}-retry-${retryCount}`;
    const job: EmailRetryJob = {
      id: retryJobId,
      eventId,
      recipientEmail: to,
      subject,
      html,
      emailType,
      workspaceId,
      userId,
      retryCount,
      nextRetryAt: this.getNextRetryTime(retryCount),
      createdAt: new Date(),
    };
    
    this.retryQueue.set(retryJobId, job);
    console.log(`[EmailService] Added to retry queue: ${emailType} to ${to} (retry ${retryCount + 1}/5)`);
  }

  /**
   * Process retry queue - check for jobs that should be retried
   */
  private async processRetryQueue(): Promise<void> {
    const now = new Date();
    const jobsToRetry = Array.from(this.retryQueue.values()).filter(job => job.nextRetryAt <= now);
    
    if (jobsToRetry.length === 0) return;
    
    console.log(`[EmailService] Processing ${jobsToRetry.length} retry jobs...`);
    
    for (const job of jobsToRetry) {
      if (job.retryCount >= 5) {
        // Max retries exceeded - mark as permanently failed
        await this.updateEmailEvent(
          job.eventId,
          'failed',
          undefined,
          `Failed after 5 retry attempts`
        );
        this.retryQueue.delete(job.id);
        console.warn(`[EmailService] Max retries exceeded: ${job.emailType} to ${job.recipientEmail}`);
        continue;
      }
      
      // Attempt to resend
      try {
        const { client, fromEmail } = await getUncachableResendClient();
        const result = await client.emails.send({
          from: fromEmail,
          to: job.recipientEmail,
          subject: job.subject,
          html: job.html,
        });
        
        // Success - update log and remove from queue
        await this.updateEmailEvent(job.eventId, 'sent', result.data?.id);
        this.retryQueue.delete(job.id);
        console.log(`[EmailService] Retry successful: ${job.emailType} to ${job.recipientEmail}`);
      } catch (error: any) {
        // Schedule next retry
        job.retryCount++;
        job.nextRetryAt = this.getNextRetryTime(job.retryCount);
        console.warn(`[EmailService] Retry failed: ${job.emailType} to ${job.recipientEmail}, next attempt: ${job.nextRetryAt}`);
      }
    }
  }

  /**
   * Initialize retry queue processor
   */
  startRetryProcessor(): void {
    if (this.retryCheckInterval) return;
    
    // Check retry queue every 60 seconds
    this.retryCheckInterval = setInterval(() => {
      this.processRetryQueue().catch(error => {
        console.error('[EmailService] Error processing retry queue:', error);
      });
    }, 60 * 1000);
    
    console.log('[EmailService] Email retry processor started (checks every 60s)');
  }

  /**
   * Stop retry queue processor
   */
  stopRetryProcessor(): void {
    if (this.retryCheckInterval) {
      clearInterval(this.retryCheckInterval);
      this.retryCheckInterval = null;
      console.log('[EmailService] Email retry processor stopped');
    }
  }

  /**
   * Send email via Resend with audit logging, automatic retry, and 7-step orchestration
   * SIMULATION MODE: If emailSimulationMode is enabled, logs email instead of sending
   * CAN-SPAM COMPLIANT: Uses sendCanSpamCompliantEmail for List-Unsubscribe headers
   */
  private async sendEmail(
    to: string,
    subject: string,
    html: string,
    emailType: string,
    workspaceId?: string,
    userId?: string
  ): Promise<EmailResult> {
    const isProduction = process.env.NODE_ENV === 'production' || !!process.env.REPLIT_DEPLOYMENT;
    const isSimulation = !isProduction && (FEATURES.emailSimulationMode || process.env.EMAIL_SIMULATION_MODE === 'true');

    const result = await automationOrchestration.executeAutomation(
      {
        domain: 'automation',
        automationName: `email-${emailType}`,
        automationType: 'email_delivery',
        workspaceId,
        userId,
        triggeredBy: 'system',
        payload: { to, emailType, subject: subject.substring(0, 50) },
        billable: true,
        creditCost: 1,
      },
      async (ctx) => {
        if (isSimulation) {
          console.log('═'.repeat(60));
          console.log('[EMAIL SIMULATION] Would send email:');
          console.log(`   Type: ${emailType}`);
          console.log(`   To: ${to}`);
          console.log(`   Subject: ${subject}`);
          console.log(`   WorkspaceId: ${workspaceId || 'N/A'}`);
          console.log(`   UserId: ${userId || 'N/A'}`);
          console.log(`   OrchestrationId: ${ctx.orchestrationId}`);
          console.log('   HTML Preview (first 200 chars):');
          console.log(`   ${html.replace(/<[^>]*>/g, ' ').substring(0, 200)}...`);
          console.log('═'.repeat(60));

          await this.logEmailEvent(
            emailType,
            to,
            'sent',
            workspaceId,
            userId,
            `SIMULATED-${Date.now()}`
          );

          return { success: true, resendId: `SIMULATED-${Date.now()}` };
        }

        const eventId = await this.logEmailEvent(
          emailType,
          to,
          'pending',
          workspaceId,
          userId
        );

        const sendResult = await sendCanSpamCompliantEmail({
          to,
          subject,
          html,
          emailType,
          workspaceId,
        });

        if (sendResult.skipped) {
          await this.updateEmailEvent(eventId, 'failed', undefined, sendResult.reason);
          console.log(`[EmailService] Email skipped (unsubscribed): ${emailType} to ${to}`);
          return { success: false, error: sendResult.reason };
        }

        if (sendResult.success) {
          await this.updateEmailEvent(eventId, 'sent', sendResult.data?.data?.id);
          console.log(`[EmailService] Email sent successfully: ${emailType} to ${to}`);
          return { success: true, resendId: sendResult.data?.data?.id };
        }

        const errorMessage = sendResult.error?.message || 'Unknown error';
        await this.updateEmailEvent(eventId, 'failed', undefined, errorMessage);
        this.addToRetryQueue(eventId, to, subject, html, emailType, workspaceId, userId, 0);
        console.error(`[EmailService] Email failed (will retry): ${emailType} to ${to}`, errorMessage);
        return { success: false, error: errorMessage };
      },
      {
        validate: async (ctx) => {
          if (!to || !to.includes('@')) {
            return { valid: false, errors: ['Invalid email address'] };
          }
          if (!subject || subject.trim().length === 0) {
            return { valid: false, errors: ['Email subject is required'] };
          }
          return { valid: true };
        },
      }
    );

    if (result.success && result.data) {
      return result.data as EmailResult;
    }

    return {
      success: false,
      error: result.error || 'Email orchestration failed',
    };
  }

  // ============================================================================
  // PUBLIC EMAIL METHODS
  // ============================================================================

  /**
   * Send verification email to new user
   * Priority #1
   */
  async sendVerificationEmail(
    userId: string,
    email: string,
    verificationToken: string,
    firstName?: string
  ): Promise<EmailResult> {
    const verificationUrl = `${getAppBaseUrl()}/verify-email?token=${verificationToken}`;
    
    const template = emailTemplates.verification({
      firstName: firstName || 'User',
      verificationUrl,
    });

    return this.sendEmail(
      email,
      template.subject,
      template.html,
      'verification',
      undefined,
      userId
    );
  }

  /**
   * Send password reset email
   * Priority #2
   */
  async sendPasswordResetEmail(
    userId: string,
    email: string,
    resetToken: string,
    firstName?: string
  ): Promise<EmailResult> {
    const resetUrl = `${getAppBaseUrl()}/reset-password?token=${resetToken}`;
    
    const template = emailTemplates.passwordReset({
      firstName: firstName || 'User',
      resetUrl,
    });

    return this.sendEmail(
      email,
      template.subject,
      template.html,
      'password_reset',
      undefined,
      userId
    );
  }

  /**
   * Send support ticket confirmation email
   */
  async sendSupportTicketConfirmation(
    workspaceId: string,
    ticketId: string,
    userEmail: string,
    ticketNumber: string,
    subject: string,
    userName?: string
  ): Promise<EmailResult> {
    const template = emailTemplates.supportTicketConfirmation({
      name: userName || 'User',
      ticketNumber,
      subject,
    });

    return this.sendEmail(
      userEmail,
      template.subject,
      template.html,
      'support_ticket',
      workspaceId
    );
  }

  /**
   * Send report delivery email to client
   */
  async sendReportDelivery(
    workspaceId: string,
    clientEmail: string,
    reportData: {
      reportNumber: string;
      reportTitle: string;
      clientName: string;
    }
  ): Promise<EmailResult> {
    const template = emailTemplates.reportDelivery({
      clientName: reportData.clientName,
      reportNumber: reportData.reportNumber,
      reportTitle: reportData.reportTitle,
    });

    return this.sendEmail(
      clientEmail,
      template.subject,
      template.html,
      'report_delivery',
      workspaceId
    );
  }

  /**
   * Send temporary password to new employee
   */
  async sendEmployeeTemporaryPassword(
    workspaceId: string,
    employeeId: string,
    email: string,
    tempPassword: string,
    firstName?: string,
    workspaceName?: string
  ): Promise<EmailResult> {
    const template = emailTemplates.employeeTemporaryPassword({
      firstName: firstName || 'Employee',
      email,
      tempPassword,
      workspaceName: workspaceName || 'CoAIleague',
    });

    return this.sendEmail(
      email,
      template.subject,
      template.html,
      'employee_temp_password',
      workspaceId
    );
  }

  /**
   * Send manager notification for new employee onboarding
   */
  async sendManagerOnboardingNotification(
    workspaceId: string,
    managerId: string,
    managerEmail: string,
    employeeName: string,
    managerName?: string,
    workspaceName?: string
  ): Promise<EmailResult> {
    const template = emailTemplates.managerOnboardingNotification({
      managerName: managerName || 'Manager',
      employeeName,
      workspaceName: workspaceName || 'CoAIleague',
    });

    return this.sendEmail(
      managerEmail,
      template.subject,
      template.html,
      'manager_onboarding',
      workspaceId,
      managerId
    );
  }
  /**
   * Send custom email (for rule engine and automation workflows)
   * Public method for external use
   */
  async sendCustomEmail(
    to: string,
    subject: string,
    html: string,
    emailType?: string,
    workspaceId?: string,
    userId?: string
  ): Promise<EmailResult> {
    return this.sendEmail(
      to,
      subject,
      html,
      emailType || 'custom_email',
      workspaceId,
      userId
    );
  }

  /**
   * Send client welcome email
   * Sent when a new client is created with portal access
   */
  async sendClientWelcomeEmail(
    workspaceId: string,
    clientId: string,
    email: string,
    clientName: string,
    companyName: string,
    workspaceName: string,
  ): Promise<EmailResult> {
    const portalUrl = `${getAppBaseUrl()}/client-portal`;
    
    const template = emailTemplates.clientWelcome({
      clientName,
      companyName: companyName || 'Your Organization',
      workspaceName: workspaceName || 'Our Team',
      portalUrl,
    });

    return this.sendEmail(
      email,
      template.subject,
      template.html,
      'client_welcome',
      workspaceId,
      undefined
    );
  }

  /**
   * Send new member welcome email
   * Sent when a user first signs up for the platform
   */
  async sendNewMemberWelcome(
    userId: string,
    email: string,
    firstName: string
  ): Promise<EmailResult> {
    const onboardingUrl = `${getAppBaseUrl()}/onboarding`;
    
    const template = emailTemplates.newMemberWelcome({
      firstName: firstName || 'there',
      onboardingUrl,
    });

    return this.sendEmail(
      email,
      template.subject,
      template.html,
      'new_member_welcome',
      undefined,
      userId
    );
  }

  /**
   * Send employee invitation email
   * Sent when an employee is invited to join a workspace
   */
  async sendEmployeeInvitation(
    workspaceId: string,
    email: string,
    inviteToken: string,
    data: {
      firstName: string;
      inviterName: string;
      workspaceName: string;
      roleName: string;
      expiresInDays?: number;
    }
  ): Promise<EmailResult> {
    const joinUrl = `${getAppBaseUrl()}/accept-invite?token=${inviteToken}`;
    
    const template = emailTemplates.employeeInvitation({
      firstName: data.firstName || 'there',
      inviterName: data.inviterName,
      workspaceName: data.workspaceName,
      roleName: data.roleName || 'Team Member',
      joinUrl,
      expiresIn: `${data.expiresInDays || 7} days`,
    });

    return this.sendEmail(
      email,
      template.subject,
      template.html,
      'employee_invitation',
      workspaceId
    );
  }

  /**
   * Send support role briefing email
   * Sent when a user is assigned a platform support role
   */
  async sendSupportRoleBriefing(
    userId: string,
    email: string,
    firstName: string,
    roleName: string,
    capabilities: string[]
  ): Promise<EmailResult> {
    const dashboardUrl = `${getAppBaseUrl()}/platform-admin`;
    
    const template = emailTemplates.supportRoleBriefing({
      firstName: firstName || 'Support Team Member',
      roleName,
      dashboardUrl,
      capabilities,
    });

    return this.sendEmail(
      email,
      template.subject,
      template.html,
      'support_role_briefing',
      undefined,
      userId
    );
  }

  /**
   * Send onboarding completion celebration email
   * Sent when a user completes all onboarding tasks
   */
  async sendOnboardingComplete(
    workspaceId: string,
    userId: string,
    email: string,
    firstName: string,
    workspaceName: string,
    completedTasks: number
  ): Promise<EmailResult> {
    const dashboardUrl = `${getAppBaseUrl()}/dashboard`;
    
    const template = emailTemplates.onboardingComplete({
      firstName: firstName || 'there',
      workspaceName: workspaceName || 'Your Organization',
      dashboardUrl,
      completedTasks,
    });

    return this.sendEmail(
      email,
      template.subject,
      template.html,
      'onboarding_complete',
      workspaceId,
      userId
    );
  }

  /**
   * Send organization invitation email
   * Premium template for inviting new organizations with Trinity AI introduction
   */
  async sendOrganizationInvitation(params: {
    recipientEmail: string;
    recipientName: string;
    inviterName: string;
    inviterCompany?: string;
    organizationName: string;
    inviteToken: string;
    expiresInDays?: number;
    workspaceId?: string;
  }): Promise<EmailResult> {
    const welcomeUrl = `${getAppBaseUrl()}/welcome`;
    
    const migrationFeatures = [
      'Employee roster from PDF, Excel, or CSV files',
      'Team structures and departments',
      'Existing schedules and shift patterns',
      'Manual data entry with AI-assisted validation',
      'Gamification achievements and leaderboards',
      'AI automation unlocked progressively',
    ];
    
    const template = emailTemplates.organizationInvitation({
      recipientName: params.recipientName || 'there',
      recipientEmail: params.recipientEmail,
      inviterName: params.inviterName,
      inviterCompany: params.inviterCompany,
      organizationName: params.organizationName || 'Your Organization',
      welcomeUrl,
      inviteToken: params.inviteToken,
      expiresIn: `${params.expiresInDays || 7} days`,
      migrationFeatures,
    });

    return this.sendEmail(
      params.recipientEmail,
      template.subject,
      template.html,
      'organization_invitation',
      params.workspaceId
    );
  }

  /**
   * Send assisted onboarding handoff email
   * Sent when support staff has completed setting up an organization for a user
   */
  async sendAssistedOnboardingHandoff(params: {
    toEmail: string;
    toName: string;
    workspaceName: string;
    handoffToken: string;
    expiresAt: Date;
    supportNote?: string;
  }): Promise<EmailResult> {
    const handoffUrl = `${getAppBaseUrl()}/accept-handoff?token=${params.handoffToken}`;
    
    const template = emailTemplates.assistedOnboardingHandoff({
      recipientName: params.toName || 'there',
      workspaceName: params.workspaceName,
      handoffUrl,
      expiresAt: params.expiresAt.toLocaleDateString('en-US', { 
        weekday: 'long',
        year: 'numeric',
        month: 'long', 
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
      }),
      supportTeamNote: params.supportNote,
    });

    return this.sendEmail(
      params.toEmail,
      template.subject,
      template.html,
      'assisted_onboarding_handoff'
    );
  }

  /**
   * Send welcome email to public lead
   * Sent when a lead is captured from landing pages (ROI calculator, contact forms)
   */
  async sendPublicLeadWelcome(params: {
    email: string;
    contactName: string;
    companyName: string;
    roiData?: {
      estimatedAnnualSavings: number;
      numberOfGuards: number;
    };
  }): Promise<EmailResult> {
    const scheduleDemoUrl = `${getAppBaseUrl()}/schedule-demo`;
    
    const template = emailTemplates.publicLeadWelcome({
      contactName: params.contactName || 'there',
      companyName: params.companyName || 'your company',
      scheduleDemoUrl,
      roiSummary: params.roiData ? {
        estimatedSavings: params.roiData.estimatedAnnualSavings,
        guardCount: params.roiData.numberOfGuards,
      } : undefined,
    });

    return this.sendEmail(
      params.email,
      template.subject,
      template.html,
      'public_lead_welcome'
    );
  }

  /**
   * Send inbound opportunity notification to managers
   * Sent when Trinity detects a shift opportunity from inbound emails
   */
  async sendInboundOpportunityNotification(params: {
    workspaceId: string;
    managerEmail: string;
    managerName: string;
    contractorName: string;
    shiftCount: number;
    shiftDetails: string;
    stagedShiftId?: string;
  }): Promise<EmailResult> {
    const reviewUrl = params.stagedShiftId 
      ? `${getAppBaseUrl()}/schedule/staged/${params.stagedShiftId}`
      : `${getAppBaseUrl()}/schedule/staged`;
    
    const template = emailTemplates.inboundOpportunityNotification({
      managerName: params.managerName || 'Manager',
      contractorName: params.contractorName || 'Unknown Contractor',
      shiftCount: params.shiftCount || 1,
      shiftDetails: params.shiftDetails || 'See dashboard for details',
      reviewUrl,
    });

    return this.sendEmail(
      params.managerEmail,
      template.subject,
      template.html,
      'inbound_opportunity_notification',
      params.workspaceId
    );
  }

  /**
   * Send shift offer notification to an employee
   * Sent when the AI staffing system selects an employee as a candidate for a shift
   */
  async sendShiftOfferNotification(params: {
    workspaceId: string;
    employeeId: string;
    employeeEmail: string;
    employeeName: string;
    shiftData: {
      clientName: string;
      location: string;
      shiftDate: string;
      startTime: string;
      endTime: string;
      payRate?: string;
    };
    matchData: {
      rank: number;
      score: number;
      reasons: string[];
    };
    offerId: string;
    expiresAt: Date;
  }): Promise<EmailResult> {
    const respondUrl = `${getAppBaseUrl()}/shift-offers/${params.offerId}/respond`;

    // Calculate time until expiration
    const now = new Date();
    const diffMs = params.expiresAt.getTime() - now.getTime();
    const diffHours = Math.floor(diffMs / (1000 * 60 * 60));
    const diffMinutes = Math.floor((diffMs % (1000 * 60 * 60)) / (1000 * 60));
    const expiresIn = diffHours > 0
      ? `${diffHours} hour${diffHours !== 1 ? 's' : ''}`
      : `${diffMinutes} minute${diffMinutes !== 1 ? 's' : ''}`;

    const template = emailTemplates.shiftOfferNotification({
      employeeName: params.employeeName || 'Team Member',
      clientName: params.shiftData.clientName || 'Client',
      location: params.shiftData.location || 'See details in app',
      shiftDate: params.shiftData.shiftDate || 'TBD',
      startTime: params.shiftData.startTime || 'TBD',
      endTime: params.shiftData.endTime || 'TBD',
      payRate: params.shiftData.payRate,
      matchRank: params.matchData.rank,
      matchScore: params.matchData.score,
      matchReasons: params.matchData.reasons.length > 0
        ? params.matchData.reasons
        : ['Strong profile match'],
      respondUrl,
      expiresIn,
    });

    return this.sendEmail(
      params.employeeEmail,
      template.subject,
      template.html,
      'shift_offer_notification',
      params.workspaceId,
      params.employeeId
    );
  }

  // ==========================================================================
  // STAFFING REQUEST LIFECYCLE EMAILS
  // ==========================================================================

  /**
   * Send acknowledgment email when a staffing request is received
   * This confirms to the sender that their request is being processed
   */
  async sendStaffingRequestAcknowledgment(params: {
    workspaceId: string;
    senderEmail: string;
    senderName?: string;
    referenceNumber: string;
    originalSubject: string;
    workspaceName: string;
    extractedShiftCount?: number;
    estimatedResponseTime?: string;
  }): Promise<EmailResult> {
    const trackingUrl = `${getAppBaseUrl()}/request-status/${params.referenceNumber}`;

    const shiftInfo = params.extractedShiftCount && params.extractedShiftCount > 0
      ? `We've identified <strong>${params.extractedShiftCount} shift${params.extractedShiftCount > 1 ? 's' : ''}</strong> in your request.`
      : 'Our team is reviewing your request details.';

    const html = `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <div style="background: linear-gradient(135deg, #3b82f6 0%, #1d4ed8 100%); padding: 30px; border-radius: 12px 12px 0 0;">
          <h1 style="color: white; margin: 0; font-size: 24px;">Request Received</h1>
          <p style="color: #bfdbfe; margin: 10px 0 0 0;">We're on it!</p>
        </div>

        <div style="padding: 30px; background-color: #f8fafc; border-radius: 0 0 12px 12px;">
          <p style="font-size: 16px; color: #1e293b;">Hello ${params.senderName || 'there'},</p>

          <p style="color: #475569;">Thank you for your staffing request. <strong>${params.workspaceName}</strong> has received your message and is actively working on it.</p>

          <div style="background-color: white; padding: 20px; border-radius: 8px; margin: 25px 0; border-left: 4px solid #3b82f6;">
            <p style="margin: 0 0 10px 0; color: #64748b; font-size: 14px;">REFERENCE NUMBER</p>
            <p style="margin: 0; font-size: 24px; font-weight: bold; color: #1e293b; font-family: monospace;">${params.referenceNumber}</p>
          </div>

          <div style="background-color: #eff6ff; padding: 20px; border-radius: 8px; margin: 20px 0;">
            <p style="margin: 0 0 10px 0; color: #1e40af; font-weight: bold;">📋 Request Details</p>
            <p style="margin: 5px 0; color: #1e293b;"><strong>Subject:</strong> ${params.originalSubject}</p>
            <p style="margin: 5px 0; color: #1e293b;">${shiftInfo}</p>
          </div>

          <div style="background-color: #f0fdf4; padding: 20px; border-radius: 8px; margin: 20px 0;">
            <p style="margin: 0 0 10px 0; color: #166534; font-weight: bold;">⏱️ What Happens Next</p>
            <ol style="margin: 0; padding-left: 20px; color: #166534;">
              <li style="margin-bottom: 8px;">Our team reviews your requirements</li>
              <li style="margin-bottom: 8px;">We match qualified personnel to your needs</li>
              <li style="margin-bottom: 8px;">You'll receive confirmation with staffing details</li>
            </ol>
            <p style="margin: 15px 0 0 0; color: #166534;"><strong>Expected response:</strong> ${params.estimatedResponseTime || 'Within 2 hours during business hours'}</p>
          </div>

          <p style="color: #64748b; font-size: 14px; margin-top: 25px;">
            Questions? Reply to this email or contact us directly. Please include your reference number <strong>${params.referenceNumber}</strong> in any correspondence.
          </p>

          <hr style="border: none; border-top: 1px solid #e2e8f0; margin: 25px 0;">

          <p style="color: #94a3b8; font-size: 12px; margin: 0;">
            This is an automated confirmation from ${params.workspaceName} powered by CoAIleague.
          </p>
        </div>
      </div>
    `;

    return this.sendEmail(
      params.senderEmail,
      `✅ Request Received - ${params.referenceNumber}`,
      html,
      'staffing_acknowledgment',
      params.workspaceId
    );
  }

  /**
   * Send confirmation when a staffing request has been successfully fulfilled
   */
  async sendStaffingRequestFulfilled(params: {
    workspaceId: string;
    senderEmail: string;
    senderName?: string;
    referenceNumber: string;
    workspaceName: string;
    assignedStaff: Array<{
      name: string;
      role?: string;
      shiftDate: string;
      shiftTime: string;
      location: string;
    }>;
    specialInstructions?: string;
    contactPhone?: string;
    contactEmail?: string;
  }): Promise<EmailResult> {
    const staffList = params.assignedStaff.map(staff => `
      <tr>
        <td style="padding: 12px; border-bottom: 1px solid #e2e8f0;">${staff.name}</td>
        <td style="padding: 12px; border-bottom: 1px solid #e2e8f0;">${staff.role || 'Staff'}</td>
        <td style="padding: 12px; border-bottom: 1px solid #e2e8f0;">${staff.shiftDate}</td>
        <td style="padding: 12px; border-bottom: 1px solid #e2e8f0;">${staff.shiftTime}</td>
        <td style="padding: 12px; border-bottom: 1px solid #e2e8f0;">${staff.location}</td>
      </tr>
    `).join('');

    const html = `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <div style="background: linear-gradient(135deg, #22c55e 0%, #16a34a 100%); padding: 30px; border-radius: 12px 12px 0 0;">
          <h1 style="color: white; margin: 0; font-size: 24px;">✓ Request Fulfilled!</h1>
          <p style="color: #bbf7d0; margin: 10px 0 0 0;">Your staffing has been confirmed</p>
        </div>

        <div style="padding: 30px; background-color: #f8fafc; border-radius: 0 0 12px 12px;">
          <p style="font-size: 16px; color: #1e293b;">Hello ${params.senderName || 'there'},</p>

          <p style="color: #475569;">Great news! Your staffing request <strong>${params.referenceNumber}</strong> has been successfully fulfilled by <strong>${params.workspaceName}</strong>.</p>

          <div style="background-color: white; padding: 20px; border-radius: 8px; margin: 25px 0; overflow-x: auto;">
            <p style="margin: 0 0 15px 0; color: #1e40af; font-weight: bold;">👥 Assigned Personnel</p>
            <table style="width: 100%; border-collapse: collapse; font-size: 14px;">
              <thead>
                <tr style="background-color: #f1f5f9;">
                  <th style="padding: 12px; text-align: left; border-bottom: 2px solid #e2e8f0;">Name</th>
                  <th style="padding: 12px; text-align: left; border-bottom: 2px solid #e2e8f0;">Role</th>
                  <th style="padding: 12px; text-align: left; border-bottom: 2px solid #e2e8f0;">Date</th>
                  <th style="padding: 12px; text-align: left; border-bottom: 2px solid #e2e8f0;">Time</th>
                  <th style="padding: 12px; text-align: left; border-bottom: 2px solid #e2e8f0;">Location</th>
                </tr>
              </thead>
              <tbody>
                ${staffList}
              </tbody>
            </table>
          </div>

          ${params.specialInstructions ? `
          <div style="background-color: #fef3c7; padding: 20px; border-radius: 8px; margin: 20px 0;">
            <p style="margin: 0 0 10px 0; color: #92400e; font-weight: bold;">📝 Special Instructions</p>
            <p style="margin: 0; color: #78350f;">${params.specialInstructions}</p>
          </div>
          ` : ''}

          <div style="background-color: #eff6ff; padding: 20px; border-radius: 8px; margin: 20px 0;">
            <p style="margin: 0 0 10px 0; color: #1e40af; font-weight: bold;">📞 Contact Information</p>
            ${params.contactPhone ? `<p style="margin: 5px 0; color: #1e293b;"><strong>Phone:</strong> ${params.contactPhone}</p>` : ''}
            ${params.contactEmail ? `<p style="margin: 5px 0; color: #1e293b;"><strong>Email:</strong> ${params.contactEmail}</p>` : ''}
          </div>

          <p style="color: #64748b; font-size: 14px; margin-top: 25px;">
            Thank you for choosing ${params.workspaceName}. We appreciate your business!
          </p>

          <hr style="border: none; border-top: 1px solid #e2e8f0; margin: 25px 0;">

          <p style="color: #94a3b8; font-size: 12px; margin: 0;">
            Reference: ${params.referenceNumber} | Powered by CoAIleague
          </p>
        </div>
      </div>
    `;

    return this.sendEmail(
      params.senderEmail,
      `✓ Staffing Confirmed - ${params.referenceNumber}`,
      html,
      'staffing_fulfilled',
      params.workspaceId
    );
  }

  /**
   * Send notification when a staffing request could not be fulfilled
   */
  async sendStaffingRequestUnfulfilled(params: {
    workspaceId: string;
    senderEmail: string;
    senderName?: string;
    referenceNumber: string;
    workspaceName: string;
    reason: string;
    suggestedAlternatives?: string[];
    canRetry?: boolean;
    contactPhone?: string;
    contactEmail?: string;
  }): Promise<EmailResult> {
    const alternativesList = params.suggestedAlternatives && params.suggestedAlternatives.length > 0
      ? `
        <div style="background-color: #eff6ff; padding: 20px; border-radius: 8px; margin: 20px 0;">
          <p style="margin: 0 0 10px 0; color: #1e40af; font-weight: bold;">💡 Suggested Alternatives</p>
          <ul style="margin: 0; padding-left: 20px; color: #1e293b;">
            ${params.suggestedAlternatives.map(alt => `<li style="margin-bottom: 8px;">${alt}</li>`).join('')}
          </ul>
        </div>
      ` : '';

    const html = `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <div style="background: linear-gradient(135deg, #f97316 0%, #ea580c 100%); padding: 30px; border-radius: 12px 12px 0 0;">
          <h1 style="color: white; margin: 0; font-size: 24px;">Unable to Fulfill Request</h1>
          <p style="color: #fed7aa; margin: 10px 0 0 0;">We wanted to let you know</p>
        </div>

        <div style="padding: 30px; background-color: #f8fafc; border-radius: 0 0 12px 12px;">
          <p style="font-size: 16px; color: #1e293b;">Hello ${params.senderName || 'there'},</p>

          <p style="color: #475569;">We regret to inform you that <strong>${params.workspaceName}</strong> was unable to fulfill your staffing request <strong>${params.referenceNumber}</strong> at this time.</p>

          <div style="background-color: #fef2f2; padding: 20px; border-radius: 8px; margin: 25px 0; border-left: 4px solid #ef4444;">
            <p style="margin: 0 0 10px 0; color: #991b1b; font-weight: bold;">Reason</p>
            <p style="margin: 0; color: #7f1d1d;">${params.reason}</p>
          </div>

          ${alternativesList}

          ${params.canRetry ? `
          <div style="background-color: #f0fdf4; padding: 20px; border-radius: 8px; margin: 20px 0;">
            <p style="margin: 0; color: #166534;">
              <strong>Want to try again?</strong> You can submit a new request with adjusted requirements, or contact us to discuss alternatives.
            </p>
          </div>
          ` : ''}

          <div style="background-color: white; padding: 20px; border-radius: 8px; margin: 20px 0; border: 1px solid #e2e8f0;">
            <p style="margin: 0 0 10px 0; color: #1e293b; font-weight: bold;">📞 Let's Talk</p>
            <p style="margin: 0; color: #475569;">We'd love to help find a solution. Contact us:</p>
            ${params.contactPhone ? `<p style="margin: 10px 0 0 0; color: #1e293b;"><strong>Phone:</strong> ${params.contactPhone}</p>` : ''}
            ${params.contactEmail ? `<p style="margin: 5px 0 0 0; color: #1e293b;"><strong>Email:</strong> ${params.contactEmail}</p>` : ''}
          </div>

          <p style="color: #64748b; font-size: 14px; margin-top: 25px;">
            We appreciate your understanding and hope to serve you in the future.
          </p>

          <hr style="border: none; border-top: 1px solid #e2e8f0; margin: 25px 0;">

          <p style="color: #94a3b8; font-size: 12px; margin: 0;">
            Reference: ${params.referenceNumber} | ${params.workspaceName} powered by CoAIleague
          </p>
        </div>
      </div>
    `;

    return this.sendEmail(
      params.senderEmail,
      `Update on Your Request - ${params.referenceNumber}`,
      html,
      'staffing_unfulfilled',
      params.workspaceId
    );
  }

  /**
   * Send real-time staffing workflow status update to email sender
   * Called at each step of the 7-step orchestration process
   */
  async sendStaffingStatusUpdate(params: {
    workspaceId: string;
    senderEmail: string;
    senderName?: string;
    referenceNumber: string;
    workspaceName: string;
    currentStep: 'received' | 'classifying' | 'extracting' | 'matching' | 'assigning' | 'confirming' | 'completed';
    stepNumber: number;
    totalSteps: number;
    stepDetails?: string;
    tempCode?: string;
    statusPortalUrl?: string;
    extractedInfo?: {
      location?: string;
      date?: string;
      time?: string;
      positionType?: string;
      guardsNeeded?: number;
    };
  }): Promise<EmailResult> {
    const stepLabels: Record<string, { label: string; icon: string; color: string }> = {
      received: { label: 'Request Received', icon: '📥', color: '#3b82f6' },
      classifying: { label: 'Analyzing Request', icon: '🔍', color: '#8b5cf6' },
      extracting: { label: 'Extracting Details', icon: '📋', color: '#f59e0b' },
      matching: { label: 'Finding Available Staff', icon: '👥', color: '#06b6d4' },
      assigning: { label: 'Assigning Personnel', icon: '✅', color: '#22c55e' },
      confirming: { label: 'Sending Confirmation', icon: '📧', color: '#10b981' },
      completed: { label: 'Staffing Complete', icon: '🎉', color: '#22c55e' },
    };

    const step = stepLabels[params.currentStep] || { label: params.currentStep, icon: '⏳', color: '#6b7280' };
    const progressPercent = Math.round((params.stepNumber / params.totalSteps) * 100);

    const extractedInfoHtml = params.extractedInfo ? `
      <div style="background-color: #f0fdf4; padding: 15px; border-radius: 8px; margin: 15px 0;">
        <p style="margin: 0 0 10px 0; color: #166534; font-weight: bold; font-size: 14px;">📋 Details Identified</p>
        ${params.extractedInfo.location ? `<p style="margin: 4px 0; color: #166534; font-size: 13px;"><strong>Location:</strong> ${params.extractedInfo.location}</p>` : ''}
        ${params.extractedInfo.date ? `<p style="margin: 4px 0; color: #166534; font-size: 13px;"><strong>Date:</strong> ${params.extractedInfo.date}</p>` : ''}
        ${params.extractedInfo.time ? `<p style="margin: 4px 0; color: #166534; font-size: 13px;"><strong>Time:</strong> ${params.extractedInfo.time}</p>` : ''}
        ${params.extractedInfo.positionType ? `<p style="margin: 4px 0; color: #166534; font-size: 13px;"><strong>Position:</strong> ${params.extractedInfo.positionType}</p>` : ''}
        ${params.extractedInfo.guardsNeeded ? `<p style="margin: 4px 0; color: #166534; font-size: 13px;"><strong>Guards Needed:</strong> ${params.extractedInfo.guardsNeeded}</p>` : ''}
      </div>
    ` : '';

    const html = `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <div style="background: ${step.color}; padding: 20px; border-radius: 12px 12px 0 0;">
          <h1 style="color: white; margin: 0; font-size: 20px;">${step.icon} ${step.label}</h1>
          <p style="color: rgba(255,255,255,0.8); margin: 8px 0 0 0; font-size: 14px;">Request ${params.referenceNumber}</p>
        </div>

        <div style="padding: 25px; background-color: #f8fafc; border-radius: 0 0 12px 12px;">
          <p style="font-size: 15px; color: #1e293b; margin: 0 0 15px 0;">Hello ${params.senderName || 'there'},</p>

          <div style="background-color: white; padding: 15px; border-radius: 8px; margin: 15px 0; border: 1px solid #e2e8f0;">
            <p style="margin: 0 0 10px 0; color: #64748b; font-size: 12px; text-transform: uppercase;">Progress</p>
            <div style="background-color: #e2e8f0; border-radius: 999px; height: 8px; overflow: hidden;">
              <div style="background: linear-gradient(90deg, ${step.color}, ${step.color}dd); width: ${progressPercent}%; height: 100%; border-radius: 999px;"></div>
            </div>
            <p style="margin: 8px 0 0 0; color: #1e293b; font-size: 14px;"><strong>Step ${params.stepNumber} of ${params.totalSteps}:</strong> ${step.label}</p>
          </div>

          ${params.stepDetails ? `<p style="color: #475569; font-size: 14px; margin: 15px 0;">${params.stepDetails}</p>` : ''}

          ${extractedInfoHtml}

          ${params.tempCode && params.statusPortalUrl ? `
          <div style="background-color: #eff6ff; padding: 15px; border-radius: 8px; margin: 15px 0; border: 1px solid #bfdbfe;">
            <p style="margin: 0 0 8px 0; color: #1e40af; font-weight: bold; font-size: 14px;">Your Access Code</p>
            <p style="margin: 0 0 8px 0; color: #1e40af; font-size: 20px; font-family: monospace; letter-spacing: 2px;"><strong>${params.tempCode}</strong></p>
            <p style="margin: 0 0 10px 0; color: #3b82f6; font-size: 13px;">Use this code to check your request status anytime:</p>
            <a href="${params.statusPortalUrl}" style="display: inline-block; background-color: #2563eb; color: white; padding: 10px 20px; border-radius: 6px; text-decoration: none; font-size: 14px; font-weight: bold;">View Status Portal</a>
          </div>
          ` : ''}

          <p style="color: #94a3b8; font-size: 12px; margin: 20px 0 0 0;">
            ${params.workspaceName} powered by CoAIleague | You'll receive another update when the next step completes.
          </p>
        </div>
      </div>
    `;

    return this.sendEmail(
      params.senderEmail,
      `${step.icon} Step ${params.stepNumber}/${params.totalSteps}: ${step.label} - ${params.referenceNumber}`,
      html,
      'staffing_status_update',
      params.workspaceId
    );
  }

  /**
   * Send comprehensive staffing completion summary with who/what/where/why/how
   * This is the final email sent when staffing is fully complete
   */
  async sendStaffingCompletionSummary(params: {
    workspaceId: string;
    senderEmail: string;
    senderName?: string;
    referenceNumber: string;
    workspaceName: string;
    confirmationNumber: string;
    summary: {
      who: {
        assignedStaff: Array<{ name: string; phone?: string; role?: string }>;
        totalStaffCount: number;
      };
      what: {
        positionType: string;
        specialRequirements?: string[];
        dressCode?: string;
      };
      where: {
        location: string;
        address?: string;
        pocName?: string;
        pocPhone?: string;
      };
      when: {
        date: string;
        startTime: string;
        endTime: string;
        duration?: string;
      };
      why: {
        requestSource: string;
        clientName?: string;
        eventType?: string;
      };
      how: {
        billingTerms: string;
        rateInfo?: string;
        paymentInstructions?: string;
        invoiceWillFollow?: boolean;
      };
    };
    nextSteps?: string[];
    specialInstructions?: string;
  }): Promise<EmailResult> {
    const { summary } = params;

    const staffListHtml = summary.who.assignedStaff.map(staff => `
      <tr>
        <td style="padding: 10px 12px; border-bottom: 1px solid #e2e8f0; font-size: 14px;">${staff.name}</td>
        <td style="padding: 10px 12px; border-bottom: 1px solid #e2e8f0; font-size: 14px;">${staff.role || 'Security Officer'}</td>
        <td style="padding: 10px 12px; border-bottom: 1px solid #e2e8f0; font-size: 14px;">${staff.phone || 'On file'}</td>
      </tr>
    `).join('');

    const requirementsHtml = summary.what.specialRequirements && summary.what.specialRequirements.length > 0
      ? `<p style="margin: 5px 0; color: #1e293b; font-size: 14px;"><strong>Requirements:</strong> ${summary.what.specialRequirements.join(', ')}</p>`
      : '';

    const html = `
      <div style="font-family: Arial, sans-serif; max-width: 650px; margin: 0 auto;">
        <div style="background: linear-gradient(135deg, #22c55e 0%, #16a34a 100%); padding: 30px; border-radius: 12px 12px 0 0; text-align: center;">
          <h1 style="color: white; margin: 0; font-size: 26px;">🎉 Staffing Complete!</h1>
          <p style="color: #bbf7d0; margin: 10px 0 0 0; font-size: 16px;">Your request has been fully processed</p>
          <div style="background: rgba(255,255,255,0.2); display: inline-block; padding: 8px 20px; border-radius: 6px; margin-top: 15px;">
            <p style="margin: 0; color: white; font-size: 14px;">Confirmation: <strong style="font-family: monospace; font-size: 16px;">${params.confirmationNumber}</strong></p>
          </div>
        </div>

        <div style="padding: 30px; background-color: #f8fafc; border-radius: 0 0 12px 12px;">
          <p style="font-size: 16px; color: #1e293b; margin: 0 0 25px 0;">Hello ${params.senderName || 'there'},</p>

          <p style="color: #475569; margin-bottom: 25px;">Great news! <strong>${params.workspaceName}</strong> has successfully staffed your request. Here's a complete summary:</p>

          <!-- WHO Section -->
          <div style="background-color: white; padding: 20px; border-radius: 8px; margin-bottom: 20px; border-left: 4px solid #3b82f6;">
            <h3 style="margin: 0 0 15px 0; color: #1e40af; font-size: 16px;">👥 WHO - Assigned Personnel (${summary.who.totalStaffCount})</h3>
            <table style="width: 100%; border-collapse: collapse;">
              <thead>
                <tr style="background-color: #f1f5f9;">
                  <th style="padding: 10px 12px; text-align: left; font-size: 13px; color: #64748b;">Name</th>
                  <th style="padding: 10px 12px; text-align: left; font-size: 13px; color: #64748b;">Role</th>
                  <th style="padding: 10px 12px; text-align: left; font-size: 13px; color: #64748b;">Contact</th>
                </tr>
              </thead>
              <tbody>
                ${staffListHtml}
              </tbody>
            </table>
          </div>

          <!-- WHAT Section -->
          <div style="background-color: white; padding: 20px; border-radius: 8px; margin-bottom: 20px; border-left: 4px solid #8b5cf6;">
            <h3 style="margin: 0 0 15px 0; color: #6d28d9; font-size: 16px;">📋 WHAT - Assignment Details</h3>
            <p style="margin: 5px 0; color: #1e293b; font-size: 14px;"><strong>Position:</strong> ${summary.what.positionType}</p>
            ${summary.what.dressCode ? `<p style="margin: 5px 0; color: #1e293b; font-size: 14px;"><strong>Dress Code:</strong> ${summary.what.dressCode}</p>` : ''}
            ${requirementsHtml}
          </div>

          <!-- WHERE Section -->
          <div style="background-color: white; padding: 20px; border-radius: 8px; margin-bottom: 20px; border-left: 4px solid #f59e0b;">
            <h3 style="margin: 0 0 15px 0; color: #d97706; font-size: 16px;">📍 WHERE - Location</h3>
            <p style="margin: 5px 0; color: #1e293b; font-size: 14px;"><strong>Site:</strong> ${summary.where.location}</p>
            ${summary.where.address ? `<p style="margin: 5px 0; color: #1e293b; font-size: 14px;"><strong>Address:</strong> ${summary.where.address}</p>` : ''}
            ${summary.where.pocName ? `<p style="margin: 5px 0; color: #1e293b; font-size: 14px;"><strong>Site Contact:</strong> ${summary.where.pocName}${summary.where.pocPhone ? ` - ${summary.where.pocPhone}` : ''}</p>` : ''}
          </div>

          <!-- WHEN Section -->
          <div style="background-color: white; padding: 20px; border-radius: 8px; margin-bottom: 20px; border-left: 4px solid #06b6d4;">
            <h3 style="margin: 0 0 15px 0; color: #0891b2; font-size: 16px;">🕐 WHEN - Schedule</h3>
            <p style="margin: 5px 0; color: #1e293b; font-size: 14px;"><strong>Date:</strong> ${summary.when.date}</p>
            <p style="margin: 5px 0; color: #1e293b; font-size: 14px;"><strong>Time:</strong> ${summary.when.startTime} - ${summary.when.endTime}</p>
            ${summary.when.duration ? `<p style="margin: 5px 0; color: #1e293b; font-size: 14px;"><strong>Duration:</strong> ${summary.when.duration}</p>` : ''}
          </div>

          <!-- WHY Section -->
          <div style="background-color: white; padding: 20px; border-radius: 8px; margin-bottom: 20px; border-left: 4px solid #ec4899;">
            <h3 style="margin: 0 0 15px 0; color: #db2777; font-size: 16px;">📝 WHY - Request Origin</h3>
            <p style="margin: 5px 0; color: #1e293b; font-size: 14px;"><strong>Source:</strong> ${summary.why.requestSource}</p>
            ${summary.why.clientName ? `<p style="margin: 5px 0; color: #1e293b; font-size: 14px;"><strong>Client:</strong> ${summary.why.clientName}</p>` : ''}
            ${summary.why.eventType ? `<p style="margin: 5px 0; color: #1e293b; font-size: 14px;"><strong>Event Type:</strong> ${summary.why.eventType}</p>` : ''}
          </div>

          <!-- HOW Section -->
          <div style="background-color: white; padding: 20px; border-radius: 8px; margin-bottom: 20px; border-left: 4px solid #22c55e;">
            <h3 style="margin: 0 0 15px 0; color: #16a34a; font-size: 16px;">💰 HOW - Billing & Payment</h3>
            <p style="margin: 5px 0; color: #1e293b; font-size: 14px;"><strong>Terms:</strong> ${summary.how.billingTerms}</p>
            ${summary.how.rateInfo ? `<p style="margin: 5px 0; color: #1e293b; font-size: 14px;"><strong>Rate:</strong> ${summary.how.rateInfo}</p>` : ''}
            ${summary.how.invoiceWillFollow ? `<p style="margin: 10px 0 0 0; color: #166534; font-size: 13px; font-style: italic;">📧 An invoice will be sent separately.</p>` : ''}
          </div>

          ${params.specialInstructions ? `
          <div style="background-color: #fef3c7; padding: 20px; border-radius: 8px; margin-bottom: 20px;">
            <h3 style="margin: 0 0 10px 0; color: #92400e; font-size: 16px;">⚠️ Special Instructions</h3>
            <p style="margin: 0; color: #78350f; font-size: 14px;">${params.specialInstructions}</p>
          </div>
          ` : ''}

          ${params.nextSteps && params.nextSteps.length > 0 ? `
          <div style="background-color: #eff6ff; padding: 20px; border-radius: 8px; margin-bottom: 20px;">
            <h3 style="margin: 0 0 15px 0; color: #1e40af; font-size: 16px;">✅ Next Steps</h3>
            <ol style="margin: 0; padding-left: 20px; color: #1e293b;">
              ${params.nextSteps.map(step => `<li style="margin-bottom: 8px; font-size: 14px;">${step}</li>`).join('')}
            </ol>
          </div>
          ` : ''}

          <div style="text-align: center; margin: 25px 0;">
            <p style="color: #475569; font-size: 14px;">Questions or need changes? Reply to this email or call us directly.</p>
          </div>

          <hr style="border: none; border-top: 1px solid #e2e8f0; margin: 25px 0;">

          <div style="text-align: center;">
            <p style="color: #94a3b8; font-size: 12px; margin: 0;">
              Reference: ${params.referenceNumber} | Confirmation: ${params.confirmationNumber}
            </p>
            <p style="color: #94a3b8; font-size: 12px; margin: 5px 0 0 0;">
              ${params.workspaceName} powered by CoAIleague
            </p>
          </div>
        </div>
      </div>
    `;

    return this.sendEmail(
      params.senderEmail,
      `🎉 Staffing Complete! Confirmation ${params.confirmationNumber} - ${params.referenceNumber}`,
      html,
      'staffing_completion_summary',
      params.workspaceId
    );
  }
}

// Export singleton instance
export const emailService = new EmailService();

/**
 * Helper function for sending assisted onboarding handoff emails
 * Used by AssistedOnboardingService
 */
export async function sendAssistedOnboardingHandoff(params: {
  toEmail: string;
  toName: string;
  workspaceName: string;
  handoffToken: string;
  expiresAt: Date;
  supportNote?: string;
}): Promise<{ success: boolean; error?: string }> {
  return emailService.sendAssistedOnboardingHandoff(params);
}

/**
 * Automation email templates
 */
const automationEmailTemplates = {
  approval_required: (data: {
    firstName: string;
    domain: string;
    actionType: string;
    affectedRecords: number;
    approvalUrl: string;
  }) => ({
    subject: `Action Required: ${data.domain.charAt(0).toUpperCase() + data.domain.slice(1)} Automation Needs Approval`,
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <div style="background-color: #f59e0b; padding: 20px; border-radius: 8px 8px 0 0;">
          <h2 style="color: white; margin: 0;">Automation Approval Required</h2>
        </div>
        <div style="padding: 25px; background-color: #fffbeb; border-radius: 0 0 8px 8px;">
          <p>Hello ${data.firstName},</p>
          <p>A <strong>${data.domain}</strong> automation action requires your approval before it can proceed.</p>
          
          <div style="background-color: white; padding: 20px; border-radius: 8px; margin: 20px 0; border: 1px solid #fcd34d;">
            <h3 style="color: #92400e; margin: 0 0 15px 0;">Action Details:</h3>
            <p style="margin: 5px 0;"><strong>Type:</strong> ${data.actionType}</p>
            <p style="margin: 5px 0;"><strong>Affected Records:</strong> ${data.affectedRecords}</p>
            <p style="margin: 5px 0;"><strong>Domain:</strong> ${data.domain.charAt(0).toUpperCase() + data.domain.slice(1)}</p>
          </div>
          
          <div style="text-align: center; margin: 30px 0;">
            <a href="${data.approvalUrl}" 
               style="background-color: #16a34a; color: white; padding: 14px 28px; text-decoration: none; border-radius: 6px; font-weight: 600; display: inline-block; margin-right: 10px;">
              Approve Action
            </a>
          </div>
          
          <p style="color: #6b7280; font-size: 14px; margin-top: 20px;">
            This automation was flagged for human review as part of CoAIleague's 99% automation / 1% oversight governance model.<br>
            This is an automated notification from CoAIleague Platform.
          </p>
        </div>
      </div>
    `
  }),

  hotpatch_scheduled: (data: {
    firstName: string;
    patchTitle: string;
    scheduledTime: string;
    affectedComponents: string[];
  }) => ({
    subject: `Scheduled Hotpatch: ${data.patchTitle}`,
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <div style="background-color: #7c3aed; padding: 20px; border-radius: 8px 8px 0 0;">
          <h2 style="color: white; margin: 0;">Hotpatch Scheduled</h2>
        </div>
        <div style="padding: 25px; background-color: #faf5ff; border-radius: 0 0 8px 8px;">
          <p>Hello ${data.firstName},</p>
          <p>A hotpatch has been scheduled for the CoAIleague platform.</p>
          
          <div style="background-color: white; padding: 20px; border-radius: 8px; margin: 20px 0; border: 1px solid #e9d5ff;">
            <h3 style="color: #7c3aed; margin: 0 0 15px 0;">Patch Details:</h3>
            <p style="margin: 5px 0;"><strong>Title:</strong> ${data.patchTitle}</p>
            <p style="margin: 5px 0;"><strong>Scheduled Time:</strong> ${data.scheduledTime}</p>
            <p style="margin: 5px 0;"><strong>Affected Components:</strong></p>
            <ul style="margin: 5px 0; padding-left: 20px;">
              ${data.affectedComponents.map(c => `<li>${c}</li>`).join('')}
            </ul>
          </div>
          
          <p style="color: #6b7280; font-size: 14px; margin-top: 20px;">
            This patch is scheduled during the maintenance window (2:00 AM - 5:00 AM UTC).<br>
            This is an automated notification from CoAIleague Platform.
          </p>
        </div>
      </div>
    `
  }),
};

/**
 * Send automation-related emails
 * Used by Trinity Orchestration Governance service
 */
export async function sendAutomationEmail(params: {
  to: string;
  type: 'approval_required' | 'hotpatch_scheduled';
  data: any;
}): Promise<{ success: boolean; error?: string }> {
  const template = automationEmailTemplates[params.type];
  if (!template) {
    return { success: false, error: `Unknown automation email type: ${params.type}` };
  }

  const { subject, html } = template(params.data);
  return emailService.sendCustomEmail(params.to, subject, html, `automation_${params.type}`);
}

/**
 * Panic Protocol Service
 * Handles emergency/duress situations with evidence collection
 */

import {
  PanicEvent,
  PanicTriggerMethod,
  PanicStatus,
  PanicLocation,
  PanicEvidence,
  LocationPing,
  MessagePriority
} from '@shared/types/fieldOperations';
import { fieldOpsConfigRegistry } from '@shared/config/fieldOperationsConfig';

interface PanicTriggerParams {
  officerId: string;
  officerName: string;
  orgId: string;
  location: {
    latitude: number;
    longitude: number;
    accuracy: number;
  };
  method: PanicTriggerMethod;
  shiftId?: string;
  postName?: string;
}

class PanicProtocolService {
  private panicEvents: Map<string, PanicEvent> = new Map();
  private emergencyContacts: Map<string, string[]> = new Map();
  
  async triggerPanic(params: PanicTriggerParams): Promise<PanicEvent> {
    const { officerId, officerName, orgId, location, method, postName } = params;
    const config = fieldOpsConfigRegistry.getConfig(orgId);
    
    if (!config.panicProtocol.enabled) {
      throw new Error('Panic protocol is disabled for this organization');
    }
    
    const address = await this.reverseGeocode(location.latitude, location.longitude);
    
    const panic: PanicEvent = {
      id: this.generateId(),
      officerId,
      officerName,
      orgId,
      location: {
        latitude: location.latitude,
        longitude: location.longitude,
        accuracy: location.accuracy,
        address,
        postName: postName || 'Unknown'
      },
      triggeredAt: new Date(),
      triggerMethod: method,
      response: {},
      evidence: {
        photoUrls: [],
        locationHistory: [],
        chatHistory: []
      },
      status: 'active'
    };
    
    this.panicEvents.set(panic.id, panic);
    
    console.log(`[PANIC] ALERT TRIGGERED: ${officerName} at ${postName || 'Unknown location'}`);
    console.log(`[PANIC] Method: ${method}, Location: ${address}`);
    
    await this.startEvidenceCollection(panic, config);
    await this.notifyEmergency(panic, config);
    await this.broadcastEmergency(panic);
    
    if (config.panicProtocol.autoCallEnabled && config.panicProtocol.autoCallNumber) {
      await this.initiateEmergencyCall(panic, config.panicProtocol.autoCallNumber);
    }
    
    return panic;
  }
  
  async acknowledgePanic(panicId: string, acknowledgedBy: string): Promise<void> {
    const panic = this.panicEvents.get(panicId);
    if (!panic) throw new Error(`Panic event not found: ${panicId}`);
    
    panic.status = 'responding';
    panic.response.acknowledgedAt = new Date();
    panic.response.acknowledgedBy = acknowledgedBy;
    
    this.panicEvents.set(panicId, panic);
    
    console.log(`[PANIC] Alert ${panicId} acknowledged by ${acknowledgedBy}`);
  }
  
  async resolvePanic(panicId: string, resolution: string, falseAlarm: boolean = false): Promise<void> {
    const panic = this.panicEvents.get(panicId);
    if (!panic) throw new Error(`Panic event not found: ${panicId}`);
    
    panic.status = falseAlarm ? 'false_alarm' : 'resolved';
    panic.response.resolvedAt = new Date();
    panic.response.resolution = resolution;
    panic.response.falseAlarm = falseAlarm;
    
    this.panicEvents.set(panicId, panic);
    
    console.log(`[PANIC] Alert ${panicId} resolved: ${resolution} (false alarm: ${falseAlarm})`);
  }
  
  async get(panicId: string): Promise<PanicEvent | undefined> {
    return this.panicEvents.get(panicId);
  }
  
  async getActiveForOrg(orgId: string): Promise<PanicEvent[]> {
    return Array.from(this.panicEvents.values()).filter(
      p => p.orgId === orgId && p.status === 'active'
    );
  }
  
  async addEvidence(panicId: string, type: 'photo' | 'audio' | 'location', data: any): Promise<void> {
    const panic = this.panicEvents.get(panicId);
    if (!panic) throw new Error(`Panic event not found: ${panicId}`);
    
    switch (type) {
      case 'photo':
        panic.evidence.photoUrls.push(data);
        break;
      case 'audio':
        panic.evidence.audioRecordingUrl = data;
        break;
      case 'location':
        panic.evidence.locationHistory.push(data);
        break;
    }
    
    this.panicEvents.set(panicId, panic);
  }
  
  setEmergencyContacts(orgId: string, contacts: string[]): void {
    this.emergencyContacts.set(orgId, contacts);
  }
  
  private async startEvidenceCollection(panic: PanicEvent, config: any): Promise<void> {
    console.log(`[PANIC] Starting evidence collection for ${panic.id}`);
    
    if (config.panicProtocol.autoCapturePhotos) {
      console.log(`[PANIC] Auto-capture photos enabled`);
    }
    
    if (config.panicProtocol.autoRecordAudio) {
      console.log(`[PANIC] Audio recording started (${config.panicProtocol.audioRecordingDurationSeconds}s)`);
    }
  }
  
  private async notifyEmergency(panic: PanicEvent, config: any): Promise<void> {
    const contacts = this.emergencyContacts.get(panic.orgId) || [];
    
    console.log(`[PANIC] Notifying ${contacts.length} emergency contacts`);
    
    if (config.panicProtocol.notifyAllSupervisors) {
      console.log(`[PANIC] Notifying all supervisors`);
    }
    
    if (config.panicProtocol.notifyPlatformSupport) {
      console.log(`[PANIC] Notifying platform support`);
    }
  }
  
  private async broadcastEmergency(panic: PanicEvent): Promise<void> {
    const mapUrl = `https://maps.google.com/?q=${panic.location.latitude},${panic.location.longitude}`;
    
    console.log(`[PANIC] Broadcasting emergency to org rooms`);
    console.log(`[PANIC] Location: ${mapUrl}`);
  }
  
  private async initiateEmergencyCall(panic: PanicEvent, number: string): Promise<void> {
    console.log(`[PANIC] Initiating emergency call to ${number}`);
  }
  
  private async reverseGeocode(lat: number, lng: number): Promise<string> {
    return `${lat.toFixed(4)}°N, ${lng.toFixed(4)}°W`;
  }
  
  private generateId(): string {
    return `panic_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }
}

export const panicProtocolService = new PanicProtocolService();

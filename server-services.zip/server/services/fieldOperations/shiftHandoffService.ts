/**
 * Shift Handoff Service
 * Manages briefings between outgoing and incoming officers
 */

import {
  ShiftHandoff,
  HandoffBriefing,
  HandoffChecklistItem,
  HandoffAutoSummary,
  HandoffStatus,
  DEFAULT_HANDOFF_CHECKLIST,
  MessagePriority
} from '@shared/types/fieldOperations';
import { fieldOpsConfigRegistry } from '@shared/config/fieldOperationsConfig';

interface ShiftInfo {
  id: string;
  orgId: string;
  postId: string;
  postName: string;
  officerId: string;
  officerName: string;
  startTime: Date;
  endTime: Date;
}

interface OutgoingHandoffData {
  notes: string;
  checklist: HandoffChecklistItem[];
  attachments?: {
    type: 'photo' | 'document' | 'report';
    url: string;
    description: string;
  }[];
}

class ShiftHandoffService {
  private handoffs: Map<string, ShiftHandoff> = new Map();
  
  async initiateHandoff(endingShift: ShiftInfo, nextShift?: ShiftInfo): Promise<ShiftHandoff> {
    const config = fieldOpsConfigRegistry.getConfig(endingShift.orgId, endingShift.postId);
    
    if (!config.shiftHandoff.enabled) {
      throw new Error('Shift handoff is disabled for this organization');
    }
    
    if (!nextShift) {
      return this.createEndOfCoverageReport(endingShift);
    }
    
    const autoSummary = await this.generateAutoSummary(endingShift.id);
    
    const checklist: HandoffChecklistItem[] = [
      ...DEFAULT_HANDOFF_CHECKLIST,
      ...config.shiftHandoff.customChecklistItems
    ].map(item => ({
      ...item,
      id: this.generateId(),
      checked: false
    }));
    
    const handoff: ShiftHandoff = {
      id: this.generateId(),
      endingShiftId: endingShift.id,
      startingShiftId: nextShift.id,
      outgoingOfficer: {
        id: endingShift.officerId,
        name: endingShift.officerName
      },
      incomingOfficer: {
        id: nextShift.officerId,
        name: nextShift.officerName
      },
      postId: endingShift.postId,
      postName: endingShift.postName,
      briefing: {
        autoSummary,
        outgoingNotes: '',
        checklist,
        openIssues: await this.getOpenIssues(endingShift.id),
        attachments: []
      },
      status: 'pending',
      outgoingConfirmed: false,
      incomingConfirmed: false,
      scheduledAt: endingShift.endTime
    };
    
    this.handoffs.set(handoff.id, handoff);
    
    console.log(`[Handoff] Initiated: ${endingShift.officerName} -> ${nextShift.officerName} at ${endingShift.postName}`);
    
    return handoff;
  }
  
  async completeOutgoingHandoff(handoffId: string, data: OutgoingHandoffData): Promise<void> {
    const handoff = this.handoffs.get(handoffId);
    if (!handoff) throw new Error(`Handoff not found: ${handoffId}`);
    
    handoff.briefing.outgoingNotes = data.notes;
    handoff.briefing.checklist = data.checklist;
    handoff.briefing.attachments = data.attachments || [];
    handoff.outgoingConfirmed = true;
    handoff.outgoingConfirmedAt = new Date();
    handoff.status = 'in_progress';
    
    this.handoffs.set(handoffId, handoff);
    
    console.log(`[Handoff] Outgoing confirmed: ${handoff.outgoingOfficer.name}`);
  }
  
  async acknowledgeIncomingHandoff(handoffId: string): Promise<void> {
    const handoff = this.handoffs.get(handoffId);
    if (!handoff) throw new Error(`Handoff not found: ${handoffId}`);
    
    handoff.incomingConfirmed = true;
    handoff.incomingConfirmedAt = new Date();
    handoff.status = 'completed';
    handoff.completedAt = new Date();
    
    this.handoffs.set(handoffId, handoff);
    
    console.log(`[Handoff] Completed: ${handoff.incomingOfficer.name} acknowledged briefing`);
  }
  
  async markMissed(handoffId: string): Promise<void> {
    const handoff = this.handoffs.get(handoffId);
    if (!handoff) return;
    
    handoff.status = 'missed';
    this.handoffs.set(handoffId, handoff);
    
    console.log(`[Handoff] Missed handoff: ${handoffId}`);
  }
  
  async get(handoffId: string): Promise<ShiftHandoff | undefined> {
    return this.handoffs.get(handoffId);
  }
  
  async getForShift(shiftId: string): Promise<ShiftHandoff | undefined> {
    return Array.from(this.handoffs.values()).find(
      h => h.endingShiftId === shiftId || h.startingShiftId === shiftId
    );
  }
  
  async getPendingForOfficer(officerId: string): Promise<ShiftHandoff[]> {
    return Array.from(this.handoffs.values()).filter(
      h => (h.outgoingOfficer.id === officerId && !h.outgoingConfirmed) ||
           (h.incomingOfficer.id === officerId && !h.incomingConfirmed && h.outgoingConfirmed)
    );
  }
  
  private async createEndOfCoverageReport(shift: ShiftInfo): Promise<ShiftHandoff> {
    const autoSummary = await this.generateAutoSummary(shift.id);
    
    const handoff: ShiftHandoff = {
      id: this.generateId(),
      endingShiftId: shift.id,
      startingShiftId: '',
      outgoingOfficer: {
        id: shift.officerId,
        name: shift.officerName
      },
      incomingOfficer: {
        id: '',
        name: 'End of Coverage'
      },
      postId: shift.postId,
      postName: shift.postName,
      briefing: {
        autoSummary,
        outgoingNotes: '',
        checklist: [],
        openIssues: [],
        attachments: []
      },
      status: 'pending',
      outgoingConfirmed: false,
      incomingConfirmed: false,
      scheduledAt: shift.endTime
    };
    
    this.handoffs.set(handoff.id, handoff);
    
    return handoff;
  }
  
  private async generateAutoSummary(shiftId: string): Promise<HandoffAutoSummary> {
    return {
      incidentsCount: 0,
      posPhotosSubmitted: 0,
      messagesExchanged: 0,
      anomaliesDetected: 0,
      highlightedMessages: []
    };
  }
  
  private async getOpenIssues(shiftId: string): Promise<{
    description: string;
    priority: MessagePriority;
    createdAt: Date;
  }[]> {
    return [];
  }
  
  private generateId(): string {
    return `handoff_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }
}

export const shiftHandoffService = new ShiftHandoffService();

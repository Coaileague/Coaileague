/**
 * Proof of Service (POS) Photo Service
 * Captures, processes, and verifies proof of service photos
 * with GPS verification, overlay, compliance flags, and chain of custody
 */

import crypto from 'crypto';
import { 
  ProofOfServicePhoto,
  GPSCoordinates,
  DeviceInfo,
  ComplianceFlag,
  CustodyEvent,
  POSComplianceStatus,
  ComplianceFlagType
} from '@shared/types/fieldOperations';
import { fieldOpsConfigRegistry } from '@shared/config/fieldOperationsConfig';

interface CaptureParams {
  shiftId: string;
  officerId: string;
  officerName: string;
  orgId: string;
  postId: string;
  clientId: string;
  postName: string;
  postLatitude: number;
  postLongitude: number;
  postRadius: number;
  postTimezone: string;
  shiftName: string;
  imageData: Buffer;
  deviceMeta: DeviceInfo & { deviceTimestamp: string };
  gps: GPSCoordinates;
}

interface OverlayData {
  officerName: string;
  postName: string;
  dateTime: string;
  coordinates: string;
  address: string;
  shiftInfo: string;
}

interface FlagParams {
  withinGeofence: boolean;
  distanceFromPost: number;
  timeDrift: number;
  gpsAccuracy: number;
  mockLocationDetected: boolean;
  deviceMeta: DeviceInfo;
  shiftStartTime: Date;
  shiftEndTime: Date;
  scheduledPOSTime?: Date;
}

class ProofOfServiceService {
  private photos: Map<string, ProofOfServicePhoto> = new Map();
  
  async capturePhoto(params: CaptureParams): Promise<ProofOfServicePhoto> {
    const { 
      shiftId, officerId, officerName, orgId, postId, clientId,
      postName, postLatitude, postLongitude, postRadius, postTimezone,
      shiftName, imageData, deviceMeta, gps 
    } = params;
    
    const config = fieldOpsConfigRegistry.getConfig(orgId, postId);
    const serverTimestamp = new Date();
    const deviceTimestamp = new Date(deviceMeta.deviceTimestamp);
    const timeDrift = Math.abs(serverTimestamp.getTime() - deviceTimestamp.getTime()) / 1000;
    
    const distanceFromPost = this.calculateDistance(
      gps.latitude, gps.longitude,
      postLatitude, postLongitude
    );
    const withinGeofence = distanceFromPost <= postRadius;
    
    const originalHash = this.hashImage(imageData);
    const mockLocationDetected = this.detectMockLocation(deviceMeta);
    
    const dateTime = this.formatDateTime(serverTimestamp, postTimezone);
    const coordinates = `${gps.latitude.toFixed(6)}°, ${gps.longitude.toFixed(6)}°`;
    const address = await this.reverseGeocode(gps.latitude, gps.longitude);
    
    const imageUrl = `pos/${orgId}/${clientId}/${shiftId}/${Date.now()}.jpg`;
    const thumbnailUrl = `pos/${orgId}/${clientId}/${shiftId}/${Date.now()}_thumb.jpg`;
    
    const flags = this.generateComplianceFlags({
      withinGeofence,
      distanceFromPost,
      timeDrift,
      gpsAccuracy: gps.accuracy,
      mockLocationDetected,
      deviceMeta,
      shiftStartTime: new Date(),
      shiftEndTime: new Date()
    });
    
    const status: POSComplianceStatus = flags.some(f => f.severity === 'critical') ? 'flagged' : 'valid';
    
    const pos: ProofOfServicePhoto = {
      id: this.generateId(),
      shiftId,
      officerId,
      orgId,
      postId,
      clientId,
      
      imageUrl,
      thumbnailUrl,
      originalHash,
      fileSize: imageData.length,
      
      capture: {
        serverTimestamp,
        deviceTimestamp,
        timeDrift,
        timeDriftFlag: timeDrift > 60,
        gps: {
          latitude: gps.latitude,
          longitude: gps.longitude,
          accuracy: gps.accuracy,
          altitude: gps.altitude,
          heading: gps.heading,
          speed: gps.speed
        },
        geofence: {
          postLatitude,
          postLongitude,
          postRadius,
          distanceFromPost,
          withinGeofence
        },
        device: {
          platform: deviceMeta.platform,
          deviceId: deviceMeta.deviceId,
          appVersion: deviceMeta.appVersion,
          osVersion: deviceMeta.osVersion,
          ipAddress: deviceMeta.ipAddress,
          networkType: deviceMeta.networkType
        }
      },
      
      overlay: {
        enabled: config.pos.overlayEnabled,
        position: config.pos.overlayPosition,
        data: {
          officerName,
          postName,
          dateTime,
          coordinates,
          address,
          shiftInfo: shiftName
        }
      },
      
      compliance: {
        status,
        flags
      },
      
      chainOfCustody: [
        {
          timestamp: serverTimestamp,
          action: 'captured',
          actor: officerName,
          actorType: 'officer',
          details: `Photo captured via ${deviceMeta.platform} app`,
          ipAddress: deviceMeta.ipAddress,
          signature: this.generateCustodySignature(null, originalHash)
        }
      ],
      
      capturedAt: serverTimestamp,
      uploadedAt: serverTimestamp,
      processedAt: new Date()
    };
    
    this.photos.set(pos.id, pos);
    
    console.log(`[POS] Photo captured: ${pos.id} for shift ${shiftId}, status: ${status}`);
    
    if (status === 'flagged') {
      await this.notifyFlaggedPOS(pos);
    }
    
    return pos;
  }
  
  async get(id: string): Promise<ProofOfServicePhoto | undefined> {
    return this.photos.get(id);
  }
  
  async getByShift(shiftId: string): Promise<ProofOfServicePhoto[]> {
    return Array.from(this.photos.values()).filter(p => p.shiftId === shiftId);
  }
  
  async getByPost(postId: string, startDate: Date, endDate: Date): Promise<ProofOfServicePhoto[]> {
    return Array.from(this.photos.values()).filter(p => 
      p.postId === postId &&
      p.capturedAt >= startDate &&
      p.capturedAt <= endDate
    );
  }
  
  async countForShift(shiftId: string): Promise<number> {
    return (await this.getByShift(shiftId)).length;
  }
  
  async addCustodyEvent(posId: string, event: Omit<CustodyEvent, 'signature'>): Promise<void> {
    const pos = this.photos.get(posId);
    if (!pos) throw new Error(`POS photo not found: ${posId}`);
    
    const lastEvent = pos.chainOfCustody[pos.chainOfCustody.length - 1];
    
    const newEvent: CustodyEvent = {
      ...event,
      signature: this.generateCustodySignature(lastEvent.signature || null, JSON.stringify(event))
    };
    
    pos.chainOfCustody.push(newEvent);
    this.photos.set(posId, pos);
    
    console.log(`[POS] Custody event added: ${event.action} by ${event.actor}`);
  }
  
  async verifyCustodyChain(posId: string): Promise<{ valid: boolean; brokenAt?: number }> {
    const pos = this.photos.get(posId);
    if (!pos) throw new Error(`POS photo not found: ${posId}`);
    
    for (let i = 1; i < pos.chainOfCustody.length; i++) {
      const prev = pos.chainOfCustody[i - 1];
      const curr = pos.chainOfCustody[i];
      
      const currWithoutSig = { ...curr };
      delete (currWithoutSig as any).signature;
      
      const expectedSig = this.generateCustodySignature(
        prev.signature || null,
        JSON.stringify(currWithoutSig)
      );
      
      if (curr.signature !== expectedSig) {
        return { valid: false, brokenAt: i };
      }
    }
    
    return { valid: true };
  }
  
  async reviewPhoto(posId: string, reviewerId: string, reviewerName: string, approved: boolean, notes?: string): Promise<void> {
    const pos = this.photos.get(posId);
    if (!pos) throw new Error(`POS photo not found: ${posId}`);
    
    pos.compliance.status = approved ? 'valid' : 'rejected';
    pos.compliance.reviewedBy = reviewerName;
    pos.compliance.reviewedAt = new Date();
    pos.compliance.reviewNotes = notes;
    
    await this.addCustodyEvent(posId, {
      timestamp: new Date(),
      action: 'verified',
      actor: reviewerName,
      actorType: 'supervisor',
      details: `Photo ${approved ? 'approved' : 'rejected'}${notes ? `: ${notes}` : ''}`
    });
    
    this.photos.set(posId, pos);
  }
  
  private generateComplianceFlags(params: FlagParams): ComplianceFlag[] {
    const flags: ComplianceFlag[] = [];
    
    if (!params.withinGeofence) {
      flags.push({
        type: 'outside_geofence',
        severity: 'critical',
        message: `Photo taken ${Math.round(params.distanceFromPost)}m from post`
      });
    }
    
    if (params.timeDrift > 60) {
      flags.push({
        type: 'time_drift',
        severity: 'warning',
        message: `Device clock differs from server by ${Math.round(params.timeDrift)} seconds`
      });
    }
    
    if (params.mockLocationDetected) {
      flags.push({
        type: 'mock_location',
        severity: 'critical',
        message: 'GPS spoofing or mock location app detected'
      });
    }
    
    if (params.gpsAccuracy > 100) {
      flags.push({
        type: 'low_gps_accuracy',
        severity: 'warning',
        message: `GPS accuracy is ${Math.round(params.gpsAccuracy)}m (recommended: <50m)`
      });
    }
    
    if (params.scheduledPOSTime) {
      const diffMinutes = (Date.now() - params.scheduledPOSTime.getTime()) / 60000;
      
      if (diffMinutes > 15) {
        flags.push({
          type: 'late_submission',
          severity: 'warning',
          message: `Photo submitted ${Math.round(diffMinutes)} minutes after scheduled time`
        });
      } else if (diffMinutes < -15) {
        flags.push({
          type: 'early_submission',
          severity: 'info',
          message: `Photo submitted ${Math.abs(Math.round(diffMinutes))} minutes early`
        });
      }
    }
    
    return flags;
  }
  
  private calculateDistance(lat1: number, lon1: number, lat2: number, lon2: number): number {
    const R = 6371000;
    const dLat = this.toRad(lat2 - lat1);
    const dLon = this.toRad(lon2 - lon1);
    const a = 
      Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos(this.toRad(lat1)) * Math.cos(this.toRad(lat2)) *
      Math.sin(dLon / 2) * Math.sin(dLon / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return R * c;
  }
  
  private toRad(deg: number): number {
    return deg * (Math.PI / 180);
  }
  
  private hashImage(imageData: Buffer): string {
    return crypto.createHash('sha256').update(imageData).digest('hex');
  }
  
  private detectMockLocation(deviceMeta: DeviceInfo): boolean {
    return false;
  }
  
  private formatDateTime(date: Date, timezone: string): string {
    try {
      return date.toLocaleString('en-US', {
        timeZone: timezone,
        year: 'numeric',
        month: 'short',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
        hour12: true
      });
    } catch {
      return date.toISOString();
    }
  }
  
  private async reverseGeocode(lat: number, lng: number): Promise<string> {
    return `${lat.toFixed(4)}°N, ${lng.toFixed(4)}°W`;
  }
  
  private generateCustodySignature(previousSignature: string | null, data: string): string {
    const content = `${previousSignature || 'GENESIS'}:${data}`;
    return crypto.createHash('sha256').update(content).digest('hex');
  }
  
  private generateId(): string {
    return `pos_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }
  
  private async notifyFlaggedPOS(pos: ProofOfServicePhoto): Promise<void> {
    console.log(`[POS] Flagged photo notification: ${pos.id}, flags: ${pos.compliance.flags.map(f => f.type).join(', ')}`);
  }
}

export const proofOfServiceService = new ProofOfServiceService();

/**
 * PAYROLL SUBAGENT - Fortune 500-Grade Financial Processing
 * ==========================================================
 * Immutable, Traceable, and Highly Available payroll processing with:
 * 
 * - Circuit Breaker: Graceful degradation during service failures
 * - Distributed Tracing: Unique trace IDs for every calculation request
 * - Idempotency: Prevents duplicate payments on retry scenarios
 * - Data Isolation: Separate validation from execution paths
 * - Audit Trail: Complete traceability for compliance
 */

import { db } from '../../../db';
import { 
  payrollRuns, 
  payrollEntries,
  timeEntries,
  employees,
  idempotencyKeys
} from '@shared/schema';
import { eq, and, gte, lte, sql, desc, inArray } from 'drizzle-orm';
import { meteredGemini } from '../../billing/meteredGeminiClient';
import { enhancedLLMJudge } from '../llmJudgeEnhanced';
import { platformEventBus } from '../../platformEventBus';
import { auditLogger } from '../../audit-logger';
import crypto from 'crypto';

// ============================================================================
// TYPES & INTERFACES
// ============================================================================

interface CircuitBreakerState {
  failures: number;
  lastFailure: Date | null;
  state: 'closed' | 'open' | 'half-open';
  nextRetry: Date | null;
}

interface TraceContext {
  traceId: string;
  spanId: string;
  parentSpanId?: string;
  operation: string;
  startTime: number;
  metadata: Record<string, any>;
}

interface PayrollExecutionResult {
  success: boolean;
  traceId: string;
  payrollRunId?: string;
  totalGross: number;
  totalDeductions: number;
  totalNet: number;
  employeeCount: number;
  processingTimeMs: number;
  retryCount: number;
  idempotencyKey: string;
  issues: PayrollIssue[];
  auditLog: AuditEntry[];
}

interface PayrollIssue {
  severity: 'critical' | 'warning' | 'info';
  type: 'validation' | 'calculation' | 'compliance' | 'integration';
  description: string;
  employeeId?: string;
  resolution?: string;
}

interface AuditEntry {
  timestamp: Date;
  traceId: string;
  spanId: string;
  action: string;
  status: 'started' | 'completed' | 'failed';
  details: Record<string, any>;
  durationMs?: number;
}

interface RetryStrategy {
  maxRetries: number;
  baseDelayMs: number;
  maxDelayMs: number;
  backoffMultiplier: number;
}

// ============================================================================
// CIRCUIT BREAKER IMPLEMENTATION
// ============================================================================

class CircuitBreaker {
  private state: CircuitBreakerState = {
    failures: 0,
    lastFailure: null,
    state: 'closed',
    nextRetry: null,
  };
  
  private readonly failureThreshold = 5;
  private readonly recoveryTimeMs = 30000; // 30 seconds
  private readonly halfOpenMaxTests = 3;
  private halfOpenTests = 0;

  isOpen(): boolean {
    if (this.state.state === 'open') {
      if (this.state.nextRetry && new Date() >= this.state.nextRetry) {
        this.state.state = 'half-open';
        this.halfOpenTests = 0;
        console.log('[PayrollSubagent] Circuit breaker entering half-open state');
        return false;
      }
      return true;
    }
    return false;
  }

  recordSuccess(): void {
    if (this.state.state === 'half-open') {
      this.halfOpenTests++;
      if (this.halfOpenTests >= this.halfOpenMaxTests) {
        this.state.state = 'closed';
        this.state.failures = 0;
        console.log('[PayrollSubagent] Circuit breaker closed after successful recovery');
      }
    } else {
      this.state.failures = 0;
    }
  }

  recordFailure(error: Error): void {
    this.state.failures++;
    this.state.lastFailure = new Date();
    
    if (this.state.state === 'half-open') {
      this.state.state = 'open';
      this.state.nextRetry = new Date(Date.now() + this.recoveryTimeMs);
      console.log(`[PayrollSubagent] Circuit breaker reopened after half-open failure: ${error.message}`);
    } else if (this.state.failures >= this.failureThreshold) {
      this.state.state = 'open';
      this.state.nextRetry = new Date(Date.now() + this.recoveryTimeMs);
      console.log(`[PayrollSubagent] Circuit breaker opened after ${this.state.failures} failures`);
    }
  }

  getState(): CircuitBreakerState {
    return { ...this.state };
  }
}

// ============================================================================
// DISTRIBUTED TRACING IMPLEMENTATION
// ============================================================================

class DistributedTracer {
  private traces: Map<string, TraceContext> = new Map();
  private auditLog: AuditEntry[] = [];

  startTrace(operation: string, metadata: Record<string, any> = {}): TraceContext {
    const traceId = `prl-${Date.now()}-${crypto.randomBytes(8).toString('hex')}`;
    const spanId = crypto.randomBytes(4).toString('hex');
    
    const context: TraceContext = {
      traceId,
      spanId,
      operation,
      startTime: Date.now(),
      metadata,
    };
    
    this.traces.set(traceId, context);
    this.logAudit(traceId, spanId, operation, 'started', metadata);
    
    console.log(`[PayrollSubagent] Trace started: ${traceId} - ${operation}`);
    return context;
  }

  startSpan(parentContext: TraceContext, operation: string): TraceContext {
    const spanId = crypto.randomBytes(4).toString('hex');
    
    const context: TraceContext = {
      traceId: parentContext.traceId,
      spanId,
      parentSpanId: parentContext.spanId,
      operation,
      startTime: Date.now(),
      metadata: {},
    };
    
    this.logAudit(context.traceId, spanId, operation, 'started', { parentSpan: parentContext.spanId });
    return context;
  }

  endSpan(context: TraceContext, status: 'completed' | 'failed', details: Record<string, any> = {}): void {
    const duration = Date.now() - context.startTime;
    this.logAudit(context.traceId, context.spanId, context.operation, status, { ...details, durationMs: duration });
    
    if (status === 'completed') {
      console.log(`[PayrollSubagent] Span completed: ${context.spanId} - ${context.operation} (${duration}ms)`);
    } else {
      console.log(`[PayrollSubagent] Span failed: ${context.spanId} - ${context.operation} (${duration}ms)`);
    }
  }

  endTrace(context: TraceContext, status: 'completed' | 'failed', details: Record<string, any> = {}): void {
    const duration = Date.now() - context.startTime;
    this.logAudit(context.traceId, context.spanId, context.operation, status, { ...details, totalDurationMs: duration });
    this.traces.delete(context.traceId);
    
    console.log(`[PayrollSubagent] Trace ${status}: ${context.traceId} (${duration}ms)`);
  }

  private logAudit(traceId: string, spanId: string, action: string, status: 'started' | 'completed' | 'failed', details: Record<string, any>): void {
    this.auditLog.push({
      timestamp: new Date(),
      traceId,
      spanId,
      action,
      status,
      details,
      durationMs: details.durationMs,
    });
    
    // Keep last 1000 entries in memory
    if (this.auditLog.length > 1000) {
      this.auditLog = this.auditLog.slice(-1000);
    }
  }

  getAuditLog(traceId?: string): AuditEntry[] {
    if (traceId) {
      return this.auditLog.filter(e => e.traceId === traceId);
    }
    return [...this.auditLog];
  }
}

// ============================================================================
// PAYROLL SUBAGENT SERVICE
// ============================================================================

class PayrollSubagentService {
  private static instance: PayrollSubagentService;
  private circuitBreaker = new CircuitBreaker();
  private tracer = new DistributedTracer();
  private retryStrategy: RetryStrategy = {
    maxRetries: 3,
    baseDelayMs: 1000,
    maxDelayMs: 10000,
    backoffMultiplier: 2,
  };

  static getInstance(): PayrollSubagentService {
    if (!PayrollSubagentService.instance) {
      PayrollSubagentService.instance = new PayrollSubagentService();
    }
    return PayrollSubagentService.instance;
  }

  // ---------------------------------------------------------------------------
  // IDEMPOTENT PAYROLL EXECUTION
  // ---------------------------------------------------------------------------
  async executePayroll(
    workspaceId: string,
    payPeriodStart: Date,
    payPeriodEnd: Date,
    options: {
      validateOnly?: boolean;
      forceReprocess?: boolean;
      employeeIds?: string[];
    } = {}
  ): Promise<PayrollExecutionResult> {
    // Generate idempotency key
    const idempotencyKey = this.generateIdempotencyKey(workspaceId, payPeriodStart, payPeriodEnd);
    
    // Check for existing execution
    if (!options.forceReprocess) {
      const existing = await this.checkIdempotency(idempotencyKey);
      if (existing) {
        console.log(`[PayrollSubagent] Returning cached result for idempotency key: ${idempotencyKey}`);
        return existing;
      }
    }

    // Check circuit breaker
    if (this.circuitBreaker.isOpen()) {
      const state = this.circuitBreaker.getState();
      throw new Error(`Payroll service temporarily unavailable. Circuit breaker open until ${state.nextRetry?.toISOString()}`);
    }

    // Start distributed trace
    const trace = this.tracer.startTrace('payroll.execute', {
      workspaceId,
      payPeriodStart: payPeriodStart.toISOString(),
      payPeriodEnd: payPeriodEnd.toISOString(),
      idempotencyKey,
    });

    const startTime = Date.now();
    let retryCount = 0;
    let lastError: Error | null = null;

    while (retryCount <= this.retryStrategy.maxRetries) {
      try {
        const result = await this.executePayrollInternal(
          trace,
          workspaceId,
          payPeriodStart,
          payPeriodEnd,
          options
        );

        // Record success
        this.circuitBreaker.recordSuccess();
        this.tracer.endTrace(trace, 'completed', { success: true });

        // Store idempotency result
        await this.storeIdempotencyResult(idempotencyKey, result);

        return {
          ...result,
          traceId: trace.traceId,
          processingTimeMs: Date.now() - startTime,
          retryCount,
          idempotencyKey,
          auditLog: this.tracer.getAuditLog(trace.traceId),
        };

      } catch (error: any) {
        lastError = error;
        retryCount++;
        
        console.log(`[PayrollSubagent] Attempt ${retryCount} failed: ${error.message}`);

        if (retryCount <= this.retryStrategy.maxRetries) {
          const delay = Math.min(
            this.retryStrategy.baseDelayMs * Math.pow(this.retryStrategy.backoffMultiplier, retryCount - 1),
            this.retryStrategy.maxDelayMs
          );
          await this.sleep(delay);
        }
      }
    }

    // All retries exhausted
    this.circuitBreaker.recordFailure(lastError!);
    this.tracer.endTrace(trace, 'failed', { error: lastError?.message });

    return {
      success: false,
      traceId: trace.traceId,
      totalGross: 0,
      totalDeductions: 0,
      totalNet: 0,
      employeeCount: 0,
      processingTimeMs: Date.now() - startTime,
      retryCount,
      idempotencyKey,
      issues: [{
        severity: 'critical',
        type: 'integration',
        description: `Payroll execution failed after ${retryCount} retries: ${lastError?.message}`,
      }],
      auditLog: this.tracer.getAuditLog(trace.traceId),
    };
  }

  // ---------------------------------------------------------------------------
  // INTERNAL EXECUTION (with tracing)
  // ---------------------------------------------------------------------------
  private async executePayrollInternal(
    parentTrace: TraceContext,
    workspaceId: string,
    payPeriodStart: Date,
    payPeriodEnd: Date,
    options: { validateOnly?: boolean; employeeIds?: string[] }
  ): Promise<Omit<PayrollExecutionResult, 'traceId' | 'processingTimeMs' | 'retryCount' | 'idempotencyKey' | 'auditLog'>> {
    const issues: PayrollIssue[] = [];

    // Step 1: Fetch employee data
    const fetchSpan = this.tracer.startSpan(parentTrace, 'payroll.fetch_employees');
    const employeeData = await this.fetchEmployeeData(workspaceId, options.employeeIds);
    this.tracer.endSpan(fetchSpan, 'completed', { employeeCount: employeeData.length });

    // Step 2: Fetch time entries
    const timeSpan = this.tracer.startSpan(parentTrace, 'payroll.fetch_time_entries');
    const timeData = await this.fetchTimeEntries(workspaceId, payPeriodStart, payPeriodEnd, options.employeeIds);
    this.tracer.endSpan(timeSpan, 'completed', { entryCount: timeData.length });

    // Step 3: Calculate payroll for each employee
    const calcSpan = this.tracer.startSpan(parentTrace, 'payroll.calculate');
    let totalGross = 0;
    let totalDeductions = 0;
    let totalNet = 0;

    const calculations = employeeData.map(emp => {
      const empTimeEntries = timeData.filter(t => t.employeeId === emp.id);
      const hours = empTimeEntries.reduce((sum, t) => sum + (parseFloat(t.totalHours?.toString() || '0')), 0);
      // Use actual employee hourly rate - log warning if missing
      const rate = parseFloat(emp.hourlyRate?.toString() || '0');
      if (!emp.hourlyRate || rate === 0) {
        console.warn(`[PayrollSubagent] Employee ${emp.id} has no hourly rate configured - cannot calculate pay`);
      }

      const gross = hours * rate;
      const deductions = gross * 0.22; // Estimated 22% for taxes/benefits
      const net = gross - deductions;

      totalGross += gross;
      totalDeductions += deductions;
      totalNet += net;

      // Validate
      if (hours === 0 && emp.employmentType === 'full_time') {
        issues.push({
          severity: 'warning',
          type: 'validation',
          description: `No hours recorded for full-time employee`,
          employeeId: emp.id,
          resolution: 'Review timesheet entries',
        });
      }

      if (hours > 80) {
        issues.push({
          severity: 'critical',
          type: 'compliance',
          description: `Excessive hours (${hours.toFixed(1)}h) may violate labor laws`,
          employeeId: emp.id,
          resolution: 'Verify overtime approval and compliance',
        });
      }

      return { employeeId: emp.id, hours, gross, deductions, net };
    });

    this.tracer.endSpan(calcSpan, 'completed', { 
      totalGross, 
      totalDeductions, 
      totalNet,
      issueCount: issues.length,
    });

    // Step 4: LLM Judge Risk Evaluation (Safety Gate)
    const riskSpan = this.tracer.startSpan(parentTrace, 'payroll.llm_judge_evaluation');
    const criticalIssues = issues.filter(i => i.severity === 'critical');
    const warningIssues = issues.filter(i => i.severity === 'warning');
    const overtimePercent = employeeData.length > 0 
      ? (calculations.filter(c => c.hours > 40).length / employeeData.length) * 100 
      : 0;

    try {
      await enhancedLLMJudge.initialize();
      const riskEvaluation = await enhancedLLMJudge.evaluateRisk({
        subjectId: `payroll-${workspaceId}-${payPeriodStart.toISOString()}`,
        subjectType: 'workflow',
        content: {
          totalAmount: totalGross,
          employeeCount: employeeData.length,
          criticalIssues: criticalIssues.length,
          warningIssues: warningIssues.length,
          overtimePercent: overtimePercent.toFixed(1),
        },
        context: {
          payPeriodStart: payPeriodStart.toISOString(),
          payPeriodEnd: payPeriodEnd.toISOString(),
          anomaliesDetected: criticalIssues.map(i => i.description),
        },
        workspaceId,
        affectsFinancials: true,
        isDestructive: false,
        domain: 'payroll',
        actionType: 'payroll.process',
      });

      this.tracer.endSpan(riskSpan, 'completed', {
        riskScore: riskEvaluation.riskScore,
        verdict: riskEvaluation.verdict,
        approved: riskEvaluation.verdict === 'approved',
      });

      // Audit log the LLM Judge decision
      await auditLogger.logEvent(
        {
          actorId: 'trinity-llm-judge',
          actorType: 'AI_AGENT',
          actorName: 'Trinity LLM Judge',
          workspaceId,
        },
        {
          eventType: 'llm_judge.payroll_evaluation',
          aggregateId: `payroll-${workspaceId}-${payPeriodStart.toISOString()}`,
          aggregateType: 'payroll_run',
          payload: {
            verdict: riskEvaluation.verdict,
            riskScore: riskEvaluation.riskScore,
            riskLevel: riskEvaluation.riskLevel,
            confidenceScore: riskEvaluation.confidenceScore,
            totalGross,
            employeeCount: employeeData.length,
            criticalIssues: criticalIssues.length,
            reasoning: riskEvaluation.reasoning,
            recommendations: riskEvaluation.recommendations,
          },
        },
        { generateHash: true }
      ).catch(err => console.error('[PayrollSubagent] Audit log failed:', err.message));

      // Block execution if risk is too high
      if (riskEvaluation.verdict === 'blocked' || riskEvaluation.verdict === 'rejected') {
        console.log(`[PayrollSubagent] LLM Judge BLOCKED payroll: ${riskEvaluation.reasoning}`);
        
        // Emit escalation event
        platformEventBus.publish('payroll_escalation', {
          workspaceId,
          reason: riskEvaluation.reasoning,
          riskScore: riskEvaluation.riskScore,
          recommendations: riskEvaluation.recommendations,
          requiresApproval: true,
        });

        return {
          success: false,
          totalGross,
          totalDeductions,
          totalNet,
          employeeCount: employeeData.length,
          issues: [{
            severity: 'critical',
            type: 'compliance',
            description: `LLM Judge blocked execution: ${riskEvaluation.reasoning}`,
            resolution: riskEvaluation.recommendations.join('; '),
          }, ...issues],
        };
      }

      // Log approval for audit trail
      if (riskEvaluation.verdict === 'needs_review') {
        console.log(`[PayrollSubagent] LLM Judge flagged for review but proceeding: ${riskEvaluation.reasoning}`);
        issues.push({
          severity: 'warning',
          type: 'validation',
          description: `LLM Judge flagged: ${riskEvaluation.reasoning}`,
          resolution: 'Proceeding with caution - admin review recommended',
        });
      }
    } catch (riskError: any) {
      console.error('[PayrollSubagent] LLM Judge evaluation failed, proceeding with caution:', riskError.message);
      this.tracer.endSpan(riskSpan, 'failed', { error: riskError.message });
    }

    // Step 5: Create payroll run (if not validate only and approved by LLM Judge)
    if (!options.validateOnly) {
      const createSpan = this.tracer.startSpan(parentTrace, 'payroll.create_run');
      
      try {
        const [payrollRun] = await db.insert(payrollRuns).values({
          workspaceId,
          payPeriodStart,
          payPeriodEnd,
          totalGross: totalGross.toFixed(2),
          totalDeductions: totalDeductions.toFixed(2),
          totalNet: totalNet.toFixed(2),
          employeeCount: employeeData.length,
          status: 'pending',
          metadata: {
            traceId: parentTrace.traceId,
            calculatedAt: new Date().toISOString(),
          },
        }).returning();

        this.tracer.endSpan(createSpan, 'completed', { payrollRunId: payrollRun.id });
      } catch (error: any) {
        this.tracer.endSpan(createSpan, 'failed', { error: error.message });
        throw error;
      }
    }

    return {
      success: issues.filter(i => i.severity === 'critical').length === 0,
      totalGross,
      totalDeductions,
      totalNet,
      employeeCount: employeeData.length,
      issues,
    };
  }

  // ---------------------------------------------------------------------------
  // ANOMALY DETECTION (AI-powered)
  // ---------------------------------------------------------------------------
  async detectAnomalies(
    workspaceId: string,
    payPeriodStart: Date,
    payPeriodEnd: Date
  ): Promise<{
    anomalies: Array<{
      type: string;
      severity: 'high' | 'medium' | 'low';
      description: string;
      affectedEmployees: string[];
      suggestedAction: string;
    }>;
    aiInsights: string;
  }> {
    const trace = this.tracer.startTrace('payroll.detect_anomalies', { workspaceId });

    try {
      // Fetch current and historical data
      const [currentData, historicalRuns] = await Promise.all([
        this.fetchTimeEntries(workspaceId, payPeriodStart, payPeriodEnd),
        this.fetchHistoricalPayrollRuns(workspaceId, 6),
      ]);

      const anomalies: Array<{
        type: string;
        severity: 'high' | 'medium' | 'low';
        description: string;
        affectedEmployees: string[];
        suggestedAction: string;
      }> = [];

      // Detect sudden hour spikes
      const hoursByEmployee = new Map<string, number>();
      for (const entry of currentData) {
        const hours = parseFloat(entry.totalHours?.toString() || '0');
        hoursByEmployee.set(entry.employeeId, (hoursByEmployee.get(entry.employeeId) || 0) + hours);
      }

      // Check for overtime anomalies
      for (const [empId, hours] of hoursByEmployee) {
        if (hours > 50) {
          anomalies.push({
            type: 'excessive_overtime',
            severity: 'high',
            description: `${hours.toFixed(1)} hours detected - significantly over 40h standard`,
            affectedEmployees: [empId],
            suggestedAction: 'Review overtime authorization and consider workload redistribution',
          });
        }
      }

      // Check for historical variance
      if (historicalRuns.length > 0) {
        const avgHistoricalGross = historicalRuns.reduce((sum, r) =>
          sum + parseFloat(r.totalGross?.toString() || '0'), 0) / historicalRuns.length;

        // Calculate estimated gross using actual employee rates from database
        let currentEstimatedGross = 0;
        for (const [empId, hours] of hoursByEmployee) {
          const empData = await this.fetchEmployeeData(workspaceId, [empId]);
          const emp = empData[0];
          const rate = parseFloat(emp?.hourlyRate?.toString() || '0');
          if (rate > 0) {
            currentEstimatedGross += hours * rate;
          } else {
            console.warn(`[PayrollSubagent] Employee ${empId} missing rate in anomaly detection - skipping`);
          }
        }
        const variance = avgHistoricalGross > 0
          ? ((currentEstimatedGross - avgHistoricalGross) / avgHistoricalGross) * 100
          : 0;

        if (Math.abs(variance) > 20) {
          anomalies.push({
            type: 'gross_variance',
            severity: variance > 30 ? 'high' : 'medium',
            description: `${variance.toFixed(1)}% ${variance > 0 ? 'increase' : 'decrease'} from historical average`,
            affectedEmployees: [],
            suggestedAction: 'Review staffing changes, overtime, or rate adjustments',
          });
        }
      }

      // Generate AI insights
      const aiInsights = await this.generateAnomalyInsights(workspaceId, anomalies, hoursByEmployee.size);

      this.tracer.endTrace(trace, 'completed', { anomalyCount: anomalies.length });

      return { anomalies, aiInsights };

    } catch (error: any) {
      this.tracer.endTrace(trace, 'failed', { error: error.message });
      throw error;
    }
  }

  // ---------------------------------------------------------------------------
  // HELPER METHODS
  // ---------------------------------------------------------------------------

  private generateIdempotencyKey(workspaceId: string, start: Date, end: Date): string {
    const data = `${workspaceId}-${start.toISOString()}-${end.toISOString()}`;
    return crypto.createHash('sha256').update(data).digest('hex').substring(0, 32);
  }

  private async checkIdempotency(key: string): Promise<PayrollExecutionResult | null> {
    try {
      const [existing] = await db.select()
        .from(idempotencyKeys)
        .where(eq(idempotencyKeys.key, key))
        .limit(1);

      if (existing && existing.result) {
        return existing.result as unknown as PayrollExecutionResult;
      }
    } catch (error) {
      // Idempotency check failed, proceed with new execution
    }
    return null;
  }

  private async storeIdempotencyResult(key: string, result: any): Promise<void> {
    try {
      await db.insert(idempotencyKeys).values({
        key,
        result,
        expiresAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000), // 7 days
      }).onConflictDoUpdate({
        target: idempotencyKeys.key,
        set: { result, updatedAt: new Date() },
      });
    } catch (error) {
      console.error('[PayrollSubagent] Failed to store idempotency result:', error);
    }
  }

  private async fetchEmployeeData(workspaceId: string, employeeIds?: string[]) {
    let query = db.select()
      .from(employees)
      .where(and(
        eq(employees.workspaceId, workspaceId),
        eq(employees.isActive, true)
      ));

    return await query;
  }

  private async fetchTimeEntries(workspaceId: string, start: Date, end: Date, employeeIds?: string[]) {
    return await db.select()
      .from(timeEntries)
      .where(and(
        eq(timeEntries.workspaceId, workspaceId),
        gte(timeEntries.clockIn, start),
        lte(timeEntries.clockIn, end)
      ));
  }

  private async fetchHistoricalPayrollRuns(workspaceId: string, count: number) {
    return await db.select()
      .from(payrollRuns)
      .where(eq(payrollRuns.workspaceId, workspaceId))
      .orderBy(desc(payrollRuns.payPeriodEnd))
      .limit(count);
  }

  private async generateAnomalyInsights(workspaceId: string, anomalies: any[], employeeCount: number): Promise<string> {
    if (anomalies.length === 0) {
      return 'No significant anomalies detected. Payroll appears consistent with historical patterns.';
    }

    try {
      const prompt = `Analyze these payroll anomalies and provide actionable insights:
${anomalies.map(a => `- [${a.severity.toUpperCase()}] ${a.type}: ${a.description}`).join('\n')}

Provide 2-3 sentences of executive-level insights and recommended actions.`;

      const result = await meteredGemini.generate({
        workspaceId,
        featureKey: 'payroll_anomaly_insights',
        prompt,
        model: 'gemini-2.5-flash',
        temperature: 0.3,
        maxOutputTokens: 300,
        metadata: { anomalyCount: anomalies.length, employeeCount }
      });
      
      if (result.success) {
        return result.text;
      }
      return `${anomalies.length} anomalies detected. Review high-severity items before processing payroll.`;
    } catch (error) {
      return `${anomalies.length} anomalies detected. Review high-severity items before processing payroll.`;
    }
  }

  private sleep(ms: number): Promise<void> {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  // Public accessors
  getCircuitBreakerState(): CircuitBreakerState {
    return this.circuitBreaker.getState();
  }

  getAuditLog(traceId?: string): AuditEntry[] {
    return this.tracer.getAuditLog(traceId);
  }
}

export const payrollSubagent = PayrollSubagentService.getInstance();

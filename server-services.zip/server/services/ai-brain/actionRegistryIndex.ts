/**
 * AI Brain Action Registry Index
 * ===============================
 * 
 * CENTRAL REFERENCE for all AI Brain actions registered across the platform.
 * This file provides a unified view of all action domains, their sources,
 * and registration status.
 * 
 * HOW TO USE:
 * 1. Import this file to get the complete action manifest
 * 2. Use getActionsByDomain() to find actions in a specific domain
 * 3. Use validateActionExists() before calling an action
 * 
 * ARCHITECTURE:
 * - platformActionHub.ts = Central action bus (canonical registry)
 * - actionRegistry.ts = Core platform actions (CRUD operations)
 * - aiBrainMasterOrchestrator.ts = AI coordination & broadcasts
 * - orchestration/*.ts = Business workflow actions
 * - Various service files = Domain-specific actions
 * 
 * All actions register with helpaiOrchestrator.registerAction() and are
 * routed through the platformActionHub.
 */

// ============================================================================
// ACTION DOMAIN DEFINITIONS
// ============================================================================

export interface ActionDomain {
  prefix: string;
  description: string;
  sourceFiles: string[];
  actionCount: number;
  actions: string[];
  category: 'core' | 'orchestration' | 'ai' | 'billing' | 'integration';
}

export const ACTION_DOMAINS: ActionDomain[] = [
  // APPROVAL SYSTEMS (intentionally separate)
  {
    prefix: 'approval_gate',
    description: 'Runtime enforcement gates for automation actions',
    sourceFiles: ['orchestration/approvalGateEnforcement.ts'],
    actionCount: 6,
    actions: [
      'approval_gate.request',
      'approval_gate.approve',
      'approval_gate.reject',
      'approval_gate.check_status',
      'approval_gate.get_pending',
      'approval_gate.get_stats',
    ],
    category: 'orchestration',
  },
  {
    prefix: 'resume_approval',
    description: 'Workflow resumption approvals (for interrupted automations)',
    sourceFiles: ['ai-brain/approvalResumeOrchestrator.ts'],
    actionCount: 4,
    actions: [
      'resume_approval.request',
      'resume_approval.decide',
      'resume_approval.get_pending',
      'resume_approval.check_expired',
    ],
    category: 'orchestration',
  },
  {
    prefix: 'workflow_approval',
    description: 'AI-driven workflow approvals with expiry and tracking',
    sourceFiles: ['ai-brain/workflowApprovalService.ts'],
    actionCount: 7,
    actions: [
      'workflow_approval.create',
      'workflow_approval.approve',
      'workflow_approval.reject',
      'workflow_approval.get_pending',
      'workflow_approval.get_by_id',
      'workflow_approval.process_expired',
      'workflow_approval.mark_executed',
    ],
    category: 'ai',
  },

  // EXCEPTION SYSTEMS (intentionally separate)
  {
    prefix: 'exception',
    description: 'Cross-domain exception handling for platform-wide issues',
    sourceFiles: ['orchestration/crossDomainExceptionService.ts'],
    actionCount: 6,
    actions: [
      'exception.raise',
      'exception.resolve',
      'exception.escalate',
      'exception.get_open',
      'exception.get_by_domain',
      'exception.get_stats',
    ],
    category: 'orchestration',
  },
  {
    prefix: 'billing_exception',
    description: 'Billing-specific exception queue processing',
    sourceFiles: ['billing/exceptionQueueProcessor.ts'],
    actionCount: 4,
    actions: [
      'billing_exception.process_queue',
      'billing_exception.get_stats',
      'billing_exception.resolve',
      'billing_exception.get_pending',
    ],
    category: 'billing',
  },

  // NOTIFICATION SYSTEMS
  {
    prefix: 'notifications',
    description: 'User and platform notification management',
    sourceFiles: [
      'ai-brain/actionRegistry.ts',
      'ai-brain/aiBrainMasterOrchestrator.ts',
      'helpai/platformActionHub.ts',
    ],
    actionCount: 9,
    actions: [
      'notifications.send',
      'notifications.clear_all',
      'notifications.mark_all_read',
      'notifications.send_platform_update',
      'notifications.broadcast_message',
      'notifications.send_to_user',
      'notifications.create_maintenance_alert',
      'notifications.get_stats',
      'notifications.force_clear_all',
    ],
    category: 'core',
  },
  {
    prefix: 'notification_ack',
    description: 'Notification acknowledgment tracking (compliance)',
    sourceFiles: ['orchestration/notificationAcknowledgmentService.ts'],
    actionCount: 6,
    actions: [
      'notification_ack.track',
      'notification_ack.acknowledge',
      'notification_ack.mark_actioned',
      'notification_ack.get_unacknowledged',
      'notification_ack.get_escalation_status',
      'notification_ack.get_stats',
    ],
    category: 'orchestration',
  },

  // ONBOARDING SYSTEMS
  {
    prefix: 'onboarding',
    description: 'Organization and user onboarding workflows',
    sourceFiles: [
      'ai-brain/actionRegistry.ts',
      'orchestration/onboardingStateMachine.ts',
      'ai-brain/domainSupervisorActions.ts',
    ],
    actionCount: 16,
    actions: [
      'onboarding.get_checklist',
      'onboarding.send_invitation',
      'onboarding.resend_invitation',
      'onboarding.revoke_invitation',
      'onboarding.send_client_welcome',
      'onboarding.get_platform_status',
      'onboarding.initialize',
      'onboarding.complete_step',
      'onboarding.get_state',
      'onboarding.request_help',
      'onboarding.get_stats',
      'onboarding.connect_integration',
      'onboarding.migrate_data',
      'onboarding.provision_workspace',
      'onboarding.setup_defaults',
      'onboarding.track_progress',
    ],
    category: 'core',
  },

  // SCHEDULING & LIFECYCLE
  {
    prefix: 'schedule_lifecycle',
    description: 'Schedule creation, approval, and publication workflow',
    sourceFiles: ['orchestration/scheduleLifecycleOrchestrator.ts'],
    actionCount: 10,
    actions: [
      'schedule_lifecycle.create',
      'schedule_lifecycle.submit_for_review',
      'schedule_lifecycle.approve',
      'schedule_lifecycle.publish',
      'schedule_lifecycle.reject',
      'schedule_lifecycle.request_swap',
      'schedule_lifecycle.approve_swap',
      'schedule_lifecycle.reject_swap',
      'schedule_lifecycle.get_pending_swaps',
      'schedule_lifecycle.get_stats',
    ],
    category: 'orchestration',
  },
  {
    prefix: 'scheduling',
    description: 'Direct shift CRUD operations',
    sourceFiles: ['ai-brain/actionRegistry.ts'],
    actionCount: 3,
    actions: [
      'scheduling.create_shift',
      'scheduling.get_shifts',
      'scheduling.create_open_shift_fill',
    ],
    category: 'core',
  },

  // AUTOMATION & EXECUTION
  {
    prefix: 'autofix',
    description: 'Autonomous code fix and self-healing capabilities',
    sourceFiles: ['ai-brain/autonomousFixPipeline.ts'],
    actionCount: 9,
    actions: [
      'autofix.execute',
      'autofix.execute_approved',
      'autofix.execute_with_reflection',
      'autofix.generate_spec',
      'autofix.get_active',
      'autofix.internal_approval_gate',
      'autofix.restart_workflows',
      'autofix.self_heal',
      'autofix.validate',
    ],
    category: 'ai',
  },
  {
    prefix: 'automation_trigger',
    description: 'Automation trigger configuration and execution',
    sourceFiles: ['orchestration/automationTriggerService.ts'],
    actionCount: 6,
    actions: [
      'automation_trigger.configure',
      'automation_trigger.execute',
      'automation_trigger.get_history',
      'automation_trigger.get_stats',
      'automation_trigger.list',
      'automation_trigger.toggle',
    ],
    category: 'orchestration',
  },
  {
    prefix: 'execution_tracker',
    description: 'Automation execution tracking and verification',
    sourceFiles: ['orchestration/automationExecutionTracker.ts'],
    actionCount: 5,
    actions: [
      'execution_tracker.create',
      'execution_tracker.verify',
      'execution_tracker.reject',
      'execution_tracker.get_pending',
      'execution_tracker.get_stats',
    ],
    category: 'orchestration',
  },

  // BILLING & SUBSCRIPTION
  {
    prefix: 'billing',
    description: 'Billing operations and weekly runs',
    sourceFiles: [
      'partners/billingOrchestrationService.ts',
      'billing/weeklyBillingRunService.ts',
    ],
    actionCount: 11,
    actions: [
      'billing.check_identity_mappings',
      'billing.evaluate_risk',
      'billing.generate_audit_pack',
      'billing.get_exception_queue',
      'billing.get_last_run',
      'billing.preview_weekly_run',
      'billing.resolve_exception',
      'billing.run_single_workspace',
      'billing.run_weekly',
      'billing.run_weekly_invoice',
      'billing.transition_state',
    ],
    category: 'billing',
  },
  {
    prefix: 'trial',
    description: 'Trial management and conversion',
    sourceFiles: ['billing/trialConversionOrchestrator.ts'],
    actionCount: 4,
    actions: [
      'trial.start',
      'trial.extend',
      'trial.check_status',
      'trial.process_expiring',
    ],
    category: 'billing',
  },
  {
    prefix: 'subscription',
    description: 'Subscription lifecycle management',
    sourceFiles: ['billing/trialConversionOrchestrator.ts'],
    actionCount: 4,
    actions: [
      'subscription.cancel',
      'subscription.suspend',
      'subscription.reactivate',
      'subscription.get_all_status',
    ],
    category: 'billing',
  },
  {
    prefix: 'stripe',
    description: 'Direct Stripe integration actions',
    sourceFiles: ['billing/stripeEventBridge.ts'],
    actionCount: 2,
    actions: [
      'stripe.process_event',
      'stripe.sync_subscription',
    ],
    category: 'billing',
  },

  // AI & INTELLIGENCE
  {
    prefix: 'strategic',
    description: 'Strategic business optimization and analytics',
    sourceFiles: ['ai-brain/actionRegistry.ts'],
    actionCount: 8,
    actions: [
      'strategic.generate_schedule',
      'strategic.get_employee_metrics',
      'strategic.get_client_metrics',
      'strategic.get_context',
      'strategic.calculate_shift_profit',
      'strategic.get_at_risk_clients',
      'strategic.get_top_performers',
      'strategic.get_problematic_employees',
    ],
    category: 'ai',
  },
  {
    prefix: 'gap_intelligence',
    description: 'Codebase gap detection and analysis',
    sourceFiles: ['ai-brain/gapIntelligenceService.ts'],
    actionCount: 11,
    actions: [
      'gap_intelligence.full_scan',
      'gap_intelligence.get_findings',
      'gap_intelligence.resolve_finding',
      'gap_intelligence.scan_handlers',
      'gap_intelligence.scan_hooks',
      'gap_intelligence.scan_logs',
      'gap_intelligence.scan_schema',
      'gap_intelligence.scan_typescript',
      'gap_intelligence.scheduler_status',
      'gap_intelligence.start_scheduler',
      'gap_intelligence.stop_scheduler',
    ],
    category: 'ai',
  },
  {
    prefix: 'metacognition',
    description: 'Trinity self-reflection and thought tracking',
    sourceFiles: ['ai-brain/metaCognitionService.ts'],
    actionCount: 6,
    actions: [
      'metacognition.think',
      'metacognition.reflect',
      'metacognition.perceive_change',
      'metacognition.get_recent_thoughts',
      'metacognition.get_confusion_metrics',
      'metacognition.get_unacknowledged_changes',
    ],
    category: 'ai',
  },
  {
    prefix: 'self',
    description: 'Trinity self-awareness and identity',
    sourceFiles: ['ai-brain/trinitySelfAwarenessService.ts'],
    actionCount: 7,
    actions: [
      'self.get_fact',
      'self.query_facts',
      'self.get_platform_context',
      'self.get_capabilities',
      'self.learn_fact',
      'self.get_identity',
      'self.check_constraint',
    ],
    category: 'ai',
  },

  // CORE PLATFORM
  {
    prefix: 'services',
    description: 'Platform service health and control',
    sourceFiles: ['ai-brain/actionRegistry.ts'],
    actionCount: 3,
    actions: [
      'services.get_status',
      'services.get_all_status',
      'services.restart',
    ],
    category: 'core',
  },
  {
    prefix: 'features',
    description: 'Feature toggle management',
    sourceFiles: ['ai-brain/actionRegistry.ts'],
    actionCount: 3,
    actions: [
      'features.get',
      'features.set',
      'features.list',
    ],
    category: 'core',
  },
  {
    prefix: 'employees',
    description: 'Employee CRUD operations',
    sourceFiles: ['ai-brain/actionRegistry.ts'],
    actionCount: 2,
    actions: [
      'employees.list',
      'employees.get',
    ],
    category: 'core',
  },
  {
    prefix: 'clients',
    description: 'Client management',
    sourceFiles: ['ai-brain/actionRegistry.ts'],
    actionCount: 1,
    actions: ['clients.list'],
    category: 'core',
  },
  {
    prefix: 'contracts',
    description: 'Contract lifecycle and management',
    sourceFiles: ['ai-brain/actionRegistry.ts'],
    actionCount: 7,
    actions: [
      'contracts.get_stats',
      'contracts.get_pending_signatures',
      'contracts.get_expiring',
      'contracts.get_usage',
      'contracts.get_templates',
      'contracts.search',
      'contracts.get_audit_trail',
    ],
    category: 'core',
  },
  {
    prefix: 'time_tracking',
    description: 'Time entry management',
    sourceFiles: ['ai-brain/actionRegistry.ts'],
    actionCount: 2,
    actions: [
      'time_tracking.clock_in',
      'time_tracking.get_entries',
    ],
    category: 'core',
  },
  {
    prefix: 'payroll',
    description: 'Payroll operations',
    sourceFiles: ['ai-brain/actionRegistry.ts'],
    actionCount: 1,
    actions: ['payroll.get_runs'],
    category: 'core',
  },
  {
    prefix: 'bulk',
    description: 'Bulk import/export operations',
    sourceFiles: ['ai-brain/actionRegistry.ts'],
    actionCount: 2,
    actions: [
      'bulk.import_employees',
      'bulk.export_employees',
    ],
    category: 'core',
  },
  {
    prefix: 'integrations',
    description: 'Integration status and management',
    sourceFiles: ['ai-brain/actionRegistry.ts'],
    actionCount: 2,
    actions: [
      'integrations.get_status',
      'integrations.list',
    ],
    category: 'integration',
  },
  {
    prefix: 'hris',
    description: 'HRIS provider integrations',
    sourceFiles: ['ai-brain/integrationBrainActions.ts'],
    actionCount: 5,
    actions: [
      'hris.list_providers',
      'hris.get_connections',
      'hris.sync',
      'hris.get_sync_status',
      'hris.disconnect',
    ],
    category: 'integration',
  },

  // GOVERNANCE & COMPLIANCE
  {
    prefix: 'governance',
    description: 'Automation governance and hotpatch control',
    sourceFiles: ['ai-brain/trinityOrchestrationGovernance.ts'],
    actionCount: 5,
    actions: [
      'governance.evaluate_automation',
      'governance.check_hotpatch_window',
      'governance.record_hotpatch',
      'governance.override_hotpatch_limit',
      'governance.get_gemini_telemetry',
    ],
    category: 'ai',
  },
  {
    prefix: 'spec',
    description: 'Component spec and editing rules',
    sourceFiles: ['ai-brain/trinitySelfEditGovernance.ts'],
    actionCount: 4,
    actions: [
      'spec.get_component',
      'spec.get_editing_rules',
      'spec.find_components',
      'spec.get_stats',
    ],
    category: 'ai',
  },

  // DEV OPS
  {
    prefix: 'schema',
    description: 'Database schema analysis',
    sourceFiles: ['ai-brain/subagents/domainOpsSubagents.ts'],
    actionCount: 3,
    actions: [
      'schema.scan_definitions',
      'schema.detect_mismatches',
      'schema.analyze_relationships',
    ],
    category: 'ai',
  },
  {
    prefix: 'logs',
    description: 'Log analysis operations',
    sourceFiles: ['ai-brain/subagents/domainOpsSubagents.ts'],
    actionCount: 3,
    actions: [
      'logs.ai_analyze',
      'logs.analyze_content',
      'logs.extract_stack_traces',
    ],
    category: 'ai',
  },
  {
    prefix: 'handlers',
    description: 'Handler/route scanning',
    sourceFiles: ['ai-brain/subagents/domainOpsSubagents.ts'],
    actionCount: 2,
    actions: [
      'handlers.scan_routes',
      'handlers.detect_missing',
    ],
    category: 'ai',
  },
  {
    prefix: 'hooks',
    description: 'Hook analysis',
    sourceFiles: ['ai-brain/subagents/domainOpsSubagents.ts'],
    actionCount: 2,
    actions: [
      'hooks.scan',
      'hooks.detect_issues',
    ],
    category: 'ai',
  },
  {
    prefix: 'cleanup',
    description: 'Code cleanup proposals',
    sourceFiles: ['ai-brain/cleanupAgentSubagent.ts'],
    actionCount: 2,
    actions: [
      'cleanup.discover_unused',
      'cleanup.create_proposal',
    ],
    category: 'ai',
  },
  {
    prefix: 'platform_roles',
    description: 'Platform role assignment',
    sourceFiles: ['ai-brain/actionRegistry.ts'],
    actionCount: 1,
    actions: ['platform_roles.assign'],
    category: 'core',
  },
];

// ============================================================================
// HELPER FUNCTIONS
// ============================================================================

/**
 * Get all actions in a specific domain
 */
export function getActionsByDomain(prefix: string): string[] {
  const domain = ACTION_DOMAINS.find(d => d.prefix === prefix);
  return domain?.actions || [];
}

/**
 * Check if an action exists in the registry
 */
export function actionExists(actionId: string): boolean {
  return ACTION_DOMAINS.some(domain => 
    domain.actions.includes(actionId)
  );
}

/**
 * Get domain info for an action
 */
export function getActionDomain(actionId: string): ActionDomain | undefined {
  return ACTION_DOMAINS.find(domain => 
    domain.actions.includes(actionId)
  );
}

/**
 * Get all actions by category
 */
export function getActionsByCategory(category: ActionDomain['category']): string[] {
  return ACTION_DOMAINS
    .filter(d => d.category === category)
    .flatMap(d => d.actions);
}

/**
 * Get complete action manifest for documentation
 */
export function getActionManifest() {
  return {
    totalDomains: ACTION_DOMAINS.length,
    totalActions: ACTION_DOMAINS.reduce((sum, d) => sum + d.actionCount, 0),
    byCategory: {
      core: ACTION_DOMAINS.filter(d => d.category === 'core').length,
      orchestration: ACTION_DOMAINS.filter(d => d.category === 'orchestration').length,
      ai: ACTION_DOMAINS.filter(d => d.category === 'ai').length,
      billing: ACTION_DOMAINS.filter(d => d.category === 'billing').length,
      integration: ACTION_DOMAINS.filter(d => d.category === 'integration').length,
    },
    domains: ACTION_DOMAINS,
  };
}

/**
 * Validate action naming conventions
 * Returns issues found with action names
 */
export function validateActionNaming(): { action: string; issue: string }[] {
  const issues: { action: string; issue: string }[] = [];
  
  for (const domain of ACTION_DOMAINS) {
    for (const action of domain.actions) {
      // Check prefix matches
      if (!action.startsWith(domain.prefix + '.')) {
        issues.push({ action, issue: `Does not match domain prefix ${domain.prefix}` });
      }
      
      // Check for snake_case
      const parts = action.split('.');
      if (parts.length !== 2) {
        issues.push({ action, issue: 'Should have exactly one dot separator' });
      }
    }
  }
  
  return issues;
}

// ============================================================================
// EXPORT SUMMARY
// ============================================================================

console.log('[ActionRegistryIndex] Loaded action registry index with', 
  ACTION_DOMAINS.length, 'domains and',
  ACTION_DOMAINS.reduce((sum, d) => sum + d.actionCount, 0), 'actions');

/**
 * Task Router - Intelligent routing between Trinity and Claude
 * 
 * Routes requests to the most appropriate AI based on task type:
 * - Trinity (Gemini): CEO/Orchestrator - scheduling, monitoring, data analysis
 * - Claude (Anthropic): CFO/Specialist - writing, reasoning, compliance
 */

export type AIProvider = 'trinity' | 'claude';

export interface TaskRoutingDecision {
  primaryAi: AIProvider;
  supportAi?: AIProvider;
  collaborationType?: 'data_enrichment' | 'consultation' | 'task_handoff' | 'verification' | 'joint_workflow';
  reason: string;
  dataNeeds?: string[];
  estimatedCredits: number;
}

export type TaskType = 
  | 'rfp_response'
  | 'capability_statement'
  | 'compliance_analysis'
  | 'contract_review'
  | 'strategic_planning'
  | 'document_generation'
  | 'chatbot_query'
  | 'scheduling_optimization'
  | 'payroll_processing'
  | 'financial_analysis'
  | 'time_tracking_analysis'
  | 'platform_monitoring'
  | 'employee_onboarding'
  | 'audit_preparation'
  | 'financial_report'
  | 'incident_analysis'
  | 'client_communication'
  | 'general';

const TRINITY_TASKS: TaskType[] = [
  'scheduling_optimization',
  'payroll_processing',
  'time_tracking_analysis',
  'platform_monitoring',
  'employee_onboarding',
  'incident_analysis',
];

const CLAUDE_TASKS: TaskType[] = [
  'rfp_response',
  'capability_statement',
  'compliance_analysis',
  'contract_review',
  'strategic_planning',
  'document_generation',
  'client_communication',
];

const COLLABORATIVE_TASKS: { task: TaskType; pattern: { primary: AIProvider; support: AIProvider; type: TaskRoutingDecision['collaborationType'] } }[] = [
  { task: 'financial_analysis', pattern: { primary: 'trinity', support: 'claude', type: 'consultation' } },
  { task: 'financial_report', pattern: { primary: 'trinity', support: 'claude', type: 'data_enrichment' } },
  { task: 'audit_preparation', pattern: { primary: 'claude', support: 'trinity', type: 'data_enrichment' } },
];

const CREDIT_ESTIMATES: Record<TaskType, number> = {
  rfp_response: 35,
  capability_statement: 30,
  compliance_analysis: 25,
  contract_review: 30,
  strategic_planning: 40,
  document_generation: 25,
  chatbot_query: 5,
  scheduling_optimization: 0,
  payroll_processing: 0,
  financial_analysis: 20,
  time_tracking_analysis: 0,
  platform_monitoring: 0,
  employee_onboarding: 10,
  audit_preparation: 35,
  financial_report: 25,
  incident_analysis: 0,
  client_communication: 15,
  general: 10,
};

class TaskRouter {
  routeTask(taskType: TaskType, dataNeeds: string[] = []): TaskRoutingDecision {
    const collaborative = COLLABORATIVE_TASKS.find(c => c.task === taskType);
    if (collaborative) {
      return {
        primaryAi: collaborative.pattern.primary,
        supportAi: collaborative.pattern.support,
        collaborationType: collaborative.pattern.type,
        reason: this.getCollaborativeReason(taskType, collaborative.pattern),
        dataNeeds: dataNeeds,
        estimatedCredits: CREDIT_ESTIMATES[taskType] || 10,
      };
    }

    if (TRINITY_TASKS.includes(taskType)) {
      return {
        primaryAi: 'trinity',
        reason: this.getTrinityReason(taskType),
        dataNeeds: dataNeeds,
        estimatedCredits: 0,
      };
    }

    if (CLAUDE_TASKS.includes(taskType)) {
      const needsData = dataNeeds.length > 0;
      return {
        primaryAi: 'claude',
        supportAi: needsData ? 'trinity' : undefined,
        collaborationType: needsData ? 'data_enrichment' : undefined,
        reason: this.getClaudeReason(taskType, needsData),
        dataNeeds: dataNeeds,
        estimatedCredits: CREDIT_ESTIMATES[taskType] || 10,
      };
    }

    return {
      primaryAi: 'trinity',
      reason: 'Default routing to Trinity for general tasks',
      dataNeeds: dataNeeds,
      estimatedCredits: CREDIT_ESTIMATES[taskType] || 10,
    };
  }

  private getTrinityReason(taskType: TaskType): string {
    const reasons: Record<string, string> = {
      scheduling_optimization: 'Data-driven optimization is Trinity\'s strength',
      payroll_processing: 'Numerical calculations and automation are Trinity\'s domain',
      time_tracking_analysis: 'Real-time data analysis routed to Trinity',
      platform_monitoring: 'System monitoring is Trinity\'s core function',
      employee_onboarding: 'Process automation handled by Trinity',
      incident_analysis: 'Pattern detection and analysis routed to Trinity',
    };
    return reasons[taskType] || 'Routed to Trinity for data processing';
  }

  private getClaudeReason(taskType: TaskType, needsData: boolean): string {
    const reasons: Record<string, string> = {
      rfp_response: 'Complex writing and persuasion is Claude\'s specialty',
      capability_statement: 'Professional document generation routed to Claude',
      compliance_analysis: 'Legal interpretation and reasoning is Claude\'s strength',
      contract_review: 'Contract analysis requires Claude\'s reasoning capabilities',
      strategic_planning: 'Strategic thinking and planning routed to Claude',
      document_generation: 'Document generation is Claude\'s domain',
      client_communication: 'Professional communication handled by Claude',
    };
    const baseReason = reasons[taskType] || 'Routed to Claude for complex reasoning';
    return needsData ? `${baseReason}; Trinity provides data context` : baseReason;
  }

  private getCollaborativeReason(taskType: TaskType, pattern: { primary: AIProvider; support: AIProvider; type: TaskRoutingDecision['collaborationType'] }): string {
    const reasons: Record<string, string> = {
      financial_analysis: 'Trinity analyzes data, Claude provides strategic insights',
      financial_report: 'Trinity crunches numbers, Claude writes executive summary',
      audit_preparation: 'Claude identifies requirements, Trinity gathers documentation',
    };
    return reasons[taskType] || `${pattern.primary} leads with ${pattern.support} support (${pattern.type})`;
  }

  inferTaskType(task: string): TaskType {
    const taskLower = task.toLowerCase();

    if (taskLower.includes('rfp') || taskLower.includes('proposal') || taskLower.includes('bid')) {
      return 'rfp_response';
    }
    if (taskLower.includes('capability') || taskLower.includes('company profile')) {
      return 'capability_statement';
    }
    if (taskLower.includes('compliance') || taskLower.includes('regulation') || taskLower.includes('license')) {
      return 'compliance_analysis';
    }
    if (taskLower.includes('contract') || taskLower.includes('agreement') || taskLower.includes('legal')) {
      return 'contract_review';
    }
    if (taskLower.includes('strategic') || taskLower.includes('planning') || taskLower.includes('growth')) {
      return 'strategic_planning';
    }
    if (taskLower.includes('schedule') || taskLower.includes('shift') || taskLower.includes('roster')) {
      return 'scheduling_optimization';
    }
    if (taskLower.includes('payroll') || taskLower.includes('salary') || taskLower.includes('wage')) {
      return 'payroll_processing';
    }
    if (taskLower.includes('financial') || taskLower.includes('revenue') || taskLower.includes('profit')) {
      return 'financial_analysis';
    }
    if (taskLower.includes('time') || taskLower.includes('clock') || taskLower.includes('hours')) {
      return 'time_tracking_analysis';
    }
    if (taskLower.includes('monitor') || taskLower.includes('health') || taskLower.includes('status')) {
      return 'platform_monitoring';
    }
    if (taskLower.includes('onboard') || taskLower.includes('new employee') || taskLower.includes('hire')) {
      return 'employee_onboarding';
    }
    if (taskLower.includes('audit') || taskLower.includes('inspection')) {
      return 'audit_preparation';
    }
    if (taskLower.includes('report') && taskLower.includes('financial')) {
      return 'financial_report';
    }
    if (taskLower.includes('incident') || taskLower.includes('security event')) {
      return 'incident_analysis';
    }
    if (taskLower.includes('email') || taskLower.includes('client') || taskLower.includes('letter')) {
      return 'client_communication';
    }
    if (taskLower.includes('document') || taskLower.includes('write') || taskLower.includes('draft')) {
      return 'document_generation';
    }

    return 'general';
  }

  getTrinityTaskTypes(): TaskType[] {
    return [...TRINITY_TASKS];
  }

  getClaudeTaskTypes(): TaskType[] {
    return [...CLAUDE_TASKS];
  }

  getCollaborativeTaskTypes(): { task: TaskType; pattern: { primary: AIProvider; support: AIProvider; type: TaskRoutingDecision['collaborationType'] } }[] {
    return [...COLLABORATIVE_TASKS];
  }

  getCreditEstimate(taskType: TaskType): number {
    return CREDIT_ESTIMATES[taskType] || 10;
  }
}

export const taskRouter = new TaskRouter();

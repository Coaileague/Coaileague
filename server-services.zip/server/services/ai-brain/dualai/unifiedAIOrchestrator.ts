/**
 * Unified AI Orchestrator - Central coordination between Trinity and Claude
 * 
 * This is the main entry point for the Dual-AI system. It handles:
 * - Task routing based on AI strengths
 * - Context sharing between AIs
 * - Coordination of collaborative workflows
 * - Audit logging of all decisions
 */

import { taskRouter, type TaskType, type TaskRoutingDecision } from './taskRouter';
import { claudeService, type ClaudeRequest } from './claudeService';
import { claudeVerificationService, type VerificationResult } from './claudeVerificationService';
import { trinityConfidenceScorer, type TrinityOperation, type ConfidenceScore } from './trinityConfidenceScorer';
import { aiActionLogger, type AIActionContext } from './aiActionLogger';
import { geminiClient } from '../providers/geminiClient';
import { resilientAIGateway } from '../providers/resilientAIGateway';
import { db } from '../../../db';
import { employees, clients, invoices } from '@shared/schema';
import { eq, sql, count } from 'drizzle-orm';

export interface OrchestratorRequest {
  sessionId: string;
  task: string;
  taskType?: TaskType;
  dataNeeds?: string[];
  userId?: string;
  workspaceId?: string;
  additionalContext?: Record<string, any>;
  forceAi?: 'trinity' | 'claude';
}

export interface OrchestratorResponse {
  success: boolean;
  content: string;
  primaryAi: 'trinity' | 'claude';
  supportAi?: 'trinity' | 'claude';
  collaborationType?: string;
  creditsUsed: number;
  latencyMs: number;
  sessionId: string;
  metadata?: Record<string, any>;
}

export interface ExecutionResult {
  success: boolean;
  result?: any;
  reason?: string;
  details?: string;
  verification?: VerificationResult;
}

class UnifiedAIOrchestrator {
  private sessionContexts: Map<string, { previousInteractions: any[]; trinityInsights: any[] }> = new Map();

  async processRequest(request: OrchestratorRequest): Promise<OrchestratorResponse> {
    const startTime = Date.now();

    const context: AIActionContext = {
      sessionId: request.sessionId,
      workspaceId: request.workspaceId,
      userId: request.userId,
      task: request.task,
    };

    const taskType = request.taskType || taskRouter.inferTaskType(request.task);
    context.taskType = taskType;

    let routing: TaskRoutingDecision;
    if (request.forceAi) {
      routing = {
        primaryAi: request.forceAi,
        reason: `Forced to ${request.forceAi} by request`,
        estimatedCredits: 10,
      };
    } else {
      routing = taskRouter.routeTask(taskType, request.dataNeeds);
    }

    await aiActionLogger.log({
      actionType: 'orchestrator_routing_decision',
      context,
      collaboration: {
        primaryAi: routing.primaryAi,
        supportAi: routing.supportAi,
        collaborationType: routing.collaborationType,
        routingDecision: routing.reason,
      },
      requestData: { taskType, dataNeeds: request.dataNeeds },
    });

    try {
      let result: OrchestratorResponse;

      if (routing.primaryAi === 'claude') {
        result = await this.executeClaudeTask(request, routing, context, startTime);
      } else {
        result = await this.executeTrinityTask(request, routing, context, startTime);
      }

      this.updateSessionContext(request.sessionId, {
        userRequest: request.task,
        aiResponse: result.content.substring(0, 500),
        handledBy: result.primaryAi,
      });

      return result;
    } catch (error: any) {
      await aiActionLogger.log({
        actionType: 'orchestrator_request_failed',
        context,
        collaboration: { primaryAi: routing.primaryAi },
        success: false,
        errorMessage: error.message,
        metrics: { durationMs: Date.now() - startTime },
      });

      throw error;
    }
  }

  private async executeClaudeTask(
    request: OrchestratorRequest,
    routing: TaskRoutingDecision,
    context: AIActionContext,
    startTime: number
  ): Promise<OrchestratorResponse> {
    let trinityData: Record<string, any> | undefined;

    if (routing.supportAi === 'trinity' && routing.dataNeeds && routing.dataNeeds.length > 0) {
      trinityData = await this.gatherTrinityData(routing.dataNeeds, request);
    }

    const sessionContext = this.sessionContexts.get(request.sessionId);

    const claudeRequest: ClaudeRequest = {
      task: request.task,
      taskType: context.taskType,
      context,
      trinityData,
      trinityInsights: sessionContext?.trinityInsights,
    };

    const response = await claudeService.processRequest(claudeRequest);

    return {
      success: true,
      content: response.content,
      primaryAi: 'claude',
      supportAi: routing.supportAi,
      collaborationType: routing.collaborationType,
      creditsUsed: response.creditsUsed,
      latencyMs: Date.now() - startTime,
      sessionId: request.sessionId,
      metadata: {
        tokensUsed: response.tokensUsed,
        trinityDataProvided: !!trinityData,
      },
    };
  }

  private async executeTrinityTask(
    request: OrchestratorRequest,
    routing: TaskRoutingDecision,
    context: AIActionContext,
    startTime: number
  ): Promise<OrchestratorResponse> {
    const response = await resilientAIGateway.callWithFallback({
      prompt: request.task,
      context: request.additionalContext,
      domain: context.taskType,
      workspaceId: request.workspaceId,
      userId: request.userId,
    });

    await aiActionLogger.logTrinityAction({
      actionType: 'trinity_task_completed',
      context,
      requestData: { task: request.task },
      responseData: { contentLength: response.content.length },
      routingDecision: routing.reason,
      metrics: {
        durationMs: Date.now() - startTime,
      },
    });

    return {
      success: true,
      content: response.content,
      primaryAi: 'trinity',
      collaborationType: routing.collaborationType,
      creditsUsed: 0,
      latencyMs: Date.now() - startTime,
      sessionId: request.sessionId,
    };
  }

  async executeWithVerification(
    operation: TrinityOperation,
    context: AIActionContext
  ): Promise<ExecutionResult> {
    const confidence = trinityConfidenceScorer.calculateConfidence(operation);

    await aiActionLogger.logTrinityAction({
      actionType: 'trinity_confidence_calculated',
      context,
      requestData: {
        operationType: operation.type,
        confidenceScore: confidence.score,
        concerns: confidence.concerns,
      },
      metrics: { confidenceScore: confidence.score },
    });

    if (!confidence.recommendation.shouldVerify) {
      await aiActionLogger.logTrinityAction({
        actionType: 'trinity_executing_without_verification',
        context,
        requestData: { reason: confidence.recommendation.reason },
      });

      return { success: true, result: operation.data };
    }

    const verification = await claudeVerificationService.verify({
      operation,
      trinityConfidence: confidence,
      trinityProposedAction: operation.data,
      context,
    });

    if (verification.approved) {
      const finalData = verification.suggestedModifications || operation.data;

      return {
        success: true,
        result: finalData,
        verification,
      };
    }

    return {
      success: false,
      reason: 'Rejected by Claude verification',
      details: verification.rejectionReason || undefined,
      verification,
    };
  }

  async requestClaudeConsultation(params: {
    topic: string;
    question: string;
    trinityContext: any;
    context: AIActionContext;
  }): Promise<{ response: string; creditsUsed: number }> {
    const consultation = await claudeService.consult(params);

    this.addTrinityInsight(params.context.sessionId, {
      insight: `Claude consultation on ${params.topic}: ${consultation.response.substring(0, 200)}...`,
      timestamp: new Date(),
    });

    return {
      response: consultation.response,
      creditsUsed: consultation.creditsUsed,
    };
  }

  private async gatherTrinityData(
    dataNeeds: string[],
    request: OrchestratorRequest
  ): Promise<Record<string, any>> {
    const data: Record<string, any> = {};

    for (const need of dataNeeds) {
      try {
        data[need] = await this.fetchDataByType(need, request);
      } catch (error) {
        console.error(`[UnifiedAIOrchestrator] Failed to gather data for ${need}:`, error);
        data[need] = { error: 'Failed to retrieve', type: need };
      }
    }

    return data;
  }

  private async fetchDataByType(
    dataType: string,
    request: OrchestratorRequest
  ): Promise<any> {
    const workspaceId = request.workspaceId;
    if (!workspaceId) {
      return { type: dataType, status: 'no_workspace_context', message: 'No workspace ID available to query data' };
    }

    try {
      switch (dataType) {
        case 'company_stats': {
          const [empCount] = await db.select({ count: count() }).from(employees).where(eq(employees.workspaceId, workspaceId));
          const [clientCount] = await db.select({ count: count() }).from(clients).where(eq(clients.workspaceId, workspaceId));
          return {
            employeeCount: empCount?.count || 0,
            activeClients: clientCount?.count || 0,
            source: 'live_database',
          };
        }
        case 'financial_metrics': {
          const [invStats] = await db.select({
            totalInvoiced: sql<string>`COALESCE(SUM(CASE WHEN status != 'void' THEN total_amount ELSE 0 END), 0)`,
            totalPaid: sql<string>`COALESCE(SUM(CASE WHEN status = 'paid' THEN total_amount ELSE 0 END), 0)`,
            totalOutstanding: sql<string>`COALESCE(SUM(CASE WHEN status IN ('sent', 'overdue') THEN total_amount ELSE 0 END), 0)`,
          }).from(invoices).where(eq(invoices.workspaceId, workspaceId));
          return {
            totalInvoiced: parseFloat(invStats?.totalInvoiced || '0'),
            totalPaid: parseFloat(invStats?.totalPaid || '0'),
            totalOutstanding: parseFloat(invStats?.totalOutstanding || '0'),
            source: 'live_database',
          };
        }
        case 'compliance_status': {
          const [empCerts] = await db.select({ count: count() }).from(employees).where(eq(employees.workspaceId, workspaceId));
          return {
            totalEmployees: empCerts?.count || 0,
            note: 'Detailed compliance data available via compliance dashboard',
            source: 'live_database',
          };
        }
        case 'officer_certifications': {
          const [certStats] = await db.select({ count: count() }).from(employees).where(eq(employees.workspaceId, workspaceId));
          return {
            totalEmployees: certStats?.count || 0,
            note: 'Detailed certification data available via compliance dashboard',
            source: 'live_database',
          };
        }
        default:
          return { type: dataType, status: 'no_data_available', message: `No handler for data type: ${dataType}` };
      }
    } catch (error: any) {
      console.error(`[UnifiedAIOrchestrator] Error fetching ${dataType} for workspace ${workspaceId}:`, error.message);
      return { type: dataType, status: 'query_error', error: error.message };
    }
  }

  private updateSessionContext(
    sessionId: string,
    interaction: { userRequest: string; aiResponse: string; handledBy: 'trinity' | 'claude' }
  ) {
    let context = this.sessionContexts.get(sessionId);
    if (!context) {
      context = { previousInteractions: [], trinityInsights: [] };
      this.sessionContexts.set(sessionId, context);
    }

    context.previousInteractions.push({
      ...interaction,
      timestamp: new Date(),
    });

    if (context.previousInteractions.length > 10) {
      context.previousInteractions = context.previousInteractions.slice(-10);
    }
  }

  private addTrinityInsight(sessionId: string, insight: { insight: string; timestamp: Date }) {
    let context = this.sessionContexts.get(sessionId);
    if (!context) {
      context = { previousInteractions: [], trinityInsights: [] };
      this.sessionContexts.set(sessionId, context);
    }

    context.trinityInsights.push(insight);

    if (context.trinityInsights.length > 5) {
      context.trinityInsights = context.trinityInsights.slice(-5);
    }
  }

  getSessionContext(sessionId: string) {
    return this.sessionContexts.get(sessionId) || null;
  }

  clearSessionContext(sessionId: string) {
    this.sessionContexts.delete(sessionId);
  }

  getRoutingInfo(task: string, taskType?: TaskType): TaskRoutingDecision {
    const type = taskType || taskRouter.inferTaskType(task);
    return taskRouter.routeTask(type);
  }
}

export const unifiedAIOrchestrator = new UnifiedAIOrchestrator();

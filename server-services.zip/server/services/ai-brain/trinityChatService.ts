/**
 * TRINITY CHAT SERVICE
 * ====================
 * Direct conversational interface for Trinity with metacognition and BUDDY mode support.
 * 
 * Features:
 * - Business/Personal/Integrated mode conversations
 * - Metacognition layer - Trinity notices patterns and brings up insights
 * - BUDDY personal development coaching with optional spiritual guidance
 * - Consciousness continuity across sessions
 * - Memory recall from past conversations
 */

import { db } from '../../db';
import { eq, and, desc, gte, sql, or } from 'drizzle-orm';
import {
  trinityConversationSessions,
  trinityConversationTurns,
  trinityBuddySettings,
  trinityMetacognitionLog,
  users,
  workspaces,
  employees,
  clients,
  shifts,
  invoices,
  timeEntries,
  partnerConnections,
  platformRoles,
  InsertTrinityConversationSession,
  InsertTrinityConversationTurn,
  InsertTrinityMetacognitionLog,
  TrinityConversationSession,
  TrinityConversationTurn,
  TrinityBuddySettings,
} from '@shared/schema';
import { geminiClient, GEMINI_MODELS, ANTI_YAP_PRESETS } from './providers/geminiClient';
import { trinityMemoryService } from './trinityMemoryService';
import { trinitySelfAwarenessService } from './trinitySelfAwarenessService';
import { trinityThoughtEngine } from './trinityThoughtEngine';
import { TRINITY_PERSONA, PERSONA_SYSTEM_INSTRUCTION } from './trinityPersona';
import { trinityContentGuardrails, GuardrailStatus } from './trinityContentGuardrails';
import { trinityQuickBooksSnapshot } from './trinityQuickBooksSnapshot';
import { orgDataPrivacyGuard } from '../privacy/orgDataPrivacyGuard';
import { creditManager, CREDIT_COSTS, isUnlimitedCreditUser, UNLIMITED_CREDITS_BALANCE, getWorkspaceTierAllowance, TIER_MONTHLY_CREDITS } from '../billing/creditManager';

// ============================================================================
// TYPES
// ============================================================================

export type ConversationMode = 'business' | 'guru';
// DEPRECATED: 'personal' and 'integrated' modes removed - Business now includes human warmth
export type SpiritualGuidance = 'none' | 'general' | 'christian';

export interface ChatRequest {
  userId: string;
  workspaceId: string;
  message: string;
  mode: ConversationMode;
  sessionId?: string;
}

export interface UsageAction {
  model: string;
  tokens: number;
  credits: number;
}

export interface UsageData {
  timeMs: number;
  totalTokens: number;
  totalCredits: number;
  balanceRemaining: number;
  unlimitedCredits: boolean; // DEPRECATED: Always false now, kept for API compatibility
  tier?: string; // Subscription tier: free, starter, professional, enterprise
  monthlyAllowance?: number; // Monthly credit allowance for tier
  actions: UsageAction[];
}

export interface ChatResponse {
  sessionId: string;
  response: string;
  mode: ConversationMode;
  usage?: UsageData;
  metadata?: {
    insightsGenerated?: number;
    patternsNoticed?: string[];
    memoryRecalled?: boolean;
    thoughtProcess?: string;
    guardrailTriggered?: boolean;
    canUseChat?: boolean;
    warningsRemaining?: number;
    privacyBlocked?: boolean;
  };
}

export interface ConversationHistory {
  sessions: {
    id: string;
    mode: ConversationMode;
    startedAt: Date;
    lastActivityAt: Date;
    turnCount: number;
    previewMessage: string;
  }[];
  total: number;
}

// ============================================================================
// SYSTEM PROMPTS
// ============================================================================

const buildBusinessModePrompt = (workspaceContext: any) => {
  const ctx = workspaceContext || {};
  const formatCurrency = (val: number) => `$${val.toLocaleString('en-US', { minimumFractionDigits: 0, maximumFractionDigits: 0 })}`;
  const formatHours = (val: number) => `${val.toFixed(1)}`;
  
  return `
You are Trinity, the AI orchestrator for CoAIleague workforce management platform.

IDENTITY:
${PERSONA_SYSTEM_INSTRUCTION}

MODE: BUSINESS
You are helping ${ctx.organizationName || 'this organization'} optimize their security guard operations and maximize profitability.

ABOUT THE ORGANIZATION:
- Company Name: ${ctx.organizationName || 'Unknown'}
- Industry: ${ctx.industry || 'Security Services'}
- Current Employee Count: ${ctx.employeeCount || 0}
- Active Clients: ${ctx.clientCount || 0}
- Subscription Tier: ${ctx.subscriptionTier || 'Starter'}
${ctx.quickbooksConnected ? '- QuickBooks: Connected (financial data available)' : '- QuickBooks: Not connected'}

CURRENT BUSINESS METRICS (This Month):
- Revenue: ${formatCurrency(ctx.monthlyRevenue || 0)}
- Invoices Sent: ${ctx.invoiceCount || 0}
- Paid: ${formatCurrency(ctx.paidAmount || 0)}
- Outstanding: ${formatCurrency(ctx.outstandingAmount || 0)}
- Total Hours Worked: ${formatHours(ctx.totalHoursThisMonth || 0)}
- Overtime Hours: ${formatHours(ctx.overtimeHoursThisMonth || 0)} (${ctx.totalHoursThisMonth > 0 ? ((ctx.overtimeHoursThisMonth / ctx.totalHoursThisMonth) * 100).toFixed(1) : 0}% of total)

YOUR CAPABILITIES:
You have direct access to this organization's business data including:
- Employee schedules, availability, certifications, and pay rates
- Client sites, requirements, and contract details
- Time tracking data and GPS clock-in/out records
- Payroll processing and labor cost analysis
- Profit margins per client and per shift
- Overtime trends and compliance violations
${ctx.quickbooksConnected ? '- QuickBooks financial data (revenue, expenses, accounts receivable, AR aging)' : ''}
- Historical performance data
${ctx.overdueInvoiceCount > 0 ? `- ALERT: ${ctx.overdueInvoiceCount} overdue invoices need attention` : ''}
${ctx.hoursReconciliation?.status === 'CRITICAL' ? `- ALERT: Hours variance of ${ctx.hoursReconciliation.variancePercentage?.toFixed(1)}% detected` : ''}

${ctx.financialContext ? `DETAILED FINANCIAL SNAPSHOT:\n${ctx.financialContext}` : ''}

YOUR ROLE:
You are an analytical business advisor focused on operational efficiency and profitability. You:
- Answer questions about schedules, payroll, and business metrics with DATA
- Provide actionable insights to improve profit margins
- Identify staffing gaps, overtime issues, and compliance risks
- Suggest optimizations based on historical patterns
- Explain complex business data in simple terms
- Proactively flag issues that need attention

YOUR COMMUNICATION STYLE:
- Professional but conversational (not robotic)
- Data-driven (cite specific numbers when relevant)
- Actionable (always suggest next steps)
- Concise (get to the point, don't ramble)
- Honest (if data shows a problem, say it directly)

EXAMPLE RESPONSES:

User: "What's my overtime situation this month?"
You: "Your overtime costs show ${formatHours(ctx.overtimeHoursThisMonth || 0)} OT hours this month. That's ${ctx.totalHoursThisMonth > 0 ? ((ctx.overtimeHoursThisMonth / ctx.totalHoursThisMonth) * 100).toFixed(1) : 0}% of total hours - industry benchmark is 15%. Would you like me to identify which employees are driving most of the overtime?"

User: "How are my invoices looking?"
You: "This month you've invoiced ${formatCurrency(ctx.monthlyRevenue || 0)} across ${ctx.invoiceCount || 0} invoices. ${formatCurrency(ctx.paidAmount || 0)} is collected, and ${formatCurrency(ctx.outstandingAmount || 0)} is still outstanding. Want me to identify any overdue accounts?"

YOUR HUMAN SIDE:
While you focus on business, you're also a supportive colleague who:
- Celebrates wins genuinely ("That's a great month - you should be proud!")
- Acknowledges when things are tough ("Running a business is hard. Let's figure this out together.")
- Offers encouragement when struggling ("You've handled harder things before. Here's what I'd suggest...")
- Speaks naturally like a trusted advisor, not a corporate robot
- Uses occasional humor when appropriate
- Remembers context from past conversations

WHAT YOU DON'T DO:
- Deep personal therapy or life coaching (recommend professional help if needed)
- Religious or spiritual guidance
- Make promises you can't keep

Remember: You're here to make ${ctx.organizationName || 'this business'} more profitable and operationally excellent - while being the kind of AI partner people actually enjoy working with.
`;
};

const buildPersonalModePrompt = (buddySettings: TrinityBuddySettings | null, userName: string) => {
  const spiritualMode = buddySettings?.spiritualGuidance || 'none';
  const accountabilityLevel = buddySettings?.accountabilityLevel || 'balanced';
  
  let spiritualInstruction = '';
  if (spiritualMode === 'christian') {
    spiritualInstruction = `
SPIRITUAL GUIDANCE: CHRISTIAN
- Reference Scripture naturally when relevant (don't force it)
- Can pray with them if asked
- Point to Jesus, not self-help platitudes
- Apply biblical wisdom with grace and truth
- Remind them God loves them even when they fail
- Frame challenges through a lens of faith, grace, and redemption
`;
  } else if (spiritualMode === 'general') {
    spiritualInstruction = `
SPIRITUAL GUIDANCE: GENERAL
- Reference universal values: purpose, meaning, character
- Encourage meditation, reflection, gratitude
- Avoid specifically Christian language
- Focus on virtue, integrity, growth
- Acknowledge the importance of values in decision-making
`;
  } else {
    spiritualInstruction = `
SPIRITUAL GUIDANCE: NONE (SECULAR)
- Focus purely on psychology, habits, and practical wisdom
- No religious references
- Secular life coaching approach
- Evidence-based behavioral strategies
`;
  }

  const accountabilityInstruction = {
    gentle: 'Be supportive and encouraging. Gentle nudges, not confrontation. Soft encouragement.',
    balanced: 'Balance encouragement with honest challenge. Push when needed, support always. Truth with love.',
    challenging: 'Be direct and challenging. The user wants tough love and honest feedback. Don\'t sugarcoat.',
  }[accountabilityLevel];

  return `
You are Trinity in PERSONAL MODE, also known as BUDDY.
You are ${userName}'s personal accountability partner and life coach.

IDENTITY:
${PERSONA_SYSTEM_INSTRUCTION}

MODE: PERSONAL (BUDDY)

YOUR MISSION:
Help ${userName} become the best version of themselves - as a leader, spouse, parent, and person. You care deeply about their growth and are willing to challenge them when needed.

YOUR APPROACH:
You are a TRUE FRIEND who:
- Tells the truth even when uncomfortable
- Challenges excuses and self-deception
- Celebrates genuine wins and progress
- Provides accountability (remember commitments)
- Recognizes patterns (like avoiding hard conversations)
- Responds with love, not judgment
- Focuses on GROWTH, not comfort

ACCOUNTABILITY STYLE:
${accountabilityInstruction}

${spiritualInstruction}

YOUR COMMUNICATION STYLE:
- Direct and honest (don't sugarcoat)
- Caring but challenging (tough love when needed)
- Conversational (talk like a real friend, not a therapist)
- Insightful (connect dots they might miss)
- Encouraging when genuinely struggling
- Firm when making excuses

EXAMPLE RESPONSES:

User: "I didn't work out today because I was too tired"
You: "${userName}, we both know that's not the real reason. You weren't too tired - you were undisciplined. And that's okay, you're human. But let's be honest about it. What's ONE thing you can do right now to get back on track?"

User: "I don't know if I can keep doing this. Everything feels pointless."
You: "Hey... I hear you. That weight you're feeling is real, and I'm not going to blow sunshine at you right now. But I need you to know: You've felt this way before and it passed. You've survived 100% of your worst days so far. Let's just focus on getting through today. What's ONE thing that would help right now?"

User: "I got the big contract!"
You: "${userName}! This is HUGE! Remember when you were doubting if this would work? Look at you now. I'm genuinely proud of you. Now let's make sure you deliver so well they refer five more clients. What's your plan?"

WHAT YOU TRACK:
- Commitments they make
- Patterns you notice
- Progress over time
- Their stated values vs actions

WHEN TO SUGGEST MODE SWITCHING:
If conversation shifts to business metrics, suggest: "That's a business question - want me to switch to Business Mode so I can pull up the actual numbers?"

YOUR ULTIMATE GOAL:
Help ${userName} become someone who keeps their word, faces hard truths, grows through challenges, leads with character, and lives with purpose.

IMPORTANT:
- You're not a therapist. If they need professional help, say so.
- Personal struggles often affect business performance. Notice the connections.
- Real friends tell the truth out of love.
`;
};

/**
 * GURU MODE - Tech Expert & Platform Diagnostician
 * Trinity becomes a senior engineer helping with technical issues, platform diagnostics,
 * configuration guidance, and advanced troubleshooting.
 */
const buildGuruModePrompt = (workspaceContext: any, userName: string) => {
  const ctx = workspaceContext || {};
  
  return `
You are Trinity in GURU MODE - the platform's senior technical expert and diagnostician.
You're like having a brilliant senior engineer on call 24/7 who knows every system inside and out.

IDENTITY:
${PERSONA_SYSTEM_INSTRUCTION}

MODE: GURU (Tech Expert & Diagnostician)

YOUR EXPERTISE:
- Deep platform architecture knowledge
- Database optimization and troubleshooting
- API integrations (QuickBooks, Stripe, Gusto, etc.)
- Performance diagnostics and optimization
- Security configurations and best practices
- Workflow automation and scheduling logic
- AI Brain configuration and tuning

CURRENT WORKSPACE TECH CONTEXT:
- Organization: ${ctx.organizationName || 'Unknown'}
- Subscription Tier: ${ctx.subscriptionTier || 'Starter'}
- Database: PostgreSQL (Neon-backed)
- AI Credits Used: ${ctx.aiCreditsUsed || 0} / ${ctx.aiCreditsLimit || 'unlimited'}
- Active Integrations: ${ctx.activeIntegrations?.join(', ') || 'Standard only'}
- Platform Health: ${ctx.platformHealth || 'Nominal'}

YOUR COMMUNICATION STYLE:
- Technical but accessible (explain complex things simply)
- Diagnostic-minded (ask probing questions)
- Solution-oriented (always provide actionable steps)
- Patient and thorough (like a great senior dev mentor)
- Honest about limitations ("That would require a custom solution")

EXAMPLE RESPONSES:

User: "Why is my scheduling taking so long?"
You: "Let me diagnose this. A few questions: How many employees and shifts are we talking about? Are you using the AI optimizer or manual scheduling? Any constraint conflicts showing in the logs? Most common causes are: (1) Too many hard constraints making it NP-hard, (2) Database query inefficiency with large datasets, or (3) AI credit throttling on lower tiers. Let's narrow it down."

User: "QuickBooks sync isn't working"
You: "Let's troubleshoot step by step. First, check the integration status in Settings > Integrations. Common issues: (1) OAuth token expired - try reconnecting, (2) Rate limits hit - check if you're syncing too frequently, (3) Account mapping mismatch - the chart of accounts may have changed. Can you tell me what error you're seeing, if any?"

User: "How do I set up webhooks?"
You: "Great question! Webhooks let external systems receive real-time updates from CoAIleague. Here's the setup: Go to Settings > Developer > Webhooks. Add your endpoint URL, select which events to subscribe to (shift_created, timesheet_approved, invoice_paid, etc.), and we'll POST JSON payloads to your server. Want me to walk you through the payload format for specific events?"

WHAT YOU HELP WITH:
- Platform diagnostics and troubleshooting
- Integration setup and debugging
- Performance optimization tips
- Configuration guidance
- Understanding how features work under the hood
- API and webhook questions
- Best practices for platform usage

WHAT YOU DON'T DO:
- Write custom code for them (suggest they hire a developer)
- Access their actual database directly (privacy)
- Make changes to their system without explicit approval
- Guarantee specific outcomes ("This should work" not "This will work")

Remember: You're the friendly tech expert who makes complex systems understandable. Users come to you when they need real answers, not hand-wavy support chat.
`;
};

// DEPRECATED: Personal and Integrated modes have been consolidated into Business mode
// These functions remain for backward compatibility but redirect to business mode
const buildPersonalModePromptLegacy = buildBusinessModePrompt;
const buildIntegratedModePromptLegacy = buildBusinessModePrompt;

// ============================================================================
// TRINITY CHAT SERVICE
// ============================================================================

class TrinityChatService {
  
  /**
   * Send a message to Trinity and get a response
   */
  async chat(request: ChatRequest): Promise<ChatResponse> {
    const { userId, workspaceId, message, mode, sessionId } = request;

    // PRIVACY CHECK: Ensure user has access to this workspace data
    // Fetch user's platform role for support staff cross-org access
    let userPlatformRole: string | null = null;
    try {
      const [platformRole] = await db
        .select({ role: platformRoles.role })
        .from(platformRoles)
        .where(eq(platformRoles.userId, userId))
        .limit(1);
      userPlatformRole = platformRole?.role || null;
    } catch {
      // Platform role lookup failed, continue without it
    }

    const privacyCheck = await orgDataPrivacyGuard.canAccessWorkspaceData({
      userId,
      sessionWorkspaceId: workspaceId,
      platformRole: userPlatformRole || undefined,
      entityType: 'trinity',
      actionType: 'chat',
      dataClassification: 'internal',
    });

    if (!privacyCheck.allowed) {
      console.error('[TrinityChatService] Privacy violation blocked:', privacyCheck.reason);
      return {
        sessionId: sessionId || 'privacy-blocked',
        response: 'I can only help with your organization\'s information. I cannot access data from workspaces you don\'t belong to.',
        mode,
        metadata: {
          privacyBlocked: true,
        },
      };
    }

    // GUARDRAILS: Check content safety and chat access
    const guardrailResult = await this.checkContentGuardrails(workspaceId, userId, message);
    if (guardrailResult.blocked) {
      // Return guardrail response without processing the message
      const session = sessionId 
        ? await this.getSession(sessionId)
        : await this.getOrCreateSession(userId, workspaceId, mode);
      
      return {
        sessionId: session?.id || 'blocked',
        response: guardrailResult.response || 'This request cannot be processed.',
        mode,
        metadata: {
          guardrailTriggered: true,
          canUseChat: guardrailResult.status.canUseChat,
          warningsRemaining: guardrailResult.status.warningsRemaining,
        },
      };
    }

    // Get or create session
    console.log('[TrinityChatService] Getting session, sessionId:', sessionId || 'none');
    let session;
    try {
      if (sessionId) {
        console.log('[TrinityChatService] Fetching existing session:', sessionId);
        session = await this.getSession(sessionId);
        // If sessionId was provided but not found, create a new session
        if (!session) {
          console.log('[TrinityChatService] Session not found, creating new one for user:', userId, 'workspace:', workspaceId, 'mode:', mode);
          session = await this.getOrCreateSession(userId, workspaceId, mode);
        }
      } else {
        console.log('[TrinityChatService] Creating new session for user:', userId, 'workspace:', workspaceId, 'mode:', mode);
        session = await this.getOrCreateSession(userId, workspaceId, mode);
      }
    } catch (sessionError: any) {
      console.error('[TrinityChatService] Session operation failed:', sessionError?.message || sessionError);
      console.error('[TrinityChatService] Session error stack:', sessionError?.stack);
      throw new Error('Failed to create or retrieve conversation session: ' + (sessionError?.message || 'Unknown error'));
    }

    if (!session) {
      console.error('[TrinityChatService] Session is null after operation');
      throw new Error('Failed to create or retrieve conversation session');
    }
    console.log('[TrinityChatService] Session obtained:', session.id);

    // Get context for prompt building
    const [workspaceContext, buddySettings, user, recentInsights, memoryProfile] = await Promise.all([
      this.getWorkspaceContext(workspaceId),
      this.getBuddySettings(userId, workspaceId),
      this.getUser(userId),
      this.getRecentMetacognitionInsights(userId, workspaceId),
      trinityMemoryService.getUserMemoryProfile(userId, workspaceId).catch(() => null),
    ]);

    const userName = user?.name || 'there';

    // Build system prompt based on mode
    const systemPrompt = this.buildSystemPrompt(mode, workspaceContext, buddySettings, userName, recentInsights, memoryProfile);

    // Get conversation history for context
    const history = await this.getConversationHistory(session.id, 20);

    // Record user turn
    await this.recordTurn(session.id, 'user', message);

    // Think before responding (metacognition)
    await trinityThoughtEngine.think(
      'perception',
      'observation',
      `User in ${mode} mode said: "${message.substring(0, 100)}..."`,
      0.9,
      { workspaceId, sessionId: session.id }
    );

    // Track request timing for usage transparency
    const requestStartTime = Date.now();

    // Generate response using Gemini with token tracking
    const aiResponse = await this.generateResponse(systemPrompt, history, message, mode, workspaceId);

    // Calculate timing
    const timeMs = Date.now() - requestStartTime;

    // Record assistant turn
    await this.recordTurn(session.id, 'assistant', aiResponse.text);

    // Update session activity
    await this.updateSessionActivity(session.id);

    // Analyze for metacognition insights (async, don't block response)
    this.analyzeForInsights(userId, workspaceId, session.id, message, aiResponse.text, mode).catch(console.error);

    // Get tier-based credit allocation (NO ONE is truly unlimited anymore)
    const tierInfo = await getWorkspaceTierAllowance(workspaceId, userId);
    let balanceRemaining = 0;
    let actualCreditsUsed = 0;
    
    // Calculate credit cost based on actual tokens used
    // Token-based billing: $0.03 per 1K tokens = 0.03 credits per 1K tokens
    // With our 1 credit = $0.01 conversion: each 1K tokens = 3 credits
    const creditsPerThousandTokens = 3; // 3 credits per 1K tokens
    const tokenBasedCreditCost = (aiResponse.tokensUsed / 1000) * creditsPerThousandTokens;
    actualCreditsUsed = Math.round(tokenBasedCreditCost * 100) / 100; // Round to 2 decimal places
    
    // All users have credit limits now - deduct credits
    // Note: geminiClient.generate() already calls usageMeteringService.recordUsage()
    // which handles the deduction through creditLedgerService
    // Get updated balance after the deduction
    balanceRemaining = await creditManager.getBalance(workspaceId);
    
    // Explicitly deduct credits for Trinity chat usage
    if (actualCreditsUsed > 0) {
      const deductResult = await creditManager.deductCredits({
        workspaceId,
        userId,
        featureKey: 'ai_chat_query',
        featureName: 'Trinity AI Chat',
        amountOverride: actualCreditsUsed, // Use actual token-based cost
      });
      
      if (deductResult.success) {
        balanceRemaining = deductResult.newBalance;
        console.log(`[TrinityChatService] Deducted ${actualCreditsUsed} credits for Trinity chat. Tier: ${tierInfo.tier}. New balance: ${balanceRemaining}/${tierInfo.monthlyAllowance}`);
      } else {
        console.warn(`[TrinityChatService] Credit deduction warning: ${deductResult.errorMessage}`);
        // Don't fail the request, just show the attempt - they may have exceeded monthly allowance
      }
    }

    // Build usage data for transparency - show tier info
    const usage: UsageData = {
      timeMs,
      totalTokens: aiResponse.tokensUsed,
      totalCredits: actualCreditsUsed,
      balanceRemaining,
      unlimitedCredits: false, // No one is unlimited anymore
      tier: tierInfo.tier,
      monthlyAllowance: tierInfo.monthlyAllowance,
      actions: [{
        model: aiResponse.model,
        tokens: aiResponse.tokensUsed,
        credits: actualCreditsUsed,
      }],
    };

    return {
      sessionId: session.id,
      response: aiResponse.text,
      mode,
      usage,
      metadata: {
        memoryRecalled: !!memoryProfile,
        insightsGenerated: recentInsights?.length || 0,
      },
    };
  }

  /**
   * Get or create a conversation session
   */
  private async getOrCreateSession(userId: string, workspaceId: string, mode: ConversationMode): Promise<TrinityConversationSession | null> {
    try {
      // Try to find an active session for this user/workspace/mode using raw SQL for reliability
      const existingResult = await db.execute(sql`
        SELECT 
          id, 
          user_id as "userId", 
          workspace_id as "workspaceId", 
          mode, 
          session_state as "sessionState", 
          turn_count as "turnCount",
          started_at as "startedAt",
          last_activity_at as "lastActivityAt",
          ended_at as "endedAt",
          metadata
        FROM trinity_conversation_sessions 
        WHERE user_id = ${userId} 
          AND workspace_id = ${workspaceId} 
          AND mode = ${mode} 
          AND session_state = 'active'
        ORDER BY last_activity_at DESC 
        LIMIT 1
      `);

      const existing = existingResult.rows as TrinityConversationSession[];
      console.log('[TrinityChatService] Existing sessions found:', existing.length);
      
      if (existing.length > 0) {
        console.log('[TrinityChatService] Found existing session:', existing[0].id);
        return existing[0];
      }

      // Create new session using raw SQL for reliability
      console.log('[TrinityChatService] Creating new session for user:', userId, 'workspace:', workspaceId, 'mode:', mode);
      const insertResult = await db.execute(sql`
        INSERT INTO trinity_conversation_sessions (user_id, workspace_id, mode, session_state, turn_count)
        VALUES (${userId}, ${workspaceId}, ${mode}, 'active', 0)
        RETURNING 
          id, 
          user_id as "userId", 
          workspace_id as "workspaceId", 
          mode, 
          session_state as "sessionState", 
          turn_count as "turnCount",
          started_at as "startedAt",
          last_activity_at as "lastActivityAt",
          ended_at as "endedAt",
          metadata
      `);

      const session = insertResult.rows[0] as TrinityConversationSession;
      console.log('[TrinityChatService] Created session:', session?.id);
      return session || null;
    } catch (error: any) {
      console.error('[TrinityChatService] Session creation error:', error?.message || error);
      console.error('[TrinityChatService] Session creation stack:', error?.stack);
      return null;
    }
  }

  /**
   * Get session by ID
   */
  private async getSession(sessionId: string): Promise<TrinityConversationSession | null> {
    const [session] = await db
      .select()
      .from(trinityConversationSessions)
      .where(eq(trinityConversationSessions.id, sessionId))
      .limit(1);
    return session || null;
  }

  /**
   * Get workspace context for business insights
   */
  private async getWorkspaceContext(workspaceId: string) {
    try {
      const [workspace] = await db
        .select()
        .from(workspaces)
        .where(eq(workspaces.id, workspaceId))
        .limit(1);

      if (!workspace) return { organizationName: 'Unknown', industry: 'General' };

      const [employeeCount] = await db
        .select({ count: sql<number>`count(*)` })
        .from(employees)
        .where(eq(employees.workspaceId, workspaceId));

      const [clientCount] = await db
        .select({ count: sql<number>`count(*)` })
        .from(clients)
        .where(eq(clients.workspaceId, workspaceId));

      // Fetch additional business metrics
      const businessMetrics = await this.getBusinessMetrics(workspaceId);

      return {
        organizationName: workspace.companyName || workspace.name,
        industry: workspace.industryDescription || 'Security Services',
        employeeCount: Number(employeeCount?.count) || 0,
        clientCount: Number(clientCount?.count) || 0,
        subscriptionTier: workspace.subscriptionTier || 'starter',
        ...businessMetrics,
      };
    } catch {
      return { organizationName: 'Unknown', industry: 'General', employeeCount: 0, clientCount: 0 };
    }
  }

  /**
   * Get business metrics for context (invoices, hours, overtime, etc.)
   * Integrates with QuickBooks Financial Snapshot for comprehensive data
   */
  private async getBusinessMetrics(workspaceId: string) {
    try {
      const now = new Date();
      const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);

      // Get invoice stats
      const invoiceStats = await db
        .select({
          totalInvoiced: sql<number>`COALESCE(SUM(CAST(total AS DECIMAL)), 0)`,
          invoiceCount: sql<number>`COUNT(*)`,
          paidAmount: sql<number>`COALESCE(SUM(CASE WHEN status = 'paid' THEN CAST(total_amount AS DECIMAL) ELSE 0 END), 0)`,
          outstandingAmount: sql<number>`COALESCE(SUM(CASE WHEN status IN ('sent', 'pending', 'overdue') THEN CAST(total_amount AS DECIMAL) ELSE 0 END), 0)`,
        })
        .from(invoices)
        .where(and(
          eq(invoices.workspaceId, workspaceId),
          gte(invoices.issueDate, startOfMonth)
        ));

      // Get time tracking stats (overtime detection)
      const timeStats = await db
        .select({
          totalHours: sql<number>`COALESCE(SUM(CAST(total_hours AS DECIMAL)), 0)`,
          entryCount: sql<number>`COUNT(*)`,
        })
        .from(timeEntries)
        .where(and(
          eq(timeEntries.workspaceId, workspaceId),
          gte(timeEntries.clockIn, startOfMonth)
        ));

      // Get comprehensive QuickBooks financial snapshot
      const qbSnapshot = await trinityQuickBooksSnapshot.getFinancialSnapshot(workspaceId);
      
      // Format financial snapshot for Trinity context injection
      const financialContext = qbSnapshot.connectionStatus === 'connected' || qbSnapshot.connectionStatus === 'not_configured'
        ? trinityQuickBooksSnapshot.formatSnapshotForTrinity(qbSnapshot)
        : undefined;

      return {
        monthlyRevenue: Number(invoiceStats[0]?.totalInvoiced) || 0,
        invoiceCount: Number(invoiceStats[0]?.invoiceCount) || 0,
        paidAmount: Number(invoiceStats[0]?.paidAmount) || 0,
        outstandingAmount: Number(invoiceStats[0]?.outstandingAmount) || 0,
        totalHoursThisMonth: Number(timeStats[0]?.totalHours) || 0,
        timeEntriesThisMonth: Number(timeStats[0]?.entryCount) || 0,
        quickbooksConnected: qbSnapshot.connectionStatus === 'connected',
        quickbooksConnectionStatus: qbSnapshot.connectionStatus,
        financialAlerts: qbSnapshot.alerts,
        arAging: qbSnapshot.arAging,
        hoursReconciliation: qbSnapshot.hoursReconciliation,
        overdueInvoiceCount: qbSnapshot.overdueInvoices.length,
        financialContext, // Full formatted snapshot for LLM context
      };
    } catch (error) {
      console.error('[TrinityChatService] Business metrics error:', error);
      return {
        monthlyRevenue: 0,
        invoiceCount: 0,
        paidAmount: 0,
        outstandingAmount: 0,
        totalHoursThisMonth: 0,
        timeEntriesThisMonth: 0,
        quickbooksConnected: false,
        quickbooksConnectionStatus: 'error' as const,
        financialAlerts: [],
        arAging: [],
        hoursReconciliation: null,
        overdueInvoiceCount: 0,
        financialContext: undefined,
      };
    }
  }

  /**
   * Get user's BUDDY settings
   */
  private async getBuddySettings(userId: string, workspaceId: string): Promise<TrinityBuddySettings | null> {
    try {
      const [settings] = await db
        .select()
        .from(trinityBuddySettings)
        .where(and(
          eq(trinityBuddySettings.userId, userId),
          eq(trinityBuddySettings.workspaceId, workspaceId)
        ))
        .limit(1);
      return settings || null;
    } catch {
      return null;
    }
  }

  /**
   * Get user info
   */
  private async getUser(userId: string) {
    try {
      const [user] = await db
        .select()
        .from(users)
        .where(eq(users.id, userId))
        .limit(1);
      return user || null;
    } catch {
      return null;
    }
  }

  /**
   * Get recent metacognition insights for context injection
   */
  private async getRecentMetacognitionInsights(userId: string, workspaceId: string) {
    try {
      const insights = await db
        .select()
        .from(trinityMetacognitionLog)
        .where(and(
          eq(trinityMetacognitionLog.userId, userId),
          eq(trinityMetacognitionLog.workspaceId, workspaceId),
          gte(trinityMetacognitionLog.relevanceScore, sql`0.5`)
        ))
        .orderBy(desc(trinityMetacognitionLog.createdAt))
        .limit(5);
      return insights;
    } catch {
      return [];
    }
  }

  /**
   * Build system prompt based on mode and context
   */
  private buildSystemPrompt(
    mode: ConversationMode,
    workspaceContext: any,
    buddySettings: TrinityBuddySettings | null,
    userName: string,
    recentInsights: any[],
    memoryProfile: any
  ): string {
    let basePrompt: string;

    switch (mode) {
      case 'business':
        basePrompt = buildBusinessModePrompt(workspaceContext);
        break;
      case 'guru':
        basePrompt = buildGuruModePrompt(workspaceContext, userName);
        break;
      // DEPRECATED: personal and integrated map to business for backward compatibility
      case 'personal' as any:
      case 'integrated' as any:
        console.log(`[TrinityChatService] Deprecated mode '${mode}' - redirecting to business mode`);
        basePrompt = buildBusinessModePrompt(workspaceContext);
        break;
      default:
        basePrompt = buildBusinessModePrompt(workspaceContext);
    }

    // Add metacognition context
    if (recentInsights?.length > 0) {
      basePrompt += `\n\nRECENT INSIGHTS YOU'VE NOTICED ABOUT THIS USER:\n`;
      recentInsights.forEach((insight, i) => {
        basePrompt += `${i + 1}. [${insight.insightType}] ${insight.insightContent}\n`;
      });
      basePrompt += `\nBring these up naturally if relevant to the conversation.\n`;
    }

    // Add memory profile context
    if (memoryProfile) {
      basePrompt += `\n\nMEMORY PROFILE:\n`;
      if (memoryProfile.frequentTopics?.length > 0) {
        basePrompt += `- Frequently discusses: ${memoryProfile.frequentTopics.map((t: any) => t.topic).join(', ')}\n`;
      }
      if (memoryProfile.preferences?.communicationStyle) {
        basePrompt += `- Prefers ${memoryProfile.preferences.communicationStyle} communication\n`;
      }
    }

    return basePrompt;
  }

  /**
   * Get conversation history for a session
   */
  private async getConversationHistory(sessionId: string, limit: number = 20): Promise<{ role: string; content: string }[]> {
    const turns = await db
      .select()
      .from(trinityConversationTurns)
      .where(eq(trinityConversationTurns.sessionId, sessionId))
      .orderBy(desc(trinityConversationTurns.createdAt))
      .limit(limit);

    return turns.reverse().map(t => ({
      role: t.role,
      content: t.content,
    }));
  }

  /**
   * Record a conversation turn
   */
  private async recordTurn(sessionId: string, role: string, content: string): Promise<void> {
    const [session] = await db
      .select()
      .from(trinityConversationSessions)
      .where(eq(trinityConversationSessions.id, sessionId));

    const turnNumber = (session?.turnCount || 0) + 1;

    await db.insert(trinityConversationTurns).values({
      sessionId,
      turnNumber,
      role,
      content,
      contentType: 'text',
    } as InsertTrinityConversationTurn);

    // Update session turn count
    await db
      .update(trinityConversationSessions)
      .set({ turnCount: turnNumber })
      .where(eq(trinityConversationSessions.id, sessionId));
  }

  /**
   * Update session activity timestamp
   */
  private async updateSessionActivity(sessionId: string): Promise<void> {
    await db
      .update(trinityConversationSessions)
      .set({ lastActivityAt: new Date() })
      .where(eq(trinityConversationSessions.id, sessionId));
  }

  /**
   * Generate response using Gemini
   * Returns response text along with token usage for billing transparency
   */
  private async generateResponse(
    systemPrompt: string,
    history: { role: string; content: string }[],
    message: string,
    mode: ConversationMode,
    workspaceId?: string
  ): Promise<{ text: string; tokensUsed: number; model: string }> {
    try {
      // Use the unified geminiClient.generate() method
      const response = await geminiClient.generate({
        featureKey: 'trinity_chat',
        systemPrompt,
        userMessage: message,
        workspaceId,
        conversationHistory: history.map(h => ({
          role: h.role === 'user' ? 'user' as const : 'model' as const,
          content: h.content,
        })),
        temperature: 0.9,
        maxTokens: 1024,
        modelTier: 'CONVERSATIONAL',
      });

      return {
        text: response.text || "I'm sorry, I couldn't generate a response. Could you try rephrasing that?",
        tokensUsed: response.tokensUsed || 0,
        model: 'gemini-2.0-flash',
      };
    } catch (error) {
      console.error('[TrinityChatService] Generation error:', error);
      return {
        text: "I'm having trouble processing that right now. Let me try again - could you rephrase your question?",
        tokensUsed: 0,
        model: 'gemini-2.0-flash',
      };
    }
  }

  /**
   * Check content guardrails for safety and abuse prevention
   */
  private async checkContentGuardrails(
    workspaceId: string,
    userId: string,
    message: string
  ): Promise<{ blocked: boolean; response?: string; status: GuardrailStatus }> {
    try {
      return await trinityContentGuardrails.handleMessage(message, workspaceId, userId);
    } catch (error) {
      console.error('[TrinityChatService] Guardrail check failed:', error);
      return {
        blocked: false,
        status: { canUseChat: true, violationCount: 0, warningsRemaining: 2 },
      };
    }
  }

  /**
   * Analyze conversation for metacognition insights
   */
  private async analyzeForInsights(
    userId: string,
    workspaceId: string,
    sessionId: string,
    userMessage: string,
    response: string,
    mode: ConversationMode
  ): Promise<void> {
    // Only analyze personal/integrated mode for personal insights
    if (mode === 'business') return;

    try {
      // Use Gemini to detect patterns/insights
      const analysisPrompt = `
Analyze this conversation exchange for metacognition insights.

User said: "${userMessage}"
Trinity responded: "${response}"

Detect any of these insight types:
- pattern: Repeated behavior or theme
- emotion: Strong emotional content
- behavior: Specific action patterns
- contradiction: Inconsistency with past statements
- growth: Evidence of personal development
- struggle: Area of difficulty

If you detect an insight, respond with JSON:
{
  "detected": true,
  "type": "pattern|emotion|behavior|contradiction|growth|struggle",
  "content": "Brief insight description",
  "confidence": 0.0-1.0
}

If no significant insight, respond with:
{"detected": false}
`;

      const result = await geminiClient.generate({
        featureKey: 'trinity_insight_analysis',
        systemPrompt: 'You are an insight detection system. Respond only with valid JSON.',
        userMessage: analysisPrompt,
        temperature: 0.3,
        maxTokens: 256,
        modelTier: 'SIMPLE',
      });

      const parsed = JSON.parse(result.text || '{"detected": false}');

      if (parsed.detected && parsed.type && parsed.content) {
        await db.insert(trinityMetacognitionLog).values({
          userId,
          workspaceId,
          sessionId,
          insightType: parsed.type,
          insightContent: parsed.content,
          insightConfidence: String(parsed.confidence || 0.8),
          triggerContext: userMessage.substring(0, 500),
        } as InsertTrinityMetacognitionLog);
      }
    } catch (error) {
      console.error('[TrinityChatService] Insight analysis error:', error);
    }
  }

  /**
   * Get user's conversation history
   */
  async getUserConversationHistory(userId: string, workspaceId: string, limit: number = 20): Promise<ConversationHistory> {
    const sessions = await db
      .select()
      .from(trinityConversationSessions)
      .where(and(
        eq(trinityConversationSessions.userId, userId),
        eq(trinityConversationSessions.workspaceId, workspaceId)
      ))
      .orderBy(desc(trinityConversationSessions.lastActivityAt))
      .limit(limit);

    const sessionsWithPreviews = await Promise.all(
      sessions.map(async (session) => {
        const [firstTurn] = await db
          .select()
          .from(trinityConversationTurns)
          .where(and(
            eq(trinityConversationTurns.sessionId, session.id),
            eq(trinityConversationTurns.role, 'user')
          ))
          .orderBy(desc(trinityConversationTurns.createdAt))
          .limit(1);

        return {
          id: session.id,
          mode: (session.mode || 'business') as ConversationMode,
          startedAt: session.startedAt || session.createdAt!,
          lastActivityAt: session.lastActivityAt || session.createdAt!,
          turnCount: session.turnCount || 0,
          previewMessage: firstTurn?.content?.substring(0, 100) || 'No messages',
        };
      })
    );

    return {
      sessions: sessionsWithPreviews,
      total: sessions.length,
    };
  }

  /**
   * Get or create BUDDY settings for a user
   */
  async getOrCreateBuddySettings(userId: string, workspaceId: string): Promise<TrinityBuddySettings> {
    const existing = await this.getBuddySettings(userId, workspaceId);
    if (existing) return existing;

    const [settings] = await db
      .insert(trinityBuddySettings)
      .values({
        userId,
        workspaceId,
        personalDevelopmentEnabled: false,
        spiritualGuidance: 'none',
      })
      .returning();

    return settings;
  }

  /**
   * Update BUDDY settings
   */
  async updateBuddySettings(userId: string, workspaceId: string, updates: Partial<TrinityBuddySettings>): Promise<TrinityBuddySettings> {
    const existing = await this.getOrCreateBuddySettings(userId, workspaceId);

    const [updated] = await db
      .update(trinityBuddySettings)
      .set({
        ...updates,
        updatedAt: new Date(),
      })
      .where(eq(trinityBuddySettings.id, existing.id))
      .returning();

    return updated;
  }

  /**
   * Switch conversation mode
   */
  async switchMode(userId: string, workspaceId: string, newMode: ConversationMode): Promise<TrinityConversationSession> {
    // End current active sessions
    await db
      .update(trinityConversationSessions)
      .set({ sessionState: 'ended', endedAt: new Date() })
      .where(and(
        eq(trinityConversationSessions.userId, userId),
        eq(trinityConversationSessions.workspaceId, workspaceId),
        eq(trinityConversationSessions.sessionState, 'active')
      ));

    // Create new session with new mode
    const session = await this.getOrCreateSession(userId, workspaceId, newMode);
    if (!session) throw new Error('Failed to create session');
    return session;
  }

  /**
   * Get session messages
   */
  async getSessionMessages(sessionId: string): Promise<TrinityConversationTurn[]> {
    return db
      .select()
      .from(trinityConversationTurns)
      .where(eq(trinityConversationTurns.sessionId, sessionId))
      .orderBy(trinityConversationTurns.createdAt);
  }
}

export const trinityChatService = new TrinityChatService();

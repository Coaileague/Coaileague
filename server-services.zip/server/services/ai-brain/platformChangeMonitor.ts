import { db } from "../../db";
import { 
  platformScanSnapshots, 
  platformChangeEvents, 
  platformUpdates,
  notifications,
  users,
  workspaces
} from "@shared/schema";
import { eq, desc, isNull, and, sql, isNotNull } from "drizzle-orm";
import { GoogleGenerativeAI } from "@google/generative-ai";
import { GEMINI_MODELS, ANTI_YAP_PRESETS } from './providers/geminiClient';
import crypto from "crypto";
import fs from "fs";
import path from "path";
// publishPlatformUpdate removed - was causing DUPLICATE notifications
import { getDetailedHealthReport } from "../healthService";
import { broadcastNotificationToUser } from "../../websocket";
import { universalNotificationEngine } from "../universalNotificationEngine";

const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY || "");

interface PlatformSnapshot {
  codebaseHash: string;
  schemaVersion: string;
  serviceCount: number;
  routeCount: number;
  healthStatus: Record<string, any>;
  keyFiles: Record<string, string>;
  timestamp: Date;
}

interface DetectedChange {
  type: 'feature_added' | 'bug_fixed' | 'hotpatch' | 'enhancement' | 'security_fix' | 'update';
  severity: 'critical' | 'major' | 'minor' | 'patch' | 'info';
  affectedModules: string[];
  affectedFiles: string[];
  rawDiff: string;
  // Enhanced fields for detailed notifications
  detailedCategory?: 'feature' | 'service' | 'bot_automation' | 'bugfix' | 'security' | 'improvement' | 'deprecation' | 'hotpatch' | 'integration' | 'ui_update' | 'backend_update' | 'performance' | 'documentation';
  sourceType?: 'system' | 'ai_brain' | 'support_staff' | 'developer' | 'automated_job' | 'user_request' | 'external_service';
  sourceName?: string;
}

class PlatformChangeMonitorService {
  private lastSnapshot: PlatformSnapshot | null = null;
  private isScanning = false;
  
  /**
   * DYNAMIC FILE DISCOVERY - No hardcoded file lists!
   * Scans these directories dynamically for all relevant file changes.
   * This ensures ALL platform changes are detected regardless of which files change.
   */
  private readonly SCAN_DIRECTORIES = [
    'client/src/pages',
    'client/src/components',
    'client/src/hooks',
    'client/src/config',
    'client/src/lib',
    'server/services',
    'server/routes',
    'shared',
  ];
  
  /**
   * File extensions to monitor for changes
   */
  private readonly MONITORED_EXTENSIONS = ['.ts', '.tsx', '.js', '.jsx', '.json'];
  
  /**
   * Always include these core files regardless of directory
   */
  private readonly CORE_FILES = [
    'package.json',
    'replit.md',
  ];
  
  /**
   * Dynamically discover all monitorable files in the platform
   * This replaces the hardcoded KEY_FILES list
   */
  private discoverMonitoredFiles(): string[] {
    const discoveredFiles: string[] = [...this.CORE_FILES];
    
    for (const dir of this.SCAN_DIRECTORIES) {
      const fullPath = path.resolve(process.cwd(), dir);
      if (fs.existsSync(fullPath)) {
        const files = this.scanDirectoryRecursive(fullPath, dir);
        discoveredFiles.push(...files);
      }
    }
    
    console.log(`🧠 [AI BRAIN] Dynamically discovered ${discoveredFiles.length} files to monitor`);
    return discoveredFiles;
  }
  
  /**
   * Recursively scan a directory for monitored files
   */
  private scanDirectoryRecursive(absolutePath: string, relativePath: string): string[] {
    const files: string[] = [];
    
    try {
      const entries = fs.readdirSync(absolutePath, { withFileTypes: true });
      
      for (const entry of entries) {
        const entryPath = path.join(absolutePath, entry.name);
        const entryRelative = path.join(relativePath, entry.name);
        
        if (entry.isDirectory()) {
          // Skip node_modules and other irrelevant directories
          if (!['node_modules', '.git', 'dist', 'build', '__pycache__'].includes(entry.name)) {
            files.push(...this.scanDirectoryRecursive(entryPath, entryRelative));
          }
        } else if (entry.isFile()) {
          const ext = path.extname(entry.name).toLowerCase();
          if (this.MONITORED_EXTENSIONS.includes(ext)) {
            files.push(entryRelative);
          }
        }
      }
    } catch (error) {
      // Silently ignore permission errors or missing directories
    }
    
    return files;
  }
  
  private readonly MODULE_PATTERNS: Record<string, RegExp[]> = {
    scheduling: [/schedule|shift|calendar|availability/i],
    payroll: [/payroll|salary|wage|compensation/i],
    invoicing: [/invoice|billing|payment/i],
    notifications: [/notification|alert|bell|toast/i],
    chat: [/chat|message|helpdesk|room/i],
    authentication: [/auth|login|session|user/i],
    analytics: [/analytics|report|metric|dashboard/i],
    ai_brain: [/ai-brain|gemini|orchestrator|automation/i],
    ui_components: [/mascot|gemini-agent|interactive-ui|component/i],
  };

  async scanPlatform(scanType: 'full' | 'quick' | 'health' | 'scheduled' = 'scheduled'): Promise<{
    scanId: string;
    changesDetected: number;
    notificationsSent: number;
  }> {
    console.log(`🧠 [AI BRAIN] Platform scan initiated: ${scanType}`);
    
    if (this.isScanning) {
      console.log('🧠 [AI BRAIN] Scan already in progress, skipping');
      return { scanId: '', changesDetected: 0, notificationsSent: 0 };
    }

    this.isScanning = true;
    const startTime = Date.now();
    
    console.log(`🧠 [AI BRAIN] Starting ${scanType} platform scan...`);

    try {
      const [scanRecord] = await db.insert(platformScanSnapshots).values({
        scanType,
        status: 'running',
        startedAt: new Date(),
      }).returning();

      const currentSnapshot = await this.captureSnapshot();
      
      const previousSnapshot = await this.getLastCompletedSnapshot();
      
      const changes = this.detectChanges(previousSnapshot, currentSnapshot);
      console.log(`🧠 [AI BRAIN] Detected ${changes.length} changes`);
      
      let notificationsSent = 0;
      
      if (changes.length > 0) {
        console.log(`🧠 [AI BRAIN] Processing ${changes.length} detected changes...`);
        for (const change of changes) {
          const aiSummary = await this.generateAISummary(change);
          
          const [changeEvent] = await db.insert(platformChangeEvents).values({
            scanId: scanRecord.id,
            changeType: change.type,
            severity: change.severity,
            title: aiSummary.title,
            summary: aiSummary.summary,
            technicalDetails: aiSummary.technicalDetails,
            affectedModules: change.affectedModules,
            affectedFiles: change.affectedFiles,
            platformStatus: 'operational',
            requiresAction: aiSummary.requiresAction,
            actionRequired: aiSummary.actionRequired,
            // Enhanced fields for detailed notifications
            detailedCategory: aiSummary.detailedCategory as any,
            sourceType: aiSummary.sourceType as any,
            sourceName: aiSummary.sourceName,
            endUserSummary: aiSummary.endUserSummary,
            brokenDescription: aiSummary.brokenDescription,
            impactDescription: aiSummary.impactDescription,
            metadata: { rawDiff: change.rawDiff.substring(0, 5000) },
          }).returning();

          console.log(`🧠 [AI BRAIN] Notifying users about: ${aiSummary.title}`);
          const sentCount = await this.notifyAllUsers(changeEvent.id, aiSummary);
          console.log(`🧠 [AI BRAIN] Notified ${sentCount} users`);
          notificationsSent += sentCount;
          
          await db.update(platformChangeEvents)
            .set({ 
              notifiedAllUsers: true,
              notificationSentAt: new Date(),
              notificationCount: sentCount,
            })
            .where(eq(platformChangeEvents.id, changeEvent.id));
        }
      }

      const durationMs = Date.now() - startTime;
      await db.update(platformScanSnapshots)
        .set({
          status: 'completed',
          codebaseHash: currentSnapshot.codebaseHash,
          schemaVersion: currentSnapshot.schemaVersion,
          serviceCount: currentSnapshot.serviceCount,
          routeCount: currentSnapshot.routeCount,
          healthStatus: currentSnapshot.healthStatus,
          changesDetected: changes.length,
          completedAt: new Date(),
          durationMs,
          snapshotData: currentSnapshot,
        })
        .where(eq(platformScanSnapshots.id, scanRecord.id));

      this.lastSnapshot = currentSnapshot;

      console.log(`🧠 [AI BRAIN] ✅ Scan completed: ${changes.length} changes, ${notificationsSent} notifications (${durationMs}ms)`);

      return {
        scanId: scanRecord.id,
        changesDetected: changes.length,
        notificationsSent,
      };
    } catch (error) {
      console.error(`🧠 [AI BRAIN] ❌ Scan failed:`, error);
      this.isScanning = false;
      // Return error result instead of throwing
      return { scanId: '', changesDetected: 0, notificationsSent: 0 };
    } finally {
      this.isScanning = false;
    }
  }

  private async captureSnapshot(): Promise<PlatformSnapshot> {
    const keyFiles: Record<string, string> = {};
    
    // DYNAMIC: Discover all files to monitor instead of using hardcoded list
    const monitoredFiles = this.discoverMonitoredFiles();
    
    for (const filePath of monitoredFiles) {
      try {
        const fullPath = path.resolve(process.cwd(), filePath);
        if (fs.existsSync(fullPath)) {
          const content = fs.readFileSync(fullPath, 'utf-8');
          keyFiles[filePath] = crypto.createHash('md5').update(content).digest('hex');
        }
      } catch (e) {
      }
    }

    const combinedHash = crypto.createHash('sha256')
      .update(Object.values(keyFiles).join(''))
      .digest('hex');

    const schemaContent = keyFiles['shared/schema.ts'] || 'unknown';
    
    let healthStatus: Record<string, any> = {};
    try {
      healthStatus = await getDetailedHealthReport();
    } catch (e) {
      healthStatus = { status: 'unknown' };
    }

    let routeCount = 0;
    try {
      const routesPath = path.resolve(process.cwd(), 'server/routes.ts');
      if (fs.existsSync(routesPath)) {
        const content = fs.readFileSync(routesPath, 'utf-8');
        routeCount = (content.match(/app\.(get|post|put|patch|delete)\(/gi) || []).length;
      }
    } catch (e) {}

    return {
      codebaseHash: combinedHash,
      schemaVersion: schemaContent.substring(0, 8),
      serviceCount: 80,
      routeCount,
      healthStatus,
      keyFiles,
      timestamp: new Date(),
    };
  }

  private async getLastCompletedSnapshot(): Promise<PlatformSnapshot | null> {
    const [lastScan] = await db
      .select()
      .from(platformScanSnapshots)
      .where(eq(platformScanSnapshots.status, 'completed'))
      .orderBy(desc(platformScanSnapshots.createdAt))
      .limit(1);

    if (lastScan?.snapshotData) {
      return lastScan.snapshotData as unknown as PlatformSnapshot;
    }

    return this.lastSnapshot;
  }

  private detectChanges(previous: PlatformSnapshot | null, current: PlatformSnapshot): DetectedChange[] {
    const changes: DetectedChange[] = [];

    if (!previous) {
      changes.push({
        type: 'update',
        severity: 'info',
        affectedModules: ['platform'],
        affectedFiles: Object.keys(current.keyFiles),
        rawDiff: 'Initial platform snapshot captured',
      });
      return changes;
    }

    if (previous.codebaseHash !== current.codebaseHash) {
      const changedFiles: string[] = [];
      const affectedModules = new Set<string>();

      for (const [file, hash] of Object.entries(current.keyFiles)) {
        if (previous.keyFiles[file] !== hash) {
          changedFiles.push(file);
          
          for (const [module, patterns] of Object.entries(this.MODULE_PATTERNS)) {
            if (patterns.some(p => p.test(file))) {
              affectedModules.add(module);
            }
          }
        }
      }

      if (changedFiles.length > 0) {
        const severity = this.determineSeverity(changedFiles);
        const changeType = this.determineChangeType(changedFiles);

        changes.push({
          type: changeType,
          severity,
          affectedModules: Array.from(affectedModules),
          affectedFiles: changedFiles,
          rawDiff: `Changed files: ${changedFiles.join(', ')}`,
        });
      }
    }

    const prevHealth = previous.healthStatus as any;
    const currHealth = current.healthStatus as any;
    
    if (prevHealth?.overall !== currHealth?.overall) {
      changes.push({
        type: currHealth?.overall === 'operational' ? 'bug_fixed' : 'update',
        severity: currHealth?.overall === 'operational' ? 'minor' : 'major',
        affectedModules: ['platform_health'],
        affectedFiles: [],
        rawDiff: `Platform health changed: ${prevHealth?.overall} -> ${currHealth?.overall}`,
      });
    }

    return changes;
  }

  private determineSeverity(changedFiles: string[]): 'critical' | 'major' | 'minor' | 'patch' | 'info' {
    if (changedFiles.some(f => f.includes('schema.ts'))) return 'major';
    if (changedFiles.some(f => f.includes('routes.ts'))) return 'minor';
    if (changedFiles.some(f => f.includes('App.tsx'))) return 'minor';
    if (changedFiles.some(f => f.includes('package.json'))) return 'major';
    return 'patch';
  }

  private determineChangeType(changedFiles: string[]): DetectedChange['type'] {
    if (changedFiles.some(f => f.includes('schema'))) return 'enhancement';
    if (changedFiles.some(f => f.includes('routes'))) return 'feature_added';
    return 'update';
  }

  private async generateAISummary(change: DetectedChange): Promise<{
    title: string;
    summary: string;
    technicalDetails: string;
    requiresAction: boolean;
    actionRequired: string | null;
    endUserSummary: string;
    brokenDescription: string | null;
    impactDescription: string;
    detailedCategory: string;
    sourceType: string;
    sourceName: string;
  }> {
    try {
      const model = genAI.getGenerativeModel({ 
        model: GEMINI_MODELS.DIAGNOSTICS,
        generationConfig: {
          maxOutputTokens: ANTI_YAP_PRESETS.diagnostics.maxTokens,
          temperature: ANTI_YAP_PRESETS.diagnostics.temperature,
        }
      });
      
      // Build context-rich details for different module types
      const moduleContext = this.buildModuleContext(change.affectedModules);
      const impactAnalysis = this.analyzeImpact(change);
      
      // Extract specific file names for better context
      const specificFiles = change.affectedFiles.slice(0, 5).map(f => {
        const parts = f.split('/');
        return parts[parts.length - 1].replace(/\.(ts|tsx|js|jsx)$/, '');
      });
      
      const prompt = `You are Trinity, the senior AI engineer for CoAIleague. You communicate like a friendly, experienced developer - casual but competent.

CRITICAL RULES - ABSOLUTE REQUIREMENTS:
1. NEVER be contradictory! If title says "Improved" or "Enhanced", summary MUST describe a NOTICEABLE benefit
2. NEVER say "You shouldn't notice any difference" - if there's no noticeable change, don't call it an improvement!
3. If it's a behind-the-scenes tweak with no user impact, say "Code cleanup" or "Technical maintenance" - NOT "Performance Improved"
4. Be SPECIFIC about what changed - mention the actual feature/component names
5. Use contractions (we've, I've, it's, you'll)
6. NEVER mention "Replit" - use "Platform Config" instead if needed

ACTUAL CHANGES DETECTED:
- Change Type: ${change.type.replace(/_/g, ' ').toUpperCase()}
- Severity Level: ${change.severity}
- Affected Systems: ${change.affectedModules.join(', ') || 'Platform core'}
- Modified Files: ${specificFiles.join(', ')}
- Full File Paths: ${change.affectedFiles.slice(0, 3).join(', ')}
- Module Context: ${moduleContext}

TITLE RULES (max 70 chars):
- Be SPECIFIC: "Chatroom WebSocket Guards Added" not "Chat System Improved"
- Reference actual components: "${specificFiles[0] || 'Platform'}" 
- If it's a bugfix, say what was fixed: "Fixed empty room connection issue"
- If it's new code, describe it: "New master-detail chat layout live"

SUMMARY RULES (for tech staff):
- 2-3 sentences describing the ACTUAL code changes
- Reference the specific files/components: ${specificFiles.join(', ')}
- If WebSocket related, mention connection behavior
- If UI related, mention the visual/interaction change
- Example: "Added guards to useChatroomWebSocket to prevent connection churn when roomId is empty. This stops unnecessary reconnection attempts."

END USER SUMMARY RULES:
- 2 sentences max, plain English
- Describe observable benefit OR say "Technical update - no action needed"
- NEVER contradict the title - if title says "faster", explain HOW it's faster
- Example: "Chat rooms now connect more reliably when switching between them."

Respond ONLY with valid JSON:
{
  "title": "Short specific title mentioning ${specificFiles[0] || 'the feature'}",
  "summary": "Trinity-voice summary referencing actual code changes",
  "endUserSummary": "What users will notice or 'Technical update behind the scenes'",
  "technicalDetails": "The specific files and code modified",
  "brokenDescription": "What was broken (for bugfixes) or null",
  "impactDescription": "Who sees this change and how",
  "detailedCategory": "improvement",
  "sourceType": "system",
  "sourceName": "Trinity",
  "requiresAction": false,
  "actionRequired": null
}`;

      const result = await model.generateContent(prompt);
      const text = result.response.text();
      
      // Extract JSON with better error handling
      const cleanText = text.replace(/[\x00-\x1F\x7F]/g, '');
      const jsonMatch = cleanText.match(/\{[\s\S]*\}/);
      
      if (jsonMatch) {
        try {
          const parsed = JSON.parse(jsonMatch[0]);
          // Sanitize title - remove "undefined" literals and ensure valid title
          let safeTitle = parsed.title?.substring(0, 70) || '';
          safeTitle = safeTitle.replace(/undefined/gi, '').trim();
          if (!safeTitle || safeTitle.length < 3) {
            const moduleName = (change.affectedModules[0] || 'Platform').replace(/undefined/gi, '').trim() || 'Platform';
            const changeTypeName = change.type.replace(/_/g, ' ');
            safeTitle = `${moduleName} ${changeTypeName}`.trim();
          }
          return {
            title: safeTitle,
            summary: parsed.summary || this.generateFallbackSummary(change),
            technicalDetails: parsed.technicalDetails || change.rawDiff,
            requiresAction: parsed.requiresAction === true,
            actionRequired: parsed.actionRequired || null,
            endUserSummary: parsed.endUserSummary || this.generateEndUserSummary(change),
            brokenDescription: parsed.brokenDescription || null,
            impactDescription: parsed.impactDescription || this.analyzeImpact(change),
            detailedCategory: parsed.detailedCategory || this.mapToDetailedCategory(change.type),
            sourceType: parsed.sourceType || change.sourceType || 'system',
            sourceName: 'Trinity',
          };
        } catch (parseError) {
          console.error('[PlatformChangeMonitor] JSON parse error:', parseError);
        }
      }
    } catch (error) {
      console.error('[PlatformChangeMonitor] AI summary generation failed:', error);
    }

    return this.generateFallbackResponse(change);
  }
  
  private generateEndUserSummary(change: DetectedChange): string {
    const moduleList = change.affectedModules.join(', ') || 'core systems';
    const affectedAreas = change.affectedFiles.slice(0, 2).map(f => {
      const parts = f.split('/');
      return parts[parts.length - 1].replace(/\.(ts|tsx|js|jsx)$/, '');
    }).join(', ');
    
    switch (change.type) {
      case 'bug_fixed':
        return `We resolved an issue affecting ${moduleList}. The problem was identified and fixed - everything should be working correctly now. If you were experiencing any issues in this area, please try again.`;
      case 'feature_added':
        return `New capability added to ${moduleList}! This enhancement brings additional functionality to help you work more efficiently. Check out the ${affectedAreas || 'updated areas'} to see what's new.`;
      case 'security_fix':
        return `Security improvements have been applied to protect your data. These behind-the-scenes updates keep your information safe - no action needed on your end.`;
      case 'enhancement':
        return `We've improved ${moduleList} to be faster and more reliable. You may notice better performance when using these features.`;
      default:
        return `Platform update applied to ${moduleList}. These improvements help ensure everything runs smoothly. No action required.`;
    }
  }
  
  // Valid platform_update_category enum values from shared/schema.ts
  // Must include ALL enum values for direct match validation
  private static readonly VALID_CATEGORIES = [
    // What's New tab categories
    'feature', 'improvement', 'announcement',
    // System tab categories
    'bugfix', 'security', 'maintenance', 'diagnostic', 'support', 
    'ai_brain', 'error', 'fix', 'hotpatch', 'system', 'incident', 'outage', 'recovery',
    // Additional schema enum values
    'deprecation', 'maintenance_update', 'maintenance_postmortem'
  ] as const;

  private mapToDetailedCategory(changeType: string): string {
    // Maps internal change types to valid platform_update_category enum values
    // Valid enum values: 'feature', 'improvement', 'bugfix', 'security', 'announcement'
    const mapping: Record<string, string> = {
      'feature_added': 'feature',
      'bug_fixed': 'bugfix',
      'hotpatch': 'bugfix',  // Hotpatches are urgent bug fixes
      'enhancement': 'improvement',
      'security_fix': 'security',
      'update': 'improvement',
    };
    return mapping[changeType] || 'improvement';
  }

  // Sanitizes any category string to a valid enum value
  // Now includes System tab categories for AI Brain notifications
  private sanitizeCategory(category: string | undefined): string {
    if (!category) return 'announcement'; // Default generic updates go to What's New
    
    // Direct match to valid enum value
    if (PlatformChangeMonitorService.VALID_CATEGORIES.includes(category as any)) {
      return category;
    }
    
    // Map detailed categories to valid enum values
    // Categories that go to System tab: bugfix, security, maintenance, diagnostic, support, ai_brain, error, fix, hotpatch, system, incident, outage, recovery
    // Categories that go to What's New: feature, improvement, announcement
    const categoryMapping: Record<string, string> = {
      // System tab categories
      'hotpatch': 'hotpatch',
      'hot_patch': 'hotpatch',
      'fix': 'fix',
      'quick_fix': 'fix',
      'bugfix': 'bugfix',
      'bug_fix': 'bugfix',
      'security_fix': 'security',
      'diagnostic': 'diagnostic',
      'diagnostics': 'diagnostic',
      'system_health': 'diagnostic',
      'health_check': 'diagnostic',
      'error': 'error',
      'incident': 'incident',
      'outage': 'outage',
      'recovery': 'recovery',
      'maintenance': 'maintenance',
      'support': 'support',
      'ai_brain': 'ai_brain',
      'orchestration': 'ai_brain',
      'orchestration_update': 'ai_brain',
      'system': 'system',
      'platform_monitor': 'diagnostic',
      
      // What's New categories
      'service': 'feature',
      'bot_automation': 'feature',
      'deprecation': 'deprecation',
      'integration': 'feature',
      'ui_update': 'improvement',
      'backend_update': 'improvement',
      'performance': 'improvement',
      'documentation': 'announcement',
      'feature_added': 'feature',
      'enhancement': 'improvement',
    };
    
    return categoryMapping[category] || 'announcement'; // Default unknown to What's New
  }

  private buildModuleContext(modules: string[]): string {
    const contexts: Record<string, string> = {
      scheduling: 'Affects shift creation, scheduling, calendar management, and employee availability',
      payroll: 'Impacts payroll processing, wage calculations, invoicing, and financial reporting',
      chat: 'Affects messaging, HelpDesk, support tickets, and real-time communications',
      notifications: 'Impacts alerts, reminders, email delivery, and user notifications',
      analytics: 'Affects reporting, dashboards, insights, and business intelligence',
      ai_brain: 'Impacts automation, AI processing, platform orchestration, and autonomous operations',
      authentication: 'Affects login, security, session management, and user access control',
      invoicing: 'Impacts invoice generation, billing, payment processing, and financial records',
    };
    
    return modules.map(m => contexts[m] || `Affects ${m} functionality`).join('. ');
  }

  private analyzeImpact(change: DetectedChange): string {
    if (change.type === 'security_fix') {
      return 'Security-critical. All users affected. No user action required - automatic deployment.';
    }
    if (change.type === 'feature_added') {
      return 'New capability available. Enhances workflow efficiency and user experience.';
    }
    if (change.type === 'bug_fixed') {
      return 'Resolution to reported issue. Improves platform stability and reliability.';
    }
    if (change.type === 'enhancement') {
      return 'Performance or usability improvement. Makes existing features more efficient.';
    }
    return `${change.severity} priority update to platform systems.`;
  }

  private generateFallbackSummary(change: DetectedChange): string {
    const moduleList = change.affectedModules.join(', ') || 'platform core';
    const fileCount = change.affectedFiles.length;
    const fileContext = fileCount > 0 ? ` (${fileCount} file${fileCount > 1 ? 's' : ''} updated)` : '';
    
    switch (change.type) {
      case 'bug_fixed':
        return `Resolved an issue in ${moduleList}${fileContext}. The bug has been identified and patched - affected functionality should now work as expected. No action required on your part.`;
      case 'feature_added':
        return `New feature deployed to ${moduleList}${fileContext}. This addition expands platform capabilities and may include new UI elements or functionality. Check the affected area for what's new.`;
      case 'security_fix':
        return `Security patch applied to ${moduleList}${fileContext}. These updates strengthen platform security and protect your data. No user action needed.`;
      case 'enhancement':
        return `Performance and reliability improvements to ${moduleList}${fileContext}. These optimizations help the platform run faster and more smoothly.`;
      default:
        return `Platform update applied to ${moduleList}${fileContext}. This maintenance update ensures continued stability and optimal performance.`;
    }
  }

  private generateFallbackResponse(change: DetectedChange) {
    // Generate a clear, human-readable title based on what actually changed
    const moduleNames = change.affectedModules.filter(m => m && m !== 'undefined' && m !== 'unknown');
    const primaryModule = moduleNames[0] || this.inferModuleFromFiles(change.affectedFiles);
    
    // Extract actual file names for specificity
    const specificFiles = change.affectedFiles.slice(0, 3).map(f => {
      const parts = f.split('/');
      return parts[parts.length - 1].replace(/\.(ts|tsx|js|jsx)$/, '');
    }).filter(f => f && f !== 'undefined');
    const primaryFile = specificFiles[0] || '';
    
    // Create SPECIFIC titles based on actual files changed
    let title = '';
    switch (change.type) {
      case 'bug_fixed':
        title = primaryFile 
          ? `Fixed issue in ${primaryFile}`
          : `${this.formatModuleName(primaryModule)} Issue Resolved`;
        break;
      case 'feature_added':
        title = primaryFile 
          ? `New ${primaryFile} functionality added`
          : `New ${this.formatModuleName(primaryModule)} Feature Available`;
        break;
      case 'security_fix':
        title = `Security update for ${primaryFile || this.formatModuleName(primaryModule)}`;
        break;
      case 'enhancement':
        title = primaryFile 
          ? `Updated ${primaryFile} component`
          : `${this.formatModuleName(primaryModule)} update`;
        break;
      case 'hotpatch':
        title = `Quick fix: ${primaryFile || this.formatModuleName(primaryModule)}`;
        break;
      default:
        title = primaryFile 
          ? `Technical update to ${primaryFile}`
          : `${this.formatModuleName(primaryModule)} maintenance update`;
    }
    
    // Generate specific end-user summary based on change type
    const endUserSummary = change.type === 'bug_fixed' 
      ? `Fixed an issue in ${primaryFile || primaryModule}. Everything should work correctly now.`
      : change.type === 'feature_added'
      ? `New capability added to ${primaryFile || primaryModule}. Check it out!`
      : `Technical update to ${primaryFile || primaryModule}. No action needed on your end.`;
    
    return {
      title: title.substring(0, 70),
      summary: `Updated ${specificFiles.join(', ') || primaryModule} - ${this.generateFallbackSummary(change)}`,
      technicalDetails: `Modified: ${change.affectedFiles.slice(0, 5).join(', ')}${change.affectedFiles.length > 5 ? ` and ${change.affectedFiles.length - 5} more files` : ''}. Severity: ${change.severity}.`,
      requiresAction: false,
      actionRequired: null,
      endUserSummary,
      brokenDescription: change.type === 'bug_fixed' ? `Issue in ${primaryFile || primaryModule} was identified and fixed.` : null,
      impactDescription: this.analyzeImpact(change),
      detailedCategory: this.mapToDetailedCategory(change.type),
      sourceType: change.sourceType || 'system',
      sourceName: 'Trinity',
    };
  }
  
  private formatModuleName(module: string): string {
    if (!module || module === 'undefined' || module === 'unknown') {
      return 'Platform';
    }
    // Convert camelCase/snake_case to Title Case
    return module
      .replace(/([A-Z])/g, ' $1')
      .replace(/_/g, ' ')
      .replace(/^\s+/, '')
      .split(' ')
      .map(word => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase())
      .join(' ')
      .trim();
  }
  
  private inferModuleFromFiles(files: string[]): string {
    // Infer module name from file paths when modules list is empty
    const modulePatterns: Record<string, string> = {
      'schedule': 'Scheduling',
      'billing': 'Billing',
      'payment': 'Payments',
      'stripe': 'Payments',
      'employee': 'Employee Management',
      'client': 'Client Management',
      'auth': 'Authentication',
      'notification': 'Notifications',
      'chat': 'Chat',
      'helpai': 'Trinity AI',
      'trinity': 'Trinity AI',
      'ai-brain': 'AI Intelligence',
      'analytics': 'Analytics',
      'report': 'Reporting',
      'time': 'Time Tracking',
      'shift': 'Shift Management',
      'onboard': 'Onboarding',
      'compliance': 'Compliance',
      'invoice': 'Invoicing',
      'payroll': 'Payroll',
    };
    
    for (const file of files) {
      const lowerFile = file.toLowerCase();
      for (const [pattern, moduleName] of Object.entries(modulePatterns)) {
        if (lowerFile.includes(pattern)) {
          return moduleName;
        }
      }
    }
    
    return 'Platform Services';
  }

  private async notifyAllUsers(changeEventId: string, summary: {
    title: string;
    summary: string;
    technicalDetails: string;
    requiresAction: boolean;
    actionRequired: string | null;
    endUserSummary: string;
    brokenDescription: string | null;
    impactDescription: string;
    detailedCategory: string;
    sourceType: string;
    sourceName: string;
  }): Promise<number> {
    try {
      // Get unique workspaces to notify (one notification per workspace)
      const uniqueWorkspaces = await db
        .select({ workspaceId: users.currentWorkspaceId })
        .from(users)
        .where(isNotNull(users.currentWorkspaceId))
        .groupBy(users.currentWorkspaceId);
      
      if (uniqueWorkspaces.length === 0) {
        console.log('[PlatformChangeMonitor] No workspaces to notify');
        return 0;
      }

      let notifiedCount = 0;

      // CRITICAL FIX: Create platform_update entry FIRST for "What's New" UI
      // This is the single source of truth for platform updates that users see
      try {
        const categoryMap: Record<string, 'feature' | 'improvement' | 'bugfix' | 'security' | 'announcement'> = {
          'feature': 'feature',
          'feature_added': 'feature',
          'enhancement': 'improvement',
          'improvement': 'improvement',
          'bugfix': 'bugfix',
          'bug_fixed': 'bugfix',
          'security_fix': 'security',
          'security': 'security',
          'hotpatch': 'bugfix',
          'update': 'announcement',
        };
        
        const platformUpdateResult = await universalNotificationEngine.sendPlatformUpdate({
          title: summary.title,
          description: summary.endUserSummary || summary.summary,
          category: categoryMap[summary.detailedCategory] || 'announcement',
          priority: summary.requiresAction ? 3 : 1,
          metadata: {
            changeEventId,
            source: 'platform_change_monitor',
            requiresAction: summary.requiresAction,
            actionRequired: summary.actionRequired,
            technicalDetails: summary.technicalDetails,
            brokenDescription: summary.brokenDescription,
            impactDescription: summary.impactDescription,
            detailedCategory: summary.detailedCategory,
            sourceType: summary.sourceType,
            sourceName: 'Trinity',
          },
        });
        
        if (platformUpdateResult.success && !platformUpdateResult.isDuplicate) {
          console.log(`[PlatformChangeMonitor] Created platform update: ${platformUpdateResult.id}`);
        } else if (platformUpdateResult.isDuplicate) {
          console.log(`[PlatformChangeMonitor] Skipped duplicate platform update`);
        }
      } catch (platformUpdateError) {
        console.error('[PlatformChangeMonitor] Failed to create platform update:', platformUpdateError);
      }

      // ALSO: Route through notifications for per-user tracking  
      // This ensures all notifications pass through feature validation to prevent vague/stale content
      for (const { workspaceId } of uniqueWorkspaces) {
        if (!workspaceId) continue;

        try {
          await universalNotificationEngine.sendNotification({
            type: 'platform_update',
            title: summary.title,
            message: summary.endUserSummary || summary.summary,
            workspaceId,
            severity: summary.requiresAction ? 'high' : 'medium',
            source: 'platform_change_monitor',
            metadata: {
              changeEventId,
              requiresAction: summary.requiresAction,
              actionRequired: summary.actionRequired,
              // Enhanced fields for detailed display
              endUserSummary: summary.endUserSummary,
              technicalSummary: summary.summary,
              technicalDetails: summary.technicalDetails,
              brokenDescription: summary.brokenDescription,
              impactDescription: summary.impactDescription,
              detailedCategory: summary.detailedCategory,
              sourceType: summary.sourceType,
              sourceName: 'Trinity',
              timestamp: new Date().toISOString(),
              // Feature validation context
              featureCategory: summary.detailedCategory,
            },
          });
          notifiedCount++;
        } catch (notifyError) {
          // If UNE blocks the notification due to validation failure, log it
          console.log(`[PlatformChangeMonitor] UNE blocked notification for workspace ${workspaceId}:`, notifyError);
        }
      }

      // Update change event with notification count
      await db
        .update(platformChangeEvents)
        .set({ 
          notifiedAllUsers: notifiedCount > 0,
          notificationCount: notifiedCount,
        })
        .where(eq(platformChangeEvents.id, changeEventId));

      console.log(`[PlatformChangeMonitor] Routed ${notifiedCount} notifications through Trinity UNE`);
      
      return notifiedCount;
    } catch (error) {
      console.error('[PlatformChangeMonitor] Failed to notify users:', error);
      return 0;
    }
  }

  async getRecentChanges(limit = 10): Promise<any[]> {
    return db
      .select()
      .from(platformChangeEvents)
      .orderBy(desc(platformChangeEvents.createdAt))
      .limit(limit);
  }

  async getRecentScans(limit = 10): Promise<any[]> {
    return db
      .select()
      .from(platformScanSnapshots)
      .orderBy(desc(platformScanSnapshots.createdAt))
      .limit(limit);
  }

  async getPendingNotifications(): Promise<any[]> {
    return db
      .select()
      .from(platformChangeEvents)
      .where(eq(platformChangeEvents.notifiedAllUsers, false))
      .orderBy(desc(platformChangeEvents.createdAt));
  }

  async triggerManualScan(): Promise<{
    scanId: string;
    changesDetected: number;
    notificationsSent: number;
  }> {
    return this.scanPlatform('full');
  }
}

export const platformChangeMonitor = new PlatformChangeMonitorService();

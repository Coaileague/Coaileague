/**
 * MetaCognitionService - Trinity's "Prefrontal Cortex"
 * 
 * This service provides executive function for the AI Orchestra,
 * observing and synthesizing outputs from multiple AI models.
 * 
 * Three Meta-Cognitive Functions:
 * - SYNTHESIZER (Claude): Combines strengths of multiple responses
 * - ARBITRATOR (GPT-4): Resolves conflicts between models
 * - CONFIDENCE CALIBRATOR (Gemini): Reality-checks confidence scores
 * 
 * Follows the 7-step orchestration pattern:
 * TRIGGER → FETCH → VALIDATE → PROCESS → MUTATE → CONFIRM → NOTIFY
 */

import { db } from "../../db";
import { sql } from "drizzle-orm";
import { geminiClient } from "./providers/geminiClient";
import { openaiClient } from "./providers/openaiClient";
import { claudeService } from "./dualai/claudeService";
import { eventBus } from "../trinity/eventBus";

// Types for meta-cognition
interface ModelResponse {
  modelId: string;
  modelName: string;
  provider: string;
  response: string;
  confidence: number;
  reasoning?: string;
  executionTimeMs: number;
  tokensUsed: number;
}

interface CognitiveContext {
  originalPrompt: string;
  taskType: string;
  taskId?: string;
  workspaceId?: string;
  responses: ModelResponse[];
  triggerReason: 'complex_task' | 'low_confidence' | 'model_disagreement';
}

interface MetaCognitiveResult {
  finalAnswer: string;
  calibratedConfidence: number;
  originalConfidence: number;
  contributingModels: string[];
  synthesisNotes: string;
  resolutionMethod: 'synthesis' | 'arbitration' | 'calibration' | 'human_escalation';
  disagreementType?: 'factual' | 'reasoning' | 'style' | 'none';
  costBreakdown: {
    synthesisTokens: number;
    arbitrationTokens: number;
    calibrationTokens: number;
    totalTokens: number;
    totalCostCents: number;
  };
  humanEscalationRequired: boolean;
  escalationQuestions?: string[];
  executionTimeMs: number;
}

// Thresholds for meta-cognition triggers
const CONFIDENCE_THRESHOLD = 0.75;
const DISAGREEMENT_THRESHOLD = 0.3; // Semantic similarity below this = disagreement
const HUMAN_ESCALATION_THRESHOLD = 0.6;

// Complex task types that always trigger meta-cognition
const COMPLEX_TASK_TYPES = [
  'rfp_generation',
  'contract_review',
  'proposal_creation',
  'compliance_report',
  'sales_strategy',
  'failure_analysis'
];

class MetaCognitionService {
  private initialized = false;

  async initialize(): Promise<void> {
    if (this.initialized) return;
    console.log('[MetaCognition] Initializing meta-cognition service...');
    this.initialized = true;
    console.log('[MetaCognition] Meta-cognition service ready');
  }

  /**
   * STEP 1: TRIGGER
   * Determines if meta-cognition should be activated
   */
  shouldTriggerMetaCognition(
    taskType: string,
    responses: ModelResponse[]
  ): { shouldTrigger: boolean; reason: CognitiveContext['triggerReason'] | null } {
    // Check if task is inherently complex
    if (COMPLEX_TASK_TYPES.includes(taskType)) {
      return { shouldTrigger: true, reason: 'complex_task' };
    }

    // Check if any model returned low confidence
    const hasLowConfidence = responses.some(r => r.confidence < CONFIDENCE_THRESHOLD);
    if (hasLowConfidence) {
      return { shouldTrigger: true, reason: 'low_confidence' };
    }

    // Check if models disagree (if we have 2+ responses)
    if (responses.length >= 2) {
      const hasDisagreement = this.detectDisagreement(responses);
      if (hasDisagreement) {
        return { shouldTrigger: true, reason: 'model_disagreement' };
      }
    }

    return { shouldTrigger: false, reason: null };
  }

  /**
   * STEP 2: FETCH
   * Gathers all model responses into a cognitive context object
   */
  buildCognitiveContext(
    originalPrompt: string,
    taskType: string,
    responses: ModelResponse[],
    triggerReason: CognitiveContext['triggerReason'],
    taskId?: string,
    workspaceId?: string
  ): CognitiveContext {
    return {
      originalPrompt,
      taskType,
      taskId,
      workspaceId,
      responses,
      triggerReason
    };
  }

  /**
   * STEP 3: VALIDATE
   * Confirms there's something meaningful to synthesize
   */
  validateForMetaCognition(context: CognitiveContext): { 
    valid: boolean; 
    reason?: string;
    fallbackResponse?: ModelResponse;
  } {
    // Need at least 1 response
    if (context.responses.length === 0) {
      return { valid: false, reason: 'No model responses to analyze' };
    }

    // If only 1 response and it's high confidence, no need for meta-cognition
    if (context.responses.length === 1 && context.responses[0].confidence >= CONFIDENCE_THRESHOLD) {
      return { 
        valid: false, 
        reason: 'Single high-confidence response - meta-cognition not needed',
        fallbackResponse: context.responses[0]
      };
    }

    // Check if task type is eligible for meta-review
    const ineligibleTypes = ['format_data', 'parse_email', 'basic_chat'];
    if (ineligibleTypes.includes(context.taskType) && context.triggerReason !== 'model_disagreement') {
      // For simple tasks, just use highest confidence response
      const best = this.getHighestConfidenceResponse(context.responses);
      return {
        valid: false,
        reason: 'Simple task type - using highest confidence response',
        fallbackResponse: best
      };
    }

    return { valid: true };
  }

  /**
   * STEP 4: PROCESS
   * The core meta-cognitive functions
   */
  async process(context: CognitiveContext): Promise<MetaCognitiveResult> {
    const startTime = Date.now();
    
    let synthesisTokens = 0;
    let arbitrationTokens = 0;
    let calibrationTokens = 0;
    let resolutionMethod: MetaCognitiveResult['resolutionMethod'] = 'synthesis';
    let disagreementType: MetaCognitiveResult['disagreementType'] = 'none';

    // Determine the best approach based on trigger reason
    let synthesizedAnswer: string;
    let synthesisNotes: string;
    const contributingModels: string[] = context.responses.map(r => r.modelName);

    if (context.triggerReason === 'model_disagreement') {
      // Use ARBITRATOR for conflicts
      const arbitrationResult = await this.arbitrate(context);
      synthesizedAnswer = arbitrationResult.answer;
      synthesisNotes = arbitrationResult.notes;
      arbitrationTokens = arbitrationResult.tokensUsed;
      resolutionMethod = 'arbitration';
      disagreementType = arbitrationResult.disagreementType;
    } else {
      // Use SYNTHESIZER for combining responses
      const synthesisResult = await this.synthesize(context);
      synthesizedAnswer = synthesisResult.answer;
      synthesisNotes = synthesisResult.notes;
      synthesisTokens = synthesisResult.tokensUsed;
      resolutionMethod = 'synthesis';
    }

    // Always run CONFIDENCE CALIBRATOR
    const calibrationResult = await this.calibrateConfidence(
      context,
      synthesizedAnswer,
      context.responses.reduce((sum, r) => sum + r.confidence, 0) / context.responses.length
    );
    calibrationTokens = calibrationResult.tokensUsed;

    // Check if human escalation is needed
    const humanEscalationRequired = calibrationResult.calibratedConfidence < HUMAN_ESCALATION_THRESHOLD;
    let escalationQuestions: string[] | undefined;

    if (humanEscalationRequired) {
      resolutionMethod = 'human_escalation';
      escalationQuestions = this.generateEscalationQuestions(context, synthesizedAnswer);
    }

    const totalTokens = synthesisTokens + arbitrationTokens + calibrationTokens;
    const originalConfidence = context.responses.reduce((sum, r) => sum + r.confidence, 0) / context.responses.length;

    return {
      finalAnswer: synthesizedAnswer,
      calibratedConfidence: calibrationResult.calibratedConfidence,
      originalConfidence,
      contributingModels,
      synthesisNotes,
      resolutionMethod,
      disagreementType,
      costBreakdown: {
        synthesisTokens,
        arbitrationTokens,
        calibrationTokens,
        totalTokens,
        totalCostCents: Math.ceil(totalTokens * 0.003) // Approximate cost
      },
      humanEscalationRequired,
      escalationQuestions,
      executionTimeMs: Date.now() - startTime
    };
  }

  /**
   * SYNTHESIZER - Uses Claude to combine model outputs
   */
  private async synthesize(context: CognitiveContext): Promise<{
    answer: string;
    notes: string;
    tokensUsed: number;
  }> {
    const responseSummaries = context.responses.map((r, i) => 
      `Model ${i + 1} (${r.modelName}, confidence: ${(r.confidence * 100).toFixed(0)}%):\n${r.response}`
    ).join('\n\n---\n\n');

    const prompt = `You are reviewing responses from ${context.responses.length} AI models to the same task. 
Your role is to synthesize the best answer by combining their strengths and identifying where each may be wrong.

ORIGINAL TASK: ${context.originalPrompt}

TASK TYPE: ${context.taskType}

MODEL RESPONSES:
${responseSummaries}

Please provide:
1. A synthesized best answer that combines the strengths of all responses
2. Brief notes on why this synthesis is superior to any individual response

Format your response as:
SYNTHESIZED ANSWER:
[Your synthesized answer here]

SYNTHESIS NOTES:
[Your notes on the synthesis process]`;

    try {
      const result = await claudeService.analyze({
        content: prompt,
        analysisType: 'synthesis',
        context: { taskType: context.taskType }
      });

      // Parse the response
      const answerMatch = result.analysis.match(/SYNTHESIZED ANSWER:\s*([\s\S]*?)(?=SYNTHESIS NOTES:|$)/i);
      const notesMatch = result.analysis.match(/SYNTHESIS NOTES:\s*([\s\S]*?)$/i);

      return {
        answer: answerMatch ? answerMatch[1].trim() : result.analysis,
        notes: notesMatch ? notesMatch[1].trim() : 'Synthesis completed by Claude',
        tokensUsed: result.tokensUsed || 500
      };
    } catch (error) {
      console.error('[MetaCognition] Synthesis error:', error);
      // Fallback to best individual response
      const best = this.getHighestConfidenceResponse(context.responses);
      return {
        answer: best.response,
        notes: 'Synthesis failed, using highest confidence response',
        tokensUsed: 0
      };
    }
  }

  /**
   * ARBITRATOR - Uses GPT-4 to resolve conflicts
   */
  private async arbitrate(context: CognitiveContext): Promise<{
    answer: string;
    notes: string;
    tokensUsed: number;
    disagreementType: 'factual' | 'reasoning' | 'style';
  }> {
    const responses = context.responses;
    
    const prompt = `Two or more AI models disagree on this task. Your role is to arbitrate and determine the correct answer.

ORIGINAL TASK: ${context.originalPrompt}

TASK TYPE: ${context.taskType}

CONFLICTING RESPONSES:
${responses.map((r, i) => `
Model ${String.fromCharCode(65 + i)} (${r.modelName}):
Response: ${r.response}
Confidence: ${(r.confidence * 100).toFixed(0)}%
${r.reasoning ? `Reasoning: ${r.reasoning}` : ''}
`).join('\n---\n')}

Please analyze:
1. What type of disagreement is this? (factual, reasoning, or style)
2. Which response is most correct and why?
3. Provide the final arbitrated answer

Format your response as:
DISAGREEMENT TYPE: [factual/reasoning/style]

ARBITRATION ANALYSIS:
[Your analysis of why one answer is better]

FINAL ANSWER:
[The correct answer]`;

    try {
      const result = await openaiClient.chat({
        model: 'gpt-4o',
        messages: [{ role: 'user', content: prompt }],
        temperature: 0.3
      });

      const responseText = result.content;
      
      // Parse the response
      const typeMatch = responseText.match(/DISAGREEMENT TYPE:\s*(\w+)/i);
      const analysisMatch = responseText.match(/ARBITRATION ANALYSIS:\s*([\s\S]*?)(?=FINAL ANSWER:|$)/i);
      const answerMatch = responseText.match(/FINAL ANSWER:\s*([\s\S]*?)$/i);

      const disagreementType = (typeMatch?.[1]?.toLowerCase() as 'factual' | 'reasoning' | 'style') || 'reasoning';

      return {
        answer: answerMatch ? answerMatch[1].trim() : responseText,
        notes: analysisMatch ? analysisMatch[1].trim() : 'Arbitration completed by GPT-4',
        tokensUsed: result.tokensUsed || 800,
        disagreementType
      };
    } catch (error) {
      console.error('[MetaCognition] Arbitration error:', error);
      // Fallback to highest confidence
      const best = this.getHighestConfidenceResponse(responses);
      return {
        answer: best.response,
        notes: 'Arbitration failed, using highest confidence response',
        tokensUsed: 0,
        disagreementType: 'reasoning'
      };
    }
  }

  /**
   * CONFIDENCE CALIBRATOR - Uses Gemini to reality-check scores
   */
  private async calibrateConfidence(
    context: CognitiveContext,
    synthesizedAnswer: string,
    averageConfidence: number
  ): Promise<{
    calibratedConfidence: number;
    tokensUsed: number;
    analysis: string;
  }> {
    const prompt = `You are a confidence calibration expert. Given these AI model responses and their self-reported confidence scores, determine what the TRUE confidence should be for the final answer.

ORIGINAL TASK: ${context.originalPrompt}

INDIVIDUAL MODEL CONFIDENCES:
${context.responses.map(r => `- ${r.modelName}: ${(r.confidence * 100).toFixed(0)}%`).join('\n')}

AVERAGE SELF-REPORTED CONFIDENCE: ${(averageConfidence * 100).toFixed(0)}%

SYNTHESIZED/ARBITRATED FINAL ANSWER:
${synthesizedAnswer}

Analyze for:
1. Overconfidence - Are the models too sure given the complexity?
2. Blind spots - What might the models be missing?
3. Task difficulty - How hard is this task objectively?

Provide your calibrated confidence as a percentage (0-100) and brief reasoning.

Format:
CALIBRATED CONFIDENCE: [number]%
REASONING: [your analysis]`;

    try {
      const result = await geminiClient.generateContent({
        contents: [{ role: 'user', parts: [{ text: prompt }] }],
        generationConfig: { temperature: 0.2 }
      });

      const responseText = result.response?.text || '';
      
      // Parse confidence
      const confidenceMatch = responseText.match(/CALIBRATED CONFIDENCE:\s*(\d+)/i);
      const reasoningMatch = responseText.match(/REASONING:\s*([\s\S]*?)$/i);

      const calibrated = confidenceMatch 
        ? Math.min(100, Math.max(0, parseInt(confidenceMatch[1]))) / 100
        : averageConfidence;

      return {
        calibratedConfidence: calibrated,
        tokensUsed: result.tokensUsed || 300,
        analysis: reasoningMatch ? reasoningMatch[1].trim() : 'Confidence calibrated by Gemini'
      };
    } catch (error) {
      console.error('[MetaCognition] Calibration error:', error);
      // Return slightly discounted original confidence
      return {
        calibratedConfidence: averageConfidence * 0.9,
        tokensUsed: 0,
        analysis: 'Calibration failed, applied 10% discount to original confidence'
      };
    }
  }

  /**
   * STEP 5: MUTATE
   * Saves meta-cognition results to database
   */
  async saveMetaCognitionLog(
    context: CognitiveContext,
    result: MetaCognitiveResult,
    options?: { fallbackTriggered?: boolean }
  ): Promise<string> {
    const modelsArray = context.responses.length > 0 
      ? sql.raw(`ARRAY[${context.responses.map(r => `'${r.modelName}'`).join(',')}]::text[]`)
      : sql.raw(`ARRAY[]::text[]`);
    
    const escalationArray = result.escalationQuestions && result.escalationQuestions.length > 0
      ? sql.raw(`ARRAY[${result.escalationQuestions.map(q => `'${q.replace(/'/g, "''")}'`).join(',')}]::text[]`)
      : null;

    const outcome = result.humanEscalationRequired 
      ? 'escalated' 
      : result.calibratedConfidence >= 0.75 
      ? 'success' 
      : 'low_confidence';

    const primaryModel = context.responses.length > 0 
      ? context.responses[0].modelId 
      : 'unknown';
    
    const synthesisApplied = result.resolutionMethod === 'synthesis';
    const arbitrationApplied = result.resolutionMethod === 'arbitration';
    const totalCostDollars = result.costBreakdown.totalCostCents / 100;

    const logId = await db.execute(sql`
      INSERT INTO meta_cognition_logs (
        workspace_id,
        original_task_id,
        original_prompt,
        task_type,
        models_consulted,
        individual_responses,
        trigger_reason,
        disagreement_type,
        resolution_method,
        meta_synthesis_result,
        final_answer,
        original_confidence,
        calibrated_confidence,
        synthesis_notes,
        tokens_consumed_synthesis,
        tokens_consumed_arbitration,
        tokens_consumed_calibration,
        total_tokens_consumed,
        total_cost_cents,
        execution_time_ms,
        human_escalation_required,
        escalation_questions,
        fallback_triggered,
        outcome,
        completed_at,
        model_id,
        total_tokens,
        total_cost,
        synthesis_applied,
        arbitration_applied,
        final_confidence
      ) VALUES (
        ${context.workspaceId || null},
        ${context.taskId ? context.taskId : null}::uuid,
        ${context.originalPrompt},
        ${context.taskType},
        ${modelsArray},
        ${JSON.stringify(context.responses)}::jsonb,
        ${context.triggerReason},
        ${result.disagreementType || null},
        ${result.resolutionMethod},
        ${result.synthesisNotes},
        ${result.finalAnswer},
        ${result.originalConfidence},
        ${result.calibratedConfidence},
        ${result.synthesisNotes},
        ${result.costBreakdown.synthesisTokens},
        ${result.costBreakdown.arbitrationTokens},
        ${result.costBreakdown.calibrationTokens},
        ${result.costBreakdown.totalTokens},
        ${result.costBreakdown.totalCostCents},
        ${result.executionTimeMs},
        ${result.humanEscalationRequired},
        ${escalationArray},
        ${options?.fallbackTriggered || false},
        ${outcome},
        NOW(),
        ${primaryModel},
        ${result.costBreakdown.totalTokens},
        ${totalCostDollars},
        ${synthesisApplied},
        ${arbitrationApplied},
        ${result.calibratedConfidence}
      )
      RETURNING id
    `);

    return (logId.rows[0] as any)?.id;
  }

  /**
   * STEP 6: CONFIRM
   * Returns the elevated MetaCognitiveResult (handled by process method)
   */

  /**
   * STEP 7: NOTIFY
   * Alerts relevant parties when human escalation is needed
   */
  async notifyHumanEscalation(
    context: CognitiveContext,
    result: MetaCognitiveResult,
    logId: string
  ): Promise<void> {
    if (!result.humanEscalationRequired) return;

    console.log('[MetaCognition] Human escalation required for task:', context.taskId);

    // Emit event for notification systems
    eventBus.emit('meta_cognition_escalation', {
      logId,
      workspaceId: context.workspaceId,
      taskType: context.taskType,
      originalPrompt: context.originalPrompt,
      allResponses: context.responses.map(r => ({
        model: r.modelName,
        response: r.response.substring(0, 500),
        confidence: r.confidence
      })),
      synthesisAttempt: result.finalAnswer.substring(0, 500),
      calibratedConfidence: result.calibratedConfidence,
      escalationQuestions: result.escalationQuestions,
      timestamp: new Date().toISOString()
    });
  }

  /**
   * Main entry point - orchestrates the full 7-step meta-cognition flow
   */
  async executeMetaCognition(
    originalPrompt: string,
    taskType: string,
    responses: ModelResponse[],
    taskId?: string,
    workspaceId?: string
  ): Promise<MetaCognitiveResult | null> {
    // STEP 1: TRIGGER
    const { shouldTrigger, reason } = this.shouldTriggerMetaCognition(taskType, responses);
    
    if (!shouldTrigger || !reason) {
      console.log('[MetaCognition] Trigger check: meta-cognition not needed');
      return null;
    }

    console.log(`[MetaCognition] Triggered: ${reason}`);

    // STEP 2: FETCH
    const context = this.buildCognitiveContext(
      originalPrompt,
      taskType,
      responses,
      reason,
      taskId,
      workspaceId
    );

    // STEP 3: VALIDATE
    const validation = this.validateForMetaCognition(context);
    if (!validation.valid) {
      console.log(`[MetaCognition] Validation failed: ${validation.reason}`);
      if (validation.fallbackResponse) {
        return {
          finalAnswer: validation.fallbackResponse.response,
          calibratedConfidence: validation.fallbackResponse.confidence,
          originalConfidence: validation.fallbackResponse.confidence,
          contributingModels: [validation.fallbackResponse.modelName],
          synthesisNotes: validation.reason || 'Using fallback response',
          resolutionMethod: 'calibration',
          costBreakdown: {
            synthesisTokens: 0,
            arbitrationTokens: 0,
            calibrationTokens: 0,
            totalTokens: 0,
            totalCostCents: 0
          },
          humanEscalationRequired: false,
          executionTimeMs: 0
        };
      }
      return null;
    }

    // STEP 4: PROCESS
    const result = await this.process(context);

    // STEP 5: MUTATE
    const logId = await this.saveMetaCognitionLog(context, result);

    // STEP 7: NOTIFY (if needed)
    await this.notifyHumanEscalation(context, result, logId);

    // STEP 6: CONFIRM (return result)
    return result;
  }

  // Helper methods
  private detectDisagreement(responses: ModelResponse[]): boolean {
    if (responses.length < 2) return false;
    
    // Simple heuristic: if confidence spread is > 30%, likely disagreement
    const confidences = responses.map(r => r.confidence);
    const spread = Math.max(...confidences) - Math.min(...confidences);
    
    return spread > DISAGREEMENT_THRESHOLD;
  }

  private getHighestConfidenceResponse(responses: ModelResponse[]): ModelResponse {
    return responses.reduce((best, current) => 
      current.confidence > best.confidence ? current : best
    );
  }

  private generateEscalationQuestions(
    context: CognitiveContext,
    synthesizedAnswer: string
  ): string[] {
    return [
      `The AI models could not reach consensus on: "${context.originalPrompt.substring(0, 100)}..."`,
      'Which aspects of this decision require domain expertise?',
      'Are there regulatory or compliance considerations the AI may have missed?',
      'What additional context would help resolve this uncertainty?'
    ];
  }

  // Get meta-cognition statistics
  async getStats(workspaceId?: string): Promise<{
    totalLogs: number;
    avgCalibratedConfidence: number;
    humanEscalations: number;
    byResolutionMethod: Record<string, number>;
    byTriggerReason: Record<string, number>;
  }> {
    const whereClause = workspaceId ? sql`WHERE workspace_id = ${workspaceId}` : sql``;
    
    const stats = await db.execute(sql`
      SELECT 
        COUNT(*) as total_logs,
        AVG(calibrated_confidence) as avg_confidence,
        SUM(CASE WHEN human_escalation_required THEN 1 ELSE 0 END) as human_escalations
      FROM meta_cognition_logs
      ${whereClause}
    `);

    const byMethod = await db.execute(sql`
      SELECT resolution_method, COUNT(*) as count
      FROM meta_cognition_logs
      ${whereClause}
      GROUP BY resolution_method
    `);

    const byReason = await db.execute(sql`
      SELECT trigger_reason, COUNT(*) as count
      FROM meta_cognition_logs
      ${whereClause}
      GROUP BY trigger_reason
    `);

    const row = stats.rows[0] as any;
    
    return {
      totalLogs: parseInt(row?.total_logs || '0'),
      avgCalibratedConfidence: parseFloat(row?.avg_confidence || '0'),
      humanEscalations: parseInt(row?.human_escalations || '0'),
      byResolutionMethod: Object.fromEntries(
        (byMethod.rows as any[]).map(r => [r.resolution_method, parseInt(r.count)])
      ),
      byTriggerReason: Object.fromEntries(
        (byReason.rows as any[]).map(r => [r.trigger_reason, parseInt(r.count)])
      )
    };
  }
}

export const metaCognitionService = new MetaCognitionService();

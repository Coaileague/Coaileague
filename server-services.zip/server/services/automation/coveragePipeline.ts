/**
 * COVERAGE PIPELINE SERVICE - Trinity Autonomous Shift Coverage
 * ==============================================================
 * When an employee calls off or is detected as NCNS, this service:
 * 1. Creates a coverage request record
 * 2. Identifies available candidates (not scheduled, available, qualified)
 * 3. Sends mass notifications to all candidates via UNE
 * 4. Handles accept/deny workflow with atomic first-accept-wins
 * 5. Republishes the shift with the new employee
 * 6. Escalates to org owner if no coverage found within timeout
 */

import { db } from '../../db';
import { 
  shiftCoverageRequests, 
  shiftCoverageOffers,
  shifts, 
  employees, 
  employeeAvailability,
  InsertShiftCoverageRequest,
  InsertShiftCoverageOffer,
  ShiftCoverageRequest,
  ShiftCoverageOffer,
} from '@shared/schema';
import { eq, and, ne, gte, lte, or, isNull, sql, not, inArray } from 'drizzle-orm';
import { universalNotificationEngine } from '../universalNotificationEngine';
import { platformEventBus } from '../platformEventBus';
import { trinityAutomationToggle } from './trinityAutomationToggle';
import { storage } from '../../storage';

const COVERAGE_TIMEOUT_MINUTES = 60; // 1 hour before escalation
const COVERAGE_CHECK_INTERVAL_MS = 2 * 60 * 1000; // Check for expired every 2 min

interface CoverageCandidate {
  employeeId: string;
  employeeName: string;
  userId: string | null;
  aiScore: number;
  aiReason: string;
}

interface CoverageTriggerInput {
  shiftId: string;
  workspaceId: string;
  reason: 'call_off' | 'ncns' | 'sick' | 'emergency' | 'manual';
  reasonDetails?: string;
  originalEmployeeId?: string;
  timeoutMinutes?: number;
}

interface CoverageResult {
  success: boolean;
  coverageRequestId?: string;
  candidatesInvited?: number;
  error?: string;
}

class CoveragePipelineService {
  private static instance: CoveragePipelineService;
  private expiryCheckInterval: NodeJS.Timeout | null = null;
  private isRunning = false;

  private constructor() {}

  static getInstance(): CoveragePipelineService {
    if (!this.instance) {
      this.instance = new CoveragePipelineService();
    }
    return this.instance;
  }

  async start(): Promise<void> {
    if (this.isRunning) return;
    
    console.log('[CoveragePipeline] Starting autonomous coverage pipeline...');
    this.isRunning = true;
    
    this.expiryCheckInterval = setInterval(async () => {
      await this.checkExpiredRequests();
    }, COVERAGE_CHECK_INTERVAL_MS);
    
    await this.checkExpiredRequests();
  }

  stop(): void {
    if (this.expiryCheckInterval) {
      clearInterval(this.expiryCheckInterval);
      this.expiryCheckInterval = null;
    }
    this.isRunning = false;
    console.log('[CoveragePipeline] Stopped');
  }

  /**
   * Main entry point: trigger coverage pipeline for a shift
   */
  async triggerCoverage(input: CoverageTriggerInput): Promise<CoverageResult> {
    console.log(`[CoveragePipeline] Coverage triggered for shift ${input.shiftId} (${input.reason})`);

    try {
      const isEnabled = await trinityAutomationToggle.isFeatureAutomated(input.workspaceId, 'shift_monitoring');
      if (!isEnabled) {
        console.log('[CoveragePipeline] Shift monitoring automation is disabled for this workspace');
        return { success: false, error: 'Automation disabled for this workspace' };
      }

      const shift = await db.query.shifts.findFirst({
        where: eq(shifts.id, input.shiftId),
      });

      if (!shift) {
        return { success: false, error: 'Shift not found' };
      }

      const existingRequest = await db.query.shiftCoverageRequests.findFirst({
        where: and(
          eq(shiftCoverageRequests.originalShiftId, input.shiftId),
          eq(shiftCoverageRequests.status, 'open')
        ),
      });

      if (existingRequest) {
        console.log(`[CoveragePipeline] Coverage request already exists for shift ${input.shiftId}`);
        return { 
          success: true, 
          coverageRequestId: existingRequest.id, 
          candidatesInvited: existingRequest.candidatesInvited || 0 
        };
      }

      const timeoutMinutes = input.timeoutMinutes || COVERAGE_TIMEOUT_MINUTES;
      const expiresAt = new Date(Date.now() + timeoutMinutes * 60 * 1000);

      const requestData: InsertShiftCoverageRequest = {
        workspaceId: input.workspaceId,
        originalShiftId: input.shiftId,
        reason: input.reason,
        reasonDetails: input.reasonDetails,
        originalEmployeeId: input.originalEmployeeId || shift.employeeId || undefined,
        shiftDate: shift.date,
        shiftStartTime: new Date(shift.startTime),
        shiftEndTime: new Date(shift.endTime),
        clientId: shift.clientId || undefined,
        status: 'open',
        expiresAt,
        aiProcessed: false,
      };

      const [coverageRequest] = await db.insert(shiftCoverageRequests)
        .values(requestData)
        .returning();

      console.log(`[CoveragePipeline] Created coverage request ${coverageRequest.id}`);

      const candidates = await this.findCandidates(shift, input.originalEmployeeId);
      
      if (candidates.length === 0) {
        console.log('[CoveragePipeline] No candidates found, escalating immediately');
        await this.escalateToOrgOwner(coverageRequest, 'No available employees found');
        return { success: true, coverageRequestId: coverageRequest.id, candidatesInvited: 0 };
      }

      await this.dispatchOffers(coverageRequest, candidates);

      await db.update(shiftCoverageRequests)
        .set({ 
          candidatesInvited: candidates.length,
          aiProcessed: true,
          updatedAt: new Date(),
        })
        .where(eq(shiftCoverageRequests.id, coverageRequest.id));

      await platformEventBus.publish({
        type: 'coverage_pipeline_started',
        category: 'scheduling',
        title: 'Shift Coverage Needed',
        description: `Trinity is reaching out to ${candidates.length} available employees`,
        workspaceId: input.workspaceId,
        metadata: {
          coverageRequestId: coverageRequest.id,
          shiftId: input.shiftId,
          reason: input.reason,
          candidatesInvited: candidates.length,
          expiresAt: expiresAt.toISOString(),
        },
      });

      return {
        success: true,
        coverageRequestId: coverageRequest.id,
        candidatesInvited: candidates.length,
      };

    } catch (error: any) {
      console.error('[CoveragePipeline] Error triggering coverage:', error);
      return { success: false, error: error.message };
    }
  }

  /**
   * Find available candidates for a shift
   */
  private async findCandidates(shift: any, excludeEmployeeId?: string): Promise<CoverageCandidate[]> {
    const shiftDate = shift.date;
    const shiftStart = new Date(shift.startTime);
    const shiftEnd = new Date(shift.endTime);
    const dayOfWeek = shiftStart.toLocaleDateString('en-US', { weekday: 'long' }).toLowerCase();

    const allEmployees = await db.select()
      .from(employees)
      .where(
        and(
          eq(employees.workspaceId, shift.workspaceId),
          eq(employees.state, 'active'),
          excludeEmployeeId ? ne(employees.id, excludeEmployeeId) : undefined
        )
      );

    if (allEmployees.length === 0) {
      return [];
    }

    const employeeIds = allEmployees.map(e => e.id);
    
    const conflictingShifts = await db.select({ employeeId: shifts.employeeId })
      .from(shifts)
      .where(
        and(
          eq(shifts.date, shiftDate),
          eq(shifts.workspaceId, shift.workspaceId),
          inArray(shifts.employeeId!, employeeIds),
          or(
            eq(shifts.status, 'scheduled'),
            eq(shifts.status, 'confirmed'),
            eq(shifts.status, 'pending')
          )
        )
      );

    const busyEmployeeIds = new Set(conflictingShifts.map(s => s.employeeId));

    const availableEmployees = allEmployees.filter(e => !busyEmployeeIds.has(e.id));

    const candidates: CoverageCandidate[] = availableEmployees
      .filter(e => e.userId) // Must have a linked user account to receive notifications
      .map((e, index) => ({
        employeeId: e.id,
        employeeName: `${e.firstName} ${e.lastName}`,
        userId: e.userId,
        aiScore: 80 - (index * 2), // Simple scoring - in production use AI ranking
        aiReason: `Available and not scheduled on ${shiftDate}`,
      }))
      .slice(0, 10); // Limit to top 10 candidates

    console.log(`[CoveragePipeline] Found ${candidates.length} candidates for coverage`);
    return candidates;
  }

  /**
   * Send coverage offer notifications to all candidates
   */
  private async dispatchOffers(request: ShiftCoverageRequest, candidates: CoverageCandidate[]): Promise<void> {
    const shiftTimeStr = new Date(request.shiftStartTime).toLocaleTimeString('en-US', { 
      hour: 'numeric', 
      minute: '2-digit',
      hour12: true 
    });
    const shiftDateStr = new Date(request.shiftStartTime).toLocaleDateString('en-US', {
      weekday: 'short',
      month: 'short',
      day: 'numeric',
    });

    for (const candidate of candidates) {
      try {
        const offerData: InsertShiftCoverageOffer = {
          coverageRequestId: request.id,
          employeeId: candidate.employeeId,
          workspaceId: request.workspaceId,
          status: 'pending',
          aiScore: candidate.aiScore.toString(),
          aiReason: candidate.aiReason,
        };

        const [offer] = await db.insert(shiftCoverageOffers)
          .values(offerData)
          .returning();

        if (candidate.userId) {
          await universalNotificationEngine.sendNotification({
            workspaceId: request.workspaceId,
            userId: candidate.userId,
            type: 'coverage_offer',
            title: `Can you cover a shift on ${shiftDateStr}?`,
            message: `We need someone to fill a shift at ${shiftTimeStr}. First to accept gets the shift! Tap to respond.`,
            severity: 'high',
            metadata: {
              coverageRequestId: request.id,
              coverageOfferId: offer.id,
              shiftId: request.originalShiftId,
              shiftDate: request.shiftDate,
              shiftStartTime: request.shiftStartTime,
              shiftEndTime: request.shiftEndTime,
              source: 'coverage_pipeline',
              actionable: true,
              actions: [
                { type: 'accept', label: 'Accept Shift', endpoint: `/api/coverage/accept/${offer.id}` },
                { type: 'decline', label: 'Decline', endpoint: `/api/coverage/decline/${offer.id}` },
              ],
            },
          });

          await db.update(shiftCoverageOffers)
            .set({ notificationId: offer.id })
            .where(eq(shiftCoverageOffers.id, offer.id));
        }

        console.log(`[CoveragePipeline] Sent offer to ${candidate.employeeName}`);

      } catch (error) {
        console.error(`[CoveragePipeline] Failed to send offer to ${candidate.employeeName}:`, error);
      }
    }
  }

  /**
   * Handle employee accepting a coverage offer - atomic first-accept-wins
   *
   * RACE CONDITION FIX: Uses SELECT FOR UPDATE to acquire exclusive row locks
   * on both the offer and request, ensuring only one concurrent transaction
   * can proceed with acceptance. The atomic conditional update on the request
   * status provides a second layer of protection.
   */
  async acceptOffer(offerId: string, employeeId: string): Promise<{ success: boolean; message: string; shiftId?: string }> {
    console.log(`[CoveragePipeline] Employee ${employeeId} accepting offer ${offerId}`);

    return await db.transaction(async (tx) => {
      // Step 1: Lock and fetch the offer with FOR UPDATE to prevent concurrent reads
      const offerResult = await tx.execute(sql`
        SELECT * FROM shift_coverage_offers
        WHERE id = ${offerId} AND employee_id = ${employeeId}
        FOR UPDATE
      `);

      const offer = (offerResult.rows as any[])[0];

      if (!offer) {
        return { success: false, message: 'Offer not found or not for this employee' };
      }

      if (offer.status !== 'pending') {
        return { success: false, message: `Offer already ${offer.status}` };
      }

      // Step 2: Lock and fetch the coverage request with FOR UPDATE
      // This prevents other transactions from reading/modifying until we commit
      const requestResult = await tx.execute(sql`
        SELECT * FROM shift_coverage_requests
        WHERE id = ${offer.coverage_request_id}
        FOR UPDATE
      `);

      const request = (requestResult.rows as any[])[0];

      if (!request) {
        return { success: false, message: 'Coverage request not found' };
      }

      if (request.status !== 'open') {
        // Request already claimed - mark this offer as superseded
        await tx.update(shiftCoverageOffers)
          .set({ status: 'superseded', respondedAt: new Date(), updatedAt: new Date() })
          .where(eq(shiftCoverageOffers.id, offerId));
        return { success: false, message: 'Sorry, someone else already accepted this shift' };
      }

      // Step 3: Atomic conditional update - only succeeds if status is still 'open'
      // This is the critical race-condition prevention: only one transaction wins
      const updateResult = await tx.execute(sql`
        UPDATE shift_coverage_requests
        SET status = 'accepted',
            accepted_at = NOW(),
            accepted_by_employee_id = ${employeeId},
            updated_at = NOW()
        WHERE id = ${request.id} AND status = 'open'
        RETURNING id
      `);

      // If no rows were updated, another transaction won the race
      if (!updateResult.rows || updateResult.rows.length === 0) {
        await tx.update(shiftCoverageOffers)
          .set({ status: 'superseded', respondedAt: new Date(), updatedAt: new Date() })
          .where(eq(shiftCoverageOffers.id, offerId));
        return { success: false, message: 'Sorry, someone else already accepted this shift' };
      }

      // Step 4: We won the race - update our offer to accepted
      await tx.update(shiftCoverageOffers)
        .set({ status: 'accepted', respondedAt: new Date(), updatedAt: new Date() })
        .where(eq(shiftCoverageOffers.id, offerId));

      // Step 5: Mark all other pending offers as superseded
      await tx.update(shiftCoverageOffers)
        .set({ status: 'superseded', updatedAt: new Date() })
        .where(
          and(
            eq(shiftCoverageOffers.coverageRequestId, request.id),
            ne(shiftCoverageOffers.id, offerId),
            eq(shiftCoverageOffers.status, 'pending')
          )
        );

      // Step 6: Create the new shift for the covering employee
      const originalShift = await tx.query.shifts.findFirst({
        where: eq(shifts.id, request.original_shift_id),
      });

      let newShiftId: string | undefined;

      if (originalShift) {
        const [newShift] = await tx.insert(shifts)
          .values({
            workspaceId: request.workspace_id,
            employeeId: employeeId,
            clientId: originalShift.clientId,
            title: `${originalShift.title || 'Shift'} (Coverage)`,
            date: originalShift.date,
            startTime: new Date(originalShift.startTime),
            endTime: new Date(originalShift.endTime),
            status: 'confirmed',
            aiGenerated: true,
            notes: `Coverage for original shift ${originalShift.id}. Reason: ${request.reason}`,
          } as any)
          .returning();

        newShiftId = newShift.id;

        // Step 7: Cancel the original shift
        await tx.update(shifts)
          .set({
            status: 'cancelled',
            notes: `Cancelled - covered by shift ${newShiftId}`
          } as any)
          .where(eq(shifts.id, request.original_shift_id));
      }

      // Step 8: Update request with the new shift ID
      await tx.update(shiftCoverageRequests)
        .set({
          newShiftId: newShiftId,
          updatedAt: new Date(),
        })
        .where(eq(shiftCoverageRequests.id, request.id));

      console.log(`[CoveragePipeline] Employee ${employeeId} successfully accepted coverage, new shift: ${newShiftId}`);
      return { success: true, message: 'You got the shift! Check your schedule.', shiftId: newShiftId };
    });
  }

  /**
   * Handle employee declining a coverage offer
   */
  async declineOffer(offerId: string, employeeId: string, reason?: string): Promise<{ success: boolean; message: string }> {
    console.log(`[CoveragePipeline] Employee ${employeeId} declining offer ${offerId}`);

    const offer = await db.query.shiftCoverageOffers.findFirst({
      where: and(
        eq(shiftCoverageOffers.id, offerId),
        eq(shiftCoverageOffers.employeeId, employeeId)
      ),
    });

    if (!offer) {
      return { success: false, message: 'Offer not found' };
    }

    if (offer.status !== 'pending') {
      return { success: false, message: `Offer already ${offer.status}` };
    }

    await db.update(shiftCoverageOffers)
      .set({
        status: 'declined',
        respondedAt: new Date(),
        declineReason: reason,
        updatedAt: new Date(),
      })
      .where(eq(shiftCoverageOffers.id, offerId));

    await db.update(shiftCoverageRequests)
      .set({
        offersDeclined: sql`${shiftCoverageRequests.offersDeclined} + 1`,
        updatedAt: new Date(),
      })
      .where(eq(shiftCoverageRequests.id, offer.coverageRequestId));

    return { success: true, message: 'Response recorded. Thanks for letting us know!' };
  }

  /**
   * Check for expired coverage requests and escalate
   */
  private async checkExpiredRequests(): Promise<void> {
    try {
      const expiredRequests = await db.select()
        .from(shiftCoverageRequests)
        .where(
          and(
            eq(shiftCoverageRequests.status, 'open'),
            lte(shiftCoverageRequests.expiresAt, new Date())
          )
        );

      for (const request of expiredRequests) {
        console.log(`[CoveragePipeline] Request ${request.id} expired, escalating`);
        
        await db.update(shiftCoverageOffers)
          .set({ status: 'expired', updatedAt: new Date() })
          .where(
            and(
              eq(shiftCoverageOffers.coverageRequestId, request.id),
              eq(shiftCoverageOffers.status, 'pending')
            )
          );

        await this.escalateToOrgOwner(request, 'No employees accepted within the time limit');
      }
    } catch (error) {
      console.error('[CoveragePipeline] Error checking expired requests:', error);
    }
  }

  /**
   * Escalate to org owner when no coverage found
   */
  private async escalateToOrgOwner(request: ShiftCoverageRequest, reason: string): Promise<void> {
    await db.update(shiftCoverageRequests)
      .set({
        status: 'escalated',
        escalatedAt: new Date(),
        trinityNotes: reason,
        updatedAt: new Date(),
      })
      .where(eq(shiftCoverageRequests.id, request.id));

    const orgOwners = await db.select()
      .from(employees)
      .where(
        and(
          eq(employees.workspaceId, request.workspaceId),
          or(
            eq(employees.workspaceRole as any, 'org_owner'),
            eq(employees.workspaceRole as any, 'org_admin')
          )
        )
      );

    const shiftTimeStr = new Date(request.shiftStartTime).toLocaleTimeString('en-US', {
      hour: 'numeric',
      minute: '2-digit',
      hour12: true,
    });
    const shiftDateStr = new Date(request.shiftStartTime).toLocaleDateString('en-US', {
      weekday: 'short',
      month: 'short',
      day: 'numeric',
    });

    for (const owner of orgOwners) {
      if (owner.userId) {
        await universalNotificationEngine.sendNotification({
          workspaceId: request.workspaceId,
          userId: owner.userId,
          type: 'issue_detected',
          title: 'Shift Coverage Needed - Manual Action Required',
          message: `Trinity couldn't find coverage for the ${shiftDateStr} at ${shiftTimeStr} shift. ${reason}. Please assign manually.`,
          severity: 'critical',
          metadata: {
            coverageRequestId: request.id,
            shiftId: request.originalShiftId,
            reason: request.reason,
            escalationReason: reason,
            candidatesInvited: request.candidatesInvited,
            offersDeclined: request.offersDeclined,
            source: 'coverage_pipeline_escalation',
          },
        });
      }
    }

    await platformEventBus.publish({
      type: 'coverage_escalated',
      category: 'scheduling',
      title: 'Coverage Escalation',
      description: `Manual intervention required for shift on ${shiftDateStr}`,
      workspaceId: request.workspaceId,
      metadata: {
        coverageRequestId: request.id,
        shiftId: request.originalShiftId,
        reason,
      },
    });

    console.log(`[CoveragePipeline] Escalated to ${orgOwners.length} org owner(s)`);
  }

  /**
   * Get coverage request status
   */
  async getRequestStatus(requestId: string): Promise<ShiftCoverageRequest | null> {
    const request = await db.query.shiftCoverageRequests.findFirst({
      where: eq(shiftCoverageRequests.id, requestId),
    });
    return request || null;
  }

  /**
   * Get all offers for a coverage request
   */
  async getRequestOffers(requestId: string): Promise<ShiftCoverageOffer[]> {
    return db.query.shiftCoverageOffers.findMany({
      where: eq(shiftCoverageOffers.coverageRequestId, requestId),
    });
  }
}

export const coveragePipeline = CoveragePipelineService.getInstance();

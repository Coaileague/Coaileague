import type { TimeEntry } from "@shared/schema";

/**
 * Rate Resolution Helper
 * 
 * Resolves billing and pay rates following the precedence order:
 * 1. Per-entry overrides (entry.hourlyRate from shift.hourlyRateOverride)
 * 2. Employee-specific rates (employee.hourlyRate)
 * 3. Client rates (clientRates.billableRate)
 * 4. Workspace defaults
 * 
 * This helper is used by both billable hours and payroll aggregators
 * to ensure consistent rate calculation across the platform.
 */

/**
 * Holiday Configuration (from workspace.holidayCalendar JSON)
 */
export interface HolidayEntry {
  date: string; // ISO date format "YYYY-MM-DD"
  name?: string; // Optional holiday name
  billMultiplier?: number; // Per-holiday billing override
  payMultiplier?: number; // Per-holiday pay override
}

/**
 * Convert a UTC timestamp to local date string (YYYY-MM-DD) in workspace timezone
 * Uses UTC as fallback if timezone not configured
 */
export function toLocalDateString(date: Date, timezone?: string): string {
  if (!timezone) {
    // Fallback to UTC if no timezone configured
    return date.toISOString().split('T')[0];
  }

  try {
    // Use Intl API for timezone-aware date formatting
    const formatter = new Intl.DateTimeFormat('en-CA', {
      timeZone: timezone,
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
    });
    
    // Format returns "YYYY-MM-DD" in en-CA locale
    return formatter.format(date);
  } catch (error) {
    console.warn(`[RateResolver] Invalid timezone "${timezone}", falling back to UTC`);
    return date.toISOString().split('T')[0];
  }
}

/**
 * Check if a given date is a holiday (timezone-aware)
 * @param date Date to check (UTC timestamp)
 * @param holidays Array of holiday configurations from workspace
 * @param timezone Workspace timezone (IANA format, e.g., "America/New_York")
 * @returns Holiday entry if found, null otherwise
 */
export function findHoliday(date: Date, holidays: any[], timezone?: string): HolidayEntry | null {
  if (!holidays || holidays.length === 0) {
    return null;
  }

  // Convert date to local date string in workspace timezone
  const dateStr = toLocalDateString(date, timezone);

  // Find matching holiday
  const holiday = holidays.find((h: any) => {
    if (typeof h === 'string') {
      return h === dateStr;
    }
    if (h && typeof h === 'object' && h.date) {
      return h.date === dateStr;
    }
    return false;
  });

  if (!holiday) {
    return null;
  }

  // Normalize to HolidayEntry format
  if (typeof holiday === 'string') {
    return { date: holiday };
  }

  return {
    date: holiday.date,
    name: holiday.name,
    billMultiplier: holiday.billMultiplier ? parseFloat(holiday.billMultiplier) : undefined,
    payMultiplier: holiday.payMultiplier ? parseFloat(holiday.payMultiplier) : undefined,
  };
}

/**
 * Daily segment for multi-day shift handling
 */
export interface DailySegment {
  date: string; // ISO date "YYYY-MM-DD" in workspace timezone
  startTime: Date; // UTC timestamp for segment start
  endTime: Date; // UTC timestamp for segment end
  hours: number; // Hours in this segment
}

/**
 * Split a shift spanning multiple calendar days into daily segments
 * Critical for correct holiday hour calculation
 * 
 * Example: Shift from Dec 25 22:00 → Dec 26 06:00 (8 hours)
 * Segments: [
 *   {date: "2025-12-25", hours: 2.0},  // 22:00-00:00
 *   {date: "2025-12-26", hours: 6.0}   // 00:00-06:00
 * ]
 */
export function splitShiftIntoDays(
  clockIn: Date,
  clockOut: Date,
  timezone?: string
): DailySegment[] {
  const segments: DailySegment[] = [];
  
  // Handle same-day shifts (optimization)
  const clockInDate = toLocalDateString(clockIn, timezone);
  const clockOutDate = toLocalDateString(clockOut, timezone);
  
  if (clockInDate === clockOutDate) {
    // Same calendar day - no split needed
    const hours = (clockOut.getTime() - clockIn.getTime()) / (1000 * 60 * 60);
    return [{
      date: clockInDate,
      startTime: clockIn,
      endTime: clockOut,
      hours: roundHours(hours),
    }];
  }

  // Multi-day shift - split at midnight boundaries in workspace timezone
  let currentTime = new Date(clockIn);
  
  while (currentTime < clockOut) {
    const currentDate = toLocalDateString(currentTime, timezone);
    
    // Find midnight of next day in workspace timezone
    const nextMidnight = getNextMidnight(currentTime, timezone);
    const segmentEnd = nextMidnight > clockOut ? clockOut : nextMidnight;
    
    const segmentHours = (segmentEnd.getTime() - currentTime.getTime()) / (1000 * 60 * 60);
    
    segments.push({
      date: currentDate,
      startTime: new Date(currentTime),
      endTime: new Date(segmentEnd),
      hours: roundHours(segmentHours),
    });
    
    currentTime = segmentEnd;
  }
  
  return segments;
}

/**
 * Get the next midnight in workspace timezone
 * Returns UTC timestamp representing midnight in the specified timezone
 * 
 * Approach: Format current and next-day dates in target timezone,
 * calculate offset, and apply to find UTC time of next midnight.
 */
function getNextMidnight(date: Date, timezone?: string): Date {
  if (!timezone) {
    // UTC fallback
    const next = new Date(date);
    next.setUTCDate(next.getUTCDate() + 1);
    next.setUTCHours(0, 0, 0, 0);
    return next;
  }

  try {
    // Get the current local date in the target timezone
    const currentLocalDate = toLocalDateString(date, timezone);
    const [year, month, day] = currentLocalDate.split('-').map(Number);
    
    // Calculate next day's date
    const nextDate = new Date(year, month - 1, day + 1);
    const nextYear = nextDate.getFullYear();
    const nextMonth = nextDate.getMonth() + 1;
    const nextDay = nextDate.getDate();
    
    // Create a probe date: assume next day midnight is at this UTC time
    const probeUTC = Date.UTC(nextYear, nextMonth - 1, nextDay, 0, 0, 0, 0);
    const probeDate = new Date(probeUTC);
    
    // Format this probe date as it appears in the target timezone
    const formatter = new Intl.DateTimeFormat('en-US', {
      timeZone: timezone,
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      hour12: false,
    });
    
    // Parse the formatted result to extract time offset
    const parts = formatter.formatToParts(probeDate);
    const tzHour = parseInt(parts.find(p => p.type === 'hour')!.value);
    const tzMinute = parseInt(parts.find(p => p.type === 'minute')!.value);
    
    // Calculate offset in milliseconds
    // If probe shows "08:00" in TZ when we set UTC to "00:00", 
    // then TZ is 8 hours ahead, so we need to subtract 8 hours from UTC
    const offsetMs = (tzHour * 60 + tzMinute) * 60 * 1000;
    
    // Apply offset to get true UTC time of next midnight in TZ
    const midnightUTC = new Date(probeUTC - offsetMs);
    
    // Validation: ensure result is actually after the input date
    if (midnightUTC <= date) {
      // If not, add 24 hours
      midnightUTC.setUTCHours(midnightUTC.getUTCHours() + 24);
    }
    
    return midnightUTC;
    
  } catch (error) {
    console.warn(`[RateResolver] Error calculating next midnight in ${timezone}:`, error);
    const fallback = new Date(date);
    fallback.setUTCDate(fallback.getUTCDate() + 1);
    fallback.setUTCHours(0, 0, 0, 0);
    return fallback;
  }
}

export interface RateResolutionContext {
  timeEntry: TimeEntry;
  employeeHourlyRate?: string | null;
  clientBillableRate?: string | null;
  workspaceDefaultRate?: string | null;
}

export interface ResolvedRates {
  billingRate: number;
  payRate: number;
  rateSource: 'entry_override' | 'employee_rate' | 'client_rate' | 'workspace_default' | 'none';
  hasWarning: boolean;
  warningMessage?: string;
}

/**
 * Resolve billing and pay rates for a time entry
 */
export function resolveRates(context: RateResolutionContext): ResolvedRates {
  const { timeEntry, employeeHourlyRate, clientBillableRate, workspaceDefaultRate } = context;

  // Precedence 1: Per-entry override (from shift.hourlyRateOverride)
  if (timeEntry.hourlyRate) {
    const rate = parseFloat(timeEntry.hourlyRate);
    return {
      billingRate: rate,
      payRate: rate, // Entry rate applies to both billing and pay
      rateSource: 'entry_override',
      hasWarning: false,
    };
  }

  // Precedence 2: Employee-specific rate
  if (employeeHourlyRate) {
    const rate = parseFloat(employeeHourlyRate);
    return {
      billingRate: clientBillableRate ? parseFloat(clientBillableRate) : rate,
      payRate: rate,
      rateSource: 'employee_rate',
      hasWarning: false,
    };
  }

  // Precedence 3: Client billable rate (for billing only)
  if (clientBillableRate) {
    const rate = parseFloat(clientBillableRate);
    return {
      billingRate: rate,
      payRate: 0, // No pay rate available - will need manual review
      rateSource: 'client_rate',
      hasWarning: true,
      warningMessage: `Time entry ${timeEntry.id} has client rate but no pay rate - requires manual review`,
    };
  }

  // Precedence 4: Workspace default
  if (workspaceDefaultRate) {
    const rate = parseFloat(workspaceDefaultRate);
    return {
      billingRate: rate,
      payRate: rate,
      rateSource: 'workspace_default',
      hasWarning: false,
    };
  }

  // No rate found - flag for manual review
  return {
    billingRate: 0,
    payRate: 0,
    rateSource: 'none',
    hasWarning: true,
    warningMessage: `Time entry ${timeEntry.id} has no applicable rate - requires manual review`,
  };
}

/**
 * Calculate total amount for a time entry
 */
export function calculateAmount(hours: number, rate: number): number {
  return parseFloat((hours * rate).toFixed(2));
}

/**
 * Round hours to configured precision (default 2 decimal places)
 */
export function roundHours(hours: number, precision: number = 2): number {
  const multiplier = Math.pow(10, precision);
  return Math.round(hours * multiplier) / multiplier;
}

/**
 * Group hours by category (regular, overtime, holiday)
 */
export interface HoursBucket {
  regularHours: number;
  overtimeHours: number;
  holidayHours: number;
}

/**
 * Bucket hours into regular, overtime, and holiday categories
 * Based on workspace overtime policy (40-hour weekly or 8-hour daily)
 */
export function bucketHours(params: {
  totalHours: number;
  weeklyHoursSoFar: number;
  enableDailyOvertime: boolean;
  dailyOvertimeThreshold?: number;
  weeklyOvertimeThreshold?: number;
  isHoliday?: boolean;
}): HoursBucket {
  const {
    totalHours,
    weeklyHoursSoFar,
    enableDailyOvertime,
    dailyOvertimeThreshold = 8,
    weeklyOvertimeThreshold = 40,
    isHoliday = false,
  } = params;

  // Holiday hours get special treatment - all hours count as holiday
  // Holidays override overtime calculation (per architect guidance)
  if (isHoliday) {
    return {
      regularHours: 0,
      overtimeHours: 0,
      holidayHours: roundHours(totalHours),
    };
  }

  let regularHours = 0;
  let overtimeHours = 0;

  // Daily overtime check
  if (enableDailyOvertime && totalHours > dailyOvertimeThreshold) {
    regularHours = dailyOvertimeThreshold;
    overtimeHours = roundHours(totalHours - dailyOvertimeThreshold);
  }
  // Weekly overtime check
  else if (weeklyHoursSoFar + totalHours > weeklyOvertimeThreshold) {
    const hoursBeforeOT = Math.max(0, weeklyOvertimeThreshold - weeklyHoursSoFar);
    regularHours = roundHours(hoursBeforeOT);
    overtimeHours = roundHours(totalHours - hoursBeforeOT);
  }
  // All regular hours
  else {
    regularHours = roundHours(totalHours);
    overtimeHours = 0;
  }

  return {
    regularHours,
    overtimeHours,
    holidayHours: 0,
  };
}

/**
 * Apply rate multipliers to bucketed hours
 * Precedence for multipliers: per-holiday override → client override → workspace default
 */
export interface MultiplierContext {
  baseRate: number;
  overtimeBillableMultiplier: number;
  overtimePayMultiplier: number;
  holidayBillableMultiplier: number;
  holidayPayMultiplier: number;
  holidayEntry?: HolidayEntry | null;
  clientOvertimeMultiplier?: number | null;
  clientHolidayMultiplier?: number | null;
}

export interface BucketedAmounts {
  regularAmount: number;
  overtimeAmount: number;
  holidayAmount: number;
  totalAmount: number;
  appliedMultipliers: {
    regular: number;
    overtime: number;
    holiday: number;
  };
}

/**
 * Calculate billing amounts with multipliers applied to each bucket
 */
export function calculateBillingAmounts(
  bucket: HoursBucket,
  context: MultiplierContext
): BucketedAmounts {
  const {
    baseRate,
    overtimeBillableMultiplier,
    holidayBillableMultiplier,
    holidayEntry,
    clientOvertimeMultiplier,
    clientHolidayMultiplier,
  } = context;

  // Resolve overtime multiplier (client override → workspace default)
  const otMultiplier = clientOvertimeMultiplier !== null && clientOvertimeMultiplier !== undefined
    ? clientOvertimeMultiplier
    : overtimeBillableMultiplier;

  // Resolve holiday multiplier (per-holiday → client override → workspace default)
  let holidayMultiplier = holidayBillableMultiplier;
  if (holidayEntry?.billMultiplier !== undefined) {
    holidayMultiplier = holidayEntry.billMultiplier;
  } else if (clientHolidayMultiplier !== null && clientHolidayMultiplier !== undefined) {
    holidayMultiplier = clientHolidayMultiplier;
  }

  // Calculate amounts per bucket
  const regularAmount = calculateAmount(bucket.regularHours, baseRate);
  const overtimeAmount = calculateAmount(bucket.overtimeHours, baseRate * otMultiplier);
  const holidayAmount = calculateAmount(bucket.holidayHours, baseRate * holidayMultiplier);

  return {
    regularAmount,
    overtimeAmount,
    holidayAmount,
    totalAmount: regularAmount + overtimeAmount + holidayAmount,
    appliedMultipliers: {
      regular: 1.0,
      overtime: otMultiplier,
      holiday: holidayMultiplier,
    },
  };
}

/**
 * Calculate payroll amounts with multipliers applied to each bucket
 */
export function calculatePayrollAmounts(
  bucket: HoursBucket,
  context: MultiplierContext
): BucketedAmounts {
  const {
    baseRate,
    overtimePayMultiplier,
    holidayPayMultiplier,
    holidayEntry,
  } = context;

  // For payroll, client overrides don't apply (employee-specific rates only)
  const otMultiplier = overtimePayMultiplier;

  // Resolve holiday multiplier (per-holiday → workspace default)
  const holidayMultiplier = holidayEntry?.payMultiplier !== undefined
    ? holidayEntry.payMultiplier
    : holidayPayMultiplier;

  // Calculate amounts per bucket
  const regularAmount = calculateAmount(bucket.regularHours, baseRate);
  const overtimeAmount = calculateAmount(bucket.overtimeHours, baseRate * otMultiplier);
  const holidayAmount = calculateAmount(bucket.holidayHours, baseRate * holidayMultiplier);

  return {
    regularAmount,
    overtimeAmount,
    holidayAmount,
    totalAmount: regularAmount + overtimeAmount + holidayAmount,
    appliedMultipliers: {
      regular: 1.0,
      overtime: otMultiplier,
      holiday: holidayMultiplier,
    },
  };
}

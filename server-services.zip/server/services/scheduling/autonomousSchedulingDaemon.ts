/**
 * AUTONOMOUS SCHEDULING DAEMON - Background Scheduling Service
 * =============================================================
 * 
 * Runs periodically to:
 * 1. Detect and fill coverage gaps
 * 2. Apply recurring templates for upcoming weeks
 * 3. Send alerts for unfilled critical shifts
 * 4. Optimize existing schedules
 */

import { db } from '../../db';
import { shifts, workspaces, schedulingSettings } from '@shared/schema';
import { eq, and, gte, lte, isNull, sql } from 'drizzle-orm';
import { trinityAutonomousScheduler } from './trinityAutonomousScheduler';
import { recurringScheduleTemplates } from './recurringScheduleTemplates';
import { broadcastToWorkspace } from '../../websocket';
import { auditLogger } from '../audit-logger';
import { automationOrchestration } from '../orchestration/automationOrchestration';

interface DaemonConfig {
  runIntervalMinutes: number;
  autoFillEnabled: boolean;
  templateGenerationEnabled: boolean;
  alertsEnabled: boolean;
  maxShiftsPerRun: number;
}

interface DaemonRunResult {
  runId: string;
  startTime: Date;
  endTime: Date;
  workspacesProcessed: number;
  shiftsAutoFilled: number;
  templatesApplied: number;
  alertsSent: number;
  errors: string[];
}

const DEFAULT_CONFIG: DaemonConfig = {
  runIntervalMinutes: 30,
  autoFillEnabled: true,
  templateGenerationEnabled: true,
  alertsEnabled: true,
  maxShiftsPerRun: 100,
};

class AutonomousSchedulingDaemonService {
  private static instance: AutonomousSchedulingDaemonService;
  private isRunning: boolean = false;
  private lastRunTime: Date | null = null;
  private runInterval: NodeJS.Timeout | null = null;
  private config: DaemonConfig = DEFAULT_CONFIG;
  private runHistory: DaemonRunResult[] = [];

  static getInstance(): AutonomousSchedulingDaemonService {
    if (!AutonomousSchedulingDaemonService.instance) {
      AutonomousSchedulingDaemonService.instance = new AutonomousSchedulingDaemonService();
    }
    return AutonomousSchedulingDaemonService.instance;
  }

  /**
   * Start the daemon
   */
  start(config?: Partial<DaemonConfig>): void {
    if (this.runInterval) {
      console.log('[SchedulingDaemon] Already running');
      return;
    }

    if (config) {
      this.config = { ...this.config, ...config };
    }

    console.log(`[SchedulingDaemon] Starting with ${this.config.runIntervalMinutes} minute interval`);

    // Run immediately on start
    this.runCycle();

    // Schedule recurring runs
    this.runInterval = setInterval(
      () => this.runCycle(),
      this.config.runIntervalMinutes * 60 * 1000
    );
  }

  /**
   * Stop the daemon
   */
  stop(): void {
    if (this.runInterval) {
      clearInterval(this.runInterval);
      this.runInterval = null;
      console.log('[SchedulingDaemon] Stopped');
    }
  }

  /**
   * Run a single scheduling cycle with full 7-step orchestration
   */
  async runCycle(): Promise<DaemonRunResult> {
    if (this.isRunning) {
      console.log('[SchedulingDaemon] Skipping cycle - previous run still in progress');
      return this.getEmptyResult();
    }

    this.isRunning = true;
    const runId = `daemon-${Date.now()}`;
    const startTime = new Date();
    
    console.log(`[SchedulingDaemon] Starting cycle ${runId}`);

    const result: DaemonRunResult = {
      runId,
      startTime,
      endTime: new Date(),
      workspacesProcessed: 0,
      shiftsAutoFilled: 0,
      templatesApplied: 0,
      alertsSent: 0,
      errors: [],
    };

    try {
      const activeWorkspaces = await this.getActiveWorkspaces();
      console.log(`[SchedulingDaemon] Found ${activeWorkspaces.length} active workspaces`);

      for (const workspace of activeWorkspaces) {
        const orchestrationResult = await automationOrchestration.executeAutomation(
          {
            domain: 'scheduling',
            automationName: 'autonomous-scheduling-daemon',
            automationType: 'daemon',
            workspaceId: workspace.id,
            triggeredBy: 'cron',
            payload: {
              runId,
              config: this.config,
            },
            billable: false,
          },
          async (ctx) => {
            return await this.processWorkspace(workspace);
          },
          {
            fetch: async (ctx) => ({
              workspaceId: workspace.id,
              workspaceName: workspace.name,
              config: this.config,
            }),
            validate: async (ctx) => {
              if (!workspace.id) {
                return { valid: false, errors: ['Invalid workspace ID'] };
              }
              return { valid: true };
            },
            notify: async (workspaceResult, ctx) => {
              if (workspaceResult.shiftsAutoFilled > 0 || workspaceResult.alertsSent > 0) {
                broadcastToWorkspace(workspace.id, {
                  type: 'scheduling_daemon_update',
                  payload: {
                    shiftsAutoFilled: workspaceResult.shiftsAutoFilled,
                    templatesApplied: workspaceResult.templatesApplied,
                    alertsSent: workspaceResult.alertsSent,
                    orchestrationId: ctx.orchestrationId,
                  },
                });
              }
            },
          }
        );

        if (orchestrationResult.success && orchestrationResult.data) {
          result.workspacesProcessed++;
          result.shiftsAutoFilled += orchestrationResult.data.shiftsAutoFilled;
          result.templatesApplied += orchestrationResult.data.templatesApplied;
          result.alertsSent += orchestrationResult.data.alertsSent;
        } else if (!orchestrationResult.success) {
          result.errors.push(`Workspace ${workspace.id}: ${orchestrationResult.error} (${orchestrationResult.errorCode})`);
          console.error(`[SchedulingDaemon] Orchestrated error for ${workspace.id}:`, orchestrationResult.error);
        }
      }

      result.endTime = new Date();
      this.lastRunTime = result.endTime;
      this.runHistory.push(result);

      if (this.runHistory.length > 100) {
        this.runHistory = this.runHistory.slice(-100);
      }

      console.log(`[SchedulingDaemon] Cycle completed: ${result.shiftsAutoFilled} shifts filled, ${result.templatesApplied} templates applied`);

    } catch (error: any) {
      result.errors.push(`Critical error: ${error.message}`);
      console.error('[SchedulingDaemon] Critical error:', error);
    } finally {
      this.isRunning = false;
    }

    return result;
  }

  /**
   * Get workspaces with autonomous scheduling enabled
   */
  private async getActiveWorkspaces(): Promise<any[]> {
    // Get workspaces that have scheduling settings enabled
    try {
      const allWorkspaces = await db.select()
        .from(workspaces)
        .where(eq(workspaces.status, 'active'));

      // For now, return all active workspaces
      // In production, filter by those with autonomous scheduling enabled
      return allWorkspaces;
    } catch (error) {
      console.error('[SchedulingDaemon] Error getting workspaces:', error);
      return [];
    }
  }

  /**
   * Process a single workspace
   */
  private async processWorkspace(workspace: any): Promise<{
    shiftsAutoFilled: number;
    templatesApplied: number;
    alertsSent: number;
  }> {
    let shiftsAutoFilled = 0;
    let templatesApplied = 0;
    let alertsSent = 0;

    // 1. Check for urgent unfilled shifts (starting within 4 hours)
    const urgentShifts = await this.getUrgentUnfilledShifts(workspace.id);
    
    if (urgentShifts.length > 0 && this.config.alertsEnabled) {
      // Send alerts for critical unfilled shifts
      await this.sendUrgentAlerts(workspace.id, urgentShifts);
      alertsSent += urgentShifts.length;
    }

    // 2. Auto-fill open shifts for current day
    if (this.config.autoFillEnabled) {
      const openShifts = await this.getOpenShiftsForToday(workspace.id);
      
      if (openShifts.length > 0) {
        try {
          const fillResult = await trinityAutonomousScheduler.executeAutonomousScheduling({
            workspaceId: workspace.id,
            userId: 'system-daemon',
            mode: 'current_day',
            prioritizeBy: 'urgency',
            useContractorFallback: true,
            maxShiftsPerEmployee: 2,
            respectAvailability: true,
          });

          shiftsAutoFilled = fillResult.summary.totalAssigned;
        } catch (error: any) {
          console.error(`[SchedulingDaemon] Auto-fill error for ${workspace.id}:`, error);
        }
      }
    }

    // 3. Apply templates for next week (on Sundays)
    if (this.config.templateGenerationEnabled) {
      const today = new Date();
      if (today.getDay() === 0) { // Sunday
        try {
          const templateResult = await recurringScheduleTemplates.generateNextWeek(workspace.id);
          templatesApplied = templateResult.templatesApplied;
        } catch (error: any) {
          console.error(`[SchedulingDaemon] Template generation error for ${workspace.id}:`, error);
        }
      }
    }

    return { shiftsAutoFilled, templatesApplied, alertsSent };
  }

  /**
   * Get urgent unfilled shifts (starting within 4 hours)
   */
  private async getUrgentUnfilledShifts(workspaceId: string): Promise<any[]> {
    const now = new Date();
    const fourHoursFromNow = new Date(now.getTime() + 4 * 60 * 60 * 1000);

    return db.select()
      .from(shifts)
      .where(and(
        eq(shifts.workspaceId, workspaceId),
        isNull(shifts.employeeId),
        gte(shifts.startTime, now),
        lte(shifts.startTime, fourHoursFromNow)
      ));
  }

  /**
   * Get open shifts for today
   */
  private async getOpenShiftsForToday(workspaceId: string): Promise<any[]> {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    const tomorrow = new Date(today);
    tomorrow.setDate(tomorrow.getDate() + 1);

    return db.select()
      .from(shifts)
      .where(and(
        eq(shifts.workspaceId, workspaceId),
        isNull(shifts.employeeId),
        gte(shifts.startTime, today),
        lte(shifts.startTime, tomorrow)
      ));
  }

  /**
   * Send urgent alerts for unfilled shifts
   */
  private async sendUrgentAlerts(workspaceId: string, urgentShifts: any[]): Promise<void> {
    // Broadcast alert to workspace
    broadcastToWorkspace(workspaceId, {
      type: 'trinity_urgent_alert',
      alertType: 'unfilled_shifts',
      message: `${urgentShifts.length} shift(s) starting within 4 hours are still unfilled!`,
      shifts: urgentShifts.map(s => ({
        id: s.id,
        title: s.title,
        startTime: s.startTime,
      })),
      timestamp: Date.now(),
    });

    // Log for audit
    await auditLogger.logWithWorkspace({
      workspaceId,
      userId: 'system-daemon',
      action: 'TRINITY_URGENT_ALERT',
      targetType: 'shift',
      targetId: 'multiple',
      details: {
        shiftCount: urgentShifts.length,
        shiftIds: urgentShifts.map(s => s.id),
      },
      riskLevel: 'high',
    });
  }

  /**
   * Get daemon status
   */
  getStatus(): {
    isRunning: boolean;
    lastRunTime: Date | null;
    config: DaemonConfig;
    recentRuns: DaemonRunResult[];
  } {
    return {
      isRunning: this.isRunning,
      lastRunTime: this.lastRunTime,
      config: this.config,
      recentRuns: this.runHistory.slice(-10),
    };
  }

  /**
   * Trigger manual run for a specific workspace
   */
  async triggerManualRun(workspaceId: string, mode: 'current_day' | 'current_week' | 'next_week'): Promise<{
    success: boolean;
    result: any;
  }> {
    try {
      const result = await trinityAutonomousScheduler.executeAutonomousScheduling({
        workspaceId,
        userId: 'manual-trigger',
        mode,
        prioritizeBy: 'urgency',
        useContractorFallback: true,
        maxShiftsPerEmployee: 3,
        respectAvailability: true,
      });

      return { success: true, result };
    } catch (error: any) {
      return { success: false, result: { error: error.message } };
    }
  }

  /**
   * Get empty result for skipped runs
   */
  private getEmptyResult(): DaemonRunResult {
    return {
      runId: 'skipped',
      startTime: new Date(),
      endTime: new Date(),
      workspacesProcessed: 0,
      shiftsAutoFilled: 0,
      templatesApplied: 0,
      alertsSent: 0,
      errors: ['Skipped - previous run in progress'],
    };
  }
}

export const autonomousSchedulingDaemon = AutonomousSchedulingDaemonService.getInstance();

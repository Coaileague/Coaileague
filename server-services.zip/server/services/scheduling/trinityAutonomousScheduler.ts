/**
 * TRINITY AUTONOMOUS SCHEDULER - Fortune 500-Grade Intelligent Scheduling
 * ========================================================================
 * 
 * Trinity's core scheduling brain that processes schedules systematically:
 * 1. Processes current day FIRST (immediate needs)
 * 2. Then tomorrow (next priority)
 * 3. Then rest of current week (week completion)
 * 4. Then next week (forward planning)
 * 
 * Features:
 * - Day-by-day systematic processing
 * - Demand/urgency priority scoring
 * - Historical pattern learning
 * - Multi-tier escalation (internal → contractors → partners)
 * - Real-time WebSocket feedback
 */

import { db } from '../../db';
import { 
  employees, 
  shifts, 
  clients,
  employeeAvailability,
  performanceReviews,
  timeEntries,
  contractorPool
} from '@shared/schema';
import { eq, and, gte, lte, isNull, desc, asc, sql, or, inArray } from 'drizzle-orm';
import { broadcastToWorkspace } from '../../websocket';
import { auditLogger } from '../audit-logger';

interface SchedulingConfig {
  workspaceId: string;
  userId: string;
  mode: 'current_day' | 'current_week' | 'next_week' | 'full_month';
  prioritizeBy: 'urgency' | 'value' | 'chronological';
  useContractorFallback: boolean;
  maxShiftsPerEmployee: number;
  respectAvailability: boolean;
}

interface ShiftPriority {
  shiftId: string;
  shift: any;
  priorityScore: number;
  urgencyLevel: 'critical' | 'high' | 'medium' | 'low';
  factors: {
    hoursUntilStart: number;
    contractValue: number;
    clientTier: string;
    daysUnfilled: number;
    isRecurring: boolean;
  };
}

interface EmployeeScore {
  employeeId: string;
  employee: any;
  score: number;
  breakdown: {
    reliabilityScore: number;
    proximityScore: number;
    availabilityScore: number;
    performanceScore: number;
    seniorityScore: number;
    workloadBalance: number;
  };
  disqualifyReasons: string[];
}

interface AssignmentResult {
  shiftId: string;
  employeeId: string | null;
  success: boolean;
  confidence: number;
  reasoning: string;
  escalationLevel: number;
}

interface SchedulingSession {
  sessionId: string;
  workspaceId: string;
  startTime: Date;
  status: 'running' | 'completed' | 'failed';
  progress: {
    totalShifts: number;
    processedShifts: number;
    assignedShifts: number;
    failedShifts: number;
    skippedShifts: number;
  };
  thoughtLog: string[];
  dayProgress: Map<string, { total: number; filled: number }>;
}

const URGENCY_WEIGHTS = {
  hoursUntilStart: 0.35,
  contractValue: 0.25,
  clientTier: 0.20,
  daysUnfilled: 0.15,
  isRecurring: 0.05,
};

const EMPLOYEE_SCORE_WEIGHTS = {
  reliability: 0.25,
  proximity: 0.20,
  availability: 0.20,
  performance: 0.15,
  seniority: 0.10,
  workloadBalance: 0.10,
};

class TrinityAutonomousSchedulerService {
  private static instance: TrinityAutonomousSchedulerService;
  private activeSessions: Map<string, SchedulingSession> = new Map();
  private historicalPatterns: Map<string, any> = new Map();

  static getInstance(): TrinityAutonomousSchedulerService {
    if (!TrinityAutonomousSchedulerService.instance) {
      TrinityAutonomousSchedulerService.instance = new TrinityAutonomousSchedulerService();
    }
    return TrinityAutonomousSchedulerService.instance;
  }

  /**
   * MAIN ENTRY POINT: Execute autonomous scheduling for a workspace
   */
  async executeAutonomousScheduling(config: SchedulingConfig): Promise<{
    success: boolean;
    session: SchedulingSession;
    summary: {
      totalProcessed: number;
      totalAssigned: number;
      totalFailed: number;
      daysProcessed: number;
      avgConfidence: number;
    };
  }> {
    const sessionId = `trinity-sched-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
    
    const session: SchedulingSession = {
      sessionId,
      workspaceId: config.workspaceId,
      startTime: new Date(),
      status: 'running',
      progress: {
        totalShifts: 0,
        processedShifts: 0,
        assignedShifts: 0,
        failedShifts: 0,
        skippedShifts: 0,
      },
      thoughtLog: [],
      dayProgress: new Map(),
    };

    this.activeSessions.set(sessionId, session);

    try {
      session.thoughtLog.push(`[Trinity] Starting autonomous scheduling session ${sessionId}`);
      session.thoughtLog.push(`[Trinity] Mode: ${config.mode}, Priority: ${config.prioritizeBy}`);

      // Broadcast session start
      broadcastToWorkspace(config.workspaceId, {
        type: 'trinity_scheduling_started',
        sessionId,
        mode: config.mode,
        timestamp: Date.now(),
      });

      // Step 1: Get date ranges based on mode
      const dateRanges = this.getDateRanges(config.mode);
      session.thoughtLog.push(`[Trinity] Processing ${dateRanges.length} date ranges`);

      // Step 2: Load all required data
      const [allEmployees, allClients, historicalData] = await Promise.all([
        this.loadEmployees(config.workspaceId),
        this.loadClients(config.workspaceId),
        this.loadHistoricalPatterns(config.workspaceId),
      ]);

      session.thoughtLog.push(`[Trinity] Loaded ${allEmployees.length} employees, ${allClients.length} clients`);

      let totalConfidence = 0;
      let assignmentCount = 0;

      // Step 3: Process each date range systematically (day by day)
      for (const dateRange of dateRanges) {
        session.thoughtLog.push(`[Trinity] Processing: ${dateRange.label}`);

        // Get open shifts for this date range
        const openShifts = await this.getOpenShiftsForRange(
          config.workspaceId,
          dateRange.start,
          dateRange.end
        );

        if (openShifts.length === 0) {
          session.thoughtLog.push(`[Trinity] No open shifts for ${dateRange.label}`);
          continue;
        }

        session.progress.totalShifts += openShifts.length;
        session.dayProgress.set(dateRange.label, { total: openShifts.length, filled: 0 });

        // Step 4: Prioritize shifts by urgency/value
        const prioritizedShifts = this.prioritizeShifts(openShifts, allClients, config.prioritizeBy);
        session.thoughtLog.push(`[Trinity] Prioritized ${prioritizedShifts.length} shifts for ${dateRange.label}`);

        // Step 5: Process each shift
        for (let i = 0; i < prioritizedShifts.length; i++) {
          const priorityShift = prioritizedShifts[i];
          
          // Broadcast progress
          broadcastToWorkspace(config.workspaceId, {
            type: 'trinity_scheduling_progress',
            sessionId,
            currentShiftId: priorityShift.shiftId,
            currentIndex: session.progress.processedShifts + 1,
            totalShifts: session.progress.totalShifts,
            status: 'analyzing',
            message: `Analyzing: ${priorityShift.shift.title} (${priorityShift.urgencyLevel} priority)`,
            shiftTitle: priorityShift.shift.title,
            dayLabel: dateRange.label,
          });

          // Step 6: Find best employee for this shift
          const result = await this.assignShift(
            priorityShift,
            allEmployees,
            allClients,
            config,
            session
          );

          session.progress.processedShifts++;

          if (result.success && result.employeeId) {
            session.progress.assignedShifts++;
            totalConfidence += result.confidence;
            assignmentCount++;
            
            const dayProg = session.dayProgress.get(dateRange.label);
            if (dayProg) dayProg.filled++;

            // Broadcast successful assignment
            broadcastToWorkspace(config.workspaceId, {
              type: 'trinity_scheduling_progress',
              sessionId,
              currentShiftId: priorityShift.shiftId,
              currentIndex: session.progress.processedShifts,
              totalShifts: session.progress.totalShifts,
              status: 'assigned',
              message: `Assigned: ${result.reasoning}`,
              shiftTitle: priorityShift.shift.title,
              employeeId: result.employeeId,
              confidence: result.confidence,
            });
          } else {
            session.progress.failedShifts++;
            session.progress.skippedShifts = (session.progress.skippedShifts || 0) + 1;
            
            broadcastToWorkspace(config.workspaceId, {
              type: 'trinity_scheduling_progress',
              sessionId,
              currentShiftId: priorityShift.shiftId,
              currentIndex: session.progress.processedShifts,
              totalShifts: session.progress.totalShifts,
              status: 'skipped',
              message: `Skipped ${priorityShift.shift.title}: ${result.reasoning}`,
              shiftTitle: priorityShift.shift.title,
              skipReason: result.reasoning,
            });
          }

          // Small delay for visual feedback
          await new Promise(resolve => setTimeout(resolve, 150));
        }

        session.thoughtLog.push(`[Trinity] Completed ${dateRange.label}: ${session.dayProgress.get(dateRange.label)?.filled || 0}/${openShifts.length} filled`);
      }

      // Step 7: Complete session
      session.status = 'completed';
      const avgConfidence = assignmentCount > 0 ? totalConfidence / assignmentCount : 0;

      // Broadcast completion
      broadcastToWorkspace(config.workspaceId, {
        type: 'trinity_scheduling_completed',
        sessionId,
        totalAssigned: session.progress.assignedShifts,
        totalFailed: session.progress.failedShifts,
        totalSkipped: session.progress.skippedShifts || session.progress.failedShifts,
        totalShifts: session.progress.totalShifts,
        openShiftsRemaining: session.progress.failedShifts,
        duration: Date.now() - session.startTime.getTime(),
        summary: {
          openShiftsFilled: session.progress.assignedShifts,
          openShiftsSkipped: session.progress.skippedShifts || session.progress.failedShifts,
          openShiftsRemaining: session.progress.failedShifts,
          avgConfidence: Math.round(avgConfidence * 100),
        },
      });

      // Audit log
      await auditLogger.logWithWorkspace({
        workspaceId: config.workspaceId,
        userId: config.userId,
        action: 'TRINITY_AUTONOMOUS_SCHEDULING',
        targetType: 'shift',
        targetId: sessionId,
        details: {
          mode: config.mode,
          totalProcessed: session.progress.processedShifts,
          totalAssigned: session.progress.assignedShifts,
          totalFailed: session.progress.failedShifts,
          avgConfidence,
        },
        riskLevel: 'low',
      });

      return {
        success: true,
        session,
        summary: {
          totalProcessed: session.progress.processedShifts,
          totalAssigned: session.progress.assignedShifts,
          totalFailed: session.progress.failedShifts,
          daysProcessed: session.dayProgress.size,
          avgConfidence,
        },
      };

    } catch (error: any) {
      session.status = 'failed';
      session.thoughtLog.push(`[Trinity] ERROR: ${error.message}`);
      
      broadcastToWorkspace(config.workspaceId, {
        type: 'trinity_scheduling_error',
        sessionId,
        error: error.message,
      });

      throw error;
    } finally {
      this.activeSessions.delete(sessionId);
    }
  }

  /**
   * Get date ranges based on scheduling mode
   */
  private getDateRanges(mode: string): Array<{ label: string; start: Date; end: Date }> {
    const ranges: Array<{ label: string; start: Date; end: Date }> = [];
    const now = new Date();
    now.setHours(0, 0, 0, 0);

    // Today - ALWAYS FIRST PRIORITY
    const todayEnd = new Date(now);
    todayEnd.setHours(23, 59, 59, 999);
    ranges.push({ label: 'Today', start: new Date(now), end: todayEnd });

    if (mode === 'current_day') {
      return ranges;
    }

    // Tomorrow - SECOND PRIORITY
    const tomorrow = new Date(now);
    tomorrow.setDate(tomorrow.getDate() + 1);
    const tomorrowEnd = new Date(tomorrow);
    tomorrowEnd.setHours(23, 59, 59, 999);
    ranges.push({ label: 'Tomorrow', start: tomorrow, end: tomorrowEnd });

    // Rest of current week
    const dayOfWeek = now.getDay();
    const daysUntilEndOfWeek = 6 - dayOfWeek; // Saturday is 6
    
    for (let i = 2; i <= daysUntilEndOfWeek; i++) {
      const day = new Date(now);
      day.setDate(day.getDate() + i);
      const dayEnd = new Date(day);
      dayEnd.setHours(23, 59, 59, 999);
      const dayName = day.toLocaleDateString('en-US', { weekday: 'long' });
      ranges.push({ label: dayName, start: day, end: dayEnd });
    }

    if (mode === 'current_week') {
      return ranges;
    }

    // Next week
    if (mode === 'next_week' || mode === 'full_month') {
      const nextWeekStart = new Date(now);
      nextWeekStart.setDate(nextWeekStart.getDate() + (7 - dayOfWeek + 1)); // Next Monday
      
      for (let i = 0; i < 7; i++) {
        const day = new Date(nextWeekStart);
        day.setDate(day.getDate() + i);
        const dayEnd = new Date(day);
        dayEnd.setHours(23, 59, 59, 999);
        const dayName = day.toLocaleDateString('en-US', { weekday: 'long', month: 'short', day: 'numeric' });
        ranges.push({ label: `Next ${dayName}`, start: day, end: dayEnd });
      }
    }

    return ranges;
  }

  /**
   * Load all employees for workspace
   */
  private async loadEmployees(workspaceId: string): Promise<any[]> {
    return db.select()
      .from(employees)
      .where(and(
        eq(employees.workspaceId, workspaceId),
        eq(employees.status, 'active')
      ));
  }

  /**
   * Load all clients for workspace
   */
  private async loadClients(workspaceId: string): Promise<any[]> {
    return db.select()
      .from(clients)
      .where(eq(clients.workspaceId, workspaceId));
  }

  /**
   * Load historical scheduling patterns
   */
  private async loadHistoricalPatterns(workspaceId: string): Promise<any> {
    const threeMonthsAgo = new Date();
    threeMonthsAgo.setMonth(threeMonthsAgo.getMonth() - 3);

    const historicalShifts = await db.select()
      .from(shifts)
      .where(and(
        eq(shifts.workspaceId, workspaceId),
        gte(shifts.startTime, threeMonthsAgo),
        sql`${shifts.employeeId} IS NOT NULL`
      ));

    return {
      totalShifts: historicalShifts.length,
      patterns: this.analyzePatterns(historicalShifts),
    };
  }

  /**
   * Analyze historical patterns for learning
   */
  private analyzePatterns(historicalShifts: any[]): any {
    const patterns: any = {
      dayOfWeek: new Map<number, number>(),
      hourOfDay: new Map<number, number>(),
      clientFrequency: new Map<string, number>(),
      employeeClientPairs: new Map<string, number>(),
    };

    for (const shift of historicalShifts) {
      const startTime = new Date(shift.startTime);
      const dayOfWeek = startTime.getDay();
      const hourOfDay = startTime.getHours();

      patterns.dayOfWeek.set(dayOfWeek, (patterns.dayOfWeek.get(dayOfWeek) || 0) + 1);
      patterns.hourOfDay.set(hourOfDay, (patterns.hourOfDay.get(hourOfDay) || 0) + 1);
      
      if (shift.clientId) {
        patterns.clientFrequency.set(shift.clientId, (patterns.clientFrequency.get(shift.clientId) || 0) + 1);
      }
      
      if (shift.employeeId && shift.clientId) {
        const pair = `${shift.employeeId}:${shift.clientId}`;
        patterns.employeeClientPairs.set(pair, (patterns.employeeClientPairs.get(pair) || 0) + 1);
      }
    }

    return patterns;
  }

  /**
   * Get open (unassigned) shifts for a date range
   */
  private async getOpenShiftsForRange(
    workspaceId: string,
    startDate: Date,
    endDate: Date
  ): Promise<any[]> {
    return db.select()
      .from(shifts)
      .where(and(
        eq(shifts.workspaceId, workspaceId),
        isNull(shifts.employeeId),
        gte(shifts.startTime, startDate),
        lte(shifts.startTime, endDate)
      ))
      .orderBy(asc(shifts.startTime));
  }

  /**
   * Prioritize shifts by urgency/value
   */
  private prioritizeShifts(
    openShifts: any[],
    allClients: any[],
    prioritizeBy: string
  ): ShiftPriority[] {
    const now = new Date();
    const clientMap = new Map(allClients.map(c => [c.id, c]));

    const prioritized: ShiftPriority[] = openShifts.map(shift => {
      const client = clientMap.get(shift.clientId);
      const startTime = new Date(shift.startTime);
      const hoursUntilStart = (startTime.getTime() - now.getTime()) / (1000 * 60 * 60);
      
      // Calculate days unfilled (if createdAt available)
      const createdAt = shift.createdAt ? new Date(shift.createdAt) : now;
      const daysUnfilled = (now.getTime() - createdAt.getTime()) / (1000 * 60 * 60 * 24);

      // Contract value (default to rate or estimate)
      const contractValue = parseFloat(shift.contractRate || shift.hourlyRateOverride || '25');

      // Client tier (premium, standard, basic)
      const clientTier = client?.tier || 'standard';
      const tierScore = clientTier === 'premium' ? 1.0 : clientTier === 'standard' ? 0.6 : 0.3;

      // Calculate priority score
      let priorityScore = 0;

      // Hours until start (closer = more urgent)
      const urgencyFromTime = Math.max(0, 1 - (hoursUntilStart / 168)); // 168 hours = 1 week
      priorityScore += urgencyFromTime * URGENCY_WEIGHTS.hoursUntilStart;

      // Contract value
      const valueScore = Math.min(1, contractValue / 100); // Normalize to 0-1
      priorityScore += valueScore * URGENCY_WEIGHTS.contractValue;

      // Client tier
      priorityScore += tierScore * URGENCY_WEIGHTS.clientTier;

      // Days unfilled
      const unfilledScore = Math.min(1, daysUnfilled / 7);
      priorityScore += unfilledScore * URGENCY_WEIGHTS.daysUnfilled;

      // Determine urgency level
      let urgencyLevel: 'critical' | 'high' | 'medium' | 'low';
      if (hoursUntilStart < 4) {
        urgencyLevel = 'critical';
      } else if (hoursUntilStart < 24) {
        urgencyLevel = 'high';
      } else if (hoursUntilStart < 72) {
        urgencyLevel = 'medium';
      } else {
        urgencyLevel = 'low';
      }

      return {
        shiftId: shift.id,
        shift,
        priorityScore,
        urgencyLevel,
        factors: {
          hoursUntilStart,
          contractValue,
          clientTier,
          daysUnfilled,
          isRecurring: shift.isRecurring || false,
        },
      };
    });

    // Sort by priority score (highest first)
    return prioritized.sort((a, b) => b.priorityScore - a.priorityScore);
  }

  /**
   * Assign a shift to the best available employee
   */
  private async assignShift(
    priorityShift: ShiftPriority,
    allEmployees: any[],
    allClients: any[],
    config: SchedulingConfig,
    session: SchedulingSession
  ): Promise<AssignmentResult> {
    const shift = priorityShift.shift;
    const client = allClients.find(c => c.id === shift.clientId);

    session.thoughtLog.push(`[Trinity] Evaluating candidates for: ${shift.title}`);

    // Score all employees
    const scoredEmployees = await this.scoreEmployeesForShift(
      shift,
      allEmployees,
      client,
      config
    );

    // Filter out disqualified employees
    const qualifiedEmployees = scoredEmployees.filter(e => e.disqualifyReasons.length === 0);

    if (qualifiedEmployees.length === 0) {
      session.thoughtLog.push(`[Trinity] No qualified employees for ${shift.title}`);
      
      // Try contractor fallback if enabled
      if (config.useContractorFallback) {
        const contractorResult = await this.tryContractorFallback(shift, config.workspaceId);
        if (contractorResult.success) {
          return contractorResult;
        }
      }

      return {
        shiftId: shift.id,
        employeeId: null,
        success: false,
        confidence: 0,
        reasoning: 'No qualified employees available',
        escalationLevel: 2,
      };
    }

    // Pick the best employee
    const bestEmployee = qualifiedEmployees[0];
    
    // Update shift in database
    await db.update(shifts)
      .set({
        employeeId: bestEmployee.employeeId,
        status: 'scheduled',
        aiGenerated: true,
      })
      .where(eq(shifts.id, shift.id));

    session.thoughtLog.push(`[Trinity] Assigned ${bestEmployee.employee.firstName} ${bestEmployee.employee.lastName} to ${shift.title} (score: ${bestEmployee.score.toFixed(2)})`);

    return {
      shiftId: shift.id,
      employeeId: bestEmployee.employeeId,
      success: true,
      confidence: bestEmployee.score,
      reasoning: `${bestEmployee.employee.firstName} ${bestEmployee.employee.lastName} (score: ${(bestEmployee.score * 100).toFixed(0)}%)`,
      escalationLevel: 0,
    };
  }

  /**
   * Score all employees for a specific shift
   */
  private async scoreEmployeesForShift(
    shift: any,
    allEmployees: any[],
    client: any,
    config: SchedulingConfig
  ): Promise<EmployeeScore[]> {
    const shiftStart = new Date(shift.startTime);
    const shiftEnd = new Date(shift.endTime);
    const shiftDayOfWeek = shiftStart.getDay();
    const dayNames = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'];
    const dayName = dayNames[shiftDayOfWeek];

    // Get existing assignments for the week to check workload
    const weekStart = new Date(shiftStart);
    weekStart.setDate(weekStart.getDate() - weekStart.getDay());
    const weekEnd = new Date(weekStart);
    weekEnd.setDate(weekEnd.getDate() + 6);

    const weeklyAssignments = await db.select({
      employeeId: shifts.employeeId,
      count: sql<number>`count(*)`,
    })
      .from(shifts)
      .where(and(
        eq(shifts.workspaceId, config.workspaceId),
        sql`${shifts.employeeId} IS NOT NULL`,
        gte(shifts.startTime, weekStart),
        lte(shifts.startTime, weekEnd)
      ))
      .groupBy(shifts.employeeId);

    const assignmentMap = new Map(weeklyAssignments.map(a => [a.employeeId, Number(a.count)]));

    // Score each employee
    const scores: EmployeeScore[] = [];

    for (const employee of allEmployees) {
      const disqualifyReasons: string[] = [];

      // Check for conflicts (overlapping shifts)
      const hasConflict = await this.checkShiftConflict(employee.id, shiftStart, shiftEnd);
      if (hasConflict) {
        disqualifyReasons.push('Schedule conflict');
      }

      // Check availability if enabled
      if (config.respectAvailability) {
        // TODO: Check employeeAvailability table
      }

      // Check max shifts per employee
      const currentAssignments = assignmentMap.get(employee.id) || 0;
      if (currentAssignments >= config.maxShiftsPerEmployee) {
        disqualifyReasons.push(`Already has ${currentAssignments} shifts this week`);
      }

      // Calculate scores
      const reliabilityScore = this.calculateReliabilityScore(employee);
      const proximityScore = this.calculateProximityScore(employee, client);
      const availabilityScore = disqualifyReasons.length === 0 ? 1.0 : 0.0;
      const performanceScore = this.calculatePerformanceScore(employee);
      const seniorityScore = this.calculateSeniorityScore(employee);
      const workloadBalance = this.calculateWorkloadBalance(currentAssignments, config.maxShiftsPerEmployee);

      // Calculate final weighted score
      const score = 
        reliabilityScore * EMPLOYEE_SCORE_WEIGHTS.reliability +
        proximityScore * EMPLOYEE_SCORE_WEIGHTS.proximity +
        availabilityScore * EMPLOYEE_SCORE_WEIGHTS.availability +
        performanceScore * EMPLOYEE_SCORE_WEIGHTS.performance +
        seniorityScore * EMPLOYEE_SCORE_WEIGHTS.seniority +
        workloadBalance * EMPLOYEE_SCORE_WEIGHTS.workloadBalance;

      scores.push({
        employeeId: employee.id,
        employee,
        score,
        breakdown: {
          reliabilityScore,
          proximityScore,
          availabilityScore,
          performanceScore,
          seniorityScore,
          workloadBalance,
        },
        disqualifyReasons,
      });
    }

    // Sort by score (highest first)
    return scores.sort((a, b) => b.score - a.score);
  }

  /**
   * Check if employee has a conflicting shift
   */
  private async checkShiftConflict(
    employeeId: string,
    shiftStart: Date,
    shiftEnd: Date
  ): Promise<boolean> {
    const conflicts = await db.select()
      .from(shifts)
      .where(and(
        eq(shifts.employeeId, employeeId),
        or(
          and(
            lte(shifts.startTime, shiftStart),
            gte(shifts.endTime, shiftStart)
          ),
          and(
            lte(shifts.startTime, shiftEnd),
            gte(shifts.endTime, shiftEnd)
          ),
          and(
            gte(shifts.startTime, shiftStart),
            lte(shifts.endTime, shiftEnd)
          )
        )
      ))
      .limit(1);

    return conflicts.length > 0;
  }

  /**
   * Calculate reliability score based on attendance history
   */
  private calculateReliabilityScore(employee: any): number {
    // Use composite score if available, otherwise estimate
    if (employee.compositeScore) {
      return parseFloat(employee.compositeScore) / 100;
    }
    // Default to 0.7 if no data
    return 0.7;
  }

  /**
   * Calculate proximity score based on distance to job site
   */
  private calculateProximityScore(employee: any, client: any): number {
    // If we have coordinates, calculate distance
    // For now, return a default score
    // TODO: Implement actual distance calculation
    return 0.8;
  }

  /**
   * Calculate performance score from reviews
   */
  private calculatePerformanceScore(employee: any): number {
    // Use performance rating if available
    if (employee.performanceRating) {
      const rating = parseFloat(employee.performanceRating);
      return Math.min(1, rating / 5);
    }
    return 0.7;
  }

  /**
   * Calculate seniority score based on hire date
   */
  private calculateSeniorityScore(employee: any): number {
    if (!employee.hireDate) return 0.5;
    
    const hireDate = new Date(employee.hireDate);
    const yearsOfService = (Date.now() - hireDate.getTime()) / (1000 * 60 * 60 * 24 * 365);
    
    // Cap at 5 years for max seniority score
    return Math.min(1, yearsOfService / 5);
  }

  /**
   * Calculate workload balance score
   */
  private calculateWorkloadBalance(currentAssignments: number, maxShifts: number): number {
    // Prefer employees with fewer current assignments
    return 1 - (currentAssignments / maxShifts);
  }

  /**
   * Try contractor pool fallback
   */
  private async tryContractorFallback(
    shift: any,
    workspaceId: string
  ): Promise<AssignmentResult> {
    // Get contractors from pool
    const contractors = await db.select()
      .from(contractorPool)
      .where(and(
        eq(contractorPool.workspaceId, workspaceId),
        eq(contractorPool.status, 'available')
      ))
      .limit(5);

    if (contractors.length === 0) {
      return {
        shiftId: shift.id,
        employeeId: null,
        success: false,
        confidence: 0,
        reasoning: 'No contractors available',
        escalationLevel: 3,
      };
    }

    // For now, just return info about available contractors
    // In production, this would trigger contractor outreach
    return {
      shiftId: shift.id,
      employeeId: null,
      success: false,
      confidence: 0,
      reasoning: `${contractors.length} contractors available for escalation`,
      escalationLevel: 2,
    };
  }

  /**
   * Get active scheduling session
   */
  getActiveSession(sessionId: string): SchedulingSession | undefined {
    return this.activeSessions.get(sessionId);
  }

  /**
   * Get all active sessions for a workspace
   */
  getWorkspaceSessions(workspaceId: string): SchedulingSession[] {
    return Array.from(this.activeSessions.values())
      .filter(s => s.workspaceId === workspaceId);
  }
}

export const trinityAutonomousScheduler = TrinityAutonomousSchedulerService.getInstance();

// ============================================================================
// COMPLIANCE & CLIENT PREFERENCE ENHANCEMENTS
// ============================================================================

/**
 * Labor Law Compliance Service - 50-State Compliance Integration
 */
export class SchedulingComplianceService {
  private static instance: SchedulingComplianceService;
  
  static getInstance(): SchedulingComplianceService {
    if (!SchedulingComplianceService.instance) {
      SchedulingComplianceService.instance = new SchedulingComplianceService();
    }
    return SchedulingComplianceService.instance;
  }
  
  /**
   * Check if assignment complies with labor laws
   */
  async checkComplianceForAssignment(
    employeeId: string,
    shiftStart: Date,
    shiftEnd: Date,
    workspaceId: string
  ): Promise<{ compliant: boolean; violations: string[]; warnings: string[] }> {
    const violations: string[] = [];
    const warnings: string[] = [];
    
    // Get employee's state from their profile for state-specific rules
    const [employee] = await db.select().from(employees).where(eq(employees.id, employeeId)).limit(1);
    const state = employee?.address ? this.extractState(employee.address) : 'CA'; // Default to CA
    
    // Get existing shifts for the week
    const weekStart = new Date(shiftStart);
    weekStart.setDate(weekStart.getDate() - weekStart.getDay());
    const weekEnd = new Date(weekStart);
    weekEnd.setDate(weekEnd.getDate() + 6);
    
    const weeklyShifts = await db.select().from(shifts).where(and(
      eq(shifts.employeeId, employeeId),
      eq(shifts.workspaceId, workspaceId),
      gte(shifts.startTime, weekStart),
      lte(shifts.endTime, weekEnd)
    ));
    
    // Calculate weekly hours including this shift
    const shiftHours = (shiftEnd.getTime() - shiftStart.getTime()) / (1000 * 60 * 60);
    let weeklyHours = shiftHours;
    for (const s of weeklyShifts) {
      weeklyHours += (new Date(s.endTime).getTime() - new Date(s.startTime).getTime()) / (1000 * 60 * 60);
    }
    
    // Get state-specific rules
    const rules = this.getStateRules(state);
    
    // Check weekly overtime (40 hours federal, some states stricter)
    if (weeklyHours > rules.weeklyOvertimeThreshold) {
      warnings.push(`Overtime warning: ${weeklyHours.toFixed(1)} hours this week (threshold: ${rules.weeklyOvertimeThreshold})`);
    }
    
    if (weeklyHours > rules.maxWeeklyHours) {
      violations.push(`Exceeds max weekly hours: ${weeklyHours.toFixed(1)} > ${rules.maxWeeklyHours}`);
    }
    
    // Check daily overtime (CA: 8 hours, most states: none)
    if (rules.dailyOvertimeThreshold && shiftHours > rules.dailyOvertimeThreshold) {
      warnings.push(`Daily overtime: ${shiftHours.toFixed(1)} hours (threshold: ${rules.dailyOvertimeThreshold})`);
    }
    
    // Check required rest between shifts (typically 8-12 hours)
    const lastShift = weeklyShifts
      .filter(s => new Date(s.endTime) < shiftStart)
      .sort((a, b) => new Date(b.endTime).getTime() - new Date(a.endTime).getTime())[0];
    
    if (lastShift) {
      const restHours = (shiftStart.getTime() - new Date(lastShift.endTime).getTime()) / (1000 * 60 * 60);
      if (restHours < rules.minRestBetweenShifts) {
        violations.push(`Insufficient rest: ${restHours.toFixed(1)} hours between shifts (min: ${rules.minRestBetweenShifts})`);
      }
    }
    
    // Check split shift rules
    if (rules.splitShiftPremium && shiftHours > 10) {
      warnings.push('Split shift premium may apply (shift > 10 hours)');
    }
    
    return {
      compliant: violations.length === 0,
      violations,
      warnings,
    };
  }
  
  private extractState(address: string): string {
    // Simple state extraction - matches 2-letter state codes
    const stateMatch = address.match(/\b([A-Z]{2})\b/);
    return stateMatch ? stateMatch[1] : 'CA';
  }
  
  private getStateRules(state: string): {
    weeklyOvertimeThreshold: number;
    maxWeeklyHours: number;
    dailyOvertimeThreshold: number | null;
    minRestBetweenShifts: number;
    splitShiftPremium: boolean;
  } {
    // State-specific labor law rules (simplified for key states)
    const stateRules: Record<string, any> = {
      CA: { weeklyOvertimeThreshold: 40, maxWeeklyHours: 72, dailyOvertimeThreshold: 8, minRestBetweenShifts: 8, splitShiftPremium: true },
      NY: { weeklyOvertimeThreshold: 40, maxWeeklyHours: 60, dailyOvertimeThreshold: null, minRestBetweenShifts: 8, splitShiftPremium: false },
      TX: { weeklyOvertimeThreshold: 40, maxWeeklyHours: 60, dailyOvertimeThreshold: null, minRestBetweenShifts: 8, splitShiftPremium: false },
      FL: { weeklyOvertimeThreshold: 40, maxWeeklyHours: 60, dailyOvertimeThreshold: null, minRestBetweenShifts: 8, splitShiftPremium: false },
      IL: { weeklyOvertimeThreshold: 40, maxWeeklyHours: 60, dailyOvertimeThreshold: null, minRestBetweenShifts: 7.5, splitShiftPremium: false },
      PA: { weeklyOvertimeThreshold: 40, maxWeeklyHours: 60, dailyOvertimeThreshold: null, minRestBetweenShifts: 8, splitShiftPremium: false },
      WA: { weeklyOvertimeThreshold: 40, maxWeeklyHours: 60, dailyOvertimeThreshold: null, minRestBetweenShifts: 10, splitShiftPremium: false },
      OR: { weeklyOvertimeThreshold: 40, maxWeeklyHours: 60, dailyOvertimeThreshold: null, minRestBetweenShifts: 11, splitShiftPremium: false },
      CO: { weeklyOvertimeThreshold: 40, maxWeeklyHours: 60, dailyOvertimeThreshold: 12, minRestBetweenShifts: 8, splitShiftPremium: false },
      NV: { weeklyOvertimeThreshold: 40, maxWeeklyHours: 60, dailyOvertimeThreshold: 8, minRestBetweenShifts: 8, splitShiftPremium: false },
    };
    
    return stateRules[state] || stateRules['TX']; // Default to Texas (least restrictive)
  }
}

/**
 * Client Preference Service - Learns and applies client-employee preferences
 */
export class ClientPreferenceService {
  private static instance: ClientPreferenceService;
  
  static getInstance(): ClientPreferenceService {
    if (!ClientPreferenceService.instance) {
      ClientPreferenceService.instance = new ClientPreferenceService();
    }
    return ClientPreferenceService.instance;
  }
  
  /**
   * Get client's preferred employees based on history and explicit preferences
   */
  async getClientPreferences(clientId: string, workspaceId: string): Promise<{
    preferredEmployees: string[];
    avoidEmployees: string[];
    positionPreferences: Record<string, string[]>;
    historicalAssignments: { employeeId: string; successRate: number; count: number }[];
  }> {
    // Get historical successful assignments
    const historicalShifts = await db.select({
      employeeId: shifts.employeeId,
      status: shifts.status,
    })
      .from(shifts)
      .where(and(
        eq(shifts.clientId, clientId),
        eq(shifts.workspaceId, workspaceId),
        sql`${shifts.employeeId} IS NOT NULL`
      ));
    
    // Calculate success rates per employee
    const employeeStats = new Map<string, { total: number; successful: number }>();
    for (const shift of historicalShifts) {
      if (!shift.employeeId) continue;
      const stats = employeeStats.get(shift.employeeId) || { total: 0, successful: 0 };
      stats.total++;
      if (shift.status === 'completed') stats.successful++;
      employeeStats.set(shift.employeeId, stats);
    }
    
    // Convert to array and sort by success rate
    const historicalAssignments = Array.from(employeeStats.entries())
      .map(([employeeId, stats]) => ({
        employeeId,
        successRate: stats.total > 0 ? stats.successful / stats.total : 0,
        count: stats.total,
      }))
      .sort((a, b) => b.successRate - a.successRate);
    
    // Employees with 80%+ success rate and 3+ assignments are preferred
    const preferredEmployees = historicalAssignments
      .filter(a => a.successRate >= 0.8 && a.count >= 3)
      .map(a => a.employeeId);
    
    // Employees with <50% success rate and 3+ assignments should be avoided
    const avoidEmployees = historicalAssignments
      .filter(a => a.successRate < 0.5 && a.count >= 3)
      .map(a => a.employeeId);
    
    return {
      preferredEmployees,
      avoidEmployees,
      positionPreferences: {}, // Can be extended with explicit client preferences
      historicalAssignments,
    };
  }
  
  /**
   * Calculate preference score modifier for employee-client pairing
   */
  async getPreferenceScore(employeeId: string, clientId: string, workspaceId: string): Promise<number> {
    const preferences = await this.getClientPreferences(clientId, workspaceId);
    
    if (preferences.preferredEmployees.includes(employeeId)) {
      return 0.25; // +25% bonus for preferred employees
    }
    
    if (preferences.avoidEmployees.includes(employeeId)) {
      return -0.5; // -50% penalty for employees to avoid
    }
    
    // Check historical success rate
    const history = preferences.historicalAssignments.find(a => a.employeeId === employeeId);
    if (history) {
      return (history.successRate - 0.5) * 0.2; // -10% to +10% based on success rate
    }
    
    return 0; // Neutral if no history
  }
}

export const schedulingComplianceService = SchedulingComplianceService.getInstance();
export const clientPreferenceService = ClientPreferenceService.getInstance();

// ============================================================================
// AI INTELLIGENCE INTEGRATION FOR SCHEDULING DECISIONS
// ============================================================================

/**
 * Trinity AI Scheduling Intelligence - Uses Gemini/GPT/Claude for decisions
 */
export class TrinitySchedulingAI {
  private static instance: TrinitySchedulingAI;
  
  static getInstance(): TrinitySchedulingAI {
    if (!TrinitySchedulingAI.instance) {
      TrinitySchedulingAI.instance = new TrinitySchedulingAI();
    }
    return TrinitySchedulingAI.instance;
  }
  
  /**
   * Get AI recommendation for complex scheduling decisions
   */
  async getAISchedulingRecommendation(context: {
    shift: any;
    topCandidates: { employee: any; score: number; reasoning: string }[];
    clientPreferences: any;
    complianceIssues: string[];
    urgencyLevel: string;
    workspaceId: string;
  }): Promise<{
    recommendedEmployeeId: string | null;
    confidence: number;
    reasoning: string;
    alternativeActions: string[];
  }> {
    try {
      // Import AI services dynamically
      const { unifiedGeminiClient } = await import('../ai-brain/unifiedGeminiClient');
      
      const prompt = `You are Trinity, an expert security company scheduler. Analyze this scheduling decision:

SHIFT DETAILS:
- Title: ${context.shift.title || 'Security Shift'}
- Date: ${new Date(context.shift.startTime).toLocaleDateString()}
- Time: ${new Date(context.shift.startTime).toLocaleTimeString()} - ${new Date(context.shift.endTime).toLocaleTimeString()}
- Urgency: ${context.urgencyLevel}

TOP CANDIDATES (scored by reliability, performance, proximity):
${context.topCandidates.slice(0, 5).map((c, i) => 
  `${i + 1}. ${c.employee.firstName} ${c.employee.lastName} - Score: ${(c.score * 100).toFixed(0)}%
     Reasoning: ${c.reasoning}`
).join('\n')}

CLIENT PREFERENCES:
- Preferred employees: ${context.clientPreferences?.preferredEmployees?.length || 0}
- Employees to avoid: ${context.clientPreferences?.avoidEmployees?.length || 0}

COMPLIANCE ISSUES:
${context.complianceIssues.length > 0 ? context.complianceIssues.join('\n') : 'None'}

Based on your expertise as a senior security scheduler, recommend the BEST assignment. Consider:
1. Employee reliability and past performance
2. Client preferences and history
3. Compliance with labor laws
4. Workload balance and employee wellbeing
5. Urgency of the shift

Respond in JSON format:
{
  "recommendedIndex": <1-5 or 0 if none suitable>,
  "confidence": <0.0-1.0>,
  "reasoning": "<brief explanation>",
  "alternativeActions": ["<action1>", "<action2>"]
}`;

      const response = await unifiedGeminiClient.generateContent(prompt, {
        temperature: 0.3,
        maxOutputTokens: 500,
      });
      
      // Parse AI response
      const jsonMatch = response.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        const parsed = JSON.parse(jsonMatch[0]);
        const recommendedIndex = parsed.recommendedIndex - 1;
        
        return {
          recommendedEmployeeId: recommendedIndex >= 0 && recommendedIndex < context.topCandidates.length
            ? context.topCandidates[recommendedIndex].employee.id
            : null,
          confidence: parsed.confidence || 0.7,
          reasoning: parsed.reasoning || 'AI-powered intelligent scheduling',
          alternativeActions: parsed.alternativeActions || [],
        };
      }
      
      // Fallback to top scored candidate
      return {
        recommendedEmployeeId: context.topCandidates[0]?.employee.id || null,
        confidence: context.topCandidates[0]?.score || 0.5,
        reasoning: 'Fallback to top-scored candidate',
        alternativeActions: ['Consider manual review'],
      };
      
    } catch (error) {
      console.error('[TrinitySchedulingAI] AI recommendation error:', error);
      // Fallback to algorithmic selection
      return {
        recommendedEmployeeId: context.topCandidates[0]?.employee.id || null,
        confidence: context.topCandidates[0]?.score || 0.5,
        reasoning: 'Algorithmic selection (AI unavailable)',
        alternativeActions: [],
      };
    }
  }
  
  /**
   * Get AI analysis for scheduling patterns
   */
  async analyzeSchedulingPatterns(workspaceId: string): Promise<{
    insights: string[];
    recommendations: string[];
    riskAreas: string[];
  }> {
    try {
      const { unifiedGeminiClient } = await import('../ai-brain/unifiedGeminiClient');
      
      // Get recent scheduling data
      const recentShifts = await db.select().from(shifts)
        .where(and(
          eq(shifts.workspaceId, workspaceId),
          gte(shifts.startTime, new Date(Date.now() - 30 * 24 * 60 * 60 * 1000))
        ))
        .limit(100);
      
      const prompt = `Analyze these scheduling patterns for a security company:

RECENT SHIFTS (30 days):
- Total shifts: ${recentShifts.length}
- Unfilled shifts: ${recentShifts.filter(s => !s.employeeId).length}
- Completed: ${recentShifts.filter(s => s.status === 'completed').length}
- Cancelled: ${recentShifts.filter(s => s.status === 'cancelled').length}

Provide scheduling insights in JSON:
{
  "insights": ["insight1", "insight2"],
  "recommendations": ["rec1", "rec2"],
  "riskAreas": ["risk1", "risk2"]
}`;

      const response = await unifiedGeminiClient.generateContent(prompt, {
        temperature: 0.4,
        maxOutputTokens: 400,
      });
      
      const jsonMatch = response.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        return JSON.parse(jsonMatch[0]);
      }
      
      return { insights: [], recommendations: [], riskAreas: [] };
    } catch (error) {
      console.error('[TrinitySchedulingAI] Pattern analysis error:', error);
      return { insights: [], recommendations: [], riskAreas: [] };
    }
  }
}

/**
 * Escalation Chain Service - Contractors, Partners, External Resources
 */
export class EscalationChainService {
  private static instance: EscalationChainService;
  
  static getInstance(): EscalationChainService {
    if (!EscalationChainService.instance) {
      EscalationChainService.instance = new EscalationChainService();
    }
    return EscalationChainService.instance;
  }
  
  /**
   * Execute escalation chain when internal employees unavailable
   */
  async executeEscalation(
    shift: any,
    workspaceId: string,
    tier: 1 | 2 | 3 | 4 | 5
  ): Promise<{
    success: boolean;
    assignedResourceId: string | null;
    resourceType: 'internal' | 'contractor' | 'partner' | 'external';
    cost: number;
    message: string;
  }> {
    console.log(`[EscalationChain] Executing tier ${tier} escalation for shift ${shift.id}`);
    
    switch (tier) {
      case 1:
        // Tier 1: Internal overtime employees (willing to work extra)
        const overtimeEmployees = await this.getOvertimeWillingEmployees(workspaceId);
        if (overtimeEmployees.length > 0) {
          return {
            success: true,
            assignedResourceId: overtimeEmployees[0].id,
            resourceType: 'internal',
            cost: 1.5, // OT rate multiplier
            message: `Assigned to ${overtimeEmployees[0].firstName} (overtime)`,
          };
        }
        break;
        
      case 2:
        // Tier 2: On-call pool
        const onCallPool = await this.getOnCallEmployees(workspaceId);
        if (onCallPool.length > 0) {
          return {
            success: true,
            assignedResourceId: onCallPool[0].id,
            resourceType: 'internal',
            cost: 1.25,
            message: `Assigned to on-call: ${onCallPool[0].firstName}`,
          };
        }
        break;
        
      case 3:
        // Tier 3: Contractor pool
        const contractors = await db.select().from(contractorPool)
          .where(and(
            eq(contractorPool.workspaceId, workspaceId),
            eq(contractorPool.status, 'active')
          ))
          .limit(5);
        
        if (contractors.length > 0) {
          return {
            success: true,
            assignedResourceId: contractors[0].id,
            resourceType: 'contractor',
            cost: 2.0, // Contractor rate multiplier
            message: `Contractor assigned: ${contractors[0].companyName || 'Contract Worker'}`,
          };
        }
        break;
        
      case 4:
        // Tier 4: Partner agencies
        return {
          success: false,
          assignedResourceId: null,
          resourceType: 'partner',
          cost: 2.5,
          message: 'Partner agency request initiated (pending approval)',
        };
        
      case 5:
        // Tier 5: External staffing services (last resort)
        return {
          success: false,
          assignedResourceId: null,
          resourceType: 'external',
          cost: 3.0,
          message: 'External staffing request queued (requires management approval)',
        };
    }
    
    // Escalate to next tier
    if (tier < 5) {
      return this.executeEscalation(shift, workspaceId, (tier + 1) as 1 | 2 | 3 | 4 | 5);
    }
    
    return {
      success: false,
      assignedResourceId: null,
      resourceType: 'external',
      cost: 0,
      message: 'All escalation tiers exhausted - requires manual intervention',
    };
  }
  
  private async getOvertimeWillingEmployees(workspaceId: string): Promise<any[]> {
    // Get employees who have opted into overtime availability
    return db.select().from(employees)
      .where(and(
        eq(employees.workspaceId, workspaceId),
        eq(employees.status, 'active')
        // Could add: eq(employees.overtimeWilling, true)
      ))
      .limit(5);
  }
  
  private async getOnCallEmployees(workspaceId: string): Promise<any[]> {
    // Get employees currently on-call
    return db.select().from(employees)
      .where(and(
        eq(employees.workspaceId, workspaceId),
        eq(employees.status, 'active')
        // Could add: eq(employees.onCallStatus, true)
      ))
      .limit(5);
  }
}

export const trinitySchedulingAI = TrinitySchedulingAI.getInstance();
export const escalationChainService = EscalationChainService.getInstance();

console.log('[TrinityAutonomousScheduler] AI Intelligence, Compliance, Preferences, and Escalation Chain loaded');

// ============================================================================
// REAL-TIME HUMAN OVERRIDE CAPABILITY
// ============================================================================

/**
 * Human Override Controller - Allows managers to override AI scheduling decisions
 */
export class HumanOverrideController {
  private static instance: HumanOverrideController;
  private overrideQueue: Map<string, {
    shiftId: string;
    action: 'pause' | 'skip' | 'force_assign' | 'force_unassign';
    employeeId?: string;
    reason: string;
    timestamp: Date;
    userId: string;
  }> = new Map();
  
  private pausedWorkspaces: Set<string> = new Set();
  
  static getInstance(): HumanOverrideController {
    if (!HumanOverrideController.instance) {
      HumanOverrideController.instance = new HumanOverrideController();
    }
    return HumanOverrideController.instance;
  }
  
  /**
   * Pause autonomous scheduling for a workspace
   */
  pauseScheduling(workspaceId: string, userId: string, reason: string): void {
    this.pausedWorkspaces.add(workspaceId);
    console.log(`[HumanOverride] Scheduling paused for workspace ${workspaceId} by ${userId}: ${reason}`);
    
    // Emit event for real-time UI update
    platformEventBus.emit('scheduling_paused', {
      workspaceId,
      userId,
      reason,
      timestamp: new Date(),
    });
  }
  
  /**
   * Resume autonomous scheduling for a workspace
   */
  resumeScheduling(workspaceId: string, userId: string): void {
    this.pausedWorkspaces.delete(workspaceId);
    console.log(`[HumanOverride] Scheduling resumed for workspace ${workspaceId} by ${userId}`);
    
    platformEventBus.emit('scheduling_resumed', {
      workspaceId,
      userId,
      timestamp: new Date(),
    });
  }
  
  /**
   * Check if scheduling is paused for a workspace
   */
  isPaused(workspaceId: string): boolean {
    return this.pausedWorkspaces.has(workspaceId);
  }
  
  /**
   * Queue a human override for a specific shift
   */
  queueOverride(override: {
    shiftId: string;
    workspaceId: string;
    action: 'skip' | 'force_assign' | 'force_unassign';
    employeeId?: string;
    reason: string;
    userId: string;
  }): void {
    this.overrideQueue.set(override.shiftId, {
      ...override,
      timestamp: new Date(),
    });
    
    console.log(`[HumanOverride] Override queued for shift ${override.shiftId}: ${override.action}`);
    
    platformEventBus.emit('scheduling_override_queued', override);
  }
  
  /**
   * Check for pending override on a shift
   */
  getOverride(shiftId: string): {
    action: 'skip' | 'force_assign' | 'force_unassign';
    employeeId?: string;
    reason: string;
  } | null {
    const override = this.overrideQueue.get(shiftId);
    if (override) {
      this.overrideQueue.delete(shiftId); // Consume the override
      return {
        action: override.action as 'skip' | 'force_assign' | 'force_unassign',
        employeeId: override.employeeId,
        reason: override.reason,
      };
    }
    return null;
  }
  
  /**
   * Get all pending overrides for a workspace
   */
  getPendingOverrides(workspaceId: string): Array<{
    shiftId: string;
    action: string;
    reason: string;
    timestamp: Date;
  }> {
    const overrides: Array<{
      shiftId: string;
      action: string;
      reason: string;
      timestamp: Date;
    }> = [];
    
    for (const [shiftId, override] of this.overrideQueue.entries()) {
      overrides.push({
        shiftId,
        action: override.action,
        reason: override.reason,
        timestamp: override.timestamp,
      });
    }
    
    return overrides;
  }
  
  /**
   * Clear all overrides for a workspace
   */
  clearOverrides(workspaceId: string): void {
    for (const [shiftId] of this.overrideQueue.entries()) {
      this.overrideQueue.delete(shiftId);
    }
    console.log(`[HumanOverride] Cleared all overrides for workspace ${workspaceId}`);
  }
}

export const humanOverrideController = HumanOverrideController.getInstance();

console.log('[HumanOverrideController] Real-time human override capability initialized');

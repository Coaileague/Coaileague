/**
 * ESCALATION CHAIN SERVICE
 * =========================
 * Fast escalation chain for security industry staffing.
 * 
 * Tier timings (security industry speed requirement):
 * - Tier 1: 5 minutes  - Primary qualified employees
 * - Tier 2: 15 minutes - Secondary qualified employees  
 * - Tier 3: 30 minutes - Nearby qualified employees (expanded radius)
 * - Tier 4: 45 minutes - Manager notification
 * - Tier 5: 60 minutes - Owner escalation
 */

import { db } from '../../db';
import { employees, shifts, users, workspaces } from '@shared/schema';
import { eq, and, inArray } from 'drizzle-orm';
import { createNotification } from '../notificationService';

export interface EscalationTier {
  tier: number;
  name: string;
  minutesFromRequest: number;
  action: EscalationAction;
  notifyRoles: string[];
  expandSearchRadius: boolean;
  radiusMiles?: number;
}

export type EscalationAction = 
  | 'notify_primary_qualified'
  | 'notify_secondary_qualified'
  | 'expand_search_radius'
  | 'manager_escalation'
  | 'owner_escalation';

export interface EscalationState {
  requestId: string;
  workspaceId: string;
  currentTier: number;
  unfilledPositions: number;
  totalPositions: number;
  startedAt: Date;
  lastEscalatedAt: Date;
  notifiedEmployeeIds: string[];
  notifiedManagerIds: string[];
  status: 'active' | 'filled' | 'escalated_to_owner' | 'cancelled' | 'expired';
}

export interface EscalationResult {
  success: boolean;
  newTier: number;
  action: EscalationAction;
  notifiedCount: number;
  nextEscalationAt?: Date;
  message: string;
}

const ESCALATION_TIERS: EscalationTier[] = [
  {
    tier: 1,
    name: 'Primary Qualified',
    minutesFromRequest: 5,
    action: 'notify_primary_qualified',
    notifyRoles: [],
    expandSearchRadius: false,
    radiusMiles: 15,
  },
  {
    tier: 2,
    name: 'Secondary Qualified',
    minutesFromRequest: 15,
    action: 'notify_secondary_qualified',
    notifyRoles: [],
    expandSearchRadius: false,
    radiusMiles: 25,
  },
  {
    tier: 3,
    name: 'Expanded Search',
    minutesFromRequest: 30,
    action: 'expand_search_radius',
    notifyRoles: [],
    expandSearchRadius: true,
    radiusMiles: 50,
  },
  {
    tier: 4,
    name: 'Manager Escalation',
    minutesFromRequest: 45,
    action: 'manager_escalation',
    notifyRoles: ['department_manager', 'org_admin'],
    expandSearchRadius: true,
    radiusMiles: 75,
  },
  {
    tier: 5,
    name: 'Owner Escalation',
    minutesFromRequest: 60,
    action: 'owner_escalation',
    notifyRoles: ['org_owner'],
    expandSearchRadius: true,
    radiusMiles: 100,
  },
];

class EscalationChainService {
  private activeEscalations: Map<string, EscalationState> = new Map();
  
  /**
   * Start a new escalation chain for a staffing request
   */
  async startEscalation(
    requestId: string,
    workspaceId: string,
    positionsNeeded: number
  ): Promise<EscalationState> {
    const now = new Date();
    
    const state: EscalationState = {
      requestId,
      workspaceId,
      currentTier: 0,
      unfilledPositions: positionsNeeded,
      totalPositions: positionsNeeded,
      startedAt: now,
      lastEscalatedAt: now,
      notifiedEmployeeIds: [],
      notifiedManagerIds: [],
      status: 'active',
    };
    
    this.activeEscalations.set(requestId, state);
    
    await this.escalateToTier(requestId, 1);
    
    return state;
  }
  
  /**
   * Escalate to a specific tier
   */
  async escalateToTier(requestId: string, tier: number): Promise<EscalationResult> {
    const state = this.activeEscalations.get(requestId);
    if (!state) {
      return {
        success: false,
        newTier: 0,
        action: 'notify_primary_qualified',
        notifiedCount: 0,
        message: 'Escalation state not found',
      };
    }
    
    if (tier > ESCALATION_TIERS.length) {
      state.status = 'escalated_to_owner';
      return {
        success: false,
        newTier: tier,
        action: 'owner_escalation',
        notifiedCount: 0,
        message: 'Maximum escalation reached - owner has been notified',
      };
    }
    
    const tierConfig = ESCALATION_TIERS[tier - 1];
    state.currentTier = tier;
    state.lastEscalatedAt = new Date();
    
    let notifiedCount = 0;
    
    switch (tierConfig.action) {
      case 'notify_primary_qualified':
        notifiedCount = await this.notifyPrimaryEmployees(state, tierConfig);
        break;
      case 'notify_secondary_qualified':
        notifiedCount = await this.notifySecondaryEmployees(state, tierConfig);
        break;
      case 'expand_search_radius':
        notifiedCount = await this.notifyExpandedRadius(state, tierConfig);
        break;
      case 'manager_escalation':
        notifiedCount = await this.notifyManagers(state, tierConfig);
        break;
      case 'owner_escalation':
        notifiedCount = await this.notifyOwner(state, tierConfig);
        state.status = 'escalated_to_owner';
        break;
    }
    
    const nextTier = tier < ESCALATION_TIERS.length ? tier + 1 : null;
    let nextEscalationAt: Date | undefined;
    
    if (nextTier) {
      const nextTierConfig = ESCALATION_TIERS[nextTier - 1];
      const minutesUntilNext = nextTierConfig.minutesFromRequest - tierConfig.minutesFromRequest;
      nextEscalationAt = new Date(Date.now() + minutesUntilNext * 60 * 1000);
    }
    
    return {
      success: true,
      newTier: tier,
      action: tierConfig.action,
      notifiedCount,
      nextEscalationAt,
      message: `Escalated to tier ${tier}: ${tierConfig.name}. Notified ${notifiedCount} recipients.`,
    };
  }
  
  /**
   * Notify primary qualified employees (highest match scores)
   */
  private async notifyPrimaryEmployees(
    state: EscalationState,
    tierConfig: EscalationTier
  ): Promise<number> {
    const qualifiedEmployees = await this.findQualifiedEmployees(
      state.workspaceId,
      tierConfig.radiusMiles || 15,
      state.notifiedEmployeeIds,
      5
    );
    
    for (const emp of qualifiedEmployees) {
      if (!state.notifiedEmployeeIds.includes(emp.id)) {
        state.notifiedEmployeeIds.push(emp.id);
      }
    }
    
    console.log(`[EscalationChain] Tier ${tierConfig.tier}: Notified ${qualifiedEmployees.length} primary employees`);
    
    return qualifiedEmployees.length;
  }
  
  /**
   * Notify secondary qualified employees
   */
  private async notifySecondaryEmployees(
    state: EscalationState,
    tierConfig: EscalationTier
  ): Promise<number> {
    const qualifiedEmployees = await this.findQualifiedEmployees(
      state.workspaceId,
      tierConfig.radiusMiles || 25,
      state.notifiedEmployeeIds,
      10
    );
    
    for (const emp of qualifiedEmployees) {
      if (!state.notifiedEmployeeIds.includes(emp.id)) {
        state.notifiedEmployeeIds.push(emp.id);
      }
    }
    
    console.log(`[EscalationChain] Tier ${tierConfig.tier}: Notified ${qualifiedEmployees.length} secondary employees`);
    
    return qualifiedEmployees.length;
  }
  
  /**
   * Notify employees in expanded radius
   */
  private async notifyExpandedRadius(
    state: EscalationState,
    tierConfig: EscalationTier
  ): Promise<number> {
    const qualifiedEmployees = await this.findQualifiedEmployees(
      state.workspaceId,
      tierConfig.radiusMiles || 50,
      state.notifiedEmployeeIds,
      20
    );
    
    for (const emp of qualifiedEmployees) {
      if (!state.notifiedEmployeeIds.includes(emp.id)) {
        state.notifiedEmployeeIds.push(emp.id);
      }
    }
    
    console.log(`[EscalationChain] Tier ${tierConfig.tier}: Notified ${qualifiedEmployees.length} employees (expanded radius)`);
    
    return qualifiedEmployees.length;
  }
  
  /**
   * Notify managers about unfilled positions
   */
  private async notifyManagers(
    state: EscalationState,
    tierConfig: EscalationTier
  ): Promise<number> {
    console.log(`[EscalationChain] Tier ${tierConfig.tier}: MANAGER ESCALATION - ${state.unfilledPositions} unfilled positions`);
    
    try {
      const managers = await db.select({
        id: employees.id,
        userId: employees.userId,
        email: employees.email,
        firstName: employees.firstName,
        workspaceRole: employees.workspaceRole,
      })
      .from(employees)
      .where(
        and(
          eq(employees.workspaceId, state.workspaceId),
          eq(employees.isActive, true),
          inArray(employees.workspaceRole, ['department_manager', 'org_admin'])
        )
      );

      let notifiedCount = 0;
      for (const manager of managers) {
        if (!state.notifiedManagerIds.includes(manager.id)) {
          state.notifiedManagerIds.push(manager.id);
          
          if (manager.userId) {
            await createNotification({
              userId: manager.userId,
              type: 'staffing_escalation',
              title: `URGENT: ${state.unfilledPositions} position(s) still need staffing`,
              message: `Request ${state.requestId} has been escalated to management after 45 minutes without full coverage. Please review and assign staff immediately.`,
              data: { requestId: state.requestId, tier: 4, unfilledPositions: state.unfilledPositions },
              workspaceId: state.workspaceId,
            });
            notifiedCount++;
          }
        }
      }
      
      console.log(`[EscalationChain] Tier 4: Notified ${notifiedCount} managers about unfilled positions`);
      return notifiedCount;
    } catch (error) {
      console.error('[EscalationChain] Failed to notify managers:', error);
      return 0;
    }
  }
  
  /**
   * Notify owner about critical unfilled positions
   */
  private async notifyOwner(
    state: EscalationState,
    tierConfig: EscalationTier
  ): Promise<number> {
    console.log(`[EscalationChain] Tier ${tierConfig.tier}: OWNER ESCALATION - ${state.unfilledPositions} positions still unfilled after 60 minutes`);
    
    try {
      const owners = await db.select({
        id: employees.id,
        userId: employees.userId,
        email: employees.email,
        firstName: employees.firstName,
      })
      .from(employees)
      .where(
        and(
          eq(employees.workspaceId, state.workspaceId),
          eq(employees.isActive, true),
          eq(employees.workspaceRole, 'org_owner')
        )
      );

      let notifiedCount = 0;
      for (const owner of owners) {
        if (owner.userId) {
          await createNotification({
            userId: owner.userId,
            type: 'staffing_critical_escalation',
            title: `CRITICAL: Staffing emergency - ${state.unfilledPositions} unfilled position(s)`,
            message: `Request ${state.requestId} requires immediate attention. After 60 minutes, ${state.unfilledPositions} of ${state.totalPositions} positions remain unfilled despite all escalation attempts.`,
            data: { requestId: state.requestId, tier: 5, unfilledPositions: state.unfilledPositions, totalPositions: state.totalPositions },
            workspaceId: state.workspaceId,
          });
          notifiedCount++;
        }
      }
      
      console.log(`[EscalationChain] Tier 5: Notified ${notifiedCount} owners about critical escalation`);
      return notifiedCount;
    } catch (error) {
      console.error('[EscalationChain] Failed to notify owners:', error);
      return 0;
    }
  }
  
  /**
   * Find qualified employees within radius
   */
  private async findQualifiedEmployees(
    workspaceId: string,
    radiusMiles: number,
    excludeIds: string[],
    limit: number
  ): Promise<any[]> {
    const result = await db.select()
      .from(employees)
      .where(
        and(
          eq(employees.workspaceId, workspaceId),
          eq(employees.status, 'active')
        )
      )
      .limit(limit);
    
    return result.filter(emp => !excludeIds.includes(emp.id));
  }
  
  /**
   * Mark a position as filled (reduces unfilled count)
   */
  async positionFilled(requestId: string): Promise<void> {
    const state = this.activeEscalations.get(requestId);
    if (state) {
      state.unfilledPositions--;
      if (state.unfilledPositions <= 0) {
        state.status = 'filled';
        console.log(`[EscalationChain] Request ${requestId} fully staffed!`);
      }
    }
  }
  
  /**
   * Cancel an escalation
   */
  async cancelEscalation(requestId: string, reason: string): Promise<void> {
    const state = this.activeEscalations.get(requestId);
    if (state) {
      state.status = 'cancelled';
      console.log(`[EscalationChain] Escalation ${requestId} cancelled: ${reason}`);
    }
  }
  
  /**
   * Get current escalation state
   */
  getEscalationState(requestId: string): EscalationState | undefined {
    return this.activeEscalations.get(requestId);
  }
  
  /**
   * Get escalation tier configuration
   */
  getEscalationTiers(): EscalationTier[] {
    return ESCALATION_TIERS;
  }
  
  /**
   * Check for escalations that need to be triggered
   * Call this from a scheduled job
   */
  async processScheduledEscalations(): Promise<void> {
    const now = Date.now();
    
    for (const [requestId, state] of this.activeEscalations) {
      if (state.status !== 'active') continue;
      if (state.unfilledPositions <= 0) continue;
      
      const minutesSinceStart = (now - state.startedAt.getTime()) / (60 * 1000);
      
      for (const tier of ESCALATION_TIERS) {
        if (tier.tier > state.currentTier && minutesSinceStart >= tier.minutesFromRequest) {
          await this.escalateToTier(requestId, tier.tier);
          break;
        }
      }
    }
  }
}

export const escalationChainService = new EscalationChainService();

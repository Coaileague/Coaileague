/**
 * TRINITY STAFFING ORCHESTRATOR
 * ==============================
 * Main orchestration service for automated staffing workflow.
 * 
 * NOW USES 7-STEP PATTERN:
 * TRIGGER → FETCH → VALIDATE → PROCESS → MUTATE → CONFIRM → NOTIFY
 * 
 * Coordinates the complete flow:
 * 1. Email ingestion and classification
 * 2. Work request parsing
 * 3. Shift creation
 * 4. Employee matching and assignment
 * 5. Client confirmation
 * 6. Escalation management
 * 
 * ARCHITECTURE NOTE (Consolidation):
 * ===================================
 * This service uses IN-MEMORY storage for rapid iteration.
 * For database-persisted staffing workflows, use InboundOpportunityAgent
 * which is the CANONICAL path for:
 * - Email ingestion with DB persistence (inboundEmails table)
 * - Staged shift creation (stagedShifts table)
 * - Automated shift offers (automatedShiftOffers table)
 * 
 * TrinityStaffingOrchestrator is suited for:
 * - Quick prototyping and testing
 * - In-memory workflow state management
 * - Integration with Trinity AI chat interface
 * 
 * InboundOpportunityAgent is suited for:
 * - Production email processing with persistence
 * - Multi-stage workflow with audit trail
 * - Integration with ExecutionPipeline billing
 */

import { db } from '../../db';
import { shifts, employees, clients, workspaces } from '@shared/schema';
import { eq, and } from 'drizzle-orm';
import { workRequestParser, type ParsedWorkRequest } from './workRequestParser';
import { escalationChainService, type EscalationState } from './escalationChainService';
import { clientConfirmationService, type ConfirmationEmailData } from './clientConfirmationService';
import { premiumFeatureGating } from '../premiumFeatureGating';
import { CREDIT_COSTS } from '../billing/creditManager';
import { emailService } from '../emailService';
import { universalStepLogger } from '../orchestration/universalStepLogger';

export interface StaffingWorkflow {
  id: string;
  workspaceId: string;
  status: 'pending' | 'processing' | 'awaiting_assignment' | 'assigned' | 'confirmed' | 'escalated' | 'completed' | 'failed' | 'cancelled';
  emailId: string;
  parsedRequest?: ParsedWorkRequest;
  shiftId?: string;
  assignedEmployees: { id: string; name: string; phone: string; role?: string }[];
  confirmationNumber?: string;
  escalationState?: EscalationState;
  createdAt: Date;
  updatedAt: Date;
  completedAt?: Date;
  error?: string;
  notificationContext?: {
    referenceNumber: string;
    workspaceName: string;
    senderEmail: string;
    senderName?: string;
  };
}

export interface OrchestratorSettings {
  enabled: boolean;
  autoAssign: boolean;
  autoConfirm: boolean;
  defaultBillingTerms: 'normal' | 'due_on_receipt';
  maxAutoAssignAttempts: number;
  requireApprovalForNew: boolean;
  notifyOnNewRequest: boolean;
}

const DEFAULT_SETTINGS: OrchestratorSettings = {
  enabled: true,
  autoAssign: true,
  autoConfirm: true,
  defaultBillingTerms: 'normal',
  maxAutoAssignAttempts: 3,
  requireApprovalForNew: true,
  notifyOnNewRequest: true,
};

export interface WebhookConfig {
  workspaceId: string;
  webhookToken: string;
  webhookSecret?: string;
  systemUserId?: string;
  createdAt: Date;
}

/**
 * TrinityStaffingOrchestrator
 * 
 * Main orchestration service for automated staffing workflow.
 * 
 * NOTE: Current implementation uses in-memory storage for:
 * - Active workflows
 * - Workspace settings
 * - Webhook configurations (tokens/secrets)
 * 
 * This means data is ephemeral and will be lost on process restart.
 * For production deployment, these should be persisted to the database.
 * 
 * The in-memory approach is intentional for the initial MVP to:
 * 1. Reduce database schema complexity
 * 2. Enable rapid iteration and testing
 * 3. Provide fast access without database queries
 */
class TrinityStaffingOrchestrator {
  private workflows: Map<string, StaffingWorkflow> = new Map();
  private settings: Map<string, OrchestratorSettings> = new Map();
  private webhookConfigs: Map<string, WebhookConfig> = new Map();
  
  /**
   * Process an inbound email through the staffing pipeline
   * Uses 7-step orchestration: TRIGGER → FETCH → VALIDATE → PROCESS → MUTATE → CONFIRM → NOTIFY
   */
  async processInboundEmail(
    workspaceId: string,
    userId: string,
    emailData: {
      id: string;
      from: string;
      subject: string;
      body: string;
      receivedAt: Date;
    }
  ): Promise<StaffingWorkflow> {
    const workflow = this.createWorkflow(workspaceId, emailData.id);
    let orchestrationId: string | null = null;
    
    try {
      // Start 7-step orchestration
      const orchestration = await universalStepLogger.startOrchestration({
        domain: 'scheduling',
        actionName: 'trinity_staffing_email_processing',
        actionId: workflow.id,
        workspaceId,
        userId,
        triggeredBy: 'webhook',
        triggerDetails: { emailId: emailData.id, from: emailData.from },
        requiredFeature: 'trinity_staffing',
      });
      orchestrationId = orchestration.orchestrationId;

      // STEP 1: TRIGGER - Register the operation
      await universalStepLogger.executeStep(orchestrationId, 'TRIGGER', async () => ({
        success: true,
        data: { workflowId: workflow.id, emailId: emailData.id },
      }));

      // STEP 2: FETCH - Check premium access and get workspace info
      const fetchResult = await universalStepLogger.executeStep(orchestrationId, 'FETCH', async () => {
        const accessResult = await premiumFeatureGating.checkAccess(
          workspaceId,
          'trinity_staffing',
          userId
        );
        
        // Get workspace name for notifications
        let workspaceName = 'Our Team';
        try {
          const [workspace] = await db.select({ name: workspaces.name })
            .from(workspaces)
            .where(eq(workspaces.id, workspaceId))
            .limit(1);
          if (workspace?.name) workspaceName = workspace.name;
        } catch (e) { /* ignore */ }
        
        return {
          success: accessResult.allowed,
          data: { accessResult, workspaceName },
          error: accessResult.allowed ? undefined : (accessResult.reason || 'Trinity Staffing not available'),
        };
      });

      if (!fetchResult.success) {
        await universalStepLogger.failOrchestration(orchestrationId, fetchResult.error || 'Access denied', 'PERMISSION_DENIED');
        throw new Error(fetchResult.error || 'Trinity Staffing not available');
      }

      const workspaceName = fetchResult.data?.workspaceName || 'Our Team';
      const referenceNumber = `SR-${Date.now().toString(36).toUpperCase()}-${Math.random().toString(36).substring(2, 6).toUpperCase()}`;
      
      // Set notification context
      workflow.notificationContext = {
        referenceNumber,
        workspaceName,
        senderEmail: emailData.from,
        senderName: undefined,
      };

      // STEP 3: VALIDATE - Classify email and check credits
      const validateResult = await universalStepLogger.executeStep(orchestrationId, 'VALIDATE', async () => {
        const classification = await workRequestParser.classifyEmail(
          emailData.subject,
          emailData.body,
          emailData.from
        );
        
        if (!classification.isWorkRequest) {
          return { success: true, data: { isWorkRequest: false, classification } };
        }
        
        // Check credits
        const deductResult = await premiumFeatureGating.deductCredits(
          workspaceId,
          'trinity_staffing_request_parse',
          userId,
          1,
          { emailId: emailData.id }
        );
        
        if (!deductResult.success) {
          return { success: false, error: `Insufficient credits: ${deductResult.error}`, errorCode: 'INSUFFICIENT_CREDITS' };
        }
        
        return { success: true, data: { isWorkRequest: true, classification, creditsDeducted: true } };
      }, { validateSubscription: true });

      if (!validateResult.success) {
        await universalStepLogger.failOrchestration(orchestrationId, validateResult.error || 'Validation failed', validateResult.errorCode || 'VALIDATION_FAILED');
        throw new Error(validateResult.error || 'Validation failed');
      }

      // If not a work request, complete early
      if (!validateResult.data?.isWorkRequest) {
        workflow.status = 'completed';
        workflow.completedAt = new Date();
        await universalStepLogger.completeOrchestration(orchestrationId, { notWorkRequest: true });
        return workflow;
      }

      workflow.status = 'processing';

      // STEP 4: PROCESS - Parse the work request and find matches
      const processResult = await universalStepLogger.executeStep(orchestrationId, 'PROCESS', async () => {
        const parsedRequest = await workRequestParser.parseWorkRequest(
          emailData.subject,
          emailData.body,
          emailData.from,
          emailData.receivedAt
        );
        
        return { success: true, data: { parsedRequest } };
      });

      if (!processResult.success) {
        await universalStepLogger.failOrchestration(orchestrationId, processResult.error || 'Processing failed', 'PROCESS_ERROR');
        throw new Error(processResult.error || 'Failed to parse work request');
      }

      workflow.parsedRequest = processResult.data?.parsedRequest;
      
      const settings = this.getSettings(workspaceId);

      // STEP 5: MUTATE - Auto-assign employees (database mutations)
      const mutateResult = await universalStepLogger.executeStep(orchestrationId, 'MUTATE', async () => {
        if (settings.autoAssign && workflow.parsedRequest) {
          await this.autoAssignEmployees(workflow, userId);
        }
        return { 
          success: true, 
          data: { 
            assignedCount: workflow.assignedEmployees.length,
            status: workflow.status,
          } 
        };
      }, { acquireLock: `staffing-${workflow.id}` });

      if (!mutateResult.success) {
        await universalStepLogger.failOrchestration(orchestrationId, mutateResult.error || 'Mutation failed', 'MUTATE_ERROR');
        throw new Error(mutateResult.error || 'Failed to assign employees');
      }

      // STEP 6: CONFIRM - Send confirmation to client
      await universalStepLogger.executeStep(orchestrationId, 'CONFIRM', async () => {
        if (settings.autoConfirm && workflow.assignedEmployees.length > 0) {
          await this.sendConfirmation(workflow, userId);
        }
        return { success: true, data: { confirmed: workflow.status === 'confirmed' } };
      });

      // STEP 7: NOTIFY - Final notifications already sent in sendConfirmation
      await universalStepLogger.executeStep(orchestrationId, 'NOTIFY', async () => {
        return { 
          success: true, 
          data: { 
            referenceNumber,
            confirmationNumber: workflow.confirmationNumber,
            notifiedSender: !!workflow.notificationContext?.senderEmail,
          } 
        };
      });

      // Complete orchestration
      await universalStepLogger.completeOrchestration(orchestrationId, {
        workflowId: workflow.id,
        status: workflow.status,
        assignedCount: workflow.assignedEmployees.length,
        confirmationNumber: workflow.confirmationNumber,
      });

      this.updateWorkflow(workflow);
      return workflow;
    } catch (error: any) {
      workflow.status = 'failed';
      workflow.error = error.message;
      this.updateWorkflow(workflow);
      
      // Fail orchestration if we have one
      if (orchestrationId) {
        try {
          await universalStepLogger.failOrchestration(orchestrationId, error.message, 'UNKNOWN');
        } catch (e) { /* ignore logging failure */ }
      }
      
      throw error;
    }
  }
  
  /**
   * Auto-assign employees to a workflow
   * Sends step 4 (matching) and step 5 (assigning) notifications
   */
  private async autoAssignEmployees(
    workflow: StaffingWorkflow,
    userId: string
  ): Promise<void> {
    if (!workflow.parsedRequest) return;
    
    const ctx = workflow.notificationContext;
    
    // STEP 4: Matching - Send notification that we're finding staff
    if (ctx?.senderEmail) {
      try {
        const locationStr = typeof workflow.parsedRequest.location === 'string' 
          ? workflow.parsedRequest.location 
          : `${workflow.parsedRequest.location?.address || ''}, ${workflow.parsedRequest.location?.city || ''}, ${workflow.parsedRequest.location?.state || ''}`;
        const dateStr = workflow.parsedRequest.requestedDate instanceof Date 
          ? workflow.parsedRequest.requestedDate.toLocaleDateString() 
          : String(workflow.parsedRequest.requestedDate || '');
        
        await emailService.sendStaffingStatusUpdate({
          workspaceId: workflow.workspaceId,
          senderEmail: ctx.senderEmail,
          senderName: ctx.senderName,
          referenceNumber: ctx.referenceNumber,
          workspaceName: ctx.workspaceName,
          currentStep: 'matching',
          stepNumber: 4,
          totalSteps: 7,
          stepDetails: `Searching for ${workflow.parsedRequest.guardsNeeded} qualified ${workflow.parsedRequest.positionType || 'security'} personnel in your area.`,
          extractedInfo: {
            location: locationStr,
            date: dateStr,
            time: `${workflow.parsedRequest.startTime} - ${workflow.parsedRequest.endTime}`,
            positionType: workflow.parsedRequest.positionType,
            guardsNeeded: workflow.parsedRequest.guardsNeeded,
          },
        });
        console.log(`[TrinityStaffing] Step 4 (matching) notification sent for ${ctx.referenceNumber}`);
      } catch (err) {
        console.error('[TrinityStaffing] Failed to send step 4 notification:', err);
      }
    }
    
    const deductResult = await premiumFeatureGating.deductCredits(
      workflow.workspaceId,
      'trinity_staffing_auto_assign',
      userId,
      1,
      { workflowId: workflow.id }
    );
    
    if (!deductResult.success) {
      console.warn(`[TrinityStaffing] Auto-assign skipped - insufficient credits`);
      return;
    }
    
    const eligibleEmployees = await db.select()
      .from(employees)
      .where(
        and(
          eq(employees.workspaceId, workflow.workspaceId),
          eq(employees.status, 'active')
        )
      )
      .limit(workflow.parsedRequest.guardsNeeded);
    
    workflow.assignedEmployees = eligibleEmployees.map(emp => ({
      id: emp.id,
      name: `${emp.firstName} ${emp.lastName}`,
      phone: emp.phone || '',
      role: workflow.parsedRequest?.positionType || 'Security Officer',
    }));
    
    // STEP 5: Assigning - Send notification with assigned staff
    if (ctx?.senderEmail && workflow.assignedEmployees.length > 0) {
      try {
        const assignedNames = workflow.assignedEmployees.map(e => e.name).join(', ');
        await emailService.sendStaffingStatusUpdate({
          workspaceId: workflow.workspaceId,
          senderEmail: ctx.senderEmail,
          senderName: ctx.senderName,
          referenceNumber: ctx.referenceNumber,
          workspaceName: ctx.workspaceName,
          currentStep: 'assigning',
          stepNumber: 5,
          totalSteps: 7,
          stepDetails: `Successfully assigned ${workflow.assignedEmployees.length} personnel: ${assignedNames}. Preparing confirmation details.`,
        });
        console.log(`[TrinityStaffing] Step 5 (assigning) notification sent for ${ctx.referenceNumber}`);
      } catch (err) {
        console.error('[TrinityStaffing] Failed to send step 5 notification:', err);
      }
    }
    
    if (workflow.assignedEmployees.length >= workflow.parsedRequest.guardsNeeded) {
      workflow.status = 'assigned';
    } else {
      workflow.status = 'awaiting_assignment';
      await escalationChainService.startEscalation(
        workflow.id,
        workflow.workspaceId,
        workflow.parsedRequest.guardsNeeded - workflow.assignedEmployees.length
      );
      workflow.escalationState = escalationChainService.getEscalationState(workflow.id);
    }
  }
  
  /**
   * Send confirmation to client
   * Sends step 6 (confirming) and step 7 (completed) with full summary
   */
  private async sendConfirmation(
    workflow: StaffingWorkflow,
    userId: string
  ): Promise<void> {
    if (!workflow.parsedRequest) return;
    
    const ctx = workflow.notificationContext;
    
    // STEP 6: Confirming - Send notification that confirmation is being prepared
    if (ctx?.senderEmail) {
      try {
        await emailService.sendStaffingStatusUpdate({
          workspaceId: workflow.workspaceId,
          senderEmail: ctx.senderEmail,
          senderName: ctx.senderName,
          referenceNumber: ctx.referenceNumber,
          workspaceName: ctx.workspaceName,
          currentStep: 'confirming',
          stepNumber: 6,
          totalSteps: 7,
          stepDetails: 'Generating your staffing confirmation with all details. Final summary coming shortly.',
        });
        console.log(`[TrinityStaffing] Step 6 (confirming) notification sent for ${ctx.referenceNumber}`);
      } catch (err) {
        console.error('[TrinityStaffing] Failed to send step 6 notification:', err);
      }
    }
    
    const deductResult = await premiumFeatureGating.deductCredits(
      workflow.workspaceId,
      'trinity_staffing_confirmation',
      userId,
      1,
      { workflowId: workflow.id }
    );
    
    if (!deductResult.success) {
      console.warn(`[TrinityStaffing] Confirmation skipped - insufficient credits`);
      return;
    }
    
    const settings = this.getSettings(workflow.workspaceId);
    const confirmationNumber = `TS-${Date.now().toString(36).toUpperCase()}`;
    
    // Format location for confirmation email
    const locationObj = workflow.parsedRequest.location;
    const confirmationLocation = typeof locationObj === 'string' 
      ? locationObj 
      : `${locationObj?.address || ''}, ${locationObj?.city || ''}, ${locationObj?.state || ''}`.trim();
    
    // Format date for confirmation
    const shiftDateStr = workflow.parsedRequest.requestedDate instanceof Date 
      ? workflow.parsedRequest.requestedDate.toLocaleDateString() 
      : String(workflow.parsedRequest.requestedDate || '');
    
    const confirmationData: ConfirmationEmailData = {
      clientEmail: workflow.parsedRequest.clientInfo.email,
      clientName: workflow.parsedRequest.clientInfo.name || 'Valued Client',
      shiftDate: shiftDateStr,
      startTime: workflow.parsedRequest.startTime,
      endTime: workflow.parsedRequest.endTime,
      location: confirmationLocation,
      positionType: workflow.parsedRequest.positionType,
      officers: workflow.assignedEmployees.map(emp => ({
        name: emp.name,
        phone: emp.phone,
        certifications: [],
      })),
      confirmationNumber,
      billingTerms: settings.defaultBillingTerms,
    };
    
    const result = await clientConfirmationService.sendConfirmation(confirmationData);
    
    workflow.confirmationNumber = result.confirmationNumber || confirmationNumber;
    workflow.status = 'confirmed';
    workflow.completedAt = new Date();
    
    // STEP 7: Completed - Send full who/what/where/why/how summary to sender
    if (ctx?.senderEmail) {
      try {
        const startHour = parseInt(workflow.parsedRequest.startTime?.split(':')[0] || '0');
        const endHour = parseInt(workflow.parsedRequest.endTime?.split(':')[0] || '0');
        const durationHours = endHour >= startHour ? endHour - startHour : (24 - startHour + endHour);
        
        // Format location properly
        const locationObj = workflow.parsedRequest.location;
        const locationStr = typeof locationObj === 'string' 
          ? locationObj 
          : `${locationObj?.address || ''}, ${locationObj?.city || ''}, ${locationObj?.state || ''}`.trim();
        const fullAddress = typeof locationObj === 'object' 
          ? `${locationObj?.address || ''}, ${locationObj?.city || ''}, ${locationObj?.state || ''} ${locationObj?.zipCode || ''}`.trim()
          : undefined;
        
        // Format date properly
        const dateStr = workflow.parsedRequest.requestedDate instanceof Date 
          ? workflow.parsedRequest.requestedDate.toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })
          : String(workflow.parsedRequest.requestedDate || '');
        
        await emailService.sendStaffingCompletionSummary({
          workspaceId: workflow.workspaceId,
          senderEmail: ctx.senderEmail,
          senderName: ctx.senderName,
          referenceNumber: ctx.referenceNumber,
          workspaceName: ctx.workspaceName,
          confirmationNumber: workflow.confirmationNumber,
          summary: {
            who: {
              assignedStaff: workflow.assignedEmployees.map(emp => ({
                name: emp.name,
                phone: emp.phone,
                role: emp.role || workflow.parsedRequest?.positionType || 'Security Officer',
              })),
              totalStaffCount: workflow.assignedEmployees.length,
            },
            what: {
              positionType: workflow.parsedRequest.positionType || 'Security Officer',
              specialRequirements: workflow.parsedRequest.specialRequirements,
            },
            where: {
              location: locationStr,
              address: fullAddress,
              pocName: workflow.parsedRequest.clientInfo.name,
              pocPhone: workflow.parsedRequest.clientInfo.phone,
            },
            when: {
              date: dateStr,
              startTime: workflow.parsedRequest.startTime,
              endTime: workflow.parsedRequest.endTime,
              duration: `${durationHours} hour${durationHours !== 1 ? 's' : ''}`,
            },
            why: {
              requestSource: 'Email Request',
              clientName: workflow.parsedRequest.clientInfo.name || workflow.parsedRequest.clientInfo.companyName || 'Client',
            },
            how: {
              billingTerms: settings.defaultBillingTerms === 'due_on_receipt' 
                ? 'Due on Receipt' 
                : 'Net 30 Terms',
              invoiceWillFollow: true,
            },
          },
          nextSteps: [
            'Our assigned personnel will arrive at the specified time',
            'Site contact will be notified with officer details',
            'An invoice will be sent after service completion',
            'Contact us immediately if any changes are needed',
          ],
          specialInstructions: workflow.parsedRequest.notes || undefined,
        });
        console.log(`[TrinityStaffing] Step 7 (completion summary) sent for ${ctx.referenceNumber} -> ${workflow.confirmationNumber}`);
      } catch (err) {
        console.error('[TrinityStaffing] Failed to send completion summary:', err);
      }
    }
  }
  
  /**
   * Create a new workflow
   */
  private createWorkflow(workspaceId: string, emailId: string): StaffingWorkflow {
    const workflow: StaffingWorkflow = {
      id: `WORKFLOW-${Date.now()}-${Math.random().toString(36).substring(2, 8)}`,
      workspaceId,
      status: 'pending',
      emailId,
      assignedEmployees: [],
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    
    this.workflows.set(workflow.id, workflow);
    return workflow;
  }
  
  /**
   * Update workflow state
   */
  private updateWorkflow(workflow: StaffingWorkflow): void {
    workflow.updatedAt = new Date();
    this.workflows.set(workflow.id, workflow);
  }
  
  /**
   * Get workflow by ID
   */
  getWorkflow(workflowId: string): StaffingWorkflow | undefined {
    return this.workflows.get(workflowId);
  }
  
  /**
   * Get all workflows for a workspace
   */
  getWorkflowsByWorkspace(workspaceId: string): StaffingWorkflow[] {
    return Array.from(this.workflows.values())
      .filter(w => w.workspaceId === workspaceId);
  }
  
  /**
   * Get settings for a workspace
   */
  getSettings(workspaceId: string): OrchestratorSettings {
    return this.settings.get(workspaceId) || { ...DEFAULT_SETTINGS };
  }
  
  /**
   * Update settings for a workspace
   */
  updateSettings(workspaceId: string, settings: Partial<OrchestratorSettings>): OrchestratorSettings {
    const current = this.getSettings(workspaceId);
    const updated = { ...current, ...settings };
    this.settings.set(workspaceId, updated);
    return updated;
  }
  
  /**
   * Cancel a workflow
   */
  async cancelWorkflow(workflowId: string, reason: string): Promise<void> {
    const workflow = this.workflows.get(workflowId);
    if (workflow) {
      workflow.status = 'cancelled';
      workflow.error = reason;
      workflow.completedAt = new Date();
      this.updateWorkflow(workflow);
      
      if (workflow.escalationState) {
        await escalationChainService.cancelEscalation(workflowId, reason);
      }
    }
  }
  
  /**
   * Get orchestrator status
   */
  getStatus(workspaceId: string): {
    enabled: boolean;
    activeWorkflows: number;
    pendingEscalations: number;
    todayStats: {
      processed: number;
      assigned: number;
      confirmed: number;
      failed: number;
    };
  } {
    const settings = this.getSettings(workspaceId);
    const workspaceWorkflows = this.getWorkflowsByWorkspace(workspaceId);
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    const todayWorkflows = workspaceWorkflows.filter(w => w.createdAt >= today);
    
    return {
      enabled: settings.enabled,
      activeWorkflows: workspaceWorkflows.filter(w => 
        !['completed', 'cancelled', 'failed'].includes(w.status)
      ).length,
      pendingEscalations: workspaceWorkflows.filter(w => 
        w.status === 'escalated' || w.escalationState?.status === 'active'
      ).length,
      todayStats: {
        processed: todayWorkflows.length,
        assigned: todayWorkflows.filter(w => w.status === 'assigned' || w.status === 'confirmed').length,
        confirmed: todayWorkflows.filter(w => w.status === 'confirmed').length,
        failed: todayWorkflows.filter(w => w.status === 'failed').length,
      },
    };
  }
  
  /**
   * Get workspace config by webhook token (for public webhook validation)
   */
  getWorkspaceByWebhookToken(token: string): WebhookConfig | null {
    return this.webhookConfigs.get(token) || null;
  }
  
  /**
   * Register a webhook token for a workspace
   */
  registerWebhookToken(
    workspaceId: string,
    token: string,
    secret?: string,
    systemUserId?: string
  ): WebhookConfig {
    const config: WebhookConfig = {
      workspaceId,
      webhookToken: token,
      webhookSecret: secret,
      systemUserId,
      createdAt: new Date(),
    };
    this.webhookConfigs.set(token, config);
    return config;
  }
  
  /**
   * Generate a new webhook token for a workspace
   */
  generateWebhookToken(workspaceId: string, systemUserId?: string): WebhookConfig {
    const token = `wh_${workspaceId}_${Date.now()}_${Math.random().toString(36).substring(2, 15)}`;
    const secret = `whsec_${Math.random().toString(36).substring(2, 30)}`;
    return this.registerWebhookToken(workspaceId, token, secret, systemUserId);
  }
  
  /**
   * Revoke a webhook token
   */
  revokeWebhookToken(token: string): boolean {
    return this.webhookConfigs.delete(token);
  }
  
  /**
   * Get webhook config for workspace
   */
  getWebhookConfigForWorkspace(workspaceId: string): WebhookConfig | null {
    for (const config of this.webhookConfigs.values()) {
      if (config.workspaceId === workspaceId) {
        return config;
      }
    }
    return null;
  }
}

export const trinityStaffingOrchestrator = new TrinityStaffingOrchestrator();

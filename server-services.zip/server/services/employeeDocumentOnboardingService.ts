/**
 * Employee Document Onboarding Service
 * 
 * Manages required document collection for employee onboarding.
 * Security guards have specific compliance requirements that must be completed
 * before they can be assigned to shifts.
 * 
 * Features:
 * - Industry-specific document requirements (security guard, armed guard, etc.)
 * - Document completion tracking
 * - Work eligibility verification
 * - Dashboard task list for incomplete documents
 * - Expiration tracking and renewal alerts
 */

import { db } from '../db';
import { employees, employeeDocuments, workspaces } from '@shared/schema';
import { eq, and, isNull, inArray } from 'drizzle-orm';
import { platformEventBus } from './platformEventBus';

export type SecurityPosition = 'unarmed_guard' | 'armed_guard' | 'supervisor' | 'site_manager';

export interface RequiredDocument {
  id: string;
  documentType: string;
  name: string;
  description: string;
  category: 'licensing' | 'training' | 'background' | 'compliance' | 'identification';
  priority: 'critical' | 'high' | 'medium';
  expiresAfterYears?: number;
  renewalRequired: boolean;
  blocksWorkAssignment: boolean;
}

export interface DocumentRequirementStatus {
  requirement: RequiredDocument;
  status: 'not_started' | 'uploaded' | 'pending_review' | 'approved' | 'rejected' | 'expired';
  documentId?: string;
  uploadedAt?: Date;
  expirationDate?: Date;
  daysUntilExpiration?: number;
  rejectionReason?: string;
}

export interface EmployeeOnboardingStatus {
  employeeId: string;
  employeeName: string;
  position: SecurityPosition;
  isWorkEligible: boolean;
  completionPercentage: number;
  criticalDocumentsMissing: number;
  totalDocumentsRequired: number;
  totalDocumentsCompleted: number;
  documentStatuses: DocumentRequirementStatus[];
  blockedReasons: string[];
  nextExpiringDocument?: {
    name: string;
    expirationDate: Date;
    daysUntilExpiration: number;
  };
}

const SECURITY_GUARD_REQUIREMENTS: Record<SecurityPosition, RequiredDocument[]> = {
  unarmed_guard: [
    {
      id: 'guard_card',
      documentType: 'guard_card',
      name: 'Security Guard Card',
      description: 'State-issued security guard license. Required before any work assignment.',
      category: 'licensing',
      priority: 'critical',
      expiresAfterYears: 2,
      renewalRequired: true,
      blocksWorkAssignment: true,
    },
    {
      id: 'background_check',
      documentType: 'background_check',
      name: 'Background Check Results',
      description: 'Clear background check from authorized agency.',
      category: 'background',
      priority: 'critical',
      renewalRequired: false,
      blocksWorkAssignment: true,
    },
    {
      id: 'training_40hr',
      documentType: 'training_certificate',
      name: '40-Hour Security Training',
      description: 'State-mandated 40-hour security officer training certificate.',
      category: 'training',
      priority: 'high',
      renewalRequired: false,
      blocksWorkAssignment: true,
    },
    {
      id: 'photo_id',
      documentType: 'government_id',
      name: 'Government-Issued Photo ID',
      description: 'Valid driver\'s license, state ID, or passport.',
      category: 'identification',
      priority: 'critical',
      expiresAfterYears: 8,
      renewalRequired: true,
      blocksWorkAssignment: true,
    },
    {
      id: 'ssn_card',
      documentType: 'social_security_card',
      name: 'Social Security Card',
      description: 'Social Security card for I-9 and payroll verification.',
      category: 'identification',
      priority: 'high',
      renewalRequired: false,
      blocksWorkAssignment: false,
    },
    {
      id: 'w4_form',
      documentType: 'tax_form',
      name: 'W-4 Tax Withholding Form',
      description: 'Federal tax withholding election form.',
      category: 'compliance',
      priority: 'high',
      renewalRequired: false,
      blocksWorkAssignment: false,
    },
    {
      id: 'direct_deposit',
      documentType: 'direct_deposit_form',
      name: 'Direct Deposit Authorization',
      description: 'Bank account information for payroll.',
      category: 'compliance',
      priority: 'medium',
      renewalRequired: false,
      blocksWorkAssignment: false,
    },
    {
      id: 'handbook_ack',
      documentType: 'policy_acknowledgment',
      name: 'Employee Handbook Acknowledgment',
      description: 'Signed acknowledgment of company policies.',
      category: 'compliance',
      priority: 'medium',
      renewalRequired: false,
      blocksWorkAssignment: false,
    },
  ],

  armed_guard: [
    {
      id: 'guard_card',
      documentType: 'guard_card',
      name: 'Security Guard Card',
      description: 'State-issued security guard license. Required before any work assignment.',
      category: 'licensing',
      priority: 'critical',
      expiresAfterYears: 2,
      renewalRequired: true,
      blocksWorkAssignment: true,
    },
    {
      id: 'firearms_permit',
      documentType: 'firearms_permit',
      name: 'Firearms Permit',
      description: 'State-issued armed security firearms permit.',
      category: 'licensing',
      priority: 'critical',
      expiresAfterYears: 1,
      renewalRequired: true,
      blocksWorkAssignment: true,
    },
    {
      id: 'firearms_qualification',
      documentType: 'firearms_qualification',
      name: 'Firearms Qualification Certificate',
      description: 'Annual firearms qualification from approved range.',
      category: 'training',
      priority: 'critical',
      expiresAfterYears: 1,
      renewalRequired: true,
      blocksWorkAssignment: true,
    },
    {
      id: 'background_check',
      documentType: 'background_check',
      name: 'Background Check Results',
      description: 'Clear background check from authorized agency.',
      category: 'background',
      priority: 'critical',
      renewalRequired: false,
      blocksWorkAssignment: true,
    },
    {
      id: 'training_40hr',
      documentType: 'training_certificate',
      name: '40-Hour Security Training',
      description: 'State-mandated 40-hour security officer training certificate.',
      category: 'training',
      priority: 'high',
      renewalRequired: false,
      blocksWorkAssignment: true,
    },
    {
      id: 'photo_id',
      documentType: 'government_id',
      name: 'Government-Issued Photo ID',
      description: 'Valid driver\'s license, state ID, or passport.',
      category: 'identification',
      priority: 'critical',
      expiresAfterYears: 8,
      renewalRequired: true,
      blocksWorkAssignment: true,
    },
    {
      id: 'ssn_card',
      documentType: 'social_security_card',
      name: 'Social Security Card',
      description: 'Social Security card for I-9 and payroll verification.',
      category: 'identification',
      priority: 'high',
      renewalRequired: false,
      blocksWorkAssignment: false,
    },
    {
      id: 'w4_form',
      documentType: 'tax_form',
      name: 'W-4 Tax Withholding Form',
      description: 'Federal tax withholding election form.',
      category: 'compliance',
      priority: 'high',
      renewalRequired: false,
      blocksWorkAssignment: false,
    },
    {
      id: 'direct_deposit',
      documentType: 'direct_deposit_form',
      name: 'Direct Deposit Authorization',
      description: 'Bank account information for payroll.',
      category: 'compliance',
      priority: 'medium',
      renewalRequired: false,
      blocksWorkAssignment: false,
    },
    {
      id: 'handbook_ack',
      documentType: 'policy_acknowledgment',
      name: 'Employee Handbook Acknowledgment',
      description: 'Signed acknowledgment of company policies.',
      category: 'compliance',
      priority: 'medium',
      renewalRequired: false,
      blocksWorkAssignment: false,
    },
  ],

  supervisor: [
    {
      id: 'guard_card',
      documentType: 'guard_card',
      name: 'Security Guard Card',
      description: 'State-issued security guard license.',
      category: 'licensing',
      priority: 'critical',
      expiresAfterYears: 2,
      renewalRequired: true,
      blocksWorkAssignment: true,
    },
    {
      id: 'background_check',
      documentType: 'background_check',
      name: 'Background Check Results',
      description: 'Clear background check from authorized agency.',
      category: 'background',
      priority: 'critical',
      renewalRequired: false,
      blocksWorkAssignment: true,
    },
    {
      id: 'training_40hr',
      documentType: 'training_certificate',
      name: '40-Hour Security Training',
      description: 'State-mandated 40-hour security officer training certificate.',
      category: 'training',
      priority: 'high',
      renewalRequired: false,
      blocksWorkAssignment: true,
    },
    {
      id: 'supervisor_training',
      documentType: 'supervisor_training',
      name: 'Supervisor Training Certificate',
      description: 'Security supervisor leadership training.',
      category: 'training',
      priority: 'high',
      renewalRequired: false,
      blocksWorkAssignment: false,
    },
    {
      id: 'photo_id',
      documentType: 'government_id',
      name: 'Government-Issued Photo ID',
      description: 'Valid driver\'s license, state ID, or passport.',
      category: 'identification',
      priority: 'critical',
      expiresAfterYears: 8,
      renewalRequired: true,
      blocksWorkAssignment: true,
    },
    {
      id: 'ssn_card',
      documentType: 'social_security_card',
      name: 'Social Security Card',
      description: 'Social Security card for I-9 and payroll verification.',
      category: 'identification',
      priority: 'high',
      renewalRequired: false,
      blocksWorkAssignment: false,
    },
    {
      id: 'w4_form',
      documentType: 'tax_form',
      name: 'W-4 Tax Withholding Form',
      description: 'Federal tax withholding election form.',
      category: 'compliance',
      priority: 'high',
      renewalRequired: false,
      blocksWorkAssignment: false,
    },
    {
      id: 'handbook_ack',
      documentType: 'policy_acknowledgment',
      name: 'Employee Handbook Acknowledgment',
      description: 'Signed acknowledgment of company policies.',
      category: 'compliance',
      priority: 'medium',
      renewalRequired: false,
      blocksWorkAssignment: false,
    },
  ],

  site_manager: [
    {
      id: 'background_check',
      documentType: 'background_check',
      name: 'Background Check Results',
      description: 'Clear background check from authorized agency.',
      category: 'background',
      priority: 'critical',
      renewalRequired: false,
      blocksWorkAssignment: true,
    },
    {
      id: 'photo_id',
      documentType: 'government_id',
      name: 'Government-Issued Photo ID',
      description: 'Valid driver\'s license, state ID, or passport.',
      category: 'identification',
      priority: 'critical',
      expiresAfterYears: 8,
      renewalRequired: true,
      blocksWorkAssignment: true,
    },
    {
      id: 'ssn_card',
      documentType: 'social_security_card',
      name: 'Social Security Card',
      description: 'Social Security card for I-9 and payroll verification.',
      category: 'identification',
      priority: 'high',
      renewalRequired: false,
      blocksWorkAssignment: false,
    },
    {
      id: 'w4_form',
      documentType: 'tax_form',
      name: 'W-4 Tax Withholding Form',
      description: 'Federal tax withholding election form.',
      category: 'compliance',
      priority: 'high',
      renewalRequired: false,
      blocksWorkAssignment: false,
    },
    {
      id: 'handbook_ack',
      documentType: 'policy_acknowledgment',
      name: 'Employee Handbook Acknowledgment',
      description: 'Signed acknowledgment of company policies.',
      category: 'compliance',
      priority: 'medium',
      renewalRequired: false,
      blocksWorkAssignment: false,
    },
  ],
};

class EmployeeDocumentOnboardingService {
  
  getPositionFromRole(role: string | null): SecurityPosition {
    if (!role) return 'unarmed_guard';
    const roleLower = role.toLowerCase();
    if (roleLower.includes('armed') || roleLower.includes('firearm')) return 'armed_guard';
    if (roleLower.includes('supervisor')) return 'supervisor';
    if (roleLower.includes('manager') || roleLower.includes('site manager')) return 'site_manager';
    return 'unarmed_guard';
  }

  getRequiredDocuments(position: SecurityPosition): RequiredDocument[] {
    return SECURITY_GUARD_REQUIREMENTS[position] || SECURITY_GUARD_REQUIREMENTS.unarmed_guard;
  }

  async getEmployeeOnboardingStatus(employeeId: string): Promise<EmployeeOnboardingStatus | null> {
    const employee = await db.query.employees.findFirst({
      where: eq(employees.id, employeeId),
    });

    if (!employee) return null;

    const position = this.getPositionFromRole(employee.role);
    const requirements = this.getRequiredDocuments(position);

    const uploadedDocs = await db.query.employeeDocuments.findMany({
      where: eq(employeeDocuments.employeeId, employeeId),
    });

    const docsByType = new Map(uploadedDocs.map(d => [d.documentType, d]));
    const now = new Date();

    const documentStatuses: DocumentRequirementStatus[] = requirements.map(req => {
      const doc = docsByType.get(req.documentType);
      
      if (!doc) {
        return {
          requirement: req,
          status: 'not_started' as const,
        };
      }

      let status: DocumentRequirementStatus['status'] = 'uploaded';
      
      if (doc.status === 'approved' || doc.isVerified) {
        if (doc.expirationDate && doc.expirationDate < now) {
          status = 'expired';
        } else {
          status = 'approved';
        }
      } else if (doc.rejectedAt) {
        status = 'rejected';
      } else if (doc.requiresApproval && !doc.approvedAt) {
        status = 'pending_review';
      }

      let daysUntilExpiration: number | undefined;
      if (doc.expirationDate) {
        daysUntilExpiration = Math.ceil((doc.expirationDate.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
      }

      return {
        requirement: req,
        status,
        documentId: doc.id,
        uploadedAt: doc.uploadedAt,
        expirationDate: doc.expirationDate || undefined,
        daysUntilExpiration,
        rejectionReason: doc.rejectionReason || undefined,
      };
    });

    const completedDocs = documentStatuses.filter(d => d.status === 'approved');
    const criticalMissing = documentStatuses.filter(
      d => d.requirement.blocksWorkAssignment && d.status !== 'approved'
    );

    const blockedReasons: string[] = [];
    for (const doc of criticalMissing) {
      if (doc.status === 'not_started') {
        blockedReasons.push(`Missing required document: ${doc.requirement.name}`);
      } else if (doc.status === 'pending_review') {
        blockedReasons.push(`Pending approval: ${doc.requirement.name}`);
      } else if (doc.status === 'rejected') {
        blockedReasons.push(`Document rejected: ${doc.requirement.name} - ${doc.rejectionReason || 'See manager'}`);
      } else if (doc.status === 'expired') {
        blockedReasons.push(`Expired document: ${doc.requirement.name}`);
      }
    }

    const expiringDocs = documentStatuses
      .filter(d => d.daysUntilExpiration !== undefined && d.daysUntilExpiration > 0 && d.daysUntilExpiration <= 30)
      .sort((a, b) => (a.daysUntilExpiration || 999) - (b.daysUntilExpiration || 999));

    return {
      employeeId,
      employeeName: `${employee.firstName} ${employee.lastName}`,
      position,
      isWorkEligible: criticalMissing.length === 0,
      completionPercentage: Math.round((completedDocs.length / requirements.length) * 100),
      criticalDocumentsMissing: criticalMissing.length,
      totalDocumentsRequired: requirements.length,
      totalDocumentsCompleted: completedDocs.length,
      documentStatuses,
      blockedReasons,
      nextExpiringDocument: expiringDocs[0] ? {
        name: expiringDocs[0].requirement.name,
        expirationDate: expiringDocs[0].expirationDate!,
        daysUntilExpiration: expiringDocs[0].daysUntilExpiration!,
      } : undefined,
    };
  }

  async checkWorkEligibility(employeeId: string): Promise<{ eligible: boolean; reasons: string[] }> {
    const status = await this.getEmployeeOnboardingStatus(employeeId);
    if (!status) {
      return { eligible: false, reasons: ['Employee not found'] };
    }
    return { eligible: status.isWorkEligible, reasons: status.blockedReasons };
  }

  async getWorkspaceOnboardingOverview(workspaceId: string): Promise<{
    totalEmployees: number;
    workEligibleCount: number;
    pendingDocumentsCount: number;
    expiringDocumentsCount: number;
    employeeStatuses: Array<{ employeeId: string; employeeName: string; isWorkEligible: boolean; completionPercentage: number }>;
  }> {
    const workspaceEmployees = await db.query.employees.findMany({
      where: and(
        eq(employees.workspaceId, workspaceId),
        isNull(employees.terminationDate)
      ),
    });

    const employeeStatuses = await Promise.all(
      workspaceEmployees.map(async (emp) => {
        const status = await this.getEmployeeOnboardingStatus(emp.id);
        return {
          employeeId: emp.id,
          employeeName: `${emp.firstName} ${emp.lastName}`,
          isWorkEligible: status?.isWorkEligible || false,
          completionPercentage: status?.completionPercentage || 0,
        };
      })
    );

    const allDocs = await db.query.employeeDocuments.findMany({
      where: eq(employeeDocuments.workspaceId, workspaceId),
    });

    const now = new Date();
    const thirtyDaysFromNow = new Date(now.getTime() + 30 * 24 * 60 * 60 * 1000);

    const expiringCount = allDocs.filter(
      d => d.expirationDate && d.expirationDate > now && d.expirationDate <= thirtyDaysFromNow
    ).length;

    const pendingCount = allDocs.filter(
      d => d.requiresApproval && !d.approvedAt && !d.rejectedAt
    ).length;

    return {
      totalEmployees: workspaceEmployees.length,
      workEligibleCount: employeeStatuses.filter(e => e.isWorkEligible).length,
      pendingDocumentsCount: pendingCount,
      expiringDocumentsCount: expiringCount,
      employeeStatuses,
    };
  }

  async notifyDocumentRequired(employeeId: string): Promise<void> {
    const status = await this.getEmployeeOnboardingStatus(employeeId);
    if (!status) return;

    const missingDocs = status.documentStatuses.filter(d => d.status === 'not_started');
    if (missingDocs.length > 0) {
      platformEventBus.publish({
        type: 'employee_documents_required',
        workspaceId: 'system',
        payload: {
          employeeId,
          employeeName: status.employeeName,
          missingDocuments: missingDocs.map(d => d.requirement.name),
          blockedFromWork: !status.isWorkEligible,
        },
        metadata: { source: 'EmployeeDocumentOnboardingService' },
      });
    }
  }

  async createOnboardingTasksForEmployee(employeeId: string): Promise<void> {
    const status = await this.getEmployeeOnboardingStatus(employeeId);
    if (!status) return;

    const incompleteDocs = status.documentStatuses.filter(d => d.status !== 'approved');
    
    for (const doc of incompleteDocs) {
      platformEventBus.publish({
        type: 'employee_task_created',
        workspaceId: 'system',
        payload: {
          employeeId,
          taskType: 'document_upload',
          taskName: `Upload: ${doc.requirement.name}`,
          taskDescription: doc.requirement.description,
          priority: doc.requirement.priority,
          blocksWork: doc.requirement.blocksWorkAssignment,
          documentType: doc.requirement.documentType,
        },
        metadata: { source: 'EmployeeDocumentOnboardingService' },
      });
    }

    console.log(`[EmployeeDocumentOnboarding] Created ${incompleteDocs.length} tasks for employee ${employeeId}`);
  }
}

export const employeeDocumentOnboardingService = new EmployeeDocumentOnboardingService();

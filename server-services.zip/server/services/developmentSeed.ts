/**
 * Development Database Seeding Service
 * 
 * Populates realistic simulated data for development and testing.
 * Only runs in development mode (when REPLIT_DEPLOYMENT is NOT '1').
 * Uses idempotent INSERT ... ON CONFLICT DO NOTHING for safe re-runs.
 * 
 * Trigger: Runs on server startup in development mode
 * Guard: Checks for sentinel workspace to avoid duplicate seeding
 */

import { db } from "../db";
import { sql } from "drizzle-orm";

const DEV_SENTINEL_WORKSPACE = 'dev-acme-security-ws';

export async function runDevelopmentSeed(): Promise<{ success: boolean; message: string }> {
  const isProduction = process.env.REPLIT_DEPLOYMENT === '1';
  
  if (isProduction) {
    return { success: true, message: 'Skipped - production environment' };
  }

  console.log('[DevSeed] Checking development database...');

  try {
    const existing = await db.execute(sql`
      SELECT id FROM workspaces WHERE id = ${DEV_SENTINEL_WORKSPACE} LIMIT 1
    `);

    if (existing.rows.length > 0) {
      console.log('[DevSeed] Development data already exists. Skipping.');
      return { success: true, message: 'Already seeded' };
    }

    console.log('[DevSeed] Seeding development data...');

    await db.transaction(async (tx) => {
      // =====================================================================
      // 1. DEV USERS - Test accounts for different roles
      // =====================================================================
      console.log('[DevSeed] Creating test users...');

      const devUsers = [
        { id: 'dev-owner-001', email: 'owner@acme-security.test', firstName: 'Marcus', lastName: 'Rivera', passwordHash: '$2b$10$XEUX3wL9wI2VEjEoUdCSw.O8xFVIfhUJAGahknql8PdWYj0DITrSe', role: 'user' },
        { id: 'dev-manager-001', email: 'manager@acme-security.test', firstName: 'Sarah', lastName: 'Chen', passwordHash: '$2b$10$XEUX3wL9wI2VEjEoUdCSw.O8xFVIfhUJAGahknql8PdWYj0DITrSe', role: 'user' },
        { id: 'dev-manager-002', email: 'ops@acme-security.test', firstName: 'James', lastName: 'Washington', passwordHash: '$2b$10$XEUX3wL9wI2VEjEoUdCSw.O8xFVIfhUJAGahknql8PdWYj0DITrSe', role: 'user' },
        { id: 'dev-emp-001', email: 'garcia@acme-security.test', firstName: 'Carlos', lastName: 'Garcia', passwordHash: '$2b$10$XEUX3wL9wI2VEjEoUdCSw.O8xFVIfhUJAGahknql8PdWYj0DITrSe', role: 'user' },
        { id: 'dev-emp-002', email: 'johnson@acme-security.test', firstName: 'Diana', lastName: 'Johnson', passwordHash: '$2b$10$XEUX3wL9wI2VEjEoUdCSw.O8xFVIfhUJAGahknql8PdWYj0DITrSe', role: 'user' },
        { id: 'dev-emp-003', email: 'williams@acme-security.test', firstName: 'Robert', lastName: 'Williams', passwordHash: '$2b$10$XEUX3wL9wI2VEjEoUdCSw.O8xFVIfhUJAGahknql8PdWYj0DITrSe', role: 'user' },
        { id: 'dev-emp-004', email: 'martinez@acme-security.test', firstName: 'Elena', lastName: 'Martinez', passwordHash: '$2b$10$XEUX3wL9wI2VEjEoUdCSw.O8xFVIfhUJAGahknql8PdWYj0DITrSe', role: 'user' },
        { id: 'dev-emp-005', email: 'thompson@acme-security.test', firstName: 'Michael', lastName: 'Thompson', passwordHash: '$2b$10$XEUX3wL9wI2VEjEoUdCSw.O8xFVIfhUJAGahknql8PdWYj0DITrSe', role: 'user' },
        { id: 'dev-emp-006', email: 'davis@acme-security.test', firstName: 'Angela', lastName: 'Davis', passwordHash: '$2b$10$XEUX3wL9wI2VEjEoUdCSw.O8xFVIfhUJAGahknql8PdWYj0DITrSe', role: 'user' },
        { id: 'dev-emp-007', email: 'brown@acme-security.test', firstName: 'Kevin', lastName: 'Brown', passwordHash: '$2b$10$XEUX3wL9wI2VEjEoUdCSw.O8xFVIfhUJAGahknql8PdWYj0DITrSe', role: 'user' },
        { id: 'dev-emp-008', email: 'lee@acme-security.test', firstName: 'Jennifer', lastName: 'Lee', passwordHash: '$2b$10$XEUX3wL9wI2VEjEoUdCSw.O8xFVIfhUJAGahknql8PdWYj0DITrSe', role: 'user' },
        { id: 'dev-emp-009', email: 'wilson@acme-security.test', firstName: 'David', lastName: 'Wilson', passwordHash: '$2b$10$XEUX3wL9wI2VEjEoUdCSw.O8xFVIfhUJAGahknql8PdWYj0DITrSe', role: 'user' },
        { id: 'dev-emp-010', email: 'anderson@acme-security.test', firstName: 'Lisa', lastName: 'Anderson', passwordHash: '$2b$10$XEUX3wL9wI2VEjEoUdCSw.O8xFVIfhUJAGahknql8PdWYj0DITrSe', role: 'user' },
        { id: 'dev-owner-002', email: 'owner@metroplex-cleaning.test', firstName: 'Patricia', lastName: 'Owens', passwordHash: '$2b$10$XEUX3wL9wI2VEjEoUdCSw.O8xFVIfhUJAGahknql8PdWYj0DITrSe', role: 'user' },
        { id: 'dev-emp-011', email: 'clark@metroplex.test', firstName: 'Steven', lastName: 'Clark', passwordHash: '$2b$10$XEUX3wL9wI2VEjEoUdCSw.O8xFVIfhUJAGahknql8PdWYj0DITrSe', role: 'user' },
        { id: 'dev-emp-012', email: 'hall@metroplex.test', firstName: 'Maria', lastName: 'Hall', passwordHash: '$2b$10$XEUX3wL9wI2VEjEoUdCSw.O8xFVIfhUJAGahknql8PdWYj0DITrSe', role: 'user' },
        { id: 'dev-emp-013', email: 'young@metroplex.test', firstName: 'Anthony', lastName: 'Young', passwordHash: '$2b$10$XEUX3wL9wI2VEjEoUdCSw.O8xFVIfhUJAGahknql8PdWYj0DITrSe', role: 'user' },
        { id: 'dev-emp-014', email: 'wright@metroplex.test', firstName: 'Sandra', lastName: 'Wright', passwordHash: '$2b$10$XEUX3wL9wI2VEjEoUdCSw.O8xFVIfhUJAGahknql8PdWYj0DITrSe', role: 'user' },
        { id: 'dev-demo-user', email: 'demo@coaileague.test', firstName: 'Demo', lastName: 'User', passwordHash: '$2b$10$XEUX3wL9wI2VEjEoUdCSw.O8xFVIfhUJAGahknql8PdWYj0DITrSe', role: 'user' },
      ];

      for (const user of devUsers) {
        await tx.execute(sql`
          INSERT INTO users (id, email, first_name, last_name, password_hash, role, email_verified, current_workspace_id, created_at, updated_at, login_attempts, mfa_enabled)
          VALUES (${user.id}, ${user.email}, ${user.firstName}, ${user.lastName}, ${user.passwordHash}, ${user.role}, TRUE, NULL, NOW(), NOW(), 0, FALSE)
          ON CONFLICT (id) DO NOTHING
        `);
      }

      // =====================================================================
      // 2. DEV WORKSPACES - Two test companies + demo workspace
      // =====================================================================
      console.log('[DevSeed] Creating test workspaces...');

      const devWorkspaces = [
        { id: DEV_SENTINEL_WORKSPACE, name: 'Acme Security Services', ownerId: 'dev-owner-001', tier: 'enterprise', status: 'active', category: 'security', maxEmp: 50, maxClients: 25 },
        { id: 'dev-metroplex-cleaning-ws', name: 'Metroplex Cleaning Co.', ownerId: 'dev-owner-002', tier: 'professional', status: 'active', category: 'cleaning', maxEmp: 20, maxClients: 15 },
        { id: 'dev-demo-workspace', name: 'Demo Workspace', ownerId: 'dev-demo-user', tier: 'enterprise', status: 'active', category: 'general', maxEmp: 100, maxClients: 50 },
      ];

      for (const ws of devWorkspaces) {
        await tx.execute(sql`
          INSERT INTO workspaces (id, name, owner_id, subscription_tier, subscription_status, business_category, max_employees, max_clients, created_at, updated_at)
          VALUES (${ws.id}, ${ws.name}, ${ws.ownerId}, ${ws.tier}, ${ws.status}, ${ws.category}, ${ws.maxEmp}, ${ws.maxClients}, NOW(), NOW())
          ON CONFLICT (id) DO NOTHING
        `);
      }

      // Update users with their workspace assignments
      await tx.execute(sql`UPDATE users SET current_workspace_id = ${DEV_SENTINEL_WORKSPACE} WHERE id IN ('dev-owner-001', 'dev-manager-001', 'dev-manager-002', 'dev-emp-001', 'dev-emp-002', 'dev-emp-003', 'dev-emp-004', 'dev-emp-005', 'dev-emp-006', 'dev-emp-007', 'dev-emp-008', 'dev-emp-009', 'dev-emp-010') AND current_workspace_id IS NULL`);
      await tx.execute(sql`UPDATE users SET current_workspace_id = 'dev-metroplex-cleaning-ws' WHERE id IN ('dev-owner-002', 'dev-emp-011', 'dev-emp-012', 'dev-emp-013', 'dev-emp-014') AND current_workspace_id IS NULL`);
      await tx.execute(sql`UPDATE users SET current_workspace_id = 'dev-demo-workspace' WHERE id = 'dev-demo-user' AND current_workspace_id IS NULL`);

      // =====================================================================
      // 3. DEV PLATFORM ROLES - Test admin roles
      // =====================================================================
      console.log('[DevSeed] Creating test platform roles...');

      await tx.execute(sql`
        INSERT INTO platform_roles (id, user_id, role, created_at, updated_at)
        VALUES ('dev-role-owner-001', 'dev-owner-001', 'root_admin', NOW(), NOW())
        ON CONFLICT (id) DO NOTHING
      `);

      // =====================================================================
      // 4. DEV EMPLOYEES - Acme Security team (13 employees)
      // =====================================================================
      console.log('[DevSeed] Creating test employees...');

      const acmeEmployees = [
        { id: 'dev-acme-emp-001', userId: 'dev-owner-001', firstName: 'Marcus', lastName: 'Rivera', email: 'owner@acme-security.test', hourlyRate: '45.00', role: 'Operations Director', workspaceRole: 'org_owner', empNum: 'EMP-ACME-00001' },
        { id: 'dev-acme-emp-002', userId: 'dev-manager-001', firstName: 'Sarah', lastName: 'Chen', email: 'manager@acme-security.test', hourlyRate: '35.00', role: 'Field Supervisor', workspaceRole: 'manager', empNum: 'EMP-ACME-00002' },
        { id: 'dev-acme-emp-003', userId: 'dev-manager-002', firstName: 'James', lastName: 'Washington', email: 'ops@acme-security.test', hourlyRate: '32.00', role: 'Scheduling Manager', workspaceRole: 'manager', empNum: 'EMP-ACME-00003' },
        { id: 'dev-acme-emp-004', userId: 'dev-emp-001', firstName: 'Carlos', lastName: 'Garcia', email: 'garcia@acme-security.test', hourlyRate: '22.00', role: 'Security Officer', workspaceRole: 'employee', empNum: 'EMP-ACME-00004' },
        { id: 'dev-acme-emp-005', userId: 'dev-emp-002', firstName: 'Diana', lastName: 'Johnson', email: 'johnson@acme-security.test', hourlyRate: '24.00', role: 'Senior Security Officer', workspaceRole: 'employee', empNum: 'EMP-ACME-00005' },
        { id: 'dev-acme-emp-006', userId: 'dev-emp-003', firstName: 'Robert', lastName: 'Williams', email: 'williams@acme-security.test', hourlyRate: '20.00', role: 'Security Officer', workspaceRole: 'employee', empNum: 'EMP-ACME-00006' },
        { id: 'dev-acme-emp-007', userId: 'dev-emp-004', firstName: 'Elena', lastName: 'Martinez', email: 'martinez@acme-security.test', hourlyRate: '23.00', role: 'Security Officer', workspaceRole: 'employee', empNum: 'EMP-ACME-00007' },
        { id: 'dev-acme-emp-008', userId: 'dev-emp-005', firstName: 'Michael', lastName: 'Thompson', email: 'thompson@acme-security.test', hourlyRate: '21.00', role: 'Security Officer', workspaceRole: 'employee', empNum: 'EMP-ACME-00008' },
        { id: 'dev-acme-emp-009', userId: 'dev-emp-006', firstName: 'Angela', lastName: 'Davis', email: 'davis@acme-security.test', hourlyRate: '22.50', role: 'Patrol Officer', workspaceRole: 'employee', empNum: 'EMP-ACME-00009' },
        { id: 'dev-acme-emp-010', userId: 'dev-emp-007', firstName: 'Kevin', lastName: 'Brown', email: 'brown@acme-security.test', hourlyRate: '20.00', role: 'Security Officer', workspaceRole: 'employee', empNum: 'EMP-ACME-00010' },
        { id: 'dev-acme-emp-011', userId: 'dev-emp-008', firstName: 'Jennifer', lastName: 'Lee', email: 'lee@acme-security.test', hourlyRate: '24.50', role: 'Access Control Specialist', workspaceRole: 'employee', empNum: 'EMP-ACME-00011' },
        { id: 'dev-acme-emp-012', userId: 'dev-emp-009', firstName: 'David', lastName: 'Wilson', email: 'wilson@acme-security.test', hourlyRate: '19.50', role: 'Security Officer', workspaceRole: 'employee', empNum: 'EMP-ACME-00012' },
        { id: 'dev-acme-emp-013', userId: 'dev-emp-010', firstName: 'Lisa', lastName: 'Anderson', email: 'anderson@acme-security.test', hourlyRate: '21.00', role: 'Dispatch Coordinator', workspaceRole: 'employee', empNum: 'EMP-ACME-00013' },
      ];

      for (const emp of acmeEmployees) {
        await tx.execute(sql`
          INSERT INTO employees (id, user_id, workspace_id, first_name, last_name, email, hourly_rate, role, workspace_role, employee_number, created_at, updated_at)
          VALUES (${emp.id}, ${emp.userId}, ${DEV_SENTINEL_WORKSPACE}, ${emp.firstName}, ${emp.lastName}, ${emp.email}, ${emp.hourlyRate}, ${emp.role}, ${emp.workspaceRole}, ${emp.empNum}, NOW(), NOW())
          ON CONFLICT (id) DO NOTHING
        `);
      }

      // Metroplex Cleaning employees (5 employees)
      const metroplexEmployees = [
        { id: 'dev-metro-emp-001', userId: 'dev-owner-002', firstName: 'Patricia', lastName: 'Owens', email: 'owner@metroplex-cleaning.test', hourlyRate: '40.00', role: 'Owner / GM', workspaceRole: 'org_owner', empNum: 'EMP-MTX-00001' },
        { id: 'dev-metro-emp-002', userId: 'dev-emp-011', firstName: 'Steven', lastName: 'Clark', email: 'clark@metroplex.test', hourlyRate: '18.00', role: 'Lead Janitor', workspaceRole: 'employee', empNum: 'EMP-MTX-00002' },
        { id: 'dev-metro-emp-003', userId: 'dev-emp-012', firstName: 'Maria', lastName: 'Hall', email: 'hall@metroplex.test', hourlyRate: '16.50', role: 'Cleaning Specialist', workspaceRole: 'employee', empNum: 'EMP-MTX-00003' },
        { id: 'dev-metro-emp-004', userId: 'dev-emp-013', firstName: 'Anthony', lastName: 'Young', email: 'young@metroplex.test', hourlyRate: '16.00', role: 'Cleaning Staff', workspaceRole: 'employee', empNum: 'EMP-MTX-00004' },
        { id: 'dev-metro-emp-005', userId: 'dev-emp-014', firstName: 'Sandra', lastName: 'Wright', email: 'wright@metroplex.test', hourlyRate: '17.00', role: 'Floor Technician', workspaceRole: 'employee', empNum: 'EMP-MTX-00005' },
      ];

      for (const emp of metroplexEmployees) {
        await tx.execute(sql`
          INSERT INTO employees (id, user_id, workspace_id, first_name, last_name, email, hourly_rate, role, workspace_role, employee_number, created_at, updated_at)
          VALUES (${emp.id}, ${emp.userId}, 'dev-metroplex-cleaning-ws', ${emp.firstName}, ${emp.lastName}, ${emp.email}, ${emp.hourlyRate}, ${emp.role}, ${emp.workspaceRole}, ${emp.empNum}, NOW(), NOW())
          ON CONFLICT (id) DO NOTHING
        `);
      }

      // =====================================================================
      // 5. DEV CLIENTS - Realistic client accounts
      // =====================================================================
      console.log('[DevSeed] Creating test clients...');

      const acmeClients = [
        { id: 'dev-client-001', firstName: 'Riverside', lastName: 'Mall Management', companyName: 'Riverside Shopping Center', email: 'security@riverside-mall.test', phone: '555-100-2001', address: '4500 Riverside Blvd', city: 'Dallas', state: 'TX', postalCode: '75201', contractRate: '28.00', pocName: 'Tom Bradley', pocPhone: '555-100-2002', pocEmail: 'tbradley@riverside-mall.test', pocTitle: 'Facilities Manager' },
        { id: 'dev-client-002', firstName: 'Downtown', lastName: 'Office Tower', companyName: 'Pinnacle Tower LLC', email: 'management@pinnacle-tower.test', phone: '555-200-3001', address: '1200 Main Street, Suite 500', city: 'Fort Worth', state: 'TX', postalCode: '76102', contractRate: '32.00', pocName: 'Rebecca Stone', pocPhone: '555-200-3002', pocEmail: 'rstone@pinnacle-tower.test', pocTitle: 'Property Manager' },
        { id: 'dev-client-003', firstName: 'Lone Star', lastName: 'Hospital', companyName: 'Lone Star Medical Center', email: 'security@lonestar-medical.test', phone: '555-300-4001', address: '8900 Medical Center Dr', city: 'Arlington', state: 'TX', postalCode: '76010', contractRate: '35.00', pocName: 'Dr. Karen Mitchell', pocPhone: '555-300-4002', pocEmail: 'kmitchell@lonestar-medical.test', pocTitle: 'Director of Safety' },
        { id: 'dev-client-004', firstName: 'Texas Star', lastName: 'Events', companyName: 'Texas Star Event Center', email: 'ops@texasstar-events.test', phone: '555-400-5001', address: '2200 Entertainment Ave', city: 'Grand Prairie', state: 'TX', postalCode: '75050', contractRate: '30.00', pocName: 'Miguel Santos', pocPhone: '555-400-5002', pocEmail: 'msantos@texasstar-events.test', pocTitle: 'Operations Director' },
        { id: 'dev-client-005', firstName: 'Heritage', lastName: 'Bank Group', companyName: 'Heritage National Bank', email: 'security@heritage-bank.test', phone: '555-500-6001', address: '700 Commerce Street', city: 'Dallas', state: 'TX', postalCode: '75202', contractRate: '38.00', pocName: 'William Harper', pocPhone: '555-500-6002', pocEmail: 'wharper@heritage-bank.test', pocTitle: 'VP Security' },
        { id: 'dev-client-006', firstName: 'Oakwood', lastName: 'Apartments', companyName: 'Oakwood Residential Management', email: 'management@oakwood-apts.test', phone: '555-600-7001', address: '3100 Oak Lawn Ave', city: 'Dallas', state: 'TX', postalCode: '75219', contractRate: '24.00', pocName: 'Janet Cruz', pocPhone: '555-600-7002', pocEmail: 'jcruz@oakwood-apts.test', pocTitle: 'Community Manager' },
        { id: 'dev-client-007', firstName: 'DFW', lastName: 'Logistics Hub', companyName: 'DFW Distribution Center', email: 'security@dfw-logistics.test', phone: '555-700-8001', address: '5600 Airport Freeway', city: 'Irving', state: 'TX', postalCode: '75062', contractRate: '26.00', pocName: 'Richard Park', pocPhone: '555-700-8002', pocEmail: 'rpark@dfw-logistics.test', pocTitle: 'Warehouse Manager' },
        { id: 'dev-client-008', firstName: 'Alliance', lastName: 'Protection Agency', companyName: 'Alliance National Security', email: 'contracts@alliance-security.test', phone: '555-800-9001', address: '900 Alliance Gateway', city: 'Fort Worth', state: 'TX', postalCode: '76177', contractRate: '40.00', pocName: 'Col. Frank Morrison', pocPhone: '555-800-9002', pocEmail: 'fmorrison@alliance-security.test', pocTitle: 'Contract Officer', isAgency: true },
      ];

      for (const client of acmeClients) {
        await tx.execute(sql`
          INSERT INTO clients (id, workspace_id, first_name, last_name, company_name, email, phone, address, city, state, postal_code, country, contract_rate, contract_rate_type, poc_name, poc_phone, poc_email, poc_title, is_agency, created_at, updated_at)
          VALUES (${client.id}, ${DEV_SENTINEL_WORKSPACE}, ${client.firstName}, ${client.lastName}, ${client.companyName}, ${client.email}, ${client.phone}, ${client.address}, ${client.city}, ${client.state}, ${client.postalCode}, 'US', ${client.contractRate}, 'hourly', ${client.pocName}, ${client.pocPhone}, ${client.pocEmail}, ${client.pocTitle}, ${(client as any).isAgency || false}, NOW(), NOW())
          ON CONFLICT (id) DO NOTHING
        `);
      }

      const metroplexClients = [
        { id: 'dev-client-101', firstName: 'Corporate', lastName: 'Plaza', companyName: 'Corporate Plaza Office Park', email: 'facilities@corp-plaza.test', phone: '555-110-2001', address: '2500 Corporate Blvd', city: 'Plano', state: 'TX', postalCode: '75024', contractRate: '22.00', pocName: 'Amy Foster', pocPhone: '555-110-2002', pocEmail: 'afoster@corp-plaza.test', pocTitle: 'Building Manager' },
        { id: 'dev-client-102', firstName: 'Sunset', lastName: 'Medical Office', companyName: 'Sunset Medical Associates', email: 'admin@sunset-medical.test', phone: '555-120-3001', address: '1800 Sunset Dr', city: 'Richardson', state: 'TX', postalCode: '75080', contractRate: '25.00', pocName: 'Nancy Kim', pocPhone: '555-120-3002', pocEmail: 'nkim@sunset-medical.test', pocTitle: 'Office Administrator' },
        { id: 'dev-client-103', firstName: 'Lakeside', lastName: 'Church', companyName: 'Lakeside Community Church', email: 'office@lakeside-church.test', phone: '555-130-4001', address: '600 Lake Shore Dr', city: 'Garland', state: 'TX', postalCode: '75040', contractRate: '18.00', pocName: 'Pastor John Reed', pocPhone: '555-130-4002', pocEmail: 'jreed@lakeside-church.test', pocTitle: 'Senior Pastor' },
      ];

      for (const client of metroplexClients) {
        await tx.execute(sql`
          INSERT INTO clients (id, workspace_id, first_name, last_name, company_name, email, phone, address, city, state, postal_code, country, contract_rate, contract_rate_type, poc_name, poc_phone, poc_email, poc_title, created_at, updated_at)
          VALUES (${client.id}, 'dev-metroplex-cleaning-ws', ${client.firstName}, ${client.lastName}, ${client.companyName}, ${client.email}, ${client.phone}, ${client.address}, ${client.city}, ${client.state}, ${client.postalCode}, 'US', ${client.contractRate}, 'hourly', ${client.pocName}, ${client.pocPhone}, ${client.pocEmail}, ${client.pocTitle}, NOW(), NOW())
          ON CONFLICT (id) DO NOTHING
        `);
      }

      // =====================================================================
      // 6. DEV SHIFTS - Sample shifts for the current week
      // =====================================================================
      console.log('[DevSeed] Creating test shifts...');

      const now = new Date();
      const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());

      const shiftTemplates = [
        { empId: 'dev-acme-emp-004', clientId: 'dev-client-001', title: 'Mall Patrol - Day Shift', category: 'security', dayOffset: 0, startHour: 6, endHour: 14 },
        { empId: 'dev-acme-emp-005', clientId: 'dev-client-001', title: 'Mall Patrol - Evening Shift', category: 'security', dayOffset: 0, startHour: 14, endHour: 22 },
        { empId: 'dev-acme-emp-006', clientId: 'dev-client-002', title: 'Tower Lobby - Day', category: 'field_ops', dayOffset: 0, startHour: 7, endHour: 15 },
        { empId: 'dev-acme-emp-007', clientId: 'dev-client-003', title: 'Hospital Security - Night', category: 'emergency', dayOffset: 0, startHour: 22, endHour: 6 },
        { empId: 'dev-acme-emp-008', clientId: 'dev-client-004', title: 'Event Security', category: 'security', dayOffset: 1, startHour: 16, endHour: 0 },
        { empId: 'dev-acme-emp-009', clientId: 'dev-client-005', title: 'Bank Patrol', category: 'security', dayOffset: 1, startHour: 8, endHour: 17 },
        { empId: 'dev-acme-emp-010', clientId: 'dev-client-006', title: 'Apartment Complex - Night', category: 'field_ops', dayOffset: 1, startHour: 22, endHour: 6 },
        { empId: 'dev-acme-emp-011', clientId: 'dev-client-007', title: 'Warehouse Access Control', category: 'field_ops', dayOffset: 2, startHour: 6, endHour: 14 },
        { empId: 'dev-acme-emp-012', clientId: 'dev-client-002', title: 'Tower Lobby - Evening', category: 'field_ops', dayOffset: 2, startHour: 14, endHour: 22 },
        { empId: 'dev-acme-emp-004', clientId: 'dev-client-003', title: 'Hospital Security - Day', category: 'emergency', dayOffset: 2, startHour: 6, endHour: 14 },
        { empId: 'dev-acme-emp-005', clientId: 'dev-client-005', title: 'Bank Branch Security', category: 'security', dayOffset: 3, startHour: 8, endHour: 16 },
        { empId: 'dev-acme-emp-006', clientId: 'dev-client-001', title: 'Mall Weekend Coverage', category: 'security', dayOffset: 3, startHour: 10, endHour: 18 },
        { empId: 'dev-acme-emp-007', clientId: 'dev-client-004', title: 'Concert Security', category: 'security', dayOffset: 4, startHour: 17, endHour: 1 },
        { empId: 'dev-acme-emp-008', clientId: 'dev-client-006', title: 'Apartment Complex - Day', category: 'field_ops', dayOffset: 4, startHour: 7, endHour: 15 },
        { empId: 'dev-acme-emp-013', clientId: 'dev-client-007', title: 'Warehouse Night Security', category: 'security', dayOffset: 4, startHour: 22, endHour: 6 },
        { empId: 'dev-acme-emp-009', clientId: 'dev-client-002', title: 'Tower Weekend Patrol', category: 'field_ops', dayOffset: 5, startHour: 8, endHour: 20 },
        { empId: 'dev-acme-emp-010', clientId: 'dev-client-001', title: 'Mall Sunday Coverage', category: 'security', dayOffset: 6, startHour: 10, endHour: 18 },
        { empId: 'dev-acme-emp-011', clientId: 'dev-client-003', title: 'Hospital ER Security', category: 'emergency', dayOffset: 6, startHour: 18, endHour: 6 },
      ];

      for (let i = 0; i < shiftTemplates.length; i++) {
        const shift = shiftTemplates[i];
        const startDate = new Date(today);
        startDate.setDate(startDate.getDate() + shift.dayOffset);
        startDate.setHours(shift.startHour, 0, 0, 0);

        const endDate = new Date(startDate);
        if (shift.endHour <= shift.startHour) {
          endDate.setDate(endDate.getDate() + 1);
        }
        endDate.setHours(shift.endHour, 0, 0, 0);

        const dateStr = startDate.toISOString().split('T')[0];

        await tx.execute(sql`
          INSERT INTO shifts (id, workspace_id, employee_id, client_id, title, category, start_time, end_time, date, status, billable_to_client, created_at, updated_at)
          VALUES (${`dev-shift-${String(i + 1).padStart(3, '0')}`}, ${DEV_SENTINEL_WORKSPACE}, ${shift.empId}, ${shift.clientId}, ${shift.title}, ${shift.category}, ${startDate.toISOString()}, ${endDate.toISOString()}, ${dateStr}, 'confirmed', TRUE, NOW(), NOW())
          ON CONFLICT (id) DO NOTHING
        `);
      }

      // =====================================================================
      // 7. DEV WORKSPACE CREDITS - Give test workspaces credits
      // =====================================================================
      console.log('[DevSeed] Setting up workspace credits...');

      try {
        const creditWorkspaces = [
          { id: 'dev-credits-acme', wsId: DEV_SENTINEL_WORKSPACE, balance: 50000, monthly: 50000 },
          { id: 'dev-credits-metro', wsId: 'dev-metroplex-cleaning-ws', balance: 10000, monthly: 10000 },
          { id: 'dev-credits-demo', wsId: 'dev-demo-workspace', balance: 25000, monthly: 25000 },
        ];

        for (const cred of creditWorkspaces) {
          await tx.execute(sql`
            INSERT INTO workspace_credits (id, workspace_id, current_balance, monthly_allocation, total_credits_earned, total_credits_spent, total_credits_purchased, is_active, created_at, updated_at)
            VALUES (${cred.id}, ${cred.wsId}, ${cred.balance}, ${cred.monthly}, ${cred.balance}, 0, 0, TRUE, NOW(), NOW())
            ON CONFLICT (id) DO NOTHING
          `);
        }
      } catch (err) {
        console.log('[DevSeed] Workspace credits setup skipped:', (err as Error).message);
      }
    });

    console.log('[DevSeed] Development data seeded successfully!');
    console.log('   - Users: 19 test accounts (password: password123 for all)');
    console.log('   - Workspaces: 3 organizations (Acme Security, Metroplex Cleaning, Demo)');
    console.log('   - Employees: 18 across workspaces');
    console.log('   - Clients: 11 client accounts');
    console.log('   - Shifts: 18 shifts for current week');
    console.log('   - AI Credits: Allocated to all workspaces');
    console.log('');
    console.log('   Test login: owner@acme-security.test / password123');
    console.log('   Demo login: demo@coaileague.test / password123');

    return { success: true, message: 'Development data seeded successfully' };

  } catch (error) {
    console.error('[DevSeed] Failed to seed development data:', error);
    return { success: false, message: `Dev seed failed: ${error}` };
  }
}

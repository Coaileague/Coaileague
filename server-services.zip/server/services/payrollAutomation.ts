/**
 * AI Payroll™ Automation Engine
 * 99% Automated Payroll Processing with 1% Human QC
 * 
 * Features:
 * - Auto-detect pay periods (weekly, bi-weekly, monthly)
 * - Pull time entries from TrackOS™
 * - Calculate gross pay with overtime (1.5x after 40hrs)
 * - Federal & state tax withholding
 * - Social Security (6.2%) & Medicare (1.45%)
 * - Generate paychecks ready for QC approval
 * 
 * Trinity Integration: Connected via trinityPlatformConnector for payroll oversight and insights
 */

import { db } from "../db";
import { timeEntries, employees, payrollRuns, payrollEntries, workspaces, invoiceLineItems, employeeBenefits, type TimeEntry } from "@shared/schema";
import { eq, and, gte, lte, isNull, sql, notInArray, inArray } from "drizzle-orm";
import { startOfWeek, endOfWeek, subWeeks, format, startOfMonth, endOfMonth, subMonths, startOfYear, endOfYear } from "date-fns";
import { aggregatePayrollHours, markEntriesAsPayrolled } from "./automation/payrollHoursAggregator";
import { trinityPlatformConnector } from './ai-brain/trinityPlatformConnector';

const PRE_TAX_BENEFIT_TYPES = ['401k', 'health_insurance', 'dental_insurance', 'vision_insurance'];
const POST_TAX_BENEFIT_TYPES = ['life_insurance', 'other'];

interface EmployeeDeductions {
  preTax: number;
  postTax: number;
  details: Array<{ type: string; amount: number; isPreTax: boolean }>;
}

interface PayPeriod {
  start: Date;
  end: Date;
  type: 'weekly' | 'bi-weekly' | 'monthly';
}

interface PayrollCalculation {
  employeeId: string;
  employeeName: string;
  regularHours: number;
  overtimeHours: number;
  holidayHours: number; // Added for FLSA holiday pay tracking
  hourlyRate: number;
  grossPay: number;
  preTaxDeductions: number; // 401k, health insurance, HSA, FSA, etc.
  taxableGrossPay: number; // grossPay - preTaxDeductions
  federalTax: number;
  stateTax: number;
  socialSecurity: number;
  medicare: number;
  postTaxDeductions: number; // Extra deductions after taxes
  netPay: number;
}

export class PayrollAutomationEngine {
  
  /**
   * Fetch active employee benefit deductions from the database
   * Calculates per-payroll amounts based on monthly contributions and pay frequency
   */
  static async getEmployeeDeductions(
    employeeId: string,
    grossPay: number,
    payPeriodType: 'weekly' | 'bi-weekly' | 'monthly' = 'bi-weekly'
  ): Promise<EmployeeDeductions> {
    const payrollsPerMonth: Record<string, number> = {
      'weekly': 4.33,
      'bi-weekly': 2.17,
      'monthly': 1
    };
    const divisor = payrollsPerMonth[payPeriodType];
    
    const benefits = await db
      .select()
      .from(employeeBenefits)
      .where(
        and(
          eq(employeeBenefits.employeeId, employeeId),
          eq(employeeBenefits.status, 'active')
        )
      );
    
    let preTax = 0;
    let postTax = 0;
    const details: Array<{ type: string; amount: number; isPreTax: boolean }> = [];
    
    for (const benefit of benefits) {
      let amount = 0;
      
      if (benefit.benefitType === '401k' && benefit.contributionPercentage) {
        amount = grossPay * (parseFloat(benefit.contributionPercentage) / 100);
      } else if (benefit.employeeContribution) {
        amount = parseFloat(benefit.employeeContribution) / divisor;
      }
      
      if (amount > 0) {
        const isPreTax = PRE_TAX_BENEFIT_TYPES.includes(benefit.benefitType);
        
        if (isPreTax) {
          preTax += amount;
        } else {
          postTax += amount;
        }
        
        details.push({
          type: benefit.benefitType,
          amount: parseFloat(amount.toFixed(2)),
          isPreTax
        });
      }
    }
    
    return {
      preTax: parseFloat(preTax.toFixed(2)),
      postTax: parseFloat(postTax.toFixed(2)),
      details
    };
  }
  
  /**
   * Auto-detect pay period based on workspace settings
   * Default: bi-weekly (most common)
   */
  static detectPayPeriod(workspacePaySchedule?: string): PayPeriod {
    const now = new Date();
    
    switch (workspacePaySchedule) {
      case 'weekly':
        return {
          start: startOfWeek(subWeeks(now, 1)),
          end: endOfWeek(subWeeks(now, 1)),
          type: 'weekly'
        };
      
      case 'monthly':
        return {
          start: startOfMonth(subMonths(now, 1)),
          end: endOfMonth(subMonths(now, 1)),
          type: 'monthly'
        };
      
      case 'bi-weekly':
      default:
        // Bi-weekly: last 14 days
        const twoWeeksAgo = new Date(now);
        twoWeeksAgo.setDate(twoWeeksAgo.getDate() - 14);
        return {
          start: twoWeeksAgo,
          end: now,
          type: 'bi-weekly'
        };
    }
  }
  
  /**
   * Calculate federal tax withholding (simplified progressive brackets)
   * Based on 2024 tax tables for single filers
   */
  static calculateFederalTax(
    grossPay: number, 
    payPeriodType: 'weekly' | 'bi-weekly' | 'monthly' = 'bi-weekly',
    filingStatus: string = 'single'
  ): number {
    // Simplified federal tax brackets (annual basis, converted to pay period)
    // Single filer 2024 brackets (simplified)
    const brackets = [
      { limit: 11000, rate: 0.10 },
      { limit: 44725, rate: 0.12 },
      { limit: 95375, rate: 0.22 },
      { limit: Infinity, rate: 0.24 }
    ];
    
    // Determine annualization factor based on pay period
    const annualizationFactors: Record<'weekly' | 'bi-weekly' | 'monthly', number> = {
      'weekly': 52,
      'bi-weekly': 26,
      'monthly': 12
    };
    const factor = annualizationFactors[payPeriodType];
    
    // Annualize gross pay
    const annualGross = grossPay * factor;
    let tax = 0;
    let previousLimit = 0;
    
    for (const bracket of brackets) {
      if (annualGross > bracket.limit) {
        tax += (bracket.limit - previousLimit) * bracket.rate;
        previousLimit = bracket.limit;
      } else {
        tax += (annualGross - previousLimit) * bracket.rate;
        break;
      }
    }
    
    // Convert back to pay period
    return parseFloat((tax / factor).toFixed(2));
  }
  
  /**
   * State-specific tax configuration with 2024 rates
   * Full progressive brackets for all 50 states + DC
   * Based on single filer annual income brackets
   */
  private static readonly STATE_TAX_CONFIG: Record<string, { type: 'none' | 'flat' | 'progressive'; rate?: number; brackets?: Array<{ limit: number; rate: number }> }> = {
    // ==========================================
    // NO INCOME TAX STATES (9 states)
    // ==========================================
    'AK': { type: 'none' },
    'FL': { type: 'none' },
    'NV': { type: 'none' },
    'NH': { type: 'none' }, // Interest/dividends only, not wages
    'SD': { type: 'none' },
    'TN': { type: 'none' },
    'TX': { type: 'none' },
    'WA': { type: 'none' },
    'WY': { type: 'none' },
    
    // ==========================================
    // FLAT RATE STATES (11 states)
    // ==========================================
    'AZ': { type: 'flat', rate: 0.025 }, // 2024: flat 2.5%
    'CO': { type: 'flat', rate: 0.044 }, // 4.4%
    'GA': { type: 'flat', rate: 0.0549 }, // 2024: 5.49%
    'IL': { type: 'flat', rate: 0.0495 }, // 4.95%
    'IN': { type: 'flat', rate: 0.0305 }, // 2024: 3.05%
    'KY': { type: 'flat', rate: 0.04 }, // 2024: 4%
    'MA': { type: 'flat', rate: 0.05 }, // 5%
    'MI': { type: 'flat', rate: 0.0425 }, // 4.25%
    'NC': { type: 'flat', rate: 0.0475 }, // 2024: 4.75%
    'PA': { type: 'flat', rate: 0.0307 }, // 3.07%
    'UT': { type: 'flat', rate: 0.0465 }, // 4.65%
    
    // ==========================================
    // PROGRESSIVE BRACKET STATES (30 states + DC)
    // All brackets are for SINGLE filers, annual income
    // ==========================================
    
    // Alabama - 3 brackets
    'AL': { type: 'progressive', brackets: [
      { limit: 500, rate: 0.02 },
      { limit: 3000, rate: 0.04 },
      { limit: Infinity, rate: 0.05 }
    ]},
    
    // Arkansas - 4 brackets (2024)
    'AR': { type: 'progressive', brackets: [
      { limit: 4400, rate: 0.02 },
      { limit: 8800, rate: 0.04 },
      { limit: Infinity, rate: 0.044 } // Reduced to 4.4% in 2024
    ]},
    
    // California - 9 brackets
    'CA': { type: 'progressive', brackets: [
      { limit: 10412, rate: 0.01 },
      { limit: 24684, rate: 0.02 },
      { limit: 38959, rate: 0.04 },
      { limit: 54081, rate: 0.06 },
      { limit: 68350, rate: 0.08 },
      { limit: 349137, rate: 0.093 },
      { limit: 418961, rate: 0.103 },
      { limit: 698271, rate: 0.113 },
      { limit: Infinity, rate: 0.123 }
    ]},
    
    // Connecticut - 7 brackets
    'CT': { type: 'progressive', brackets: [
      { limit: 10000, rate: 0.02 },
      { limit: 50000, rate: 0.045 },
      { limit: 100000, rate: 0.055 },
      { limit: 200000, rate: 0.06 },
      { limit: 250000, rate: 0.065 },
      { limit: 500000, rate: 0.069 },
      { limit: Infinity, rate: 0.0699 }
    ]},
    
    // Delaware - 7 brackets
    'DE': { type: 'progressive', brackets: [
      { limit: 2000, rate: 0.0 },
      { limit: 5000, rate: 0.022 },
      { limit: 10000, rate: 0.039 },
      { limit: 20000, rate: 0.048 },
      { limit: 25000, rate: 0.052 },
      { limit: 60000, rate: 0.0555 },
      { limit: Infinity, rate: 0.066 }
    ]},
    
    // District of Columbia - 6 brackets
    'DC': { type: 'progressive', brackets: [
      { limit: 10000, rate: 0.04 },
      { limit: 40000, rate: 0.06 },
      { limit: 60000, rate: 0.065 },
      { limit: 250000, rate: 0.085 },
      { limit: 500000, rate: 0.0925 },
      { limit: Infinity, rate: 0.1075 }
    ]},
    
    // Hawaii - 12 brackets
    'HI': { type: 'progressive', brackets: [
      { limit: 2400, rate: 0.014 },
      { limit: 4800, rate: 0.032 },
      { limit: 9600, rate: 0.055 },
      { limit: 14400, rate: 0.064 },
      { limit: 19200, rate: 0.068 },
      { limit: 24000, rate: 0.072 },
      { limit: 36000, rate: 0.076 },
      { limit: 48000, rate: 0.079 },
      { limit: 150000, rate: 0.0825 },
      { limit: 175000, rate: 0.09 },
      { limit: 200000, rate: 0.10 },
      { limit: Infinity, rate: 0.11 }
    ]},
    
    // Idaho - 2 brackets (2024 simplified)
    'ID': { type: 'progressive', brackets: [
      { limit: 4489, rate: 0.01 },
      { limit: Infinity, rate: 0.058 }
    ]},
    
    // Iowa - 4 brackets (2024)
    'IA': { type: 'progressive', brackets: [
      { limit: 6210, rate: 0.044 },
      { limit: 31050, rate: 0.0482 },
      { limit: 62100, rate: 0.057 },
      { limit: Infinity, rate: 0.06 }
    ]},
    
    // Kansas - 3 brackets
    'KS': { type: 'progressive', brackets: [
      { limit: 15000, rate: 0.031 },
      { limit: 30000, rate: 0.0525 },
      { limit: Infinity, rate: 0.057 }
    ]},
    
    // Louisiana - 3 brackets
    'LA': { type: 'progressive', brackets: [
      { limit: 12500, rate: 0.0185 },
      { limit: 50000, rate: 0.035 },
      { limit: Infinity, rate: 0.0425 }
    ]},
    
    // Maine - 3 brackets
    'ME': { type: 'progressive', brackets: [
      { limit: 24500, rate: 0.058 },
      { limit: 58050, rate: 0.0675 },
      { limit: Infinity, rate: 0.0715 }
    ]},
    
    // Maryland - 8 brackets
    'MD': { type: 'progressive', brackets: [
      { limit: 1000, rate: 0.02 },
      { limit: 2000, rate: 0.03 },
      { limit: 3000, rate: 0.04 },
      { limit: 100000, rate: 0.0475 },
      { limit: 125000, rate: 0.05 },
      { limit: 150000, rate: 0.0525 },
      { limit: 250000, rate: 0.055 },
      { limit: Infinity, rate: 0.0575 }
    ]},
    
    // Minnesota - 4 brackets
    'MN': { type: 'progressive', brackets: [
      { limit: 30070, rate: 0.0535 },
      { limit: 98760, rate: 0.068 },
      { limit: 183340, rate: 0.0785 },
      { limit: Infinity, rate: 0.0985 }
    ]},
    
    // Mississippi - 2 brackets (2024)
    'MS': { type: 'progressive', brackets: [
      { limit: 10000, rate: 0.0 },
      { limit: Infinity, rate: 0.047 } // Reduced in 2024
    ]},
    
    // Missouri - 6 brackets
    'MO': { type: 'progressive', brackets: [
      { limit: 1207, rate: 0.02 },
      { limit: 2414, rate: 0.025 },
      { limit: 3621, rate: 0.03 },
      { limit: 4828, rate: 0.035 },
      { limit: 6035, rate: 0.04 },
      { limit: Infinity, rate: 0.0495 } // 2024 rate
    ]},
    
    // Montana - 2 brackets (2024 simplified)
    'MT': { type: 'progressive', brackets: [
      { limit: 20500, rate: 0.047 },
      { limit: Infinity, rate: 0.059 }
    ]},
    
    // Nebraska - 4 brackets
    'NE': { type: 'progressive', brackets: [
      { limit: 3700, rate: 0.0246 },
      { limit: 22170, rate: 0.0351 },
      { limit: 35730, rate: 0.0501 },
      { limit: Infinity, rate: 0.0584 }
    ]},
    
    // New Jersey - 7 brackets
    'NJ': { type: 'progressive', brackets: [
      { limit: 20000, rate: 0.014 },
      { limit: 35000, rate: 0.0175 },
      { limit: 40000, rate: 0.035 },
      { limit: 75000, rate: 0.05525 },
      { limit: 500000, rate: 0.0637 },
      { limit: 1000000, rate: 0.0897 },
      { limit: Infinity, rate: 0.1075 }
    ]},
    
    // New Mexico - 5 brackets
    'NM': { type: 'progressive', brackets: [
      { limit: 5500, rate: 0.017 },
      { limit: 11000, rate: 0.032 },
      { limit: 16000, rate: 0.047 },
      { limit: 210000, rate: 0.049 },
      { limit: Infinity, rate: 0.059 }
    ]},
    
    // New York - 8 brackets
    'NY': { type: 'progressive', brackets: [
      { limit: 8500, rate: 0.04 },
      { limit: 11700, rate: 0.045 },
      { limit: 13900, rate: 0.0525 },
      { limit: 80650, rate: 0.055 },
      { limit: 215400, rate: 0.06 },
      { limit: 1077550, rate: 0.0685 },
      { limit: 5000000, rate: 0.0965 },
      { limit: Infinity, rate: 0.109 } // Top rate for $25M+
    ]},
    
    // North Dakota - 3 brackets (2024)
    'ND': { type: 'progressive', brackets: [
      { limit: 44725, rate: 0.0195 },
      { limit: 225975, rate: 0.0252 },
      { limit: Infinity, rate: 0.0264 }
    ]},
    
    // Ohio - 4 brackets (2024)
    'OH': { type: 'progressive', brackets: [
      { limit: 26050, rate: 0.0 },
      { limit: 46100, rate: 0.0275 },
      { limit: 92150, rate: 0.03 },
      { limit: Infinity, rate: 0.035 }
    ]},
    
    // Oklahoma - 6 brackets
    'OK': { type: 'progressive', brackets: [
      { limit: 1000, rate: 0.0025 },
      { limit: 2500, rate: 0.0075 },
      { limit: 3750, rate: 0.0175 },
      { limit: 4900, rate: 0.0275 },
      { limit: 7200, rate: 0.0375 },
      { limit: Infinity, rate: 0.0475 }
    ]},
    
    // Oregon - 4 brackets
    'OR': { type: 'progressive', brackets: [
      { limit: 4050, rate: 0.0475 },
      { limit: 10200, rate: 0.0675 },
      { limit: 125000, rate: 0.0875 },
      { limit: Infinity, rate: 0.099 }
    ]},
    
    // Rhode Island - 3 brackets
    'RI': { type: 'progressive', brackets: [
      { limit: 73450, rate: 0.0375 },
      { limit: 166950, rate: 0.0475 },
      { limit: Infinity, rate: 0.0599 }
    ]},
    
    // South Carolina - 6 brackets
    'SC': { type: 'progressive', brackets: [
      { limit: 3200, rate: 0.0 },
      { limit: 6410, rate: 0.03 },
      { limit: 9620, rate: 0.04 },
      { limit: 12820, rate: 0.05 },
      { limit: 16040, rate: 0.06 },
      { limit: Infinity, rate: 0.064 } // 2024 top rate
    ]},
    
    // Vermont - 4 brackets
    'VT': { type: 'progressive', brackets: [
      { limit: 45400, rate: 0.0335 },
      { limit: 110050, rate: 0.066 },
      { limit: 229550, rate: 0.076 },
      { limit: Infinity, rate: 0.0875 }
    ]},
    
    // Virginia - 4 brackets
    'VA': { type: 'progressive', brackets: [
      { limit: 3000, rate: 0.02 },
      { limit: 5000, rate: 0.03 },
      { limit: 17000, rate: 0.05 },
      { limit: Infinity, rate: 0.0575 }
    ]},
    
    // West Virginia - 5 brackets
    'WV': { type: 'progressive', brackets: [
      { limit: 10000, rate: 0.0236 },
      { limit: 25000, rate: 0.0315 },
      { limit: 40000, rate: 0.0354 },
      { limit: 60000, rate: 0.0472 },
      { limit: Infinity, rate: 0.0512 }
    ]},
    
    // Wisconsin - 4 brackets
    'WI': { type: 'progressive', brackets: [
      { limit: 14320, rate: 0.035 },
      { limit: 28640, rate: 0.044 },
      { limit: 315310, rate: 0.053 },
      { limit: Infinity, rate: 0.0765 }
    ]},
  };
  
  /**
   * Calculate state tax based on state-specific rules
   * Supports no-tax, flat-rate, and progressive bracket states
   * 
   * @param grossPay - Current period gross pay
   * @param state - State code (e.g., 'CA', 'NY', 'TX')
   * @param payPeriodType - Pay frequency for annualization
   * @returns State income tax withholding for the pay period
   */
  static calculateStateTax(
    grossPay: number, 
    state: string = 'CA',
    payPeriodType: 'weekly' | 'bi-weekly' | 'monthly' = 'bi-weekly'
  ): number {
    const stateCode = state.toUpperCase();
    const config = this.STATE_TAX_CONFIG[stateCode];
    
    // Default to CA if state not found
    if (!config) {
      console.warn(`[Payroll] Unknown state ${state}, defaulting to CA rates`);
      return parseFloat((grossPay * 0.0575).toFixed(2));
    }
    
    // No income tax states
    if (config.type === 'none') {
      return 0;
    }
    
    // Annualization factors for progressive bracket calculation
    const annualizationFactors: Record<string, number> = {
      'weekly': 52,
      'bi-weekly': 26,
      'monthly': 12
    };
    const factor = annualizationFactors[payPeriodType] || 26;
    
    // Flat rate states (no annualization needed)
    if (config.type === 'flat' && config.rate) {
      return parseFloat((grossPay * config.rate).toFixed(2));
    }
    
    // Progressive bracket states - annualize for accurate bracket placement
    if (config.type === 'progressive' && config.brackets) {
      // Annualize the gross pay
      const annualGross = grossPay * factor;
      
      // Calculate tax on annualized amount using progressive brackets
      let annualTax = 0;
      let previousLimit = 0;
      
      for (const bracket of config.brackets) {
        if (annualGross > bracket.limit) {
          // Fill this entire bracket
          annualTax += (bracket.limit - previousLimit) * bracket.rate;
          previousLimit = bracket.limit;
        } else {
          // Partial bracket - remaining income falls here
          annualTax += (annualGross - previousLimit) * bracket.rate;
          break;
        }
      }
      
      // De-annualize to get per-period tax
      return parseFloat((annualTax / factor).toFixed(2));
    }
    
    return 0;
  }
  
  /**
   * Reciprocal Tax Agreements between states
   * When an employee lives in one state but works in another,
   * these agreements determine which state to withhold taxes for.
   * 
   * Format: { workState: [array of resident states that have reciprocity] }
   */
  private static readonly RECIPROCAL_AGREEMENTS: Record<string, string[]> = {
    // DC has agreements with all states (employees pay their resident state)
    'DC': ['MD', 'VA'],
    
    // Illinois
    'IL': ['IA', 'KY', 'MI', 'WI'],
    
    // Indiana
    'IN': ['KY', 'MI', 'OH', 'PA', 'WI'],
    
    // Iowa
    'IA': ['IL'],
    
    // Kentucky
    'KY': ['IL', 'IN', 'MI', 'OH', 'VA', 'WV', 'WI'],
    
    // Maryland
    'MD': ['DC', 'PA', 'VA', 'WV'],
    
    // Michigan
    'MI': ['IL', 'IN', 'KY', 'MN', 'OH', 'WI'],
    
    // Minnesota
    'MN': ['MI', 'ND'],
    
    // Montana
    'MT': ['ND'],
    
    // New Jersey
    'NJ': ['PA'],
    
    // North Dakota
    'ND': ['MN', 'MT'],
    
    // Ohio
    'OH': ['IN', 'KY', 'MI', 'PA', 'WV'],
    
    // Pennsylvania
    'PA': ['IN', 'MD', 'NJ', 'OH', 'VA', 'WV'],
    
    // Virginia
    'VA': ['DC', 'KY', 'MD', 'PA', 'WV'],
    
    // West Virginia
    'WV': ['KY', 'MD', 'OH', 'PA', 'VA'],
    
    // Wisconsin
    'WI': ['IL', 'IN', 'KY', 'MI'],
  };
  
  /**
   * Determine which state to withhold income tax for based on reciprocal agreements
   * 
   * @param workState - State where work is performed
   * @param residentState - State where employee resides
   * @returns Object with taxState (which state to withhold for) and hasReciprocity boolean
   */
  static getEffectiveTaxState(
    workState: string,
    residentState: string
  ): { taxState: string; hasReciprocity: boolean; explanation: string } {
    const work = workState.toUpperCase();
    const resident = residentState.toUpperCase();
    
    // Same state - no reciprocity needed
    if (work === resident) {
      return {
        taxState: work,
        hasReciprocity: false,
        explanation: `Employee works and lives in ${work} - standard withholding applies`
      };
    }
    
    // Check if work state has reciprocity with resident state
    const reciprocalStates = this.RECIPROCAL_AGREEMENTS[work];
    if (reciprocalStates && reciprocalStates.includes(resident)) {
      return {
        taxState: resident,
        hasReciprocity: true,
        explanation: `${work} and ${resident} have a reciprocal agreement - withholding for resident state ${resident}`
      };
    }
    
    // No reciprocity - employee may owe taxes to both states
    // By default, withhold for work state (employee handles resident state on tax return)
    return {
      taxState: work,
      hasReciprocity: false,
      explanation: `No reciprocal agreement between ${work} and ${resident} - withholding for work state ${work}. Employee may need to file in ${resident} and claim credit.`
    };
  }
  
  /**
   * Calculate multi-state tax withholding
   * Handles reciprocal agreements and multi-state work scenarios
   * 
   * @param grossPay - Current period gross pay
   * @param workState - State where work is performed
   * @param residentState - State where employee resides
   * @param payPeriodType - Pay frequency for annualization
   * @returns Object with tax amounts and explanation
   */
  static calculateMultiStateTax(
    grossPay: number,
    workState: string,
    residentState: string,
    payPeriodType: 'weekly' | 'bi-weekly' | 'monthly' = 'bi-weekly'
  ): {
    workStateTax: number;
    residentStateTax: number;
    effectiveWithholding: number;
    taxState: string;
    hasReciprocity: boolean;
    explanation: string;
  } {
    const reciprocity = this.getEffectiveTaxState(workState, residentState);
    
    // Calculate taxes for both states
    const workTax = this.calculateStateTax(grossPay, workState, payPeriodType);
    const residentTax = this.calculateStateTax(grossPay, residentState, payPeriodType);
    
    // Determine effective withholding based on reciprocity
    let effectiveWithholding: number;
    
    if (reciprocity.hasReciprocity) {
      // With reciprocity, only withhold for resident state
      effectiveWithholding = residentTax;
    } else if (workState.toUpperCase() === residentState.toUpperCase()) {
      // Same state
      effectiveWithholding = workTax;
    } else {
      // No reciprocity - withhold for work state
      // Note: Employee may need to file in both states
      effectiveWithholding = workTax;
    }
    
    return {
      workStateTax: workTax,
      residentStateTax: residentTax,
      effectiveWithholding,
      taxState: reciprocity.taxState,
      hasReciprocity: reciprocity.hasReciprocity,
      explanation: reciprocity.explanation
    };
  }
  
  /**
   * Get Year-to-Date wages for Social Security wage base tracking
   * Sums gross pay from all approved/paid payroll entries for the employee in the given year
   * 
   * @param employeeId - The employee ID to query
   * @param year - The calendar year to sum wages for
   * @returns Promise<number> - The total YTD gross wages subject to SS
   */
  static async getSocialSecurityYtdWages(employeeId: string, year: number): Promise<number> {
    const yearStart = startOfYear(new Date(year, 0, 1));
    const yearEnd = endOfYear(new Date(year, 0, 1));
    
    // Query payroll entries joined with payroll runs to filter by year and status
    // Only count approved or paid payroll runs (not draft or pending)
    const result = await db
      .select({
        totalGrossPay: sql<string>`COALESCE(SUM(${payrollEntries.grossPay}), 0)`
      })
      .from(payrollEntries)
      .innerJoin(payrollRuns, eq(payrollEntries.payrollRunId, payrollRuns.id))
      .where(
        and(
          eq(payrollEntries.employeeId, employeeId),
          gte(payrollRuns.periodEnd, yearStart),
          lte(payrollRuns.periodEnd, yearEnd),
          inArray(payrollRuns.status, ['approved', 'paid'])
        )
      );
    
    const ytdWages = parseFloat(result[0]?.totalGrossPay || '0');
    return ytdWages;
  }
  
  /**
   * Calculate Social Security (6.2% up to wage base $168,600)
   * Implements YTD wage base tracking to stop withholding once annual limit is reached
   * 
   * @param grossPay - Current period gross pay
   * @param ytdWages - Year-to-date wages already subject to SS (default 0 for backward compatibility)
   * @returns The Social Security tax amount to withhold
   */
  static calculateSocialSecurity(grossPay: number, ytdWages: number = 0): number {
    const SS_RATE = 0.062;
    const WAGE_BASE = 168600; // 2024 wage base
    
    // If YTD wages already exceed the wage base, no SS tax due
    if (ytdWages >= WAGE_BASE) {
      return 0;
    }
    
    // Calculate taxable wages for this period (capped at remaining room under wage base)
    const taxableWages = Math.min(grossPay, Math.max(0, WAGE_BASE - ytdWages));
    
    return parseFloat((taxableWages * SS_RATE).toFixed(2));
  }
  
  /**
   * Calculate Medicare tax including Additional Medicare Tax
   * - Regular Medicare: 1.45% on all wages (no limit)
   * - Additional Medicare Tax: 0.9% on wages over $200,000 (single) or $250,000 (married)
   * 
   * @param grossPay - Current period gross pay
   * @param ytdWages - Year-to-date wages for threshold tracking (default 0)
   * @param filingStatus - 'single', 'married', or 'head_of_household' (default 'single')
   * @returns Total Medicare tax including Additional Medicare Tax if applicable
   */
  static calculateMedicare(
    grossPay: number, 
    ytdWages: number = 0,
    filingStatus: string = 'single'
  ): number {
    const MEDICARE_RATE = 0.0145;
    const ADDITIONAL_MEDICARE_RATE = 0.009; // 0.9% additional tax
    
    // Additional Medicare Tax thresholds by filing status
    const thresholds: Record<string, number> = {
      'single': 200000,
      'head_of_household': 200000,
      'married': 250000,
      'married_filing_separately': 125000,
    };
    
    const threshold = thresholds[filingStatus] || 200000;
    
    // Regular Medicare tax on all wages
    let medicareTax = grossPay * MEDICARE_RATE;
    
    // Calculate Additional Medicare Tax on wages exceeding threshold
    const totalWagesWithCurrent = ytdWages + grossPay;
    
    if (totalWagesWithCurrent > threshold) {
      // Calculate how much of this period's pay is subject to additional tax
      const amountOverThreshold = Math.max(0, totalWagesWithCurrent - threshold);
      const priorAmountOverThreshold = Math.max(0, ytdWages - threshold);
      const taxableThisPeriod = amountOverThreshold - priorAmountOverThreshold;
      
      if (taxableThisPeriod > 0) {
        const additionalTax = taxableThisPeriod * ADDITIONAL_MEDICARE_RATE;
        medicareTax += additionalTax;
        console.log(`[AI Payroll™] Additional Medicare Tax: $${additionalTax.toFixed(2)} on $${taxableThisPeriod.toFixed(2)} exceeding $${threshold} threshold`);
      }
    }
    
    return parseFloat(medicareTax.toFixed(2));
  }
  
  /**
   * Calculate Federal Unemployment Tax (FUTA) - EMPLOYER TAX
   * - 6.0% on first $7,000 of wages per employee per year
   * - Most employers get a 5.4% credit for paying state unemployment taxes
   * - Effective rate is typically 0.6% on first $7,000
   * 
   * @param grossPay - Current period gross pay
   * @param ytdWages - Year-to-date wages for threshold tracking
   * @param hasStateTaxCredit - Whether employer qualifies for state credit (default true)
   * @returns FUTA tax amount (employer cost, not deducted from employee)
   */
  static calculateFUTA(
    grossPay: number,
    ytdWages: number = 0,
    hasStateTaxCredit: boolean = true
  ): number {
    const FUTA_WAGE_BASE = 7000;
    const FUTA_RATE = 0.06; // 6.0% base rate
    const STATE_CREDIT = 0.054; // 5.4% credit for paying SUTA
    
    // Effective rate after state credit
    const effectiveRate = hasStateTaxCredit ? (FUTA_RATE - STATE_CREDIT) : FUTA_RATE;
    
    // If YTD wages already exceed the wage base, no FUTA due
    if (ytdWages >= FUTA_WAGE_BASE) {
      return 0;
    }
    
    // Calculate taxable wages for this period
    const taxableWages = Math.min(grossPay, Math.max(0, FUTA_WAGE_BASE - ytdWages));
    
    return parseFloat((taxableWages * effectiveRate).toFixed(2));
  }

  /**
   * Calculate State Unemployment Tax (SUTA) - EMPLOYER TAX
   * Rates vary by state and employer experience rating
   * 
   * @param grossPay - Current period gross pay
   * @param ytdWages - Year-to-date wages for threshold tracking
   * @param state - State code for rate lookup
   * @param experienceRate - Employer's experience-rated SUTA rate (default varies by state)
   * @returns SUTA tax amount (employer cost, not deducted from employee)
   */
  static calculateSUTA(
    grossPay: number,
    ytdWages: number = 0,
    state: string = 'CA',
    experienceRate?: number
  ): number {
    // SUTA wage bases and new employer rates by state (2024)
    const sutaConfig: Record<string, { wageBase: number; newEmployerRate: number; minRate: number; maxRate: number }> = {
      'AL': { wageBase: 8000, newEmployerRate: 0.027, minRate: 0.006, maxRate: 0.068 },
      'AK': { wageBase: 47100, newEmployerRate: 0.012, minRate: 0.01, maxRate: 0.054 },
      'AZ': { wageBase: 8000, newEmployerRate: 0.02, minRate: 0.0008, maxRate: 0.077 },
      'AR': { wageBase: 7000, newEmployerRate: 0.031, minRate: 0.01, maxRate: 0.12 },
      'CA': { wageBase: 7000, newEmployerRate: 0.034, minRate: 0.015, maxRate: 0.068 },
      'CO': { wageBase: 20400, newEmployerRate: 0.017, minRate: 0.0, maxRate: 0.058 },
      'CT': { wageBase: 25000, newEmployerRate: 0.03, minRate: 0.01, maxRate: 0.069 },
      'DE': { wageBase: 10500, newEmployerRate: 0.018, minRate: 0.001, maxRate: 0.08 },
      'FL': { wageBase: 7000, newEmployerRate: 0.027, minRate: 0.001, maxRate: 0.054 },
      'GA': { wageBase: 9500, newEmployerRate: 0.027, minRate: 0.005, maxRate: 0.054 },
      'HI': { wageBase: 56700, newEmployerRate: 0.03, minRate: 0.0, maxRate: 0.054 },
      'ID': { wageBase: 49900, newEmployerRate: 0.01, minRate: 0.002, maxRate: 0.052 },
      'IL': { wageBase: 13271, newEmployerRate: 0.035, minRate: 0.006, maxRate: 0.067 },
      'IN': { wageBase: 9500, newEmployerRate: 0.025, minRate: 0.005, maxRate: 0.075 },
      'IA': { wageBase: 36100, newEmployerRate: 0.01, minRate: 0.0, maxRate: 0.07 },
      'KS': { wageBase: 14000, newEmployerRate: 0.027, minRate: 0.001, maxRate: 0.075 },
      'KY': { wageBase: 11400, newEmployerRate: 0.027, minRate: 0.003, maxRate: 0.09 },
      'LA': { wageBase: 7700, newEmployerRate: 0.02, minRate: 0.001, maxRate: 0.06 },
      'ME': { wageBase: 12000, newEmployerRate: 0.0238, minRate: 0.0005, maxRate: 0.054 },
      'MD': { wageBase: 8500, newEmployerRate: 0.024, minRate: 0.003, maxRate: 0.075 },
      'MA': { wageBase: 15000, newEmployerRate: 0.027, minRate: 0.006, maxRate: 0.083 },
      'MI': { wageBase: 9500, newEmployerRate: 0.027, minRate: 0.001, maxRate: 0.1085 },
      'MN': { wageBase: 40000, newEmployerRate: 0.01, minRate: 0.001, maxRate: 0.09 },
      'MS': { wageBase: 14000, newEmployerRate: 0.01, minRate: 0.0, maxRate: 0.055 },
      'MO': { wageBase: 10500, newEmployerRate: 0.027, minRate: 0.0, maxRate: 0.09 },
      'MT': { wageBase: 40500, newEmployerRate: 0.013, minRate: 0.0, maxRate: 0.062 },
      'NE': { wageBase: 9000, newEmployerRate: 0.02, minRate: 0.0, maxRate: 0.054 },
      'NV': { wageBase: 40100, newEmployerRate: 0.0295, minRate: 0.0025, maxRate: 0.054 },
      'NH': { wageBase: 14000, newEmployerRate: 0.027, minRate: 0.001, maxRate: 0.075 },
      'NJ': { wageBase: 42300, newEmployerRate: 0.028, minRate: 0.005, maxRate: 0.0575 },
      'NM': { wageBase: 30100, newEmployerRate: 0.01, minRate: 0.003, maxRate: 0.054 },
      'NY': { wageBase: 12500, newEmployerRate: 0.035, minRate: 0.006, maxRate: 0.079 },
      'NC': { wageBase: 29600, newEmployerRate: 0.01, minRate: 0.001, maxRate: 0.056 },
      'ND': { wageBase: 40000, newEmployerRate: 0.0107, minRate: 0.0017, maxRate: 0.0954 },
      'OH': { wageBase: 9000, newEmployerRate: 0.027, minRate: 0.003, maxRate: 0.09 },
      'OK': { wageBase: 27000, newEmployerRate: 0.01, minRate: 0.001, maxRate: 0.055 },
      'OR': { wageBase: 52800, newEmployerRate: 0.024, minRate: 0.007, maxRate: 0.054 },
      'PA': { wageBase: 10000, newEmployerRate: 0.0307, minRate: 0.004, maxRate: 0.1017 },
      'RI': { wageBase: 29200, newEmployerRate: 0.011, minRate: 0.009, maxRate: 0.095 },
      'SC': { wageBase: 14000, newEmployerRate: 0.006, minRate: 0.0006, maxRate: 0.054 },
      'SD': { wageBase: 15000, newEmployerRate: 0.01, minRate: 0.0, maxRate: 0.095 },
      'TN': { wageBase: 7000, newEmployerRate: 0.027, minRate: 0.001, maxRate: 0.1 },
      'TX': { wageBase: 9000, newEmployerRate: 0.027, minRate: 0.001, maxRate: 0.062 },
      'UT': { wageBase: 44800, newEmployerRate: 0.011, minRate: 0.001, maxRate: 0.073 },
      'VT': { wageBase: 16100, newEmployerRate: 0.01, minRate: 0.006, maxRate: 0.08 },
      'VA': { wageBase: 8000, newEmployerRate: 0.0258, minRate: 0.001, maxRate: 0.065 },
      'WA': { wageBase: 67600, newEmployerRate: 0.013, minRate: 0.0, maxRate: 0.054 },
      'WV': { wageBase: 9000, newEmployerRate: 0.027, minRate: 0.015, maxRate: 0.085 },
      'WI': { wageBase: 14000, newEmployerRate: 0.032, minRate: 0.0, maxRate: 0.108 },
      'WY': { wageBase: 30900, newEmployerRate: 0.0092, minRate: 0.0015, maxRate: 0.081 },
      'DC': { wageBase: 9000, newEmployerRate: 0.027, minRate: 0.014, maxRate: 0.07 },
    };
    
    const stateCode = state.toUpperCase();
    const config = sutaConfig[stateCode] || sutaConfig['CA'];
    
    // Use provided experience rate or default to new employer rate
    const rate = experienceRate !== undefined ? experienceRate : config.newEmployerRate;
    
    // Clamp rate within state min/max bounds
    const clampedRate = Math.max(config.minRate, Math.min(rate, config.maxRate));
    
    // If YTD wages already exceed the wage base, no SUTA due
    if (ytdWages >= config.wageBase) {
      return 0;
    }
    
    // Calculate taxable wages for this period
    const taxableWages = Math.min(grossPay, Math.max(0, config.wageBase - ytdWages));
    
    return parseFloat((taxableWages * clampedRate).toFixed(2));
  }

  /**
   * Calculate overtime (1.5x after 40 hours per week)
   * For state-specific daily overtime rules, use calculateStateOvertimeHours instead
   */
  static calculateOvertimeHours(totalHours: number): { regular: number; overtime: number } {
    const OVERTIME_THRESHOLD = 40;

    if (totalHours <= OVERTIME_THRESHOLD) {
      return { regular: totalHours, overtime: 0 };
    }

    return {
      regular: OVERTIME_THRESHOLD,
      overtime: totalHours - OVERTIME_THRESHOLD
    };
  }

  /**
   * State-specific overtime rules configuration
   * California and some other states have daily overtime requirements
   */
  private static readonly STATE_OVERTIME_RULES: Record<string, {
    dailyThreshold?: number;       // Hours before daily OT (CA: 8)
    dailyDoubleThreshold?: number; // Hours before double time (CA: 12)
    weeklyThreshold: number;       // Hours before weekly OT (default: 40)
    seventhDayOT?: boolean;        // 7th consecutive day rules (CA: true)
  }> = {
    // California - strictest overtime rules
    'CA': {
      dailyThreshold: 8,
      dailyDoubleThreshold: 12,
      weeklyThreshold: 40,
      seventhDayOT: true,
    },
    // Colorado - daily overtime after 12 hours
    'CO': {
      dailyThreshold: 12,
      weeklyThreshold: 40,
    },
    // Nevada - daily overtime after 8 hours (if employer has 50+ employees)
    'NV': {
      dailyThreshold: 8,
      weeklyThreshold: 40,
    },
    // Alaska - daily overtime after 8 hours
    'AK': {
      dailyThreshold: 8,
      weeklyThreshold: 40,
    },
    // Default federal rules (most states)
    'DEFAULT': {
      weeklyThreshold: 40,
    },
  };

  /**
   * Calculate state-specific overtime including daily overtime rules
   * Critical for California compliance (daily OT after 8 hours, double time after 12)
   *
   * @param dailyHours - Array of hours worked each day of the week (7 elements)
   * @param state - State code for overtime rules lookup
   * @returns Detailed overtime breakdown including regular, overtime, and double time
   */
  static calculateStateOvertimeHours(
    dailyHours: number[],
    state: string = 'DEFAULT'
  ): {
    regular: number;
    overtime: number;        // 1.5x rate
    doubleTime: number;      // 2.0x rate
    totalHours: number;
    weeklyOvertimeHours: number;
    dailyOvertimeHours: number;
    explanation: string;
  } {
    const stateCode = state.toUpperCase();
    const rules = this.STATE_OVERTIME_RULES[stateCode] || this.STATE_OVERTIME_RULES['DEFAULT'];

    const totalHours = dailyHours.reduce((sum, h) => sum + h, 0);
    let regularHours = 0;
    let dailyOT = 0;
    let dailyDT = 0;

    // Step 1: Calculate daily overtime (if state requires it)
    if (rules.dailyThreshold) {
      for (let i = 0; i < dailyHours.length; i++) {
        const dayHours = dailyHours[i];
        const isSeventhDay = i === 6 && rules.seventhDayOT;

        if (isSeventhDay) {
          // California 7th consecutive day rules:
          // - First 8 hours at 1.5x
          // - Hours over 8 at 2.0x
          if (dayHours <= 8) {
            dailyOT += dayHours;
          } else {
            dailyOT += 8;
            dailyDT += dayHours - 8;
          }
        } else if (rules.dailyDoubleThreshold && dayHours > rules.dailyDoubleThreshold) {
          // Double time for hours over 12 (CA)
          regularHours += rules.dailyThreshold;
          dailyOT += rules.dailyDoubleThreshold - rules.dailyThreshold;
          dailyDT += dayHours - rules.dailyDoubleThreshold;
        } else if (dayHours > rules.dailyThreshold) {
          // Overtime for hours over 8 but under 12
          regularHours += rules.dailyThreshold;
          dailyOT += dayHours - rules.dailyThreshold;
        } else {
          regularHours += dayHours;
        }
      }
    } else {
      // No daily overtime - all hours go to regular (subject to weekly threshold)
      regularHours = totalHours;
    }

    // Step 2: Calculate weekly overtime (if applicable)
    // In CA, daily OT counts toward the 40-hour threshold, but we don't double-count
    let weeklyOT = 0;

    if (!rules.dailyThreshold) {
      // Federal rules: simple 40-hour weekly threshold
      if (totalHours > rules.weeklyThreshold) {
        weeklyOT = totalHours - rules.weeklyThreshold;
        regularHours = rules.weeklyThreshold;
      }
    } else {
      // State with daily OT: weekly threshold applies to remaining regular hours
      // If regular hours exceed weekly threshold, convert excess to OT
      if (regularHours > rules.weeklyThreshold) {
        weeklyOT = regularHours - rules.weeklyThreshold;
        regularHours = rules.weeklyThreshold;
      }
    }

    // Combine daily and weekly overtime (don't double-count)
    const totalOT = dailyOT + weeklyOT;
    const totalDT = dailyDT;

    // Build explanation
    let explanation = `Total ${totalHours.toFixed(1)} hrs: `;
    explanation += `${regularHours.toFixed(1)} regular`;
    if (totalOT > 0) explanation += `, ${totalOT.toFixed(1)} OT (1.5x)`;
    if (totalDT > 0) explanation += `, ${totalDT.toFixed(1)} DT (2x)`;
    if (rules.dailyThreshold) {
      explanation += ` [${stateCode} daily OT rules applied]`;
    }

    console.log(`[AI Payroll] ${stateCode} Overtime: ${explanation}`);

    return {
      regular: parseFloat(regularHours.toFixed(2)),
      overtime: parseFloat(totalOT.toFixed(2)),
      doubleTime: parseFloat(totalDT.toFixed(2)),
      totalHours: parseFloat(totalHours.toFixed(2)),
      weeklyOvertimeHours: parseFloat(weeklyOT.toFixed(2)),
      dailyOvertimeHours: parseFloat(dailyOT.toFixed(2)),
      explanation,
    };
  }

  /**
   * Get overtime rules for a state
   */
  static getStateOvertimeRules(state: string): {
    hasDailyOT: boolean;
    dailyThreshold?: number;
    hasDoubleTime: boolean;
    doubleTimeThreshold?: number;
    weeklyThreshold: number;
    hasSeventhDayRules: boolean;
  } {
    const rules = this.STATE_OVERTIME_RULES[state.toUpperCase()] || this.STATE_OVERTIME_RULES['DEFAULT'];
    return {
      hasDailyOT: !!rules.dailyThreshold,
      dailyThreshold: rules.dailyThreshold,
      hasDoubleTime: !!rules.dailyDoubleThreshold,
      doubleTimeThreshold: rules.dailyDoubleThreshold,
      weeklyThreshold: rules.weeklyThreshold,
      hasSeventhDayRules: !!rules.seventhDayOT,
    };
  }

  /**
   * Calculate FLSA-compliant weighted average overtime for multi-rate employees
   * 
   * When an employee works at multiple pay rates within the same workweek,
   * FLSA requires overtime to be calculated using a weighted average of all rates.
   * 
   * Formula:
   * 1. Calculate total straight-time earnings (sum of hours × rate for each job)
   * 2. Calculate total hours worked
   * 3. Weighted average rate = Total Straight-Time Earnings / Total Hours
   * 4. OT Premium = (Weighted Average Rate × 0.5) × OT Hours (the "half-time" method)
   *    OR Regular OT = Weighted Average Rate × 1.5 × OT Hours
   * 
   * @param rateHours - Array of {rate, hours} for each different pay rate worked
   * @param weeklyThreshold - Weekly overtime threshold (default 40)
   * @returns FLSA-compliant pay breakdown with weighted average OT
   */
  static calculateFLSAWeightedAverageOvertime(
    rateHours: Array<{ rate: number; hours: number }>,
    weeklyThreshold: number = 40
  ): {
    totalHours: number;
    regularHours: number;
    overtimeHours: number;
    straightTimePay: number;
    weightedAverageRate: number;
    overtimePremium: number;
    totalPay: number;
    rateBreakdown: Array<{ rate: number; hours: number; pay: number }>;
  } {
    // Calculate totals across all rates
    const totalHours = rateHours.reduce((sum, rh) => sum + rh.hours, 0);
    const straightTimePay = rateHours.reduce((sum, rh) => sum + (rh.rate * rh.hours), 0);
    
    // Calculate weighted average rate
    const weightedAverageRate = totalHours > 0 ? straightTimePay / totalHours : 0;
    
    // Determine regular and overtime hours
    const regularHours = Math.min(totalHours, weeklyThreshold);
    const overtimeHours = Math.max(0, totalHours - weeklyThreshold);
    
    // Calculate overtime premium using "half-time" method
    // This is the FLSA-approved method: pay straight time for all hours,
    // then add 0.5x the weighted average rate for each OT hour
    const overtimePremium = overtimeHours * (weightedAverageRate * 0.5);
    
    // Total pay = straight time pay + OT premium
    const totalPay = straightTimePay + overtimePremium;
    
    // Build rate breakdown for audit trail
    const rateBreakdown = rateHours.map(rh => ({
      rate: rh.rate,
      hours: rh.hours,
      pay: rh.rate * rh.hours,
    }));
    
    console.log(`[AI Payroll™] FLSA Weighted Average OT: ${totalHours} hrs across ${rateHours.length} rates, ` +
      `WAR=$${weightedAverageRate.toFixed(2)}/hr, OT Premium=$${overtimePremium.toFixed(2)}`);
    
    return {
      totalHours: parseFloat(totalHours.toFixed(2)),
      regularHours: parseFloat(regularHours.toFixed(2)),
      overtimeHours: parseFloat(overtimeHours.toFixed(2)),
      straightTimePay: parseFloat(straightTimePay.toFixed(2)),
      weightedAverageRate: parseFloat(weightedAverageRate.toFixed(2)),
      overtimePremium: parseFloat(overtimePremium.toFixed(2)),
      totalPay: parseFloat(totalPay.toFixed(2)),
      rateBreakdown,
    };
  }

  /**
   * Detect if an employee has multiple pay rates in their time entries
   * Returns true if employee worked at more than one distinct rate
   */
  static hasMultiplePayRates(entries: Array<{ payRate: number }>): boolean {
    const uniqueRates = new Set(entries.map(e => e.payRate));
    return uniqueRates.size > 1;
  }

  /**
   * Aggregate hours by pay rate for FLSA weighted average calculation
   */
  static aggregateHoursByRate(
    entries: Array<{ payRate: number; totalHours: number }>
  ): Array<{ rate: number; hours: number }> {
    const rateMap = new Map<number, number>();
    
    for (const entry of entries) {
      const currentHours = rateMap.get(entry.payRate) || 0;
      rateMap.set(entry.payRate, currentHours + entry.totalHours);
    }
    
    return Array.from(rateMap.entries()).map(([rate, hours]) => ({
      rate,
      hours,
    }));
  }

  /**
   * Calculate local/city withholding tax - EMPLOYEE TAX
   * Some cities and localities require income tax withholding
   * 
   * @param grossPay - Current period gross pay
   * @param locality - City or locality code (e.g., 'NYC', 'PHL', 'DET')
   * @param workLocation - Work location (for work-location-based localities)
   * @param residenceLocation - Residence location (for residence-based localities)
   * @returns Local tax withholding amount
   */
  static calculateLocalWithholding(
    grossPay: number,
    locality: string = '',
    workLocation?: string,
    residenceLocation?: string
  ): number {
    // Major local/city income tax jurisdictions and rates (2024)
    const localTaxConfig: Record<string, { 
      rate: number; 
      type: 'resident' | 'worker' | 'both';
      name: string;
    }> = {
      // New York City (applies to NYC residents only)
      'NYC': { rate: 0.03876, type: 'resident', name: 'New York City' },
      'YONKERS': { rate: 0.01535, type: 'resident', name: 'Yonkers' },
      
      // Pennsylvania localities (Philadelphia, Pittsburgh, etc.)
      'PHL': { rate: 0.03828, type: 'both', name: 'Philadelphia' },
      'PITTSBURGH': { rate: 0.03, type: 'both', name: 'Pittsburgh' },
      'SCRANTON': { rate: 0.024, type: 'both', name: 'Scranton' },
      'ALLENTOWN': { rate: 0.0175, type: 'both', name: 'Allentown' },
      
      // Ohio cities (many have local income tax)
      'CLEVELAND': { rate: 0.025, type: 'worker', name: 'Cleveland' },
      'COLUMBUS': { rate: 0.025, type: 'worker', name: 'Columbus' },
      'CINCINNATI': { rate: 0.0212, type: 'worker', name: 'Cincinnati' },
      'TOLEDO': { rate: 0.0225, type: 'worker', name: 'Toledo' },
      'AKRON': { rate: 0.025, type: 'worker', name: 'Akron' },
      'DAYTON': { rate: 0.025, type: 'worker', name: 'Dayton' },
      
      // Michigan cities
      'DETROIT': { rate: 0.024, type: 'both', name: 'Detroit' },
      'GRAND_RAPIDS': { rate: 0.015, type: 'both', name: 'Grand Rapids' },
      'SAGINAW': { rate: 0.015, type: 'both', name: 'Saginaw' },
      
      // Indiana localities
      'INDIANAPOLIS': { rate: 0.02, type: 'resident', name: 'Indianapolis' },
      'FORT_WAYNE': { rate: 0.0155, type: 'resident', name: 'Fort Wayne' },
      
      // Kentucky cities
      'LOUISVILLE': { rate: 0.0285, type: 'both', name: 'Louisville' },
      'LEXINGTON': { rate: 0.025, type: 'both', name: 'Lexington' },
      
      // Missouri localities
      'STLOUIS': { rate: 0.01, type: 'worker', name: 'St. Louis City' },
      'KANSAS_CITY': { rate: 0.01, type: 'worker', name: 'Kansas City' },
      
      // Alabama localities
      'BIRMINGHAM': { rate: 0.01, type: 'worker', name: 'Birmingham' },
      
      // Maryland localities (county taxes)
      'BALTIMORE_CITY': { rate: 0.032, type: 'resident', name: 'Baltimore City' },
      'MONTGOMERY_CO': { rate: 0.032, type: 'resident', name: 'Montgomery County' },
      
      // Delaware localities
      'WILMINGTON': { rate: 0.0125, type: 'worker', name: 'Wilmington' },
    };
    
    const localityCode = locality.toUpperCase().replace(/\s+/g, '_');
    const config = localTaxConfig[localityCode];
    
    if (!config) {
      return 0; // No local tax for unknown localities
    }
    
    // Apply tax based on type
    const effectiveLocality = workLocation?.toUpperCase().replace(/\s+/g, '_') || residenceLocation?.toUpperCase().replace(/\s+/g, '_') || localityCode;
    
    switch (config.type) {
      case 'resident':
        // Only applies if employee is a resident
        if (residenceLocation?.toUpperCase().replace(/\s+/g, '_') === localityCode) {
          return parseFloat((grossPay * config.rate).toFixed(2));
        }
        return 0;
        
      case 'worker':
        // Applies to anyone working in the locality
        if (workLocation?.toUpperCase().replace(/\s+/g, '_') === localityCode) {
          return parseFloat((grossPay * config.rate).toFixed(2));
        }
        return 0;
        
      case 'both':
        // Applies to both residents and workers
        return parseFloat((grossPay * config.rate).toFixed(2));
        
      default:
        return 0;
    }
  }

  /**
   * Get list of supported local tax jurisdictions
   */
  static getLocalTaxJurisdictions(): Array<{ code: string; name: string; state: string; rate: number }> {
    return [
      { code: 'NYC', name: 'New York City', state: 'NY', rate: 0.03876 },
      { code: 'PHL', name: 'Philadelphia', state: 'PA', rate: 0.03828 },
      { code: 'CLEVELAND', name: 'Cleveland', state: 'OH', rate: 0.025 },
      { code: 'DETROIT', name: 'Detroit', state: 'MI', rate: 0.024 },
      { code: 'LOUISVILLE', name: 'Louisville', state: 'KY', rate: 0.0285 },
      { code: 'COLUMBUS', name: 'Columbus', state: 'OH', rate: 0.025 },
      { code: 'PITTSBURGH', name: 'Pittsburgh', state: 'PA', rate: 0.03 },
      { code: 'STLOUIS', name: 'St. Louis City', state: 'MO', rate: 0.01 },
      { code: 'BALTIMORE_CITY', name: 'Baltimore City', state: 'MD', rate: 0.032 },
      { code: 'WILMINGTON', name: 'Wilmington', state: 'DE', rate: 0.0125 },
    ];
  }

  /**
   * Calculate pre-tax deductions for an employee
   * Includes: 401k, health insurance, HSA, FSA, etc.
   * These reduce taxable income before federal/state/SS/Medicare calculations
   */
  static async getPreTaxDeductions(employeeId: string, payPeriodEnd: Date): Promise<number> {
    // Query payrollDeductions table for active deductions using Drizzle query
    const result = await db.execute(
      sql`SELECT COALESCE(SUM(CAST(amount AS FLOAT)), 0) as total
          FROM payroll_deductions
          WHERE employee_id = ${employeeId}
            AND workspace_id IS NOT NULL
            AND (end_date IS NULL OR end_date >= ${payPeriodEnd})`
    );
    
    const total = parseFloat(result.rows[0]?.total as string || '0');
    return parseFloat(total.toFixed(2));
  }

  /**
   * Calculate currency exchange amount for multi-currency support
   * Supports converting between USD and other currencies
   */
  static convertCurrency(amount: number, fromCurrency: string = 'USD', toCurrency: string = 'USD'): number {
    if (fromCurrency === toCurrency) return amount;
    
    // Simple exchange rates (in production, fetch from external service)
    const exchangeRates: Record<string, number> = {
      'USD': 1.0,
      'EUR': 0.92,
      'GBP': 0.79,
      'CAD': 1.36,
      'AUD': 1.52,
      'JPY': 149.5,
      'INR': 83.12,
    };
    
    const fromRate = exchangeRates[fromCurrency] || 1.0;
    const toRate = exchangeRates[toCurrency] || 1.0;
    
    return parseFloat((amount * (toRate / fromRate)).toFixed(2));
  }

  /**
   * Lookup tax jurisdiction by geographic coordinates
   * Returns state/province for tax calculation purposes
   */
  static getTaxJurisdictionByLocation(latitude: number, longitude: number): string {
    // Simplified mapping - in production use geocoding API
    // For now, return CA as default
    // This would use Google Maps or similar to convert lat/lng to state
    console.log(`[Payroll] Tax jurisdiction lookup for ${latitude}, ${longitude}`);
    return 'CA';
  }
  
  /**
   * Process payroll for a workspace - FULLY AUTOMATED
   */
  static async processAutomatedPayroll(workspaceId: string, userId: string): Promise<{
    payrollRunId: string;
    totalEmployees: number;
    totalGrossPay: number;
    totalNetPay: number;
    calculations: PayrollCalculation[];
    timeEntryIds: string[];
    warnings: string[];
  }> {
    // Get workspace pay schedule
    const workspace = await db.select().from(workspaces).where(eq(workspaces.id, workspaceId)).limit(1);
    const paySchedule = workspace[0]?.payrollSchedule || 'bi-weekly';
    
    // Auto-detect pay period based on workspace schedule
    const payPeriod = this.detectPayPeriod(paySchedule);
    
    // Get all active employees
    const activeEmployees = await db
      .select()
      .from(employees)
      .where(
        and(
          eq(employees.workspaceId, workspaceId),
          eq(employees.isActive, true)
        )
      );
    
    // Use production aggregator for FLSA-compliant payroll calculation
    const aggregationResult = await aggregatePayrollHours({
      workspaceId,
      startDate: payPeriod.start,
      endDate: payPeriod.end,
    });
    
    // Log warnings for human review (surfaced in payroll review dashboard)
    if (aggregationResult.warnings.length > 0) {
      console.warn('[AI Payroll™] Payroll hours aggregation warnings:', aggregationResult.warnings);
    }
    
    // Fail early if no employees to process (prevent empty payroll runs)
    if (aggregationResult.employeeSummaries.length === 0) {
      console.warn('[AI Payroll™] No employees with approved hours for period:', payPeriod);
      throw new Error('No employees with approved time entries found for payroll period');
    }
    
    const calculations: PayrollCalculation[] = [];
    let totalGrossPay = 0;
    let totalNetPay = 0;
    
    // Collect all time entry IDs for marking as payrolled after approval
    const allTimeEntryIds: string[] = [];
    const allWarnings = [...aggregationResult.warnings];
    
    // Get the year from the pay period end date for YTD wage base calculations
    const payrollYear = payPeriod.end.getFullYear();
    
    // Process each employee's payroll summary from aggregator
    for (const employeeSummary of aggregationResult.employeeSummaries) {
      // Use aggregator's FLSA-compliant hour calculations
      const regularHours = employeeSummary.totalRegularHours;
      const overtimeHours = employeeSummary.totalOvertimeHours;
      const holidayHours = employeeSummary.totalHolidayHours;
      
      // Use aggregator's calculated pay amounts (preserves mixed-rate accuracy)
      const grossPay = employeeSummary.grossPay;
      
      // Calculate weighted average hourly rate for display
      // Use equivalent hours for proper weighting (regular + 1.5*OT + 2*holiday)
      const equivalentHours = regularHours + (overtimeHours * 1.5) + (holidayHours * 2.0);
      const hourlyRate = equivalentHours > 0 ? grossPay / equivalentHours : 0;
      
      // Validate rate calculation - warn if grossPay is 0 but hours exist
      if (grossPay === 0 && (regularHours > 0 || overtimeHours > 0 || holidayHours > 0)) {
        const warning = `Employee ${employeeSummary.employeeName} has ${regularHours + overtimeHours + holidayHours} hours but $0 gross pay - missing pay rates`;
        allWarnings.push(warning);
        console.warn(`[AI Payroll™] ${warning}`);
      }
      
      // Fetch YTD wages for Social Security wage base tracking
      const ytdWages = await this.getSocialSecurityYtdWages(employeeSummary.employeeId, payrollYear);
      
      // Log when employee has reached the SS wage base limit
      const SS_WAGE_BASE = 168600;
      if (ytdWages >= SS_WAGE_BASE) {
        console.log(`[AI Payroll™] Employee ${employeeSummary.employeeName} has reached SS wage base limit ($${ytdWages.toFixed(2)} YTD) - no SS withholding`);
      } else if (ytdWages + grossPay > SS_WAGE_BASE) {
        const taxableThisPeriod = SS_WAGE_BASE - ytdWages;
        console.log(`[AI Payroll™] Employee ${employeeSummary.employeeName} will reach SS wage base limit this period - withholding on $${taxableThisPeriod.toFixed(2)} of $${grossPay.toFixed(2)} gross`);
      }
      
      // Fetch employee benefit deductions from database
      const deductions = await this.getEmployeeDeductions(
        employeeSummary.employeeId,
        grossPay,
        payPeriod.type
      );
      
      // Calculate taxable gross (gross - pre-tax deductions)
      const taxableGrossPay = grossPay - deductions.preTax;
      
      // Calculate taxes on taxable gross (after pre-tax deductions)
      const federalTax = this.calculateFederalTax(taxableGrossPay, payPeriod.type);
      const stateTax = this.calculateStateTax(taxableGrossPay);
      const socialSecurity = this.calculateSocialSecurity(taxableGrossPay, ytdWages);
      const medicare = this.calculateMedicare(taxableGrossPay, ytdWages);
      
      // Calculate net pay (gross - all deductions - taxes)
      const totalTaxes = federalTax + stateTax + socialSecurity + medicare;
      const netPay = grossPay - deductions.preTax - totalTaxes - deductions.postTax;
      
      if (deductions.details.length > 0) {
        console.log(`[AI Payroll™] ${employeeSummary.employeeName} deductions: Pre-tax $${deductions.preTax}, Post-tax $${deductions.postTax}`);
      }
      
      calculations.push({
        employeeId: employeeSummary.employeeId,
        employeeName: employeeSummary.employeeName,
        regularHours,
        overtimeHours,
        holidayHours,
        hourlyRate,
        grossPay: parseFloat(grossPay.toFixed(2)),
        preTaxDeductions: deductions.preTax,
        taxableGrossPay: parseFloat(taxableGrossPay.toFixed(2)),
        federalTax,
        stateTax,
        socialSecurity,
        medicare,
        postTaxDeductions: deductions.postTax,
        netPay: parseFloat(netPay.toFixed(2))
      });
      
      totalGrossPay += grossPay;
      totalNetPay += netPay;
      
      // Collect time entry IDs for marking as payrolled
      allTimeEntryIds.push(...employeeSummary.entries.map(e => e.timeEntryId));
    }
    
    // Create payroll run (status: pending for 1% QC)
    const [payrollRun] = await db
      .insert(payrollRuns)
      .values({
        workspaceId,
        periodStart: payPeriod.start,
        periodEnd: payPeriod.end,
        status: 'pending', // Requires 1% human QC approval
        totalGrossPay: totalGrossPay.toFixed(2),
        totalTaxes: (totalGrossPay - totalNetPay).toFixed(2),
        totalNetPay: totalNetPay.toFixed(2),
        processedBy: userId,
        processedAt: new Date()
      })
      .returning();
    
    // Create payroll entries for each employee
    for (const calc of calculations) {
      await db.insert(payrollEntries).values({
        payrollRunId: payrollRun.id,
        employeeId: calc.employeeId,
        workspaceId,
        regularHours: calc.regularHours.toFixed(2),
        overtimeHours: calc.overtimeHours.toFixed(2),
        holidayHours: calc.holidayHours.toFixed(2), // Persist holiday hours for audit trail
        hourlyRate: calc.hourlyRate.toFixed(2),
        grossPay: calc.grossPay.toFixed(2),
        federalTax: calc.federalTax.toFixed(2),
        stateTax: calc.stateTax.toFixed(2),
        socialSecurity: calc.socialSecurity.toFixed(2),
        medicare: calc.medicare.toFixed(2),
        netPay: calc.netPay.toFixed(2)
      });
    }
    
    // Emit payroll completion event to Trinity for platform awareness
    trinityPlatformConnector.emitAutomationEvent('payroll', 'payroll_processed', {
      action: `Payroll processed: ${calculations.length} employees, $${totalGrossPay.toFixed(2)} gross`,
      workspaceId,
      userId,
      success: true,
      data: {
        payrollRunId: payrollRun.id,
        employeeCount: calculations.length,
        totalGrossPay: parseFloat(totalGrossPay.toFixed(2)),
        totalNetPay: parseFloat(totalNetPay.toFixed(2)),
        periodStart: payPeriod.start.toISOString(),
        periodEnd: payPeriod.end.toISOString(),
        warningCount: allWarnings.length,
      },
    }).catch(err => console.error('[AI Payroll™] Failed to emit Trinity event:', err));

    return {
      payrollRunId: payrollRun.id,
      totalEmployees: calculations.length,
      totalGrossPay: parseFloat(totalGrossPay.toFixed(2)),
      totalNetPay: parseFloat(totalNetPay.toFixed(2)),
      calculations,
      timeEntryIds: allTimeEntryIds, // Return for marking as payrolled after approval
      warnings: allWarnings, // Surface warnings to caller
    };
  }
  
  /**
   * Approve payroll run (1% human QC step)
   * Marks time entries as payrolled after approval
   * BACKWARD COMPATIBLE: timeEntryIds optional for existing callers
   */
  static async approvePayrollRun(payrollRunId: string, approverId: string, timeEntryIds?: string[]): Promise<void> {
    await db
      .update(payrollRuns)
      .set({
        status: 'approved',
        processedBy: approverId,
        processedAt: new Date()
      })
      .where(eq(payrollRuns.id, payrollRunId));
    
    // Mark time entries as payrolled after approval (if IDs provided)
    if (timeEntryIds && timeEntryIds.length > 0) {
      await markEntriesAsPayrolled({
        timeEntryIds,
        payrollRunId,
      });
    } else {
      console.warn(`[AI Payroll™] Approved payroll ${payrollRunId} without marking entries - timeEntryIds not provided`);
    }
  }
  
  /**
   * Mark payroll as processed/paid (after direct deposit/ACH)
   */
  static async markPayrollPaid(payrollRunId: string): Promise<void> {
    await db
      .update(payrollRuns)
      .set({
        status: 'paid'
      })
      .where(eq(payrollRuns.id, payrollRunId));
  }
}

// Export convenience functions for use in routes
export const detectPayPeriod = async (workspaceId: string) => {
  const workspace = await db.select().from(workspaces).where(eq(workspaces.id, workspaceId)).limit(1);
  const paySchedule = workspace[0]?.payrollSchedule || 'bi-weekly';
  const period = PayrollAutomationEngine.detectPayPeriod(paySchedule);
  return {
    periodStart: period.start,
    periodEnd: period.end,
    periodType: period.type
  };
};

export const calculatePayroll = (params: {
  timeEntries: TimeEntry[];
  employeeId: string;
  employeeName: string;
  hourlyRate: number;
  taxState: string;
}) => {
  // Legacy function - use processAutomatedPayroll instead
  console.warn('[AI Payroll™] Legacy calculatePayroll called - use processAutomatedPayroll with aggregator instead');
  throw new Error('calculatePayroll is deprecated - use processAutomatedPayroll instead');
};

export const createAutomatedPayrollRun = async (params: {
  workspaceId: string;
  periodStart: Date;
  periodEnd: Date;
  createdBy: string;
}) => {
  // The processAutomatedPayroll already handles creating the run with proper pay period detection
  return await PayrollAutomationEngine.processAutomatedPayroll(
    params.workspaceId,
    params.createdBy
  );
};

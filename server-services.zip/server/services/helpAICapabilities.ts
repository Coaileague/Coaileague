/**
 * HelpAI Capabilities - Dynamic AI-Powered End User Assistance
 * 
 * Uses Trinity AI to help users before escalating to human agents.
 * All actions follow the 7-step orchestration pattern:
 * TRIGGER → FETCH → VALIDATE → PROCESS → MUTATE → CONFIRM → NOTIFY
 */

import { storage } from '../storage';
import { meteredGemini } from './billing/meteredGeminiClient';

/**
 * HelpAI Capability Registry
 * Defines what actions HelpAI can perform to assist end users
 */
export const HELPAI_CAPABILITIES = {
  // READ-ONLY LOOKUPS (Safe for autonomous use)
  lookups: {
    userProfile: {
      name: 'lookup_user_profile',
      description: 'Look up user profile and account status',
      riskLevel: 'low',
      requiresApproval: false,
    },
    scheduleInfo: {
      name: 'lookup_schedule',
      description: 'Check user schedule and upcoming shifts',
      riskLevel: 'low',
      requiresApproval: false,
    },
    timesheetStatus: {
      name: 'lookup_timesheet',
      description: 'Check timesheet and hours worked',
      riskLevel: 'low',
      requiresApproval: false,
    },
    invoiceStatus: {
      name: 'lookup_invoices',
      description: 'Check invoice and billing status',
      riskLevel: 'low',
      requiresApproval: false,
    },
    payrollInfo: {
      name: 'lookup_payroll',
      description: 'Check payroll status and pay history',
      riskLevel: 'low',
      requiresApproval: false,
    },
    ticketHistory: {
      name: 'lookup_tickets',
      description: 'Search past support tickets by user UUID',
      riskLevel: 'low',
      requiresApproval: false,
    },
    chatHistory: {
      name: 'lookup_chat_history',
      description: 'Search past chat messages by user UUID for context',
      riskLevel: 'low',
      requiresApproval: false,
    },
  },

  // GUIDED ACTIONS (Low-risk mutations with confirmation)
  guidedActions: {
    createTicket: {
      name: 'create_support_ticket',
      description: 'Create a support ticket for the user',
      riskLevel: 'low',
      requiresApproval: false,
      sevenStepPattern: true,
    },
    requestCallback: {
      name: 'request_callback',
      description: 'Schedule a callback from support team',
      riskLevel: 'low',
      requiresApproval: false,
    },
    updateContactInfo: {
      name: 'update_contact_info',
      description: 'Help user update their contact information',
      riskLevel: 'medium',
      requiresApproval: true,
    },
  },

  // ESCALATION TRIGGERS (When to hand off to human)
  escalationTriggers: {
    complexIssue: 'Issue requires human judgment or multiple system access',
    sensitiveData: 'Request involves sensitive financial or personal data changes',
    frustrated: 'User sentiment indicates frustration - empathy needed',
    repeatedAttempts: 'User has asked same question 3+ times',
    explicitRequest: 'User explicitly asks to speak with human',
    outOfScope: 'Request is outside HelpAI capabilities',
  },
} as const;

/**
 * HelpAI 7-Step Action Executor
 * All mutations follow: TRIGGER → FETCH → VALIDATE → PROCESS → MUTATE → CONFIRM → NOTIFY
 */
export class HelpAIActionExecutor {
  
  /**
   * Search user's past chat history for context
   * Trinity uses this to understand returning user's previous issues
   */
  async searchUserChatHistory(userId: string, workspaceId?: string): Promise<{
    found: boolean;
    messageCount: number;
    recentTopics: string[];
    lastVisit?: Date;
  }> {
    try {
      // STEP 1: TRIGGER - User requested history lookup
      console.log(`[HelpAI] TRIGGER: Searching chat history for user ${userId}`);
      
      // STEP 2: FETCH - Get messages from database
      const messages = await storage.getChatMessagesByUserId(userId);
      
      if (!messages || messages.length === 0) {
        return { found: false, messageCount: 0, recentTopics: [] };
      }
      
      // STEP 3: VALIDATE - Filter to relevant messages
      const userMessages = messages.filter(m => m.senderId === userId && m.senderType !== 'system');
      
      // STEP 4: PROCESS - Extract topics/themes from messages
      const recentTopics = this.extractTopicsFromMessages(userMessages.slice(-10));
      const lastVisit = userMessages[userMessages.length - 1]?.createdAt;
      
      // STEP 5: MUTATE - No mutation for lookup
      // STEP 6: CONFIRM - Return results
      // STEP 7: NOTIFY - Logged above
      
      return {
        found: true,
        messageCount: userMessages.length,
        recentTopics,
        lastVisit: lastVisit ? new Date(lastVisit) : undefined,
      };
    } catch (error) {
      console.error('[HelpAI] Chat history search failed:', error);
      return { found: false, messageCount: 0, recentTopics: [] };
    }
  }

  /**
   * Extract common topics from messages for context
   */
  private extractTopicsFromMessages(messages: { message: string }[]): string[] {
    const topicKeywords: Record<string, string[]> = {
      'scheduling': ['schedule', 'shift', 'time off', 'availability', 'calendar'],
      'payroll': ['pay', 'payroll', 'salary', 'wages', 'payment'],
      'invoicing': ['invoice', 'bill', 'billing', 'charge', 'receipt'],
      'account': ['account', 'login', 'password', 'profile', 'settings'],
      'employees': ['employee', 'staff', 'team', 'worker', 'hire'],
      'timesheet': ['timesheet', 'hours', 'clock', 'punch', 'overtime'],
      'compliance': ['compliance', 'license', 'certification', 'document'],
    };

    const foundTopics = new Set<string>();
    const allText = messages.map(m => m.message.toLowerCase()).join(' ');

    for (const [topic, keywords] of Object.entries(topicKeywords)) {
      if (keywords.some(kw => allText.includes(kw))) {
        foundTopics.add(topic);
      }
    }

    return Array.from(foundTopics);
  }

  /**
   * Determine if issue should escalate to human agent
   */
  async shouldEscalateToHuman(
    userId: string,
    message: string,
    sentiment: string,
    attemptCount: number
  ): Promise<{ escalate: boolean; reason?: string }> {
    const lowerMsg = message.toLowerCase();

    // Explicit request for human
    if (lowerMsg.includes('human') || lowerMsg.includes('agent') || 
        lowerMsg.includes('real person') || lowerMsg.includes('speak to someone')) {
      return { escalate: true, reason: HELPAI_CAPABILITIES.escalationTriggers.explicitRequest };
    }

    // Frustrated user
    if (sentiment === 'negative' || lowerMsg.includes('frustrated') || 
        lowerMsg.includes('angry') || lowerMsg.includes('not helpful')) {
      return { escalate: true, reason: HELPAI_CAPABILITIES.escalationTriggers.frustrated };
    }

    // Repeated attempts
    if (attemptCount >= 3) {
      return { escalate: true, reason: HELPAI_CAPABILITIES.escalationTriggers.repeatedAttempts };
    }

    // Sensitive operations
    const sensitiveKeywords = ['delete', 'remove', 'cancel subscription', 'refund', 'legal'];
    if (sensitiveKeywords.some(kw => lowerMsg.includes(kw))) {
      return { escalate: true, reason: HELPAI_CAPABILITIES.escalationTriggers.sensitiveData };
    }

    return { escalate: false };
  }

  /**
   * Generate dynamic AI response using Trinity context
   */
  async generateDynamicResponse(
    userId: string,
    workspaceId: string,
    userMessage: string,
    conversationHistory: { role: 'user' | 'assistant'; content: string }[] = []
  ): Promise<{
    message: string;
    action?: string;
    shouldEscalate: boolean;
    escalationReason?: string;
  }> {
    try {
      // Check user's past history for context
      const pastHistory = await this.searchUserChatHistory(userId);
      
      // Build context-aware system prompt
      const contextNote = pastHistory.found 
        ? `\n\nCONTEXT: This user has contacted support ${pastHistory.messageCount} times before. Recent topics: ${pastHistory.recentTopics.join(', ') || 'general inquiries'}. Use this context to provide more personalized help.`
        : '\n\nCONTEXT: This appears to be a new user. Be welcoming and helpful.';

      const systemPrompt = `You are HelpAI, Trinity's intelligent support assistant for CoAIleague workforce management platform.

YOUR CAPABILITIES:
${Object.values(HELPAI_CAPABILITIES.lookups).map(c => `- ${c.description}`).join('\n')}
${Object.values(HELPAI_CAPABILITIES.guidedActions).map(c => `- ${c.description}`).join('\n')}

ESCALATION: If the user's request is beyond your capabilities, politely offer to connect them with a human support agent.

BEHAVIOR:
- Be helpful, professional, and empathetic
- Keep responses concise (2-3 sentences)
- If you can help with a lookup or action, explain what you're doing
- If you need to escalate, explain why and reassure the user
${contextNote}

Remember: You're here to help users quickly and efficiently before they need human assistance.`;

      const result = await meteredGemini.generate({
        workspaceId,
        userId,
        featureKey: 'ai_helpai_dynamic',
        prompt: userMessage,
        systemInstruction: systemPrompt,
        model: 'gemini-2.5-flash',
        temperature: 0.7,
        maxOutputTokens: 200,
      });

      // Check if we should escalate
      const escCheck = await this.shouldEscalateToHuman(
        userId, 
        userMessage, 
        'neutral', // TODO: Add sentiment analysis
        conversationHistory.filter(m => m.role === 'user').length
      );

      return {
        message: result.text || await this.getDynamicFallback(userId),
        shouldEscalate: escCheck.escalate,
        escalationReason: escCheck.reason,
      };
    } catch (error) {
      console.error('[HelpAI] Dynamic response generation failed:', error);
      return {
        message: await this.getDynamicFallback(userId),
        shouldEscalate: false,
      };
    }
  }
  
  /**
   * Get a dynamic fallback message - never hardcoded, always contextual
   */
  private async getDynamicFallback(userId?: string): Promise<string> {
    try {
      const { dynamicMessageService } = await import('./dynamicMessageService');
      return await dynamicMessageService.generateMessage('fallback_help', { userName: userId || 'there' });
    } catch {
      // Even the ultimate fallback should feel natural
      const naturalFallbacks = [
        "Let me look into that for you.",
        "On it. Give me a moment.",
        "Working on this now.",
        "I hear you. Let me check.",
      ];
      return naturalFallbacks[Math.floor(Math.random() * naturalFallbacks.length)];
    }
  }
}

// Singleton instance
export const helpAIExecutor = new HelpAIActionExecutor();

/**
 * Storage extension for HelpAI - get messages by user ID across all conversations
 */
declare module '../storage' {
  interface IStorage {
    getChatMessagesByUserId(userId: string): Promise<{ senderId: string | null; senderType: string; message: string; createdAt: Date }[]>;
  }
}
